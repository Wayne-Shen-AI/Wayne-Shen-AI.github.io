---
name: ggs-sales-crm-tools
description: >
  针对**指定公司/客户**，查询其 CRM 信息与平台数据，并执行 CRM 写操作。

  【触发条件】已明确要找哪家公司/客户，要查询、了解或操作它：
  - **私海列表**："看下我的私海"、"我私海有多少客户"、"我的客户里高意向的"、"我跟进中的客户"
  - **公海/分配池/inbound 列表**：
      - "最近放出来的公海"、"最近一周分配的"
      - "最近 inbound 的"、"my_alibaba 上有活动的"
      - "高意向的有哪些"（按意向等级列表，Global 用 customer_level/sales_degree，HKTW 用 willing_level）
  - **客户基础信息**："xxx 公司在 CRM 里有什么"、"看下 xxx 在 CRM 里的详情"
  - **平台数据**："xxx 在国际站表现怎么样"、"xxx 店铺卖什么"、"xxx 最近询盘成交情况"
  - **客户数据分析**："分析 xxx 4月的数据"、"xxx 这个月表现怎么样"、"给我一份 xxx 的改善建议"（对象是指定公司/客户，不是行业）
  - **拜访/联系人记录**：
      - "上次什么时候联系的 xxx"、"xxx 公司的拜访记录"
      - "xxx 的 KP 是谁"（仅查 CRM 现有联系人）
  - **写 CRM**："释放这个客户"、"捡入"、"新增客户 xx"、"补全联系方式"、"加个标签"、"记一笔拜访"
  - **查重**："这个公司在不在 CRM 里"

  【不触发】
  - "找一批线索"、"找越南家具厂"、"附近 10 公里的工厂"、"展会 leads" → ggs-sales-leads-finder
  - "调研 xxx 公司"、"xxx 公司什么情况"、"扒一下 xxx" → ggs-sales-enrichment
  - "找 xxx 公司的 KP / 邮箱 / 电话"（含外部挖取）→ ggs-sales-enrichment
  - "补全 xxx 这条线索的联系方式"（含外部挖取）→ ggs-sales-enrichment
  - "给这个客户写邮件" → ggs-sales-outreach
  - "这个行业怎么样" / "行业数据" / "最近有什么 RFQ" → ggs-sales-industry-insights
  - "信保规则" → ggs-sales-knowledge-base

  【边界判断】"找 KP / 邮箱"：
  - 看 CRM 已有（查、看、列）→ 本 skill
  - 外部挖取/补全（找、挖、补全）→ ggs-sales-enrichment
  - 不确定时优先 enrichment

  【核心约束】所有写操作执行前必须显式确认（详见 prompt.md `<read_vs_write>`）。
---

# CRM Tools

## 核心准则

1. **只读 vs 写分离**：read 工具可以连续调，write 工具必须按 `prompt.md <read_vs_write>` 走显式确认。
2. **拒绝编造**：API 返回什么就展示什么。返回为空 → 告知用户"暂无记录"，不补猜测。
3. **不脑补**：工具失败/空返回时，告知失败原因，不换工具试三次后给个看起来对的答案。
4. **时间戳程序化转换**：CRM 返回的 10 位 Unix 时间戳必须用 `date -r <ts>` 或 `python3 -c "from datetime import datetime; print(datetime.fromtimestamp(<ts>))"` 转换，**禁止心算**。
5. **Tool Contract 为准**：行为以实际 CLI 参数为准，不假设不存在的能力。
6. **Source Attribution**：所有 CRM 数据按 `prompt.md <source_attribution>` 内部 tag `[CRM: lead_id=xxx]`，空返回 tag `[searched_but_empty]`，呈现时翻译成自然语言（"CRM 里显示..."、"没找到这条记录"）。
7. **PII 原样展示 + 附 detailUrl**：CRM 返回的邮箱、手机号**按返回值原样展示**，不做任何额外打码/脱敏/省略——返回什么展示什么（合规处理由 CRM 服务端负责，不是 agent 的职责）。展示时：
   - **同时附 `detailUrl`**（响应字段），方便用户跳转 CRM 查看完整客户档案
   - 不要自己拼 CRM URL——`detailUrl` 里的 globalId 是加密参数，**只能用 API 返回的 detailUrl**
   - 详细字段定义见 `ggs-crm show-docs crm-search-global-fields` / `crm-search-hktw-fields`

---

## 环境与认证

> 详细流程见 `prompt.md <crm_auth>`。以下为速查。

**⚠️ 路径说明**：`ensure-crm-cli.py` 位于本 skill 的 `scripts/` 目录下：

```bash
python3 scripts/ensure-crm-cli.py
```

**认证方式：**
环境准备：
`python3 scripts/ensure-crm-cli.py` → 安装 CLI，输出 `invoke_prefix`
**自动（默认）**：CLI 从 Accio Work Connector 缓存读取 Token，无需手动操作。

**手动**：当自动认证失败（401 / 未认证）时：
1. **先告知用户**："请在 Accio Work 左侧导航栏点击**插件** → 找到**阿里巴巴销售助手** → 在**应用授权**模块找到**先富港台/ORION CRM**，完成授权（如已授权但 Token 失效，先断开再重新授权；操作后若未生效，请重启 Accio Work）。完成后请回复'已认证'。"，等待用户确认后重试
2. **用户反馈无法操作**时，再执行 `ggs-crm sales-auth`进行 SSO 登录。不要在未告知用户的情况下直接执行 `sales-auth`。

**首次/新会话初始化：**
1`ggs-crm sales-auth` → 获取 Token（自动缓存到 `~/.ggs_sales_auth_cache.json`）
2`ggs-crm crm-roles` → 获取角色列表（单角色直接用，多角色让用户选）
3`ggs-crm config --sales-id X --org-id X --role-id X` → 持久化身份（存 `~/.ggs_crm_identity.json`）

**持久化后**：所有命令的 `--token`、`--sales-id`、`--org-id` 均可省略，CLI 自动读取。

---

## CRM Family 路由

操作前必须确定 CRM Family，因为 Global CRM 和 HKTW CRM 字段定义不同。

判断规则：
1. 用户提及国家 → HK/TW = HKTW，其他 = Global
2. 未提及国家 → 从 `crm-roles` 返回的 orgName/fullPathName 判断
3. 仍无法确定 → 向用户澄清

**关键差异：**
- **Global CRM**：`crm-search` 查询条件中**必须包含 `country` 字段**用于路由
- **HKTW CRM**：搜索范围由 `--org-id` 和 `--sales-id` 自动限定，查询条件中**不需要 `country` 字段**

---

## 调用规则

**入参以 show-docs 为准**——本文档只描述场景和业务规则，不是完整 contract：

```bash
ggs-crm show-docs <tool_name>
```

- `ggs-crm show-docs` — 工具列表索引
- `ggs-crm show-docs <tool-name>` — 单个工具详细文档
- 支持子文档：`crm-visit-ggs-new` / `crm-visit-ggs-revisit` / `crm-visit-hktw-new` / `crm-visit-hktw-revisit` / `crm-search-global-fields` / `crm-search-hktw-fields`

**命令报错时**（unknown field / missing required 等），**第一反应是 show-docs 拿权威 contract**，不要凭错误信息猜测重试。

其他 CLI 命令（google-search、google-map、web-scrape、email-send 等）见 `ggs-crm show-docs`。

---

## CRM Web 补充读取

CLI 是首选——`ggs-crm show-docs` 有对应工具时直接用 CLI。

**CLI 未覆盖时**，通过 Browser Relay 只读以下两个来源：
- **crm.alibaba-inc.com**：客户详情页内的通话明细、线索行为、平台经营数据等 CLI 暂未暴露的内部数据（需登录）
- **alibaba.com**：客户的公开店铺页，在售商品、交易等级、响应率、公司主页等（多数无需登录）

**CRM Web 只读，不通过浏览器提交任何写操作。**

**Browser Relay 操作规范：**
1. 确认 Relay 已连接——未连接提示用户点亮 Chrome 插件栏 Accio 图标；连不上则如实告知无法读取，不编结果。
2. `browser(action='open', targetUrl='https://crm.alibaba-inc.com')` → `snapshot` 定位目标页面，**不硬拼深层 URL**。
3. **未登录**（跳 BUC / 登录页）→ **不代登录**，提示用户自己打开 https://crm.alibaba-inc.com 登录，确认后重试。
4. 读到什么说什么，**不编造**；拿不到则如实告知。

---

# 查询(Read)

read 工具可以在同一意图内连续调用，不需要中间确认（详见 `prompt.md <chained_execution>`）。

## 1. crm-search

查客户列表或单个客户的 CRM 基本属性；**不含**客户在国际站的平台表现数据（询盘/成交/流量等），那些通过 CRM Web 补充读取。

> 入参详见 `ggs-crm show-docs crm-search`；字段白名单见 `ggs-crm show-docs crm-search-global-fields` / `crm-search-hktw-fields`

**Pool 映射：**

| 用户表达 | pool 值 |
|---|---|
| "我的客户"、"私海"、"我在跟的" | `private` |
| "公海"、"公海客户" | `public` |
| "所有客户" | `all` |

**输出规则：**
- 多条匹配 → 展示列表让用户选择，不自动选一条
- 字段缺失 → 如实展示"未录入"，**不编造**
- PII 展示 → 按返回值原样展示，不额外打码 + 同时附 `detailUrl`（按核心准则 7）
- > 10 条时提示翻页（`--start`）或缩小范围
- 时间字段必须程序化转换

---

## 2. crm-visit-query

查指定客户的拜访/跟进/沟通记录，时间倒序；**不含**电话通话明细（§4）和买家平台行为（§5）。

口语"最近怎么跟进的"、"上次沟通说了啥"、"有哪些拜访"全部映射到本工具。

> 入参详见 `ggs-crm show-docs crm-visit-query`

**输出：**
- 按时间倒序展示
- 每条：日期（程序化转换）+ 拜访方式 + 拜访摘要
- 默认展示最近 5 条，提示用户可查看更多
- 不对内容做评价或建议，除非用户明确要求

---

## 3. crm-contact-query

查指定客户在 CRM 里已有的联系人；**不做**外部挖取，需外部找 KP/邮箱走 ggs-sales-enrichment。

> 入参详见 `ggs-crm show-docs crm-contact-query`

**输出：**
- 展示所有联系人：姓名、职位、邮箱、电话
- 缺失字段标"未录入"，不编造
- 邮箱、电话按核心准则 7：按返回值原样展示，不额外打码 + 同时附 `detailUrl`

---

## 4. 通话记录

查电话通话明细；CLI 未覆盖，通过 CRM Web 只读（见「CRM Web 补充读取」节）。

**注意**："跟进/沟通/拜访记录" ≠ 通话记录，前者有 CLI 走 §2，本节只在用户明确要"电话通话明细/录音/呼叫记录"时触发。

---

## 5. 线索行为

查买家在平台上的行为（询盘/访问等）；CLI 未覆盖，通过 CRM Web 只读（见「CRM Web 补充读取」节）。

**注意**：这是买家侧动作，不是销售侧跟进记录，后者走 §2。

---

## 预调用工具（按需缓存）

read 操作中按需调用，会话内缓存复用：

| 工具 | 用途 | 备注 |
|---|---|---|
| `crm-address` | 城市/省份编码映射 | 涉及城市/省份筛选时调用 |
| `crm-tag` | tagId 映射 | 涉及标签筛选时调用 |
| `industry-mapping` | 行业 ID 映射 | **无需 Token**，本地数据 |

---

# 写操作(Write)

**所有写操作执行前必须按 `prompt.md <read_vs_write>` 走显式确认。** 即使前面所有 read 都很顺，write 那一步也要重新等用户点头。

确认时展示：写什么内容、写到哪里（lead_id/字段名）、是否可逆。

## 1. crm-dedup

判断某家公司是否已在 CRM；只判断不录入，crm-add 的强制前置。**只读，无需确认。**

> 入参详见 `ggs-crm show-docs crm-dedup`

**判重状态处理：**

| `deduplicationStatus` | 含义 | 后续 |
|---|---|---|
| `not_repeat` | 不存在 | 可 crm-add |
| `public_repeat` / `channel_repeat` | 公海重复 | 可 crm-pickup |
| `depot_repeat` | 私海重复 | 告知归属销售 |
| `manager_repeat` | 经理库 | 告知需联系经理 |

---

## 2. crm-pickup

把公海客户捡入私海；只捡入不补全信息。

> 入参详见 `ggs-crm show-docs crm-pickup`

**前置工作流：** 如只有公司名 → 先 crm-search --pool public 定位 → 确认 pool=public → 已在私海则告知无需捡入 → 不存在则告知不在公海。

**确认话术：**
> 确认：将 **[公司名]** 从公海捡入你的私海？捡入后归属于你。

**操作后：** 告知成功；如有需补全的信息，提示"是否需要补全该客户的信息？"（crm-refine）。

---

## 3. crm-add

把新公司录入 CRM；必须先过 crm-dedup。

> 入参详见 `ggs-crm show-docs crm-add`

**⚠️ 强制前置：必须先调 `crm-dedup` 查重。** 查重结果为 `not_repeat` 才可继续，其他状态按查重章节处理。

**业务规则（show-docs 没说的）：**
- **国家差异**：Global 与 HKTW 必填字段不同。HKTW 的 `country` 字段传值以 `../ggs-sales-enrichment/references/countries/{tw|hk}.md` Part 3 为准
- **跨工具依赖**：地址字段必须先调 `crm-address` 取编码；行业字段必须先调 `industry-mapping` 取 ID
- **质量标签**：`qualityTags` 是顶层 CLI 参数 `--quality-tags`，不在 `-d` JSON 里

**确认时**列出所有已填字段，缺失必填字段请求补充，**不编造**。

---

## 4. crm-refine

补全/更新已有客户的 CRM 字段；不做外部信息挖取。

> 入参详见 `ggs-crm show-docs crm-refine`

业务规则同 crm-add：地址需 crm-address、行业需 industry-mapping 转码，`qualityTags` 用顶层 `--quality-tags`。

**确认时**列出要补全的字段和值。

---

## 5. crm-contact-add

给已有客户新增联系人；不做外部联系方式挖取。

> 入参详见 `ggs-crm show-docs crm-contact-add`

**联系方式必填差异：**
- **Global CRM**：`email` / `mobilePhone` / `phoneNumber` 三者**至少填一项**
- **HKTW CRM**：`mobilePhone` / `phoneNumber` 二者**至少填一项**——**不支持仅填 email**

**确认时**列出联系人姓名、邮箱、电话。

---

## 6. crm-visit

给指定客户写一条拜访/沟通记录；不可撤销。

口语"加 note 到 X 公司"、"记一笔 X 客户对价格敏感"、"刚跟 X 通完电话，记一下"全部映射到本工具（visitDesc 字段）。

**⚠️ 关键差异：** GGS CRM 与 HKTW CRM、新签客户与服务中客户字段定义不同。**调用前必须先按场景查 show-docs：**

| 场景 | 详细文档命令 | 适用 |
|---|---|---|
| GGS 新签小计 | `ggs-crm show-docs crm-visit-ggs-new` | Global CRM 非服务中 |
| GGS 回访小计 | `ggs-crm show-docs crm-visit-ggs-revisit` | Global CRM 服务中（`out_service = "0"`） |
| HKTW 新签小计 | `ggs-crm show-docs crm-visit-hktw-new` | 港台非服务中 |
| HKTW 回访小计 | `ggs-crm show-docs crm-visit-hktw-revisit` | 港台服务中（`contract_status = "40"`） |

**如何判断"服务中"：**
- **GGS（Global）**：`out_service = "0"` → 服务中 → 用回访小计
- **HKTW（港台）**：`contract_status = "40"` → 服务中 → 用回访小计

**确认话术：**
> 确认：给 **[公司名]** 新增拜访记录？
> - 拜访日期：[转换后的日期]
> - 拜访方式：[visitType 解读]
> - 摘要：[visitDesc]
> - 下一步：[nextSopStatus 解读]

写入后注意：此操作**不可撤销**——记录会留在 CRM 流转历史中。

---

## 7. crm-open

把私海客户释放回公海；不可逆。

> 入参详见 `ggs-crm show-docs crm-open`

**确认话术（强化版）：**
> ⚠️ **确认：将 [公司名] 释放回公海？**
> - **释放后该客户将不再归属于你，其他销售可以捡入。**
> - **此操作不可撤销。**

---

## 8. 标签 / 分组 / 收藏

CLI 待开发，暂不支持，引导用户在 CRM 系统中手动操作。

---

# 术语映射

| 用户表达 | CRM 概念 | 说明 |
|---|---|---|
| 私海 | pool = private | 已分配给销售 |
| 公海 | pool = public | 未分配公共池 |
| KP / 关键人 | 联系人（contacts） | 决策人 |
| 拜访 / 跟进 / 沟通 / 互动 / 单跟 | visit records | 销售侧主动跟进记录 → crm-visit-query（有 CLI） |
| 通话明细 / 通话录音 / 呼叫记录 | 电话系统通话日志 | → §4（CLI 未覆盖，CRM Web 只读），≠ 跟进记录 |
| 线索行为 / 平台动态 / 询盘访问 | 买家侧平台动作 | → §5（CLI 未覆盖，CRM Web 只读），≠ 销售侧跟进 |
| 流转记录 | 客户在销售之间的转移历史 | — |
| inbound | leads_origins 平台行为 | 客户主动进线 |
| 意向等级 | sales_degree | 销售人工打标，B+ 及以上为高意向 |
| 线索等级 | customer_level | 平台计算，4 最高 1 最低 |
| 线索阶段 | sop_status | NEW → QUALIFICATION → ... → IN_SERVICE |

---

# Source Attribution 落地

按 `prompt.md <source_attribution>` 内部 tag，呈现给用户时翻译成自然语言。

**典型映射：**

| 内部 tag | 呈现 |
|---|---|
| `[CRM: lead_id=12345]` | "CRM 里这家公司..." |
| `[CRM: searched, total=0]` | "CRM 里没找到这条记录" |
| `[searched_but_empty: crm-visit-query for gid=xxx]` | "这家客户在 CRM 里还没有拜访记录" |
| `[unverified]` | **不输出**——值为空就标"未录入"，不要编一个 |

**禁止：**
- 不输出方括号标签给用户
- 不编造缺失字段
- 工具失败时直接告知失败原因，不换工具试三次后给个看起来对的答案

---

# 异常处理

| 场景 | 处理 |
|---|---|
| Token 失败 | 引导用户 BUC 登录（详见 `prompt.md <crm_auth>`） |
| crm-roles 返回空 | 提示检查 token，中断 |
| 查询返回 0 条 | "未找到匹配的客户/记录"，可建议放宽条件；**不编造** |
| 查询单家客户返回 0 条 + 用户原意是问 KP/详情/拜访 | 提示"未在 CRM 找到 xxx。如要做外部调研找联系方式/详情，可以说'调研 xxx 公司'（hand-off ggs-sales-enrichment）。" |
| API 超时/报错 | 如实展示错误，建议稍后重试 |
| 客户无法定位 | 请用户提供更多信息（公司名、邮箱、member_id） |
| CRM Family 无法确定 | 询问用户目标国家/地区 |
| 查询字段不在白名单 | 告知该条件暂不支持筛选，建议替代方案 |
| 写操作 API 报错 | 展示错误，**不自动重试**（网络/系统问题）；参数错误可调整后重试 |
| 地址编码转换失败 | 请用户提供更精确的地址 |
| 写操作判重发现已存在 | 告知具体状态，引导正确操作（捡入 vs 联系经理） |
| 响应里有 PII 字段但没 detailUrl | 异常，PII 字段照常原样展示，并告知用户"本次响应没带 CRM 链接，如需查看完整客户档案请直接去 CRM 系统" |
| CRM Web 读取时 Relay 未连接 | 提示用户点亮 Accio 插件；连不上则如实告知无法读取 |
| CRM Web 读取时未登录 | 引导用户自己打开 https://crm.alibaba-inc.com 登录，**不代登录**，登录后重试 |
