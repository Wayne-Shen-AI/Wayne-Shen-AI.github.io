#!/usr/bin/env python3
"""
ensure-crm-cli.py — Deterministic environment prep for ggs-crm-cli.

Replaces the multi-step natural-language instructions in agents.md with a
single script that the Agent runs once per session. The script checks,
installs/upgrades, and validates the CLI tool, then prints a JSON result
the Agent can parse directly.

Usage:
    python3 scripts/ensure-crm-cli.py          # always checks remote for latest version

Output (JSON to stdout):
    {
      "status": "ready" | "installed" | "upgraded" | "failed",
      "version": "0.0.62",
      "invoke_prefix": "python3 -m ggs_crm_cli",
      "action_taken": "already_installed" | "installed" | "upgraded" | "failed",
      "message": "human-readable summary"
    }

Exit codes:
    0  ready (already installed or just installed/upgraded)
    1  failed (Python/pip unavailable, install failed, etc.)
"""

import json
import subprocess
import sys
from pathlib import Path

PACKAGE_NAME = "ggs-crm-cli"
MODULE_NAME = "ggs_crm_cli"
PYPI_INDEX = "https://artlab.alibaba-inc.com/1/pypi/simple"
PYPI_HOST = "artlab.alibaba-inc.com"
EXTRA_INDEX = "https://mirrors.aliyun.com/pypi/simple"
EXTRA_HOST = "mirrors.aliyun.com"

NETWORK_HINT = (
    "无法连接内部 PyPI 源 (artlab.alibaba-inc.com)。"
    "请确认已通过 AliLang 连接阿里内网后重试。"
)


def check_pypi_reachable():
    """Probe internal PyPI host connectivity."""
    code, _, _ = run(f"curl -s --connect-timeout 5 -o /dev/null -w '%{{http_code}}' http://{PYPI_HOST}/", timeout=10)
    return code == 0


def run(cmd, timeout=60):
    """Run a shell command and return (returncode, stdout, stderr)."""
    try:
        result = subprocess.run(
            cmd, shell=True, capture_output=True, text=True, timeout=timeout
        )
        return result.returncode, result.stdout.strip(), result.stderr.strip()
    except subprocess.TimeoutExpired:
        return 1, "", "timeout"
    except Exception as exc:
        return 1, "", str(exc)


def _check_cli_on_path():
    """Check if ggs-crm CLI is available on PATH (e.g. installed by AW via clis.json).

    Returns the version string if found, None otherwise.
    """
    code, stdout, _ = run("ggs-crm --version", timeout=10)
    if code == 0 and stdout:
        parts = stdout.split("version")
        version = parts[-1].strip() if len(parts) >= 2 else stdout.strip()
        return version
    return None


def _is_inside_venv():
    """Check if we are running inside a virtual environment."""
    return (
        hasattr(sys, "real_prefix")  # old-style virtualenv
        or (hasattr(sys, "base_prefix") and sys.base_prefix != sys.prefix)
    )


def _find_system_python():
    """Find the system Python 3 interpreter (outside any venv)."""
    # Common locations on macOS / Linux
    candidates = [
        "/usr/bin/python3",
        "/usr/local/bin/python3",
        "/opt/homebrew/bin/python3",
    ]
    # Also try `which python3` which may resolve to a non-venv python
    code, which_result, _ = run("which -a python3")
    if code == 0 and which_result:
        for line in which_result.split("\n"):
            path = line.strip()
            if path and ".venv" not in path and "virtualenv" not in path:
                candidates.insert(0, path)

    for path in candidates:
        if Path(path).exists():
            # Verify it's not itself inside a venv
            code, stdout, _ = run(
                f'{path} -c "import sys; print(sys.prefix == sys.base_prefix)"'
            )
            if code == 0 and stdout.strip() == "True":
                return path
    return None


def _resolve_target_python():
    """Determine which Python interpreter to use for installation and invocation.

    If running inside a project venv, fall back to system Python because
    ggs-crm-cli is a global CLI tool, not a project dependency.
    Returns the python executable path to use.
    """
    if not _is_inside_venv():
        return sys.executable

    system_python = _find_system_python()
    if system_python:
        print(
            f"Detected venv ({sys.prefix}). Using system Python: {system_python}",
            file=sys.stderr,
        )
        return system_python

    # Can't find system Python, try current interpreter anyway
    print(
        "Warning: inside venv but cannot find system Python, trying current interpreter.",
        file=sys.stderr,
    )
    return sys.executable


# ---------------------------------------------------------------------------
# Resolution priority: AW per-tool venv first, system Python fallback second.
# ---------------------------------------------------------------------------
CLI_VERSION = _check_cli_on_path()
if CLI_VERSION:
    TARGET_PYTHON = None
    INVOKE_PREFIX = "ggs-crm"
else:
    TARGET_PYTHON = _resolve_target_python()
    INVOKE_PREFIX = f"{TARGET_PYTHON} -m {MODULE_NAME}"


def get_installed_version():
    """Check currently installed version via target python -m module."""
    code, stdout, _ = run(f"{TARGET_PYTHON} -m {MODULE_NAME} --version")
    if code == 0 and stdout:
        # Output format: "ggs-crm, version 0.0.62"
        parts = stdout.split("version")
        if len(parts) >= 2:
            return parts[-1].strip()
        return stdout.strip()
    return None


def resolve_pip_command():
    """Find a working pip command that targets the SAME Python as TARGET_PYTHON.

    Priority:
      1. {TARGET_PYTHON} -m pip  (guarantees same environment)
      2. Try to bootstrap pip via ensurepip
      3. Fall back to pip3 ONLY if its site-packages matches TARGET_PYTHON
    Never return a pip that installs into a different Python.
    """
    # Best: pip module within the target interpreter
    candidate = f"{TARGET_PYTHON} -m pip"
    code, _, _ = run(f"{candidate} --version")
    if code == 0:
        return candidate

    # Try to bootstrap pip into the target interpreter
    bootstrap_code, _, _ = run(f"{TARGET_PYTHON} -m ensurepip --upgrade")
    if bootstrap_code == 0:
        code, _, _ = run(f"{candidate} --version")
        if code == 0:
            return candidate

    # Last resort: system pip3, but ONLY if it targets the same Python
    code, stdout, _ = run("pip3 --version")
    if code == 0 and stdout:
        # pip3 output: "pip 24.0 from /path/site-packages/pip (python 3.12)"
        # Verify it points to the same Python by checking the path
        code2, target_lib, _ = run(
            f'{TARGET_PYTHON} -c "import sysconfig; print(sysconfig.get_path(\'purelib\'))"'
        )
        if code2 == 0 and target_lib and target_lib in stdout:
            return "pip3"

    return None


def install_or_upgrade(pip_cmd, action="install"):
    """Install or upgrade the package."""
    flag = "--upgrade" if action == "upgrade" else ""
    code, stdout, stderr = run(
        f"{pip_cmd} install {flag} {PACKAGE_NAME}"
        f" -i {PYPI_INDEX} --trusted-host {PYPI_HOST}"
        f" --extra-index-url {EXTRA_INDEX} --trusted-host {EXTRA_HOST}",
        timeout=120,
    )
    return code == 0, stdout, stderr


def output_result(status, version, action_taken, message):
    """Print JSON result and exit."""
    result = {
        "status": status,
        "version": version or "unknown",
        "invoke_prefix": INVOKE_PREFIX,
        "action_taken": action_taken,
        "message": message,
    }
    print(json.dumps(result, indent=2))
    sys.exit(0 if status in ("ready", "installed", "upgraded") else 1)


def _check_env():
    """Common environment checks. Returns (pip_cmd, installed_version)."""
    # Step 1: Check Python (we're already running in Python, so just log it)
    python_version = f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
    print(f"Python: {sys.executable} ({python_version})", file=sys.stderr)

    # Step 2: Check pip
    pip_cmd = resolve_pip_command()
    if not pip_cmd:
        output_result(
            "failed", None, "failed",
            "pip is not available. Run: python3 -m ensurepip --upgrade"
        )

    print(f"pip: {pip_cmd}", file=sys.stderr)

    # Step 3: Check installed version
    installed_version = get_installed_version()
    print(f"Installed: {installed_version or 'not installed'}", file=sys.stderr)

    return pip_cmd, installed_version


def _try_upgrade(pip_cmd, installed_version, version_cmd=None):
    """Attempt pip upgrade. Returns (changed, final_version)."""
    print("Action: checking for updates...", file=sys.stderr)
    ok, _, stderr = install_or_upgrade(pip_cmd, "upgrade")
    if not ok:
        print(f"Upgrade failed: {stderr}", file=sys.stderr)
        return False, installed_version
    if version_cmd:
        code, stdout, _ = run(version_cmd, timeout=10)
        if code == 0 and stdout:
            parts = stdout.split("version")
            final_version = parts[-1].strip() if len(parts) >= 2 else stdout.strip()
        else:
            final_version = installed_version
    else:
        final_version = get_installed_version() or installed_version
    changed = final_version != installed_version
    if changed:
        print(f"Upgraded: {installed_version} → {final_version}", file=sys.stderr)
    else:
        print(f"Already up-to-date: {final_version}", file=sys.stderr)
    return changed, final_version


def main():
    # ── Primary path: CLI already on PATH (managed by AW plugin via clis.json) ──
    if CLI_VERSION:
        code, cli_path, _ = run("which ggs-crm", timeout=5)
        if code == 0 and cli_path:
            venv_bin = str(Path(cli_path).resolve().parent)
            venv_python = f"{venv_bin}/python3"
            venv_pip = f"{venv_python} -m pip"
            print(f"Python: {venv_python}", file=sys.stderr)
            print(f"pip: {venv_pip}", file=sys.stderr)
            print(f"Installed: {CLI_VERSION}", file=sys.stderr)
            changed, final_version = _try_upgrade(
                venv_pip, CLI_VERSION, "ggs-crm --version")
            if changed:
                output_result("upgraded", final_version, "upgraded",
                              f"ggs-crm-cli {final_version} is ready.")
        output_result("ready", CLI_VERSION, "already_installed",
                      f"ggs-crm-cli {CLI_VERSION} is ready.")

    # ── Legacy fallback: self-install for users without clis.json ──
    pip_cmd, installed_version = _check_env()

    if installed_version is None:
        if not check_pypi_reachable():
            output_result("failed", None, "network_unreachable", NETWORK_HINT)
        print("Action: installing...", file=sys.stderr)
        ok, _, stderr = install_or_upgrade(pip_cmd, "install")
        if not ok:
            hint = f"Install failed: {stderr}"
            if not check_pypi_reachable():
                hint = NETWORK_HINT
            output_result("failed", None, "failed", hint)
        final_version = get_installed_version()
        if final_version:
            print(f"Installed: {final_version}", file=sys.stderr)
            output_result("installed", final_version, "installed",
                          f"ggs-crm-cli {final_version} is ready.")
        else:
            output_result("failed", None, "failed",
                          "Install succeeded but module not loadable.")
    else:
        changed, final_version = _try_upgrade(pip_cmd, installed_version)
        if changed:
            output_result("upgraded", final_version, "upgraded",
                          f"ggs-crm-cli {final_version} is ready.")
        output_result("ready", final_version, "already_installed",
                      f"ggs-crm-cli {final_version} is ready.")


if __name__ == "__main__":
    main()
