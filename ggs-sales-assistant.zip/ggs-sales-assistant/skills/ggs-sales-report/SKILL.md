---
name: ggs-sales-report
description: >
  当销售想给具体客户生成调研报告 / 诊断 deck / 商业提案 / 行业 deck 时使用——产出可直接打开/分享/转 PDF 的 HTML deck。
  覆盖：单家客户深度诊断报告、行业现状分析 deck、客户提案 deck、谈判用商业 deck。
  触发词："给 xx 做一份调研报告"、"生成一个 xx 行业 deck"、"做一份给客户的商业提案"、"拜访前给我准备一份客户报告"。
  数据来自 先富 / Orion CRM + 行业数据。
  不处理：找新潜客（用 ggs-sales-leads-finder）、写触达邮件草稿（用 ggs-sales-outreach）。
metadata:
  version: 1.4.9
---

# Alibaba.com Sales Deck Generator

Generate client-facing proposal decks as **self-contained HTML files**. The deck looks like it was crafted **for this specific client** (visual style, color, layout, imagery — all tailored to the client's industry / country / business type), is backed by real data (CRM + web search, never fabricated), and tells a story that earns the client's trust.

**Output**: a single self-contained HTML file. PDF conversion: open in Chrome / Safari / Edge → File → Print → Save as PDF.

---

## 关键设计原则

**Deck 视觉由 AI 自己创作,不照模板抄**。skill 提供的是:
- ✅ CRM 工具调用规则(AI 不知道字段名 / 参数 / empty 数据处理)
- ✅ 客户阶段心理(awareness / interest / decision)的 storyline
- ✅ 每章 "打动客户原则" 4 段(共情起点 / 数据支撑 / 应避免 / 一句话叙事公式)
- ✅ 本地化词表(TW / VN / KR / IN / HK banned 词)
- ✅ KB 动态发现协议(怎么从 KB 拿国家独有内容)


---

## Runtime prerequisites

- **Python 3.7+** — for `scripts/render-deck.py`(Node ≥ 18 仅 `map-crm-product.js` 需要)
- **`ggs-crm` CLI** — for chapters requiring CRM data
- **A valid sales-domain CRM token**
- **Network access at render time** — for Chart.js CDN + Alibaba product image CDN

### CRM CLI 环境与认证

> ⚠️ 任何 `ggs-crm` 命令调用前，必须先完成环境准备。流程见 `prompt.md <crm_auth>`。
>
> ⚠️ **必须使用绝对路径**（基于 `repo_root_path`）：
> ```bash
> python3 {repo_root_path}/skills/ggs-sales-crm-tools/scripts/ensure-crm-cli.py
> ```
>
> 输出 JSON 中的 `invoke_prefix` 是后续所有 CRM 命令的前缀。`status=failed` 时停止并展示 `message`（通常是需要通过 AliLang 连接内网）。

业务执行中遇到 `unknown command` / `subcommand not found` → 怀疑版本太旧，重跑 `ensure-crm-cli.py --force` 升级后重试。

---

## What this skill provides

| File | What it's for |
|---|---|
| `reference/tone-and-narrative.md` | 默认 14 章弧线 + "打动客户原则" 4 段 + 销售一句话覆盖话术表 |
| `reference/awareness-deck.md` | 认知期 deck 14 章 storyline + 每章心理体感 |
| `reference/interest-deck.md` | 兴趣评估期 deck 6 章 storyline + 每章心理体感 |
| `reference/decision-deck.md` | 决策成交期 deck 6 章 storyline + 每章心理体感 + 对客视角异议预案 |
| `reference/data-and-rules.md` | **CRM 字段定义 + 处理规则 + Locale Vocabulary Guide + QA 自检** — 客观规范,任何 deck 都要参考 |
| `design-tokens.css` | 默认主题。**默认场景(行业不清晰/无特殊视觉诉求)直接 `<link rel="stylesheet" href="design-tokens.css">` 使用**;按客户行业自定义视觉时可不用。 |
| `assets/logos/` | Alibaba logos。**02 章(About Alibaba)的 Trade Assurance / Smart Assistant / Alibaba Guaranteed 三个 brand-mark 必用**(真实品牌资产,禁止用 SVG 自绘顶替);封面/页脚 Alibaba logo 默认使用,销售明确要"白牌/无品牌"才省略。 |
| `assets/photos/` | stock 商务图,可选。AI 倾向自绘 SVG/渐变时可不用。 |

> **资产路径写法(必须遵守)**:deck 源文件里一律写**相对形式** `assets/logos/xxx.png` / `design-tokens.css`——`render-deck.py` 会先按 deck 所在目录、再按 skill 目录解析并内联,**不要写绝对路径,不要拷贝资产到 `<RUN_DIR>`**。
>
> **Logo 渲染防护(必须遵守)**:`assets/logos/` 里各 logo **宽高比差异极大**(方形 mark vs 超宽横条 wordmark)。渲染 logo **禁止只定 `height`**(横条 logo 会宽度失控撑爆卡片/版面),一律写双向限制:`style="max-height:40px;max-width:85%;width:auto;height:auto;object-fit:contain;"`(数值按场景调,模式不变)。
| `scripts/render-deck.py` | 必用。把 deck 源文件打包成 self-contained HTML |
| `scripts/map-crm-product.js` | CRM 产品数据 mapper(确保 `main_img_url` 不丢) |

---

## 视觉品味原则(AI 创作 deck 视觉时遵守)

**deck 不是报告**。每页 30 秒读完,视觉锚点 > 文字段落。

### 1. 视觉风格按客户选,不强制 Alibaba 蓝橙

按客户行业 + 国家选主题色 + 字体 + 整体气质:

| 客户类型 | 视觉方向(参考,不强制) |
|---|---|
| 精密制造 / 电子 / 工业 / 机械 | 深色调 + 金属感 + 衬线字(serif)/ 工业风 |
| 家具 / 食品 / 手工艺 / 木制品 | 暖色 + 米白 + 圆润字 / craft 感 |
| 时尚 / 美妆 / 服装 | 简洁柔色 + 现代无衬线 / minimal 感 |
| 科技 / 数位品牌 / SaaS | 黑白 + 一抹品牌色 / 极简感 |
| 印度 / 中东客户 | 暖色 + 文化纹饰元素 / warm 感 |
| 北美 / 西欧通用 | 中性蓝 + 冷色 / corporate 感 |
| **默认(行业不清晰)** | 现代简洁(白底 + 一抹品牌色)— 可直接用 design-tokens.css 默认 Alibaba 色 |

字体选系统字体或常见 web safe 字体。颜色选 4-6 个,不超过。

### 2. 每页一个核心,不堆叠

每页应该让客户**30 秒内理解核心信息**:

- **大数字 + 一句话** → 数据感
- **大图 + 一行标题** → 视觉感
- **关键词 + 简短列表** → 速读
- **数据可视化(chart / bar / progress)** → 数据感

❌ 一页不要超过 5 个块
❌ 一页不要超过 100 字(除非显式做 ROI 测算章节)
❌ 一页不要超过 1 个主信息(不要塞 SWOT 2×2 4 个 quad — 拆 4 章铺开)

### 3. 图形优先,文字辅助

按优先级用视觉元素:

1. **图形 / 数据可视化**: SVG icon / Chart.js / progress bar / chart / 客户实物图
2. **大数字 / 关键词**: 替代段落叙事
3. **短句**: section title + 一行 caption + AI summary(≤ 100 字)
4. **段落叙事**: 仅在不得不用时(如 brief / quote)

❌ 不要把 narrative 写成 5 段文字 — 拆成关键词 / icon / 短句
❌ 不要在一张卡里堆 "标题 + 段落 + 副段落 + bullet list" — deck 不是报告

### 4. 全 deck 视觉一致性

- 选一套色 / 选一种字 / 选一种间距系统 → 全 deck 14 章统一
- 不同章节可用不同视觉范式,但**视觉语言一致**
- 销售可一句话改主题:"deck 风格做极简一点" / "用深色调" → AI 按要求调整

### 5. SVG / Chart.js / 实物图

- **SVG**: 自由创建图标 / 抽象图形 — AI 可以 inline 写 SVG
- **Chart.js**: 真实数据可视化(CDN 加载)
- **实物图**: 从 `assets/photos/`(stock)或 CRM 返回的产品图拿,**不凭训练记忆补图 URL**
- 需要客户工厂 / 产品实拍而 KB 没有 → **静默**用抽象 SVG / 渐变占位顶替,**不在 deck 里写任何面向销售的批注**(如“建议销售换实拍”)。这类提示写进 `<DECK_BASE>.notes.md` 的"过程备注",不进 HTML

---

## Workflow

> **Resume rule (断点续跑)**: Before Step 1, determine `<RUN_DIR>` from the current task (client/industry + country), then scan **only that `<RUN_DIR>`** for prior outputs matching `deck-*.html`. If one or more exist, list them (newest first) and ask whether to (a) generate a brand-new deck, (b) refresh specific chapters of a chosen existing deck, or (c) re-render a chosen existing deck. **A new run never overwrites an existing deck** — it always writes a new uniquely-named file (see § "输出文件命名与任务隔离"). Reuse cached CRM JSONs **only from the current `<RUN_DIR>`** unless user explicitly says "refresh data" — never read `crm-*.json` from the workspace root or another task's directory (it may belong to a different client).

### Phase 0:storyline 路由

**开始 Workflow 之前先按这个顺序检测**:

#### 1. 销售一句话覆盖(优先级最高)

如果销售 query 包含 storyline / 阶段 / 章节模式 / 客户类型微调 / 内容偏向 / 视觉风格 的覆盖话术(详细识别表见 `reference/tone-and-narrative.md` § "销售一句话覆盖"),**直接走销售指定的路径**,跳过下面的 strategy 检测。

常见覆盖话术:
- 阶段路由:"按 awareness 做" / "按认知期做" / "按 interest 做" / "按 decision 做" / "按 cold 也做 deck"
- 章节模式:"SWOT 用 2×2 别铺开" / "短版 / 10 页内"
- 客户类型微调:"强调工厂角度" / "强调贸易商角度"
- 内容偏向:"客户对 ROI 最敏感,详细测算"
- 视觉风格:"deck 风格做极简一点" / "用深色调工业风" / "客户喜欢简洁,少字多图"

销售加了语气词但没明确话术(如 "简单点" / "短版") → 按 tone-and-narrative.md 映射推断 + 问销售一次确认再执行。

#### 2. strategy 软依赖检测(无销售覆盖时)

检测上下文里是否有 ggs-sales-strategy 的 JSON 输出。

**有 strategy JSON 输出** → 按 `strategy.customer_stage.stage` 路由:

| 客户阶段 | deck 结构 reference |
|---|---|
| `cold` | ⚠️ 不做 deck — 建议销售先用 outreach |
| `awareness` | `reference/awareness-deck.md` |
| `interest_evaluation` | `reference/interest-deck.md` |
| `decision_closing` | `reference/decision-deck.md` |

**cold 阶段强制中断**:
1. 立即中断,不要继续 Workflow Step 1-9
2. 输出提示:"客户当前处于冷启动阶段,直接送 deck 通常没用。建议先切换到 outreach。"
3. 等销售确认 "按 cold 也做 deck" 后,按 awareness-deck.md 精简版生成

**无 strategy JSON 输出** → 默认 14 章弧线(SWOT 4 章拆分 + 三级递降)— 详细定义见 `reference/tone-and-narrative.md` § "Default story arc" 和 `reference/awareness-deck.md`(可作章节心理体感参考)。

无 strategy 时在 Workflow Step 1 之前提示销售一次(只说一次):
> 💡 如果先用 strategy 盘下这家客户的整体打法,这份 deck 会更贴客户视角。当前是基于通用 SWOT 弧线的默认模式。

#### 3. 首次 vs 后续判定(客户级 deck 必做,正交于上面的阶段路由)

无论走哪条弧线,先判定**这是给客户的第一份 deck,还是后续跟进**(依据:query 措辞、CRM 沟通记录、销售上下文):

- **首次接触** → 侧重是 **pitch**:调研客户(见 Step 4 调研模式 A),每个章节的落点都收在"结合你的情况,Alibaba.com 能带给你什么"。
- **后续跟进** → 侧重是**回答顾虑**:客户见过第一版了,这次见面一定有具体的关注点(费用?人手?认证?物流?)。组装逻辑变为 **concern-driven**:
  - **本次重点是必填输入**。query 给了就用;**没给 → Step 1 反问销售一次**:"这次见面的重点是什么 / 客户上次提了哪些顾虑?"——拿不到重点不要按默认弧线硬出,那等于把第一版再讲一遍。
  - **每个重点至少一章直接回答**;与重点无关的默认章节**删掉**——后续 deck 要短、要正面接球。常见映射:
    | 客户顾虑 | 组装的章 |
    |---|---|
    | 费用 / 值不值 | 标杆获客效率 + ROI 测算(decision-deck 机制) |
    | 没人手 / 不会运营 | 平台工具(Smart Assistant / 半托管)+ 同行运营节奏 |
    | 认证 / 市场准入 | 目标市场准入定制章(KB 优先,web 补) |
    | 物流 / 履约 / 品质争议 | Alibaba Guaranteed + Trade Assurance 机制章 |
  - 异议的写法复用 `interest-deck.md`(客户原话开场、案例对号入座)和 `decision-deck.md`(对客视角异议预案)的现成机制,不另起炉灶。
  - 调研也跟着定向(见 Step 4 调研模式 B):围绕顾虑查,不重复首次的全貌调研。

---

### 输出文件命名与任务隔离(防覆盖、防串数据 — 必读)

工作空间可能**跨会话、跨客户共享**。两层防护:

**第一层:任务目录 `<RUN_DIR>` — 防跨客户串数据。**

```
<RUN_DIR> = <WORK_DIR>/ggsr-<task_slug>-<CC>/
```

- `task_slug`:客户公司名 slug(规则同下);行业 deck(无客户名)用行业 slug(如 `fresh-fruit`);都没有时用 CRM `lead_id`。
- **本次运行的所有产物——CRM 留痕 JSON、mapper 产物、deck 源文件、最终 HTML——只写进 `<RUN_DIR>`,绝不落在 `<WORK_DIR>` 根部。**
- **读缓存只允许读当前 `<RUN_DIR>` 内的文件。禁止从 `<WORK_DIR>` 根部或其他任务目录读取任何 `crm-*.json` / `trending.json`**——那些可能是别的客户的数据,静默引用会把 A 客户的数字写进 B 客户的报告,比覆盖更危险。

**第二层:deck 文件名时间戳 — 防同客户多次生成互相覆盖。**

定义本次生成的 `<DECK_BASE>`:

```
deck-<client_slug>-<CC>-<YYYYMMDD-HHMM>
```

- `client_slug`:客户公司名 → 小写、空格与符号转 `-`、去掉非 `a-z0-9-` 字符(如 `Acme Furniture Co.,Ltd` → `acme-furniture-co-ltd`)。无公司名时同 `task_slug`。
- `CC`:客户国家两字码(VN / KR / TW / HK / IN / JP / TR …)。
- `YYYYMMDD-HHMM`:本次生成的本地时间戳,精确到分钟(`date +%Y%m%d-%H%M`)。

由此,本次运行的文件布局:

```
<RUN_DIR>/
├── client-research.md             ← 客户调研留痕(客户级 deck 才有)
├── crm-industry-traffic.json …    ← CRM 原始留痕(任务级缓存,同任务续跑可复用)
├── trending.json                  ← mapper 产物
├── <DECK_BASE>.src.html           ← deck 源文件(AI 撰写)
├── <DECK_BASE>.html               ← 最终交付(render 产物,给客户)
└── <DECK_BASE>.notes.md           ← 讲演稿(给销售,勿发客户)
```

Step 4–8 一律以 `<RUN_DIR>` 为当前目录、以 `<DECK_BASE>` 引用 deck,**不得再出现写死的 `deck.html` / `deck-final.html`,也不得把任何 JSON 写到 `<WORK_DIR>` 根部**。

### Workflow Step 1-9

1. **Clarify with the user** what's needed. Use a **single `ask_user` form**:

   **Required**:
   - Client company name (or CRM `lead_id` / `customer_id`)
   - Client country
   - Industry / main products
   - **后续跟进场景必填**:本次见面的重点 / 客户上次提出的顾虑(query 与 CRM 沟通记录都没有 → 在本表单里反问;首次接触不问此项)

   **Optional**(allow skip):
   - Deck structure preferences / Audience emphasis / Length preference
   - **Visual style preference**(按客户类型选,默认 AI 判断;销售可指定"极简" / "工业风" / "暖色 craft" 等)
   - Optional chapters / Known prior trade-show participation

   If user's opening message supplies enough context, proceed without asking.

   **Optional chapters**(off by default):

   | Chapter | Auto-trigger | Skip rule |
   |---|---|---|
   | Same-Country Supplier Gap | Export-promotion country (VN/ID/IN/TR) AND CRM peer count < 50 | Skip if no CRM data — never reverse-count via web search |
   | Trade Show vs Alibaba.com | User input or CRM tag indicates offline-show participation | Skip if no documented show history |

   **Output language**(deck 用什么语言写):
   - **默认跟 user query 的语言** — 用户用中文问就用中文写,用英文问就用英文写,等等
   - 如果跟 user 的 CRM 销售角色国家冲突(如 user 是 KR 销售但 query 用英文)→ **问 user 一次确认**,不要自己假设
   - **客户国家不同于 user 的语言** — 比如 user 用中文问"给 KR 客户做 deck",deck 默认用中文(跟 user),除非 user 明确说"客户看,用韩文"

   **Content localization**(deck 内容里用什么本地化:banned 词、礼貌用语、案例选哪国):
   - 跟**客户所在国家**走,**不跟 output language 走**
   - 例:user 用中文问,客户是 TW 工厂 → output 用中文,但 deck 里的银词扫描走 TW 繁中表(避免大陆用词)、案例从 TW KB 拿
   - 详细银词扫描见 `reference/data-and-rules.md` § "Locale Vocabulary Guide"

   **Don't proactively ask for any personal information** — including sales rep's name, email, phone, or any other PII. If the user volunteers it, use as given (verbatim, no transform).

2. **Plan the deck**: tell the user what chapters you'll include and what visual style you plan to use. Get confirmation before CRM calls.

3. **Resolve industry to CRM IDs**:
   ```bash
   ggs-crm industry-mapping
   ```
   Takes no arguments, returns full lv1/lv2/lv3 JSON. Semantically match user's free-text industry. Ask user to pick if multiple candidates look plausible.

4. **Gather data**. 客户级 deck 先做**客户调研**(行业 deck 跳过),再进 CRM 取数:

   **调研模式 A(首次接触)— 全貌,喂 pitch**:主营产品/产能、现有出口市场、线上现状(独立站/平台店/社媒)、认证资质、规模信号。来源优先级:销售上下文 > CRM lead 数据 > enrichment(若 `ggs-sales-enrichment` 可用)> 官网/web。**预算上限:web ≤3 次 + enrichment 1 次**,查不到就收。
   **调研模式 B(后续跟进)— 定向,喂顾虑**:只围绕"本次重点"查(认证→目标市场准入,KB 优先;物流→KB 履约方案;费用→CRM 标杆效率数据),公司信息只做增量补充,不重复全貌调研。
   **共同纪律**:查到的事实存 `<RUN_DIR>/client-research.md` 留痕,deck 中客户事实必须可溯源至此;**查不到 ≠ 编**——缺失项让对应表述降级为行业级,禁止脑补客户事实;PII 红线沿用 enrichment 规则(KP 个人联系方式不进 deck 也不进 notes)。

   For each chapter:
   1. Read `<SKILL_DIR>/reference/data-and-rules.md` for that chapter's data source + field meanings + processing rules
   2. Before first call to any `ggs-crm crm-industry-*` tool, run `ggs-crm show-docs <tool-name>` once
   3. Call the tool, save raw response to `<RUN_DIR>/crm-<tool>.json` for traceability
   4. Apply empty-data fallback chain if needed

5. **Compose the deck source** in `<RUN_DIR>`(源文件命名 `<DECK_BASE>.src.html`,见 § “输出文件命名与任务隔离”)— **AI 自己设计视觉**:

   - 决定主题色 / 字体 / 版式(参考"视觉品味原则",按客户类型选)
   - 决定每章用什么视觉范式(大数字 / 大图 / icon 墙 / 时间轴 / Chart.js / SVG 等)
   - 视觉路线二选一:默认场景 `<link>` `design-tokens.css`;按行业自定义则自写 CSS
   - 封面/页脚放 `assets/logos/alibaba-*.png`(默认;销售要白牌才省);02 章三个 brand-mark **必用** `assets/logos/`
   - 决定要不要用 `assets/photos/`(可选)
   - 读对应阶段 `reference/{阶段}-deck.md` 拿章节 storyline + 心理体感
   - 读 `reference/tone-and-narrative.md` 拿 "打动客户原则" 4 段
   - 引入 Chart.js CDN(若用): `<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>`

6. **Compose the speaker notes**(`<DECK_BASE>.notes.md`,与 deck 同目录)— 给销售的讲演稿,**默认生成**(Step 1 表单可加"不要讲稿"退出项):
   - **语言跟销售 query 语言**(同 deck 输出语言规则——两者对象不同:deck 给客户读,notes 给销售读,但都跟 query)。
   - 每页两块,每页 150–250 字、问答 ≤3 条:
     ① **怎么讲**:讲法要点**分行列出**(不写成一段),每页固定收在**价值落点**上——数据 → 对客户的含义 → **平台/销售能提供什么**(如:信任痛点→Trade Assurance;回复速度→AI 工具;关键词→P4P/优化服务;下一步→销售可代办的事)。**只复述数据、没有价值落点的讲法不合格**。落点提及的产品/服务必须真实存在(KB 可查),不编造服务承诺。
     ② **客户可能问 & 怎么答**:口径类(指数是什么/获客成本怎么算)与缺席类(为什么没有某章)。口径警示直接融进答法(如"指数是相对热度,不是访问次数"),不单列。
   - **排版要求**:块与块之间空行;要点用列表分行;引导词加粗。整页堆成一段 = 不合格。
   - 末尾**过程备注**一节:本次跳过的章节及原因、占位图位置(建议换实拍)、数据快照月份——原"只在交付聊天里说"的提示一律落进此文件,聊天里指向它即可。
   - **后续跟进 deck 的讲稿以"回应顾虑"为主线**:每页讲法围绕本次重点展开,价值落点直接对着顾虑给方案;问答区预演客户对该顾虑的追问。
   - notes 是**销售视角**文件,hard rule 4(deck 零过程信息)不约束它;**但它绝不能发给客户**,交付话术必须写明。

7. **Package the deliverable**(输出唯一文件名,见 § “输出文件命名”):
   ```bash
   BASE="deck-<client_slug>-<CC>-$(date +%Y%m%d-%H%M)"
   python3 <SKILL_DIR>/scripts/render-deck.py --input <RUN_DIR>/$BASE.src.html --output <RUN_DIR>/$BASE.html
   ```

8. **QA self-check** — run validation in `<SKILL_DIR>/reference/data-and-rules.md` § "Output Validation":
   - Provenance / Visual integrity / Cross-chapter consistency / Math accuracy / Locale vocabulary / Completeness

9. **Deliver**:

   - 告知 `<DECK_BASE>.html` 的完整路径(含客户名与时间戳),提示:浏览器打开即看,需要 PDF 用 Print → Save as PDF。
   - 同时交付 `<DECK_BASE>.notes.md` 并注明:**讲稿仅供销售内部使用,请勿发给客户**。
   - 不提供公网分享链接;如何分发给客户(邮件附件 / 内部分享通道)由销售自行决定。

---

## CRM Tools

详见 `reference/data-and-rules.md` 各章节 Data source 段。常用工具:

| Purpose | Command |
|---|---|
| Industry hierarchy lookup | `ggs-crm industry-mapping` (no args, no token) |
| Industry success stories | `ggs-crm crm-industry-success-story -t <token> -i <lv1_id> -c <CC>` (lv1 only) |
| Buyer traffic | `ggs-crm crm-industry-traffic -t <token> -i <lv1_id> --industry-lv2-id <lv2_id> [--industry-lv3-id <lv3_id>] -c <CC>` |
| Top buyer countries | `ggs-crm crm-industry-buyer-country ...` (same params) |
| Trending products | `ggs-crm crm-industry-product ...` (same params) — post-process with `scripts/map-crm-product.js` |
| Industry benchmarks | `ggs-crm crm-industry-benchmark ...` (same params) |
| Active buyer RFQs | `ggs-crm crm-rfq-query -t <token> -i <cate_id>` |

### Mandatory CRM behaviors

**Read tool docs before first use**: `ggs-crm show-docs <tool-name>` — authoritative source. No token needed.

**Empty-data fallback** for lv2-capable tools: lv3 fails → drop lv3 keep lv2 → fails → drop lv2 keep lv1 → fails → skip chapter. See `data-and-rules.md` for full table including `unknown command` (= CLI version too old) vs data errors.

**Macroeconomic data**(no CRM tool): web search ITC Trade Map / UN Comtrade / Statista / World Bank / customs / industry associations. Never fabricate.

---

## Hard rules

1. **数据真实可追溯**. 每个数字 / 公司名 / 案例 / 引用 必须可追溯到:CRM tool response / web_search / KB(动态发现协议) / 销售上下文 / 用户输入。**禁止凭训练记忆补**。产品名 / 报价 / 折扣 / 限时:只从 KB 或销售明确指定拿,不编。

2. **客户视角,不平台自夸**. 通篇用"你 / 你的",避免"我们的平台多牛"。客户名拼对,通篇一致。Peer 公司名必须 masking(见 data-and-rules.md Chapter 07)。

3. **输出 self-contained HTML**. 用 `scripts/render-deck.py` 渲染。不引入 weasyprint / puppeteer / playwright / aspose / libreoffice。若用户要 PPT/PDF,告诉他用浏览器 Print → Save as PDF。

4. **Client-facing 成品,零过程信息**. deck 直接给客户看,**禁止**任何面向销售/agent 的过程性或内部性文字:给销售的批注(“建议销售…”)、数据缺失/降级提示(“暂未在 KB 维护”“CRM 返回空”)、工具名 / CLI 命令 / 调用过程、来源溯源方括号 tag(`[internal:]` `[web:]`)、QA 报告、版本号。需要提示销售时写进 `<DECK_BASE>.notes.md`(讲演稿,Step 6),不写进 HTML。数据来源若要给客户看,用客户可读署名(如 “Data source: Alibaba.com Platform Analytics, 2026-05”),不暴露内部工具名

---

## Customization vs. defaults

**The 3 hard rules above never bend**, even if the user asks.

**Everything else bends to user input.** 视觉风格 / 章节顺序 / 章节内容 / 章节数 全可销售一句话覆盖。reference 文件是 starting point,不是 contract。

When user hasn't specified visual style, use your judgment based on client (industry + country + business type). See § "视觉品味原则" above.

---

## Render troubleshooting

| Error | Action |
|---|---|
| `python3: command not found` AND `node: command not found` | Report. Don't install. |
| Render reports "input file not found" | Check path passed via `--input`. |
| Render exits with code 137 (OOM) | 减少单次内联图片数量(分批渲染)后重试。 |
| `ggs-crm: command not found` | Report. Don't install. |
| User asks for PDF | Chrome headless: `/Applications/Google\ Chrome.app/Contents/MacOS/Google\ Chrome --headless --disable-gpu --no-sandbox --print-to-pdf=<OUT> --print-to-pdf-no-header file://<HTML>` |
| User asks to share online | 不提供公网分享;给本地文件,建议邮件附件或公司内部通道分发。 |

For any other error: capture exact error → report → stop. Do not improvise.
