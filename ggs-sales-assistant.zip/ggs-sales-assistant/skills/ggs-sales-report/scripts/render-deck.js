#!/usr/bin/env node
/**
 * render-deck.js — Inline a deck.html into a single self-contained HTML file.
 *
 * What it does:
 *   1. Reads the AI-authored deck.html.
 *   2. Inlines the linked CSS (<link rel="stylesheet" href="design-tokens.css">)
 *      into a <style> block, so the file works even when CSS isn't reachable.
 *   3. Inlines all local images referenced via <img src="assets/..."> as base64
 *      data: URIs, so the file works offline and can be emailed as a single .html.
 *   4. Fetches CRM-returned remote images (e.g. https://sc04.alicdn.com/...) and
 *      inlines them too, so even product thumbnails travel with the file.
 *   5. Writes the result to <input>-inlined.html (or --output FILE).
 *
 * What it does NOT do:
 *   - PDF rendering. PDF conversion is the user's job: open the inlined HTML in
 *     Chrome / Safari / Edge and use File → Print → Save as PDF.
 *   - npm installs, chromium downloads, or any external dependencies.
 *
 * Why HTML-only:
 *   PDF renderers (playwright / wkhtmltopdf / weasyprint) don't install reliably
 *   in low-memory containers (npm install playwright OOMs at ≤ 1 GB). The user's
 *   browser already has a high-quality print-to-PDF — that's a more portable and
 *   higher-quality output than any backend renderer.
 *
 * Usage:
 *   node scripts/render-deck.js --input deck.html [--output deck-final.html]
 *
 *   --input    Path to AI-generated deck.html (with relative paths to design-tokens.css, assets/).
 *   --output   Output file path. Default: <input-basename>-inlined.html in same dir.
 *
 * Exit codes:
 *   0  success
 *   1  runtime error (file IO, etc.)
 *   2  bad input or validation failure
 */

const fs = require('fs');
const path = require('path');

// ─── CLI ──────────────────────────────────────────────────────────────
const argv = process.argv.slice(2);
function getArg(flag, fallback = null) {
  const i = argv.indexOf(flag);
  if (i >= 0 && i + 1 < argv.length) return argv[i + 1];
  return fallback;
}

const inputPath = getArg('--input');
let outputPath = getArg('--output');

if (!inputPath) {
  console.error('Usage: node scripts/render-deck.js --input deck.html [--output FILE]');
  process.exit(2);
}
if (!fs.existsSync(inputPath)) {
  console.error(`ERROR: input file not found: ${inputPath}`);
  process.exit(2);
}

const inputAbs = path.resolve(inputPath);
const inputDir = path.dirname(inputAbs);
const inputBase = path.basename(inputPath, path.extname(inputPath));

if (!outputPath) {
  outputPath = path.join(inputDir, `${inputBase}-inlined.html`);
}
const outputAbs = path.resolve(outputPath);

// ─── Validation ───────────────────────────────────────────────────────
function validateHtml(html) {
  const issues = [];

  const sectionMatches = html.match(/<section\s+[^>]*class="[^"]*\breport-section\b[^"]*"/g) || [];
  if (sectionMatches.length === 0) {
    issues.push({ severity: 'fatal', msg: 'deck.html contains no <section class="report-section"> blocks' });
  } else {
    console.log(`  Detected ${sectionMatches.length} report section(s)`);
  }

  const reportWrapper = html.match(/<div\s+[^>]*class="[^"]*\breport\b[^"]*"/);
  if (!reportWrapper) {
    issues.push({ severity: 'warn', msg: 'deck.html missing <div class="report"> wrapper — section content may run full-page width' });
  }

  // Forbidden alternative renderers
  if (/python-pptx|aspose|libreoffice|apache poi|weasyprint|wkhtmltopdf/i.test(html)) {
    issues.push({ severity: 'fatal', msg: 'deck.html mentions an alternative PDF/PPT library — forbidden, see SKILL.md hard rule 4' });
  }

  // Warn on absolute paths or parent traversal in CSS / image refs
  const badPaths = [];
  const linkRe = /<link[^>]+href="([^"]+)"/g;
  const imgRe = /<img[^>]+src="([^"]+)"/g;
  let m;
  while ((m = linkRe.exec(html)) !== null) {
    const p = m[1];
    if (p.startsWith('http') || p.startsWith('data:')) continue;
    if (p.startsWith('/') || p.startsWith('../') || p.startsWith('./')) badPaths.push(p);
  }
  while ((m = imgRe.exec(html)) !== null) {
    const p = m[1];
    if (p.startsWith('http') || p.startsWith('data:')) continue;
    if (p.startsWith('/') || p.startsWith('../') || p.startsWith('./')) badPaths.push(p);
  }
  if (badPaths.length > 0) {
    issues.push({
      severity: 'warn',
      msg: `Found ${badPaths.length} non-root-relative path(s): ${badPaths.slice(0, 3).join(', ')}${badPaths.length > 3 ? '…' : ''}`,
    });
    issues.push({
      severity: 'warn',
      msg: 'Paths starting with /, ./, or ../ may not inline correctly. Use "assets/..." and "design-tokens.css".',
    });
  }

  return issues;
}

// ─── Inlining ─────────────────────────────────────────────────────────

function inlineCss(html, baseDir) {
  return html.replace(
    /<link\s+([^>]*?)rel="stylesheet"([^>]*?)\/?>(?!\s*<\/link>)/gi,
    (match, before, after) => {
      const fullAttrs = before + ' ' + after;
      const hrefMatch = fullAttrs.match(/href="([^"]+)"/);
      if (!hrefMatch) return match;
      const href = hrefMatch[1];
      if (href.startsWith('http://') || href.startsWith('https://') || href.startsWith('//')) {
        // Remote stylesheet — leave as-is (browser will fetch when opened)
        return match;
      }
      const cssPath = path.resolve(baseDir, href);
      if (!fs.existsSync(cssPath)) {
        console.warn(`  ⚠ CSS file not found, leaving link as-is: ${href}`);
        return match;
      }
      const css = fs.readFileSync(cssPath, 'utf8');
      console.log(`  Inlined CSS: ${href} (${(css.length / 1024).toFixed(1)} KB)`);
      return `<style>\n/* inlined from ${href} */\n${css}\n</style>`;
    }
  );
}

function inlineCssUrls(css, baseDir) {
  return css.replace(
    /url\(\s*["']?([^"')]+)["']?\s*\)/gi,
    (match, url) => {
      if (url.startsWith('http://') || url.startsWith('https://') || url.startsWith('//') || url.startsWith('data:')) {
        return match;
      }
      const filePath = path.resolve(baseDir, url);
      if (!fs.existsSync(filePath)) return match;
      const ext = path.extname(filePath).slice(1).toLowerCase();
      const mime = ext === 'svg' ? 'image/svg+xml'
        : ext === 'jpg' || ext === 'jpeg' ? 'image/jpeg'
        : ext === 'png' ? 'image/png'
        : 'application/octet-stream';
      const b64 = fs.readFileSync(filePath).toString('base64');
      return `url("data:${mime};base64,${b64}")`;
    }
  );
}

async function inlineImages(html, baseDir) {
  let localCount = 0, localBytes = 0;
  let remoteCount = 0, remoteBytes = 0, remoteFailed = 0;

  // Collect all <img src="..."> matches
  const matches = [];
  const re = /<img([^>]*?)src="([^"]+)"([^>]*?)>/gi;
  let m;
  while ((m = re.exec(html)) !== null) {
    matches.push({ full: m[0], before: m[1], src: m[2], after: m[3] });
  }

  // Build replacements (local synchronous, remote async)
  const replacements = await Promise.all(matches.map(async ({ full, before, src, after }) => {
    if (src.startsWith('data:')) {
      return { full, replacement: full }; // already inlined
    }

    const isRemote = src.startsWith('http://') || src.startsWith('https://') || src.startsWith('//');

    if (isRemote) {
      try {
        const url = src.startsWith('//') ? 'https:' + src : src;
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 10000);
        const response = await fetch(url, { signal: controller.signal });
        clearTimeout(timeout);
        if (!response.ok) {
          console.warn(`  ⚠ Remote image fetch failed (${response.status}): ${src.substring(0, 60)}…`);
          remoteFailed++;
          return { full, replacement: full };
        }
        const buf = Buffer.from(await response.arrayBuffer());
        const ct = response.headers.get('content-type') || 'image/jpeg';
        const mime = ct.split(';')[0].trim();
        const b64 = buf.toString('base64');
        remoteCount++;
        remoteBytes += buf.length;
        return { full, replacement: `<img${before}src="data:${mime};base64,${b64}"${after}>` };
      } catch (err) {
        console.warn(`  ⚠ Remote image fetch error: ${src.substring(0, 60)}… (${err.message})`);
        remoteFailed++;
        return { full, replacement: full };
      }
    }

    // Local image
    const imgPath = path.resolve(baseDir, src);
    if (!fs.existsSync(imgPath)) {
      console.warn(`  ⚠ Image not found, leaving as-is: ${src}`);
      return { full, replacement: full };
    }
    const ext = path.extname(imgPath).slice(1).toLowerCase();
    const mime = ext === 'svg' ? 'image/svg+xml'
      : ext === 'jpg' || ext === 'jpeg' ? 'image/jpeg'
      : ext === 'png' ? 'image/png'
      : ext === 'webp' ? 'image/webp'
      : ext === 'gif' ? 'image/gif'
      : 'application/octet-stream';
    const buf = fs.readFileSync(imgPath);
    const b64 = buf.toString('base64');
    localCount++;
    localBytes += buf.length;
    return { full, replacement: `<img${before}src="data:${mime};base64,${b64}"${after}>` };
  }));

  // Apply replacements (each `full` string is unique enough that simple replace is safe)
  let result = html;
  for (const { full, replacement } of replacements) {
    if (full !== replacement) {
      result = result.replace(full, replacement);
    }
  }

  if (localCount > 0) {
    console.log(`  Inlined ${localCount} local image(s), ${(localBytes / 1024 / 1024).toFixed(2)} MB`);
  }
  if (remoteCount > 0) {
    console.log(`  Fetched + inlined ${remoteCount} remote image(s), ${(remoteBytes / 1024 / 1024).toFixed(2)} MB`);
  }
  if (remoteFailed > 0) {
    console.log(`  ⚠ ${remoteFailed} remote image(s) failed to fetch — left as URL (will load when online)`);
  }
  return result;
}

// ─── Main ─────────────────────────────────────────────────────────────
(async () => {
  console.log('\n═══════════════════════════════════════════════════════════════');
  console.log('GGS Deck Renderer (HTML-only)');
  console.log('═══════════════════════════════════════════════════════════════');
  console.log(`  Input:  ${inputPath}`);
  console.log(`  Output: ${outputPath}`);
  console.log('───────────────────────────────────────────────────────────────\n');

  const rawHtml = fs.readFileSync(inputAbs, 'utf8');
  const issues = validateHtml(rawHtml);

  let hasFatal = false;
  for (const issue of issues) {
    const tag = issue.severity === 'fatal' ? '❌' : '⚠';
    console.log(`  ${tag} ${issue.msg}`);
    if (issue.severity === 'fatal') hasFatal = true;
  }
  if (hasFatal) {
    console.error('\nFatal validation errors. Aborting.');
    process.exit(2);
  }

  console.log('\n  Inlining assets…');
  let inlined = inlineCss(rawHtml, inputDir);
  inlined = inlined.replace(/<style>([\s\S]*?)<\/style>/gi, (_m, css) => {
    return `<style>${inlineCssUrls(css, inputDir)}</style>`;
  });
  inlined = await inlineImages(inlined, inputDir);

  console.log(`  Final size: ${(inlined.length / 1024 / 1024).toFixed(2)} MB`);

  fs.writeFileSync(outputAbs, inlined, 'utf8');
  console.log(`\n✅ Self-contained HTML saved: ${outputAbs}`);
  console.log('\n   To convert to PDF: open in Chrome / Safari / Edge,');
  console.log('   then File → Print → Save as PDF (landscape, no margins).');
})().catch(err => {
  console.error(`\nERROR: ${err.message}`);
  if (err.stack) console.error(err.stack);
  process.exit(1);
});
