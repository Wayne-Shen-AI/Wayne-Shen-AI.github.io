#!/usr/bin/env node
/**
 * map-crm-product.js — Deterministic mapper: CRM crm-industry-product → trending_products_data
 *
 * Purpose:
 * Map the CRM response into the deck's `trending_products_data` schema in one
 * deterministic pass. The `main_img_url` field must survive the mapping
 * (it powers product thumbnails in the deck); doing this in code rather
 * than free-form prompting guarantees the field is preserved.
 *
 * Usage:
 *   node scripts/map-crm-product.js --input crm-product-raw.json --output trending.json
 *
 * Input: raw stdout JSON from `ggs-crm crm-industry-product ...`
 * Output: a JSON object you can splice into report-data.json under
 *         `trending_products_data`.
 *
 * Mapping rules (validated against live responses, 2026-05, TW Cycling + VN Fresh Fruit):
 *   data.values.highDemandProducts[] -> high_demand.items[]   (signal: high_demand_visitor_cnt)
 *   data.values.highGrowthProducts[] -> high_growth.items[]   (signal: high_growth_received_gmv, USD)
 *   data.values.topSearchProducts[]  -> hot_categories.items[] (signal: idx_12m_imps_cnt_30d + top3_hot_kw)
 *
 * Item field mapping (ONLY fields the CRM actually returns):
 *   prod_name                 -> name (sanitized: contact tails stripped, promo lead trimmed)
 *   main_img_url              -> image            ← preserved verbatim; may be absent for a whole category
 *   top3_hot_kw               -> keywords[]       (pipe-split)
 *   idx_12m_imps_cnt_30d      -> imps_idx
 *   high_growth_received_gmv  -> gmv + gmv_display (USD)
 *   high_demand_visitor_cnt   -> demand_cnt
 *
 * Note — these fields DO NOT exist in the response (do not reference): category/leaf_category_name,
 *   demand_idx, supply_idx, opportunity_index, search_idx, click_idx, ctr, yoy.
 * Zero-signal rows are dropped; rows whose name hints juice/frozen/powder are flagged _bleed
 * for the agent to review (origin/processed-form bleed is prospect-specific).
 */

const fs = require('fs');

const argv = process.argv.slice(2);
function getArg(flag, fallback = null) {
  const i = argv.indexOf(flag);
  if (i >= 0 && i + 1 < argv.length) return argv[i + 1];
  return fallback;
}

const inputPath = getArg('--input');
const outputPath = getArg('--output');
const country = getArg('--country', '');

if (!inputPath || !outputPath) {
  console.error('Usage: node scripts/map-crm-product.js --input <crm-raw.json> --output <trending.json> [--country VN]');
  process.exit(2);
}

// CRM CLI sometimes prepends a Python warning line before the JSON body.
// Strip everything before the first '{' to make parsing robust.
let rawText = fs.readFileSync(inputPath, 'utf8');
const firstBrace = rawText.indexOf('{');
if (firstBrace > 0) rawText = rawText.slice(firstBrace);
const raw = JSON.parse(rawText);
if (!raw || !raw.success || !raw.data || !raw.data.values) {
  console.error('ERROR: input does not look like a crm-industry-product response (missing data.values)');
  process.exit(1);
}

const v = raw.data.values;

// --- helpers ---------------------------------------------------------------
function num(x) {
  const f = parseFloat(x);
  return isNaN(f) ? null : f;
}
function isZeroOrEmpty(x) {
  const f = num(x);
  return f === null || f === 0;
}
// Strip trailing seller contact strings + leading promo shouting.
// We only trim contact tails / promo lead — the core product description is kept.
function sanitizeName(name) {
  if (!name) return '';
  let s = String(name).trim();
  // remove WhatsApp / phone tails. Handle underscore-glued forms like "_WA84972678053"
  // (no word boundary after "_"), spaced forms "W/A: 0084...", and labelled tels.
  s = s.replace(/[\s_|,-]*_?W\s*\/?\s*A\s*[:#]?\s*\+?\d[\d\s().-]{5,}/gi, '');   // _WA84.., W/A: 0084..
  s = s.replace(/[\s_|,-]*\b(?:WHATSAPP|TEL|PHONE|MOB(?:ILE)?)\b\s*[:#]?\s*\+?\d[\d\s().-]{5,}/gi, '');
  s = s.replace(/[\s_|,-]*\+?\b00\d{8,}\b\s*$/g, '');     // trailing 0084909740687 etc.
  s = s.replace(/[\s_|,-]*\+\d{8,}\b\s*$/g, '');          // trailing +84...
  // demote leading promo shouting
  s = s.replace(/^\s*(CHEAP(?:\s+PRICE)?|BEST\s+SELLER|FLASH\s+SALE|HOT\s+SALE|FREE\s+SAMPLE|TOP\s+DEAL|TOP\s+RATED|WHOLESALE)\b[\s,:-]*/i, '');
  return s.replace(/\s{2,}/g, ' ').trim();
}
// Foreign-origin / processed-form bleed often leaks into a "fresh" lv2.
// We don't hard-drop here (origin policy is prospect-specific) but flag for the agent.
function bleedFlag(name) {
  return /\b(juice|drink|sparkling|carbonated|beverage|powder|IQF|frozen)\b/i.test(name || '');
}

function mapDemand(p, idx) {
  return {
    rank: idx + 1,
    name: sanitizeName(p.prod_name),
    image: p.main_img_url || '',
    demand_cnt: num(p.high_demand_visitor_cnt),
    _bleed: bleedFlag(p.prod_name),     // agent should review/drop if off-category
  };
}
function mapGrowth(p, idx) {
  const gmv = num(p.high_growth_received_gmv);
  return {
    rank: idx + 1,
    name: sanitizeName(p.prod_name),
    image: p.main_img_url || '',
    gmv,                                 // USD, already converted upstream
    gmv_display: gmv === null ? '' : gmv >= 1000 ? `~${Math.round(gmv / 1000)}K` : `~$${Math.round(gmv)}`,
    _bleed: bleedFlag(p.prod_name),
  };
}
function mapHotCategory(p, idx) {
  const imps = num(p.idx_12m_imps_cnt_30d);
  return {
    rank: idx + 1,
    name: sanitizeName(p.prod_name),
    keywords: (p.top3_hot_kw || '').split('|').map((k) => k.trim()).filter(Boolean),
    image: p.main_img_url || '',
    imps_idx: imps === null ? null : Math.round(imps),
    _bleed: bleedFlag(p.prod_name),
  };
}

const out = { trending_products_data: {} };
const tpd = out.trending_products_data;

if (Array.isArray(v.highDemandProducts)) {
  const items = v.highDemandProducts
    .filter((p) => !isZeroOrEmpty(p.high_demand_visitor_cnt))   // drop 0-signal rows
    .sort((a, b) => num(b.high_demand_visitor_cnt) - num(a.high_demand_visitor_cnt))
    .slice(0, 10)
    .map(mapDemand);
  if (items.length > 0) {
    tpd.high_demand = {
      has_images: items.some((it) => it.image),
      items,
      data_source: `Data source: Alibaba.com Platform Analytics${country ? ' — ' + country : ''}`,
      data_note: 'Top high-demand products in the target market.',
      ai_summary: '',
    };
  }
}

if (Array.isArray(v.highGrowthProducts)) {
  const items = v.highGrowthProducts
    .filter((p) => !isZeroOrEmpty(p.high_growth_received_gmv))   // drop 0-GMV rows
    .sort((a, b) => num(b.high_growth_received_gmv) - num(a.high_growth_received_gmv))
    .slice(0, 10)
    .map(mapGrowth);
  if (items.length > 0) {
    tpd.high_growth = {
      has_images: items.some((it) => it.image),
      items,
      data_source: `Data source: Alibaba.com Platform Analytics${country ? ' — ' + country : ''}`,
      data_note: 'Fastest-growing products by received GMV.',
      ai_summary: '',
    };
  }
}

if (Array.isArray(v.topSearchProducts)) {
  const items = v.topSearchProducts
    .filter((p) => !isZeroOrEmpty(p.idx_12m_imps_cnt_30d))      // drop 0-impression rows
    .sort((a, b) => num(b.idx_12m_imps_cnt_30d) - num(a.idx_12m_imps_cnt_30d))
    .slice(0, 10)
    .map(mapHotCategory);
  if (items.length > 0) {
    tpd.hot_categories = {
      has_images: items.some((it) => it.image),
      items,
      data_source: `Data source: Alibaba.com Platform Analytics${country ? ' — ' + country : ''}`,
      data_note: 'Top searched products in the target market.',
      ai_summary: '',
    };
  }
}

// Sanity report
const summary = [];
['high_demand', 'high_growth', 'hot_categories'].forEach((k) => {
  if (tpd[k]) {
    const total = tpd[k].items.length;
    const withImg = tpd[k].items.filter((it) => it.image).length;
    summary.push(`${k}: ${total} items, ${withImg} with image`);
  }
});

fs.writeFileSync(outputPath, JSON.stringify(out, null, 2));
console.log(`✅ Wrote ${outputPath}`);
summary.forEach((s) => console.log(`   • ${s}`));
if (summary.length === 0) {
  console.log('   ⚠ No products mapped — input had no recognized arrays.');
}
console.log('');
console.log('NEXT: remember to fill in `ai_summary` for each sub-object before building.');
