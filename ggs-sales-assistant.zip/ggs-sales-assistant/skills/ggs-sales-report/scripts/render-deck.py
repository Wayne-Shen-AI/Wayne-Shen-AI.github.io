#!/usr/bin/env python3
"""
render-deck.py — Inline a deck.html into a single self-contained HTML file.

Single render implementation. Uses standard library only (no pip
install). Produces lower memory pressure than the Node version, which
matters in low-memory containers.

Behavior:
  1. Reads the AI-authored deck.html.
  2. Inlines linked CSS into a <style> block.
  3. Inlines all local <img src="assets/..."> as base64 data: URIs.
  4. Fetches remote <img src="https://..."> and inlines them (10s timeout).
     If a remote fetch fails, the URL is left in place.
  5. Writes the result to <input>-inlined.html (or --output FILE).

Does NOT generate PDF. PDF conversion is the user's job: open the inlined
HTML in Chrome / Safari / Edge → File → Print → Save as PDF.

Usage:
  python3 scripts/render-deck.py --input deck.html [--output deck-final.html]

Exit codes:
  0  success
  1  runtime error (file IO, etc.)
  2  bad input or validation failure
"""

import argparse
import base64
import os
import re
import sys
import urllib.request
import urllib.error
from pathlib import Path


# ─── CLI ──────────────────────────────────────────────────────────────
def parse_args():
    parser = argparse.ArgumentParser(
        description="Inline a deck.html into a single self-contained HTML file.",
        add_help=True,
    )
    parser.add_argument("--input", required=True, help="Path to deck.html")
    parser.add_argument(
        "--output",
        default=None,
        help="Output path (default: <input>-inlined.html)",
    )
    return parser.parse_args()


# ─── Validation ───────────────────────────────────────────────────────
def validate_html(html: str):
    """Return list of (severity, message) tuples."""
    issues = []

    # Must contain at least one <section class="...report-section...">
    section_pattern = re.compile(
        r'<section\s+[^>]*class="[^"]*\breport-section\b[^"]*"', re.IGNORECASE
    )
    sections = section_pattern.findall(html)
    if not sections:
        issues.append(("fatal", 'deck.html contains no <section class="report-section"> blocks'))
    else:
        print(f"  Detected {len(sections)} report section(s)")

    # Should contain a <div class="...report...">
    report_wrapper = re.search(
        r'<div\s+[^>]*class="[^"]*\breport\b[^"]*"', html, re.IGNORECASE
    )
    if not report_wrapper:
        issues.append((
            "warn",
            'deck.html missing <div class="report"> wrapper — section content may run full-page width',
        ))

    # Forbidden alternative renderers
    if re.search(
        r"python-pptx|aspose|libreoffice|apache poi|weasyprint|wkhtmltopdf",
        html,
        re.IGNORECASE,
    ):
        issues.append((
            "fatal",
            "deck.html mentions an alternative PDF/PPT library — forbidden, see SKILL.md hard rule 4",
        ))

    # Warn on absolute paths or parent traversal
    bad_paths = []
    for ref in re.finditer(r'<link[^>]+href="([^"]+)"', html):
        p = ref.group(1)
        if p.startswith(("http", "data:")):
            continue
        if p.startswith(("/", "../", "./")):
            bad_paths.append(p)
    for ref in re.finditer(r'<img[^>]+src="([^"]+)"', html):
        p = ref.group(1)
        if p.startswith(("http", "data:")):
            continue
        if p.startswith(("/", "../", "./")):
            bad_paths.append(p)
    if bad_paths:
        sample = ", ".join(bad_paths[:3]) + ("…" if len(bad_paths) > 3 else "")
        issues.append((
            "warn",
            f"Found {len(bad_paths)} non-root-relative path(s): {sample}",
        ))
        issues.append((
            "warn",
            'Paths starting with /, ./, or ../ may not inline correctly. Use "assets/..." and "design-tokens.css".',
        ))

    return issues


# ─── Inlining helpers ─────────────────────────────────────────────────
EXT_MIME = {
    "svg": "image/svg+xml",
    "jpg": "image/jpeg",
    "jpeg": "image/jpeg",
    "png": "image/png",
    "webp": "image/webp",
    "gif": "image/gif",
}


def mime_for(ext: str) -> str:
    return EXT_MIME.get(ext.lower(), "application/octet-stream")


def inline_css_in_html(html: str, base_dir: Path) -> str:
    """Replace <link rel="stylesheet" href="..."> with inline <style>."""

    def replace(match):
        full = match.group(0)
        href_match = re.search(r'href="([^"]+)"', full)
        if not href_match:
            return full
        href = href_match.group(1)
        if href.startswith(("http://", "https://", "//")):
            return full
        css_path = (base_dir / href).resolve()
        if not css_path.is_file():
            skill_root = Path(__file__).resolve().parent.parent
            fallback = (skill_root / href).resolve()
            if fallback.is_file():
                css_path = fallback
            else:
                print(f"  ⚠ CSS file not found (tried deck dir and skill dir), leaving link as-is: {href}")
                return full
        css = css_path.read_text(encoding="utf-8")
        print(f"  Inlined CSS: {href} ({len(css) / 1024:.1f} KB)")
        return f"<style>\n/* inlined from {href} */\n{css}\n</style>"

    pattern = re.compile(
        r'<link\s+[^>]*rel="stylesheet"[^>]*/?>(?!\s*</link>)',
        re.IGNORECASE,
    )
    return pattern.sub(replace, html)


def inline_css_urls(css: str, base_dir: Path) -> str:
    """Replace url(...) refs in CSS with base64 data: URIs (for local assets only)."""

    def replace(match):
        full = match.group(0)
        url = match.group(1).strip("\"'")
        if url.startswith(("http://", "https://", "//", "data:")):
            return full
        file_path = (base_dir / url).resolve()
        if not file_path.is_file():
            return full
        ext = file_path.suffix.lstrip(".")
        mime = mime_for(ext)
        b64 = base64.b64encode(file_path.read_bytes()).decode("ascii")
        return f'url("data:{mime};base64,{b64}")'

    return re.sub(r'url\(\s*(["\']?[^"\')\s]+["\']?)\s*\)', replace, css)


def inline_style_blocks(html: str, base_dir: Path) -> str:
    """For each <style>...</style>, inline url(...) refs inside."""

    def replace(match):
        css_inner = match.group(1)
        return f"<style>{inline_css_urls(css_inner, base_dir)}</style>"

    return re.sub(r"<style>([\s\S]*?)</style>", replace, html, flags=re.IGNORECASE)


def fetch_remote(url: str, timeout: int = 10):
    """Fetch a remote URL. Returns (bytes, content_type) or raises."""
    if url.startswith("//"):
        url = "https:" + url
    req = urllib.request.Request(url, headers={"User-Agent": "render-deck/1.0"})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        ct = resp.headers.get("Content-Type", "image/jpeg")
        # Strip charset etc.
        mime = ct.split(";")[0].strip()
        return resp.read(), mime


def inline_images(html: str, base_dir: Path) -> str:
    """Inline all <img src="..."> — local as base64, remote via fetch."""
    local_count = 0
    local_bytes = 0
    remote_count = 0
    remote_bytes = 0
    remote_failed = 0

    img_pattern = re.compile(r'<img([^>]*?)\ssrc="([^"]+)"([^>]*?)>', re.IGNORECASE)

    def replace(match):
        nonlocal local_count, local_bytes, remote_count, remote_bytes, remote_failed
        before = match.group(1)
        src = match.group(2)
        after = match.group(3)

        if src.startswith("data:"):
            return match.group(0)

        is_remote = src.startswith(("http://", "https://", "//"))

        if is_remote:
            try:
                data, mime = fetch_remote(src)
                b64 = base64.b64encode(data).decode("ascii")
                remote_count += 1
                remote_bytes += len(data)
                return f'<img{before} src="data:{mime};base64,{b64}"{after}>'
            except (urllib.error.URLError, urllib.error.HTTPError, TimeoutError, Exception) as e:
                short_src = src[:60] + "…" if len(src) > 60 else src
                print(f"  ⚠ Remote image fetch failed: {short_src} ({e})")
                remote_failed += 1
                return match.group(0)

        # Local image — resolve against the deck's dir first, then fall back
        # to the skill root (this script lives at <SKILL_DIR>/scripts/), so
        # "assets/..." and "design-tokens.css" work even though the deck file
        # lives in the per-task <RUN_DIR>, not inside the skill directory.
        img_path = (base_dir / src).resolve()
        if not img_path.is_file():
            skill_root = Path(__file__).resolve().parent.parent
            fallback = (skill_root / src).resolve()
            if fallback.is_file():
                img_path = fallback
            else:
                print(f"  ⚠ Image not found (tried deck dir and skill dir), leaving as-is: {src}")
                return match.group(0)
        ext = img_path.suffix.lstrip(".")
        mime = mime_for(ext)
        data = img_path.read_bytes()
        b64 = base64.b64encode(data).decode("ascii")
        local_count += 1
        local_bytes += len(data)
        return f'<img{before} src="data:{mime};base64,{b64}"{after}>'

    result = img_pattern.sub(replace, html)

    if local_count:
        print(f"  Inlined {local_count} local image(s), {local_bytes / 1024 / 1024:.2f} MB")
    if remote_count:
        print(f"  Fetched + inlined {remote_count} remote image(s), {remote_bytes / 1024 / 1024:.2f} MB")
    if remote_failed:
        print(f"  ⚠ {remote_failed} remote image(s) failed to fetch — left as URL (will load when online)")

    return result


# ─── Main ─────────────────────────────────────────────────────────────
def main():
    args = parse_args()
    input_path = Path(args.input)
    if not input_path.is_file():
        print(f"ERROR: input file not found: {args.input}", file=sys.stderr)
        sys.exit(2)

    input_abs = input_path.resolve()
    input_dir = input_abs.parent
    if args.output:
        output_abs = Path(args.output).resolve()
    else:
        stem = input_abs.stem
        output_abs = input_dir / f"{stem}-inlined.html"

    print()
    print("═══════════════════════════════════════════════════════════════")
    print("GGS Deck Renderer (Python · HTML-only)")
    print("═══════════════════════════════════════════════════════════════")
    print(f"  Input:  {args.input}")
    print(f"  Output: {output_abs}")
    print("───────────────────────────────────────────────────────────────")
    print()

    raw_html = input_abs.read_text(encoding="utf-8")
    issues = validate_html(raw_html)

    has_fatal = False
    for severity, msg in issues:
        tag = "❌" if severity == "fatal" else "⚠"
        print(f"  {tag} {msg}")
        if severity == "fatal":
            has_fatal = True
    if has_fatal:
        print("\nFatal validation errors. Aborting.", file=sys.stderr)
        sys.exit(2)

    print("\n  Inlining assets…")
    html = inline_css_in_html(raw_html, input_dir)
    html = inline_style_blocks(html, input_dir)
    html = inline_images(html, input_dir)

    print(f"  Final size: {len(html.encode('utf-8')) / 1024 / 1024:.2f} MB")

    output_abs.parent.mkdir(parents=True, exist_ok=True)
    output_abs.write_text(html, encoding="utf-8")
    print(f"\n✅ Self-contained HTML saved: {output_abs}")
    print("\n   To convert to PDF: open in Chrome / Safari / Edge,")
    print("   then File → Print → Save as PDF (landscape, no margins).")


if __name__ == "__main__":
    try:
        main()
    except SystemExit:
        raise
    except Exception as e:
        print(f"\nERROR: {e}", file=sys.stderr)
        import traceback
        traceback.print_exc()
        sys.exit(1)
