# Tone & Narrative

This is **guidance, not a template**. Use your judgment to adapt to the data and the user's wishes.

---

## What you're really doing

The deck is a sales proposal **delivered face-to-face in a 45-60 minute meeting**. The client's boss is in the room, time-stressed, brings multi-year offline-business confidence, and may already have biases against Alibaba.com. **The first 5 pages decide whether they keep listening.**

The real goal of the deck is **not "have them sign now"** — it's:

> Push the client from "stranger / skeptical" to **"willing to take the next step"** (visit / trial / data exchange / second meeting).

The client at the end should feel: *"this person understands my business, the market I'm in is heading somewhere I can ride, Alibaba.com is credible, and the next step is concrete and low-risk."*

---

## 打动客户原则 (the heart of every chapter)

Every chapter the AI authors **must** be designed around 4 segments below — not "what fields go in this chapter" but "what psychological landing the client should feel after reading this chapter".

When the per-stage deck files (`awareness-deck.md` / `interest-deck.md` / `decision-deck.md`) describe a chapter, they will give you the 4 segments below for that specific chapter. **Use them as your authoring guide for that chapter.**

### 4 段心理体感指引 (per-chapter authoring lens)

**1. 共情起点 (where the client's head is when reading this chapter)**
- 客户老板会在想什么 / 在嘀咕什么 / 在防御什么
- Not "客户需要什么" (that's product-speak) — but "客户此刻在想什么"
- Example: 在 Strengths 章,客户老板想的是 "我们的技术真的比大陆便宜货好,客户却转单走 — 凭什么?" — deck 必须**先致敬他的真本事**,再讲话

**2. 数据支撑路径 (what data lets the client stop and listen)**
- What specific data point makes the client lean in
- Where does that data come from (CRM tool / web_search / KB / enrichment) — reference the dynamic-discovery protocol where applicable
- Prefer **客户类型 + 客户国家 + 客户行业 的具体数字** over global stats
  - Bad: "全球 B2B 市场 7.5% CAGR" (客户听过 100 次,免疫)
  - Good: "过去 12 个月,跟你一样的台湾电子工厂,有 42 家上线了 Alibaba.com" (来源:`crm-industry-success-story` 该国 + 该 lv2)
- ❌ 凭训练记忆补数字 — 客户瞬间识破

**3. 应该避免 (what kills this chapter)**
- 这一章最容易踩的坑
- Common kills: 凭训练记忆补 / 通用商业口号 / 平台自夸 / 总结式陈述("你的优势是 X / Y / Z" — 显得销售在打分)/ 教育客户基础概念

**4. 一句话叙事公式 (the one-sentence anchor for the chapter)**
- The AI's authoring should produce **one sentence first** that captures the chapter's emotional landing
- Then expand from that one sentence
- The formula is per-chapter, given in the deck file

**Why these 4 segments matter**: 章节内容的"打动力"不在 "装了什么数据",而在 **数据 vs. 客户心理状态的对位**。同样的数字,装在错的位置 → 客户不听;装在对的心理状态后面 → 客户记住。

---

## Default story arc (SWOT 4-chapter split + 3-level macro)

⚠️ **默认结构**:以 "SWOT 作骨架 + 三级递降" 为基础,**默认把 SWOT 拆成 S / W / O / T 4 章独立深讲**。

理由:
- 4 章独立后,每章有时间在客户心里**留 30-60 秒共鸣**(S+O / W+T 合并时每个维度只剩 10 秒)
- 每章可用**不同视觉范式**(由 AI 按客户类型设计 — 例如圆形 icon 卡 / 对照表 / 大数字 + narrative / 警示卡 + 应对段)— 破样式僵化
- 每章可独立按 "打动客户原则 4 段" 落地 — 心理体感更精准

### 推荐弧线 (无 strategy 上下文时的默认)

```
1. Cover — 客户名 + 你给他的核心承诺("这是为你做的")

2. 战略契机(三级递降)—— 取代原 "Macroeconomic Trends"
   2.1 全球宏观信号(web_search 实时拿,按客户行业筛 — 关税 / ESG / AI / 数字化等当下大事)
   2.2 对你所在行业意味着什么(industry-insights — 流量 / 买家 / 热搜词的具体变化)
   2.3 对你这家公司意味着什么(基于 enrichment + 客户类型,AI 推断 1-2 个具体影响,标"可调整")

3. 公司概览 — 基于 enrichment 的真实事实(可选,若客户类型很明显可跳过)

4. Strengths(独立章)— 致敬客户真本事
   视觉建议(AI 可自由发挥):圆形 icon + 横向列
   按 "打动客户原则 4 段" 落地

5. Weaknesses(独立章)— 不卖惨,讲差距 + 缩短路径
   视觉建议(AI 可自由发挥):左红"当前状态" / 右灰"缩短差距路径"
   按 "打动客户原则 4 段" 落地

6. Opportunities(独立章)— 3 张大数字卡 + narrative
   视觉建议(AI 可自由发挥):大数字 + narrative + 趋势箭头
   按 "打动客户原则 4 段" 落地

7. Threats(独立章)— 不卖恐慌,讲威胁 + 应对
   视觉建议(AI 可自由发挥):警示卡 + 应对段
   按 "打动客户原则 4 段" 落地

8. 同类型客户走通的路径(Success Stories)
   - KB 拿该国成功案例(动态发现协议)
   - 1 hero + 4 mini 混排(1 hero + 4 mini 混排视觉)

9. About Alibaba.com — 减薄为 1 页(平台核心数据 + 信任背书)
   - 不展开自我推销
   - 单行 stats 横条视觉

10. 行业弹药章节(根据 deck 长度选用):
    - 10a. Local Industry Outlook(流量 + 买家国分布)
    - 10b. Trending Products(热搜词 + 高需求产品)
    - 10c. Industry Benchmarks(2 张大 peer card)

11. L1-L4 Buyer Tier(可选,通用骨架)— 让客户看到"签后能看见什么"
    视觉建议(AI 可自由发挥):渐变阶梯

12. 12-month Roadmap(可选,通用骨架 + 国家本地化)
    视觉建议(AI 可自由发挥):横向时间轴 + 渐变线

13. Action Plan — 4 个方向,主推 2 个高亮
    视觉建议(AI 可自由发挥):2 主推 + 2 常规
    ❌ 对客版**不绑负责人 / 时间点** — 那是销售内部素材
    ⚠️ "异议预案" 若放进 deck → 必须用**对客视角**写法(见 decision-deck.md 章节 4),不是销售反驳话术

14. Thank You / Next Step — 不是销售自介,是"销售跟客户下一步"
```

**关键约束**:
- 4 章拆分模式下,每章保持**视觉变化**(不要 4 章都用同一种 card 范式)— 这是破样式僵化的核心动作
- About Alibaba.com **减薄**到单行 stats 横条 — 不展开自我推销
- 章节预算紧张时,可以删 11 / 12 章(可选),但不要删 SWOT 任何一章

### 原 v1.0.3 弧线(兼容支持,销售明确要求时用)

```
1. Cover
2. SWOT(2×2 4 格)
3. Macroeconomic Trends
4. About Alibaba.com
5. Success Stories
6. Industry Outlook
7. Trending Products
8. Industry Leaders & Benchmarks
9. Action Plan
10. Thank You
```

销售触发条件(见下方"销售一句话覆盖"):
- "按 v1.0.3 原章节顺序做" / "按 Macro → About → ... 做"
- "SWOT 用 2×2 别铺开" / "SWOT 合并"
- "短版 deck / 10 页内"

### 有 strategy 上下文时 — 阶段化 deck

按 SKILL.md Phase 0 路由到:

- `awareness` → `awareness-deck.md` — 客户心理:"国际站是什么 / 跟我什么关系" / SWOT 4 章铺开 + 三级递降
- `interest_evaluation` → `interest-deck.md` — 客户心理:"适不适合我 / 选谁" / 案例对号入座 + 买家画像 + 对比 + 保守 ROI
- `decision_closing` → `decision-deck.md` — 客户心理:"签哪一档 / 条款怎么走" / 套餐方向对比 + ROI + **对客视角异议预案** + 强 CTA
- `cold` → 不做 deck(建议销售先用 outreach 起草短触达)

每个阶段 deck 文件**详细描述各章的 "打动客户原则 4 段"**。

Skip any chapter where data is unavailable (after the lv2→lv1 fallback). Don't pad with placeholders.

---

## SWOT chapter spec(schema 与渲染规则)

**Purpose**: Show you've studied the client. Earn the right to advise.

**Data source**: LLM analysis combining web research about the client + user-provided context. Not from `ggs-crm`. Optionally enriched by Table 4 metrics (`valid_prod_cnt`, `pv_avg_d_6m`, `dab_r_6m`, `avg_reply_time_6m`, etc.) when available, used as factual data points to ground bullets.

**Special placement**: SWOT precedes the numbered chapters and is informational — does **not** get a numbered section divider. Chapter numbering starts from "01 Macroeconomic Trends".

### Rendering — AI 自己决定

SWOT 渲染方式由 AI 按 deck 整体节奏 + 客户类型 决定。两种常见做法:

- **4 章独立铺开**(default for 拜访 deck)— S / W / O / T 各自作为独立章节,每章一个 `<section>`。让客户在每一面停下来共鸣 30-60 秒。每章用不同视觉(圆形 icon 卡 / 对照表 / 大数字卡 / 警示卡)。
- **2×2 grid 合并**(短版 deck)— SWOT 4 格塞一个章节。适合短版 deck / 销售明确要 v1.0.3 原版 / 总章节预算紧张。

两种方式用**同一个 `swot_data` JSON 字段**(下方定义)。

### Fields

```json
{
  "swot_data": {
    "company_name": "<full name>",
    "company_logo": "<URL or empty>",
    "industry": "<industry/category label>",
    "country": "<country>",
    "brief": "<30–60 word description>",
    "strengths":     ["<3–5 bullets>"],
    "weaknesses":    ["<3–5 bullets>"],
    "opportunities": ["<3–5 bullets>"],
    "threats":       ["<3–5 bullets>"]
  }
}
```

### Field rules

- `company_name`: display verbatim. Required.
- `company_logo`: optional remote URL. If empty, fall back to a circle showing the company's initials (single-word name → first 2 chars; multi-word → first char of first 2 words).
- `industry`: appears as a small tag/badge near the company name.
- `country`: appears as a small tag/badge.
- `brief`: 1–3 sentences, 30–60 words. **Neutral, factual tone** — describe core business, location, target markets, capabilities. NOT positively-framed sales copy (different from `ai_summary`).
- Each SWOT array: 3–5 bullets recommended.
- **Empty quadrant**: render a `—` placeholder, don't drop the quadrant.

### Tone

Honest but constructive. Strengths should be specific and credible. Weaknesses should be real (not softened to look like strengths). Threats should feel like solvable challenges, not doom.

---

---

## 销售一句话覆盖 (Sales override)

agent 默认按上面路由,但销售一句话能改 — **优先级最高**。

### 覆盖话术识别(同义词广覆盖)

| 维度 | 销售可能说 | agent 路由到 |
|---|---|---|
| 阶段路由 | "按 awareness 做" / "按认知期做" / "客户还没听过国际站,简单点" | awareness-deck.md |
|  | "按 interest 做" / "按兴趣评估做" / "客户在比平台,多放案例" | interest-deck.md |
|  | "按 decision 做" / "按决策成交做" / "客户准备签了,详细 ROI" | decision-deck.md |
|  | "按 cold 也做 deck" / "冷启动也要 deck" | awareness-deck.md(精简版) |
| 章节模式 | "SWOT 用 2×2 别铺开" / "SWOT 合并" | 退回 v1.0.3 SWOT 2×2 |
|  | "短版 / 10 页内 / 精简" | 退回 v1.0.3 弧线 + 删可选章节 |
|  | "按 v1.0.3 原版做" | v1.0.3 完整弧线 |
| 客户类型微调 | "强调工厂角度" | SWOT Strengths 偏制造 / 认证 / 产能 |
|  | "强调贸易商角度" | SWOT Strengths 偏客户网络 / 客户管理 / 多 SKU |
|  | "强调品牌商角度" | SWOT Strengths 偏品牌资产 / 设计 / 渠道 |
| 内容偏向 | "客户对 ROI 最敏感,详细测算" | 加重 decision-deck.md ROI 章节 |
|  | "客户问过 vs 展会怎么算,展开讲" | 触发 Optional Chapter B (Trade Show vs Alibaba) |

### 覆盖识别规则

- 销售在 query 里包含上面任一覆盖话术 → **直接用该覆盖路径**,跳过 strategy 软依赖检测
- 销售说"按 X 做" 但又说"用 Y 输出" → X 是 storyline 覆盖,Y 是 output language 覆盖(规则:输出语言跟 user query 语言,内容本地化跟客户国家)
- 销售没明确说但加了语气词("简单点" / "短版" / "重点放在 ...") → 按上面映射推断,执行前**问销售一次确认**

---

## Tone

- **Specific over vague.** "$17.2B exports, +11% YoY" beats "growing market".
- **Confident but honest.** Don't oversell. If a SWOT weakness is real, say it.
- **Forward-looking.** Frame data toward "what this means for you next quarter".
- **客户视角 not 平台视角.** 通篇用"你 / 你的",避免"我们的平台多牛"。
- **One idea per chapter.** Don't cram. 4 章拆分后每章只讲一件事。
- **No product names hardcoded.** OKKI / KWA / Verified Supplier / Gold Supplier 等具体产品名 — 由 KB 提供,不在 deck 内容里凭训练记忆点名。
- **No price hardcoded.** 报价 / 折扣 / 限时 由 KB 提供或销售明确给,不凭训练记忆编。
- **Output language:** 跟 user query 语言走;内容本地化(银词/案例)按客户国家走。

---

## Customization examples

- *"Skip SWOT, the client knows themselves"* → drop chapters 4-7 (SWOT 4 章)
- *"Lead with the action plan"* → reorder
- *"Add a chapter on pricing strategy"* → make a new one; reuse the visual style
- *"Make it 10 slides total"* → tighten ruthlessly (drop optional chapters 11/12 first)
- *"Focus on hospitality buyers"* → bias data emphasis throughout

When unsure, ask the user before generating.
