# Business Rules & Field Reference

This document is your **per-chapter reference** for: data sources, field meanings, processing rules, writing tone, and known pitfalls. It does **not** prescribe layout, sizes, or colors — visual design is AI's call per client (see `SKILL.md` § "视觉品味原则"). Use your judgment for visual composition.

`ggs-crm show-docs <tool-name>` is always the authoritative source for current field names, response shape, and business meaning of every field. Run it once per tool per conversation **before the first call**. The command needs no token. Do not use `--help` as a substitute — `--help` only shows argument syntax, not field semantics. If the live `show-docs` output differs from anything below, follow `show-docs`.

---

## Common Conventions

### Platform terms

| Term | Meaning |
|---|---|
| **IPV** | Item Page View — number of times a product detail page is viewed. Primary demand metric. |
| **GGS** | Global Gold Supplier — Alibaba.com's overseas merchants (excludes mainland China). "GGS benchmark" = cross-country average for the same industry. |
| **shop_pv** | Backend column combining product PDP views + storefront page views. "IPV" in API output is usually `shop_pv` aggregated. |
| **lv1 / lv2 / lv3 industry** | Category hierarchy. lv1 = broad ("Furniture"), lv2 = mid ("Outdoor Furniture"), lv3 = leaf ("Outdoor Wicker Sofa"). CLI flags: `-i` for lv1 (required), `--industry-lv2-id` (required for the four lv2-capable tools), `--industry-lv3-id` (optional, for finer filtering when known). |
| **TA / Trade Assurance** | Alibaba.com's payment-protection program. |
| **share** | A percentage (0–100) within some grouping dimension. |
| **YoY** | Year-over-year. Current 12-month rolling vs. prior 12-month. Can be negative. |

### Output language

The deck's default language follows the **language of the user's query**, not English by default. If the user asks in Chinese, generate the deck in Chinese; in Vietnamese, generate in Vietnamese; etc. Override only if the user explicitly says otherwise (e.g. "client speaks Korean, write the deck in Korean even though I'm asking in English").

When generating in a non-English language:
- **Translate**: section titles, subtitles, all narrative copy, ai_summary content, card labels, axis titles, chart legends, bullets.
- **Do NOT translate**: company names (mask them per the rules below, but keep original script), country names (use original romanized form), currency symbols, year labels, numbers, percentages, month labels in `YYYY-MM` format, source attribution names (ITC Trade Map, UN Comtrade, etc.), brand names (Alibaba.com, Trade Assurance, Smart Assistant, Alibaba Guaranteed), platform terms (IPV, GGS, YoY, CTR, P4P), URLs.
- **AI summaries must be regenerated natively** in the target language, not word-for-word translated from English.
- For amount display, follow the target language's convention: Chinese "约24万", English "~241K", Vietnamese "~241K", etc.

### AI summary writing rules (apply to every `ai_summary` field)

1. **Word limit**: ≤100 words.
2. **Tone**: Positive, sales-oriented, action-driving. (Macro chapter has a tighter version, see below.)
3. **Forbidden words**: never use `decline`, `drop`, `collapse`, `crisis`, `loss`, `failure`, `weak`, `poor`, `threat`, `danger`, `beat`, `destroy`.
4. **Reframing negatives**: If data shows YoY decline, frame as "market recalibration", "shifting buyer preferences", "global disruption", or "emerging opportunity for digital-first sellers" — never name it as a decline.
5. **Always end with a forward-looking statement** connecting the data to *why now is the right time to sell on Alibaba.com*.

### Currency conversion

- **Trust each field's `_meta` description for its currency.** Do NOT apply a blanket RMB assumption.
- The amount fields in these CRM tools are documented in their `_meta` as **USD already**: benchmark `total_cost_180d` / `p4p_cost_180d` / `cpab_180d` / `rcvd_amt_180d` (each meta = "…（美元）"), and Chapter 05 `high_growth_received_gmv` (meta = "收款金额（美元）"). **Display these verbatim in USD — do NOT divide by 7.2.**
- Only convert with `usd = round(rmb / 7.2)` (fixed rate 1 USD = 7.2 RMB) for a field whose `_meta` explicitly says RMB / 人民币. None of the six current tools' displayed amount fields are RMB.
- Display always in USD throughout the deck.

### Amount desensitization

For any displayed USD amount — benchmark cost fields (`total_cost_180d`, `p4p_cost_180d`, `cpab_180d`, `rcvd_amt_180d`) and Chapter 05 `high_growth` GMV. All are already USD (see "Currency conversion" — no ÷7.2).

- Input is in USD (already converted from RMB).
- `amount >= 1000` → display as `~{round(amount/1000)}K` (e.g. 33500 → "~34K", 9722 → "~10K").
- `amount < 1000` → display as `~{amount}`.

### Field-explanation footnote (every data chapter)

Every chapter that displays CRM metrics **must** carry, in (or right under) its `data_source` footer line, a one-line explanation of each displayed metric — the client should never have to guess what a number means. Rules:

- Derive wording from the tool's `_meta` description, rewritten **client-friendly** — never show raw field names (`idx_12m_shop_pv_30d`) or internal jargon.
- Indexed metrics must say they are **relative indices, not absolute counts**.
- Monetary metrics state the currency (美元) and time window (e.g. 近180天).
- Target one short line per chapter (2 max), same language as the deck. Examples:
  - Traffic: `指数说明:店铺访问指数为平台归一化的相对热度指标,数值越高流量越大,非绝对访问次数。`
  - Products: `指标说明:曝光指数为近12个月商品曝光的相对指数;访客数为近期浏览买家数;收款额为美元。`
  - Benchmark: `指标口径:均为近180天;转化率=访客转化为买家比例;获客成本=总花费÷活跃买家(美元)。`

### Company name masking

For benchmark peer names and any displayed competitor names. Works across English, Chinese, and other scripts (positional, not character-class).

| Length (incl. spaces) | Rule |
|---|---|
| ≤ 4 chars | No masking |
| 5–8 | Keep first 2 + last 2, middle = `***` |
| 9–16 | Keep first 3 + last 4, middle = `***` |
| > 16 | Keep first 4 + last 5, middle = `***` |

**Worked examples (apply the bracket strictly — count length first, then pick the rule):**

| Raw name | Length | Bracket | Masked |
|---|---|---|---|
| `"Acme Trading"` | 12 | 9–16 → first 3 + last 4 | `"Acm***ding"` |
| `"Viet Seafarm"` | 12 | 9–16 → first 3 + last 4 | `"Vie***farm"` |
| `"Vietnam Dairy Products JSC"` | 26 | >16 → first 4 + last 5 | `"Viet***s JSC"` |

⚠️ Do NOT eyeball it — count the length first, then apply that bracket's rule. A 12-char name uses the **9–16** rule (first 3 + last 4), not the 5–8 rule.

### Image / URL handling

CRM tools return image fields as **remote HTTPS URLs** (typically `https://sc04.alicdn.com/...` or similar). Render them as plain `<img src="https://...">` in your deck.html.

`render-deck.py` fetches each remote URL at build time and embeds it as base64 in the inlined HTML, so the final output is fully offline-viewable. If a remote URL is unreachable at build time, `render-deck.py` leaves the URL in place — it'll load when the file is opened online.

You don't need to download or convert images yourself.

**Always preserve the image URL field** when mapping CRM responses to your data. Hand-mapping `crm-industry-product` is error-prone because the image field can easily be dropped, leaving thumbnails as broken icons. Use `scripts/map-crm-product.js` for trending-products mapping, or be very careful when mapping by hand.

### Saving raw CRM responses

After every `ggs-crm` call, save the raw JSON to `<RUN_DIR>/crm-<tool>.json` (e.g. `crm-buyer-country.json`) — inside the **current task directory**, never the workspace root. The workspace is shared across sessions and clients; a stray JSON at the root can be silently picked up by another client's run, putting client A's numbers into client B's deck. This preserves traceability — if any number in the deck looks wrong, the raw response is your audit trail. The CLI may emit a Python warning line on stderr; the JSON body itself comes on stdout, sometimes prefixed with stray text — strip everything before the first `{` if you need to parse it.

### Citing data sources on each section

Every CRM-sourced number in a section must have a small footnote indicating its source — typically the CRM tool name or "Alibaba.com Platform Analytics" plus the date range. Web-sourced macro figures cite the source agency (ITC Trade Map, UN Comtrade, etc.) at the section bottom. Hardcoded About Alibaba stats and milestone dates don't need source notes.

### Empty-response detection

- **`total: 0` is NOT always reliable.** Especially for regions like Vietnam, the CRM may return `total: 0` even when data exists in the sub-arrays. **NEVER** treat `total: 0` as a definitive "no data" signal without checking the `values` or `dataList` arrays directly.
- **The `total` count is also unreliable when non-zero.** Observed: a `crm-industry-buyer-country` response with `total: 17` but only 16 rows in `values`. **Never use `total` for counting, pagination, or "X buyers/peers" copy — always count `values.length` (or the relevant sub-array length) yourself.**
- A response with even **one** valid row in any relevant array is **not** empty — use it. Don't reach for fallback to get more rows.

### Empty-data fallback (CORRECT order — read carefully)

`crm-industry-traffic`, `crm-industry-buyer-country`, `crm-industry-product`, `crm-industry-benchmark`, `crm-industry-success-story`, and `crm-rfq-query` all follow this fallback chain. **Do NOT skip steps or reorder — the order matters.**

1. **Category escalation (intra-CRM, MUST exhaust first)**:
   - Retry with parent **lv2** category.
   - Retry with parent **lv1** industry.
   - **Retry with at least 2 neighboring lv1 industries** that semantically overlap with the prospect's business. Examples:
     - i=5 (Electrical) ↔ i=2 (Machinery) ↔ i=13 (Lights & Lighting)
     - Furniture ↔ Home & Garden ↔ Building Materials
     - Apparel ↔ Textile ↔ Sport
   - Why this matters: a prospect like a Vietnamese electrical-equipment distributor may show as "0 records" in `i=5` but have rich data in `i=2`, because the buyer-side category mapping for industrial channel partners often falls under Machinery. **Real-world incident: lv1=5/13 returned `total:0` for VN, but lv1=2 returned 3 valid success stories with full `logoUrl`.**

2. **Cross-Source Search (only after step 1 is fully exhausted)**:
   - For high-priority regions (VN, ID, IN, TR, etc.), use `ggs-sales-knowledge-base` skill or platform web search to find verified success stories, top supplier lists, or industry whitepapers.
   - Knowledge-base content typically has **text only, no imagery** — see "Visual fallback rules" below for what to do when images are missing.

3. **Regional Fallbacks**: Use the "Regional Industry Benchmarks" section at the end of this document for known performance standards (reply time, growth %, peer names) when live data is sparse.

4. **Skip**: If steps 1-3 yield nothing, skip the chapter (apply Skipping rules).

**Visual fallback rules** (applies to chapters that normally render images — e.g. success stories, products):

- If step 1 yields data with image URLs → **use the URLs verbatim**, never strip them.
- If step 2 (knowledge base / web) yields text-only data → either (a) skip the chapter to avoid an image-less degraded layout, or (b) explicitly add a CSS gradient placeholder block. **Do NOT silently render a card with no visual** — it looks broken.
- Image URLs from `sc04.alicdn.com`, `sc02.alicdn.com`, `cbu01.alicdn.com` are official Alibaba CDN and safe to inline.


### Skipping rules

When CRM data is unavailable for a chapter (or sub-section) after the fallback above:

1. **Skip silently.** No "data unavailable" placeholder section. No 404 page. No section divider for the skipped chapter.
2. If a numbered chapter is skipped, **renumber** the remaining chapter dividers — if Chapter 4 is dropped, what was Chapter 5 becomes Chapter 4.
3. If you're showing a Table of Contents, it reflects only chapters that actually appear.
4. **Don't annotate** that data came from a lv1 fallback — display the data as-is, no "this is broader / fallback" label.
5. **Don't fabricate data** to fill skipped chapters or empty sub-sections. Ever.

### Tool errors are not data errors

A response with empty arrays = "no data for this segment" → apply fallback.

A response that's a **CLI error** (`Missing option`, `Invalid value`, `command not found`, malformed JSON, network timeout, etc.) = something is wrong with the tool or environment → **stop and report to the user verbatim**. Don't try other tools, alternative parameter shapes, or web searches as a substitute. The user needs to know the tool failed so they can fix the environment.

### Top-level required fields (deck-level)

Every deck must have these populated, regardless of which chapters are included:

| Field | Description |
|---|---|
| `title` | Deck title, e.g. `"Alibaba.com Business Proposal"` (translated) |
| `company_name` | Client company name, displayed on cover and SWOT |
| `main_category` | Client's primary industry/category as a display label |
| `target_country` | The client's country (English name). Used both for display and to pass to CRM tools (resolved to ISO 2-letter code with `-c` flag). |
| `target_industry` | Free-text description of the industry. Resolved to lv1/lv2 IDs via `ggs-crm industry-mapping` before CRM calls. |

Optional top-level flags:

| Field | Description |
|---|---|
| `include_about` | Boolean. If `false`, skip the About Alibaba.com chapter. Default = `true`. The user's structure preferences in step 1 may set this. |
| `sales_name` | Sales rep's name (string). **Optional. Do not proactively ask the user for this.** If the user volunteers it in their query, display verbatim on the Cover and Thank You sections — do not transform or apply masking. If absent, both the Cover sales-line and the entire Thank You contact block are omitted; the layout remains visually balanced without them. |
| `sales_email` | Sales rep's email (string). Same rules as `sales_name` — optional, never proactively asked, display verbatim if user supplied. |

If any required field is missing, ask the user before proceeding. Optional fields are never proactively requested; they're used only if the user supplies them in their own message.

### Resolving industry to CRM IDs

The CRM tools take numeric IDs, not text. Before the first call to any `crm-industry-*` tool, get the full industry hierarchy:

```bash
ggs-crm industry-mapping
```

This command takes no arguments and returns the full lv1 / lv2 / lv3 hierarchy as JSON. **You** then semantically match the user's free-text industry against this JSON to pick the right `(lv1_id, lv2_id)` pair, optionally with `lv3_id` for finer detail.

If multiple candidate matches look plausible (e.g. "furniture" might map to several lv2 categories), confirm with the user before proceeding.

Don't pass the free-text industry as an argument to `industry-mapping` — the CLI doesn't accept positional args, and any extra arg is silently ignored.

### Don't write in JSON-mapping mode

The single biggest authoring mistake: dumping CRM fields onto slides like a database export.

❌ "Vietnam exported $17.2B of furniture in 2024."
✅ "Vietnam's furniture industry exported a record $17.2B in 2024 — and it's still growing 11% YoY. Your timing is good."

The data is the evidence. The narrative is the argument. Every chapter should read like a sales argument backed by the numbers, not a numbered list of fields.

---

> SWOT 章不依赖 CRM 数据(LLM + web + enrichment 综合),其 schema 与渲染规则见 `tone-and-narrative.md` § "SWOT chapter spec"。


## Chapter 01: Macroeconomic Trends

**Purpose**: Show the client's country/industry exports are growing. Frames the opportunity.

**Data source**: LLM web search. Not from `ggs-crm`.

**Authoritative sources, in priority order**:
1. ITC Trade Map (trademap.org)
2. UN Comtrade (comtrade.un.org)
3. Statista
4. World Bank Open Data
5. Country's national customs / trade ministry
6. Industry association reports

**Search strategy**: query like `"<country> <industry> export value USD <year range>"`. Gather **6 years** (5 completed + current year estimate). If current year actuals aren't available, mark with `"E"` suffix (e.g. `"2025E"`) and extrapolate from trend. **Never fabricate figures.** If <4 data points found, skip the chapter.

### Fields

```json
{
  "macro_data": {
    "country": "<country>",
    "industry": "<industry>",
    "currency": "USD",
    "unit": "Billion | Million",
    "export_data": [
      { "year": "2020",  "value": 14.8 },
      { "year": "2021",  "value": 16.2 },
      { "year": "2025E", "value": 21.8 }
    ],
    "cagr": 8.1,
    "scenario": "A | B | C",
    "ai_summary": "<4–6 sentence narrative per scenario rules>",
    "data_sources": ["ITC Trade Map", "..."]
  }
}
```

### Field rules

- `unit`: `"Billion"` if total ≥ $10B, otherwise `"Million"`. Don't mix within one chart.
- `export_data`: 4–6 points. Last point may be estimate (year ends with `"E"`).
- `cagr`: `((last_value / first_value) ^ (1 / years)) - 1`, expressed as percentage to 1 decimal. E.g. start=$14.8B (2020), end=$21.8B (2025E), 5 years → CAGR = 8.1%.
- `data_sources`: 1–4 source names to cite at section bottom.
- `ai_summary`: **4–6 sentences** (more constrained than the generic ≤100 words).

### Scenario classification & framing

After gathering data, classify into exactly ONE scenario, then write `ai_summary` per its rules.

#### Scenario A — "Riding the Wave" (Consecutive Growth)

**Trigger**: Growth in ≥4 of last 5 YoY comparisons, no single-year decline > 5%.

**Framing keywords**: supply chain strength, export boom, accelerating demand, established momentum, early mover advantage.

**Narrative structure** (4–6 sentences):
1. Open with the growth trajectory and CAGR.
2. Highlight the strongest growth year.
3. Attribute growth to industry/country strengths.
4. Connect to Alibaba.com: *"With <country>'s <industry> exports on a clear upward trajectory, NOW is the ideal time to capture international demand through Alibaba.com's global B2B platform."*

#### Scenario B — "Resilient Rebound" (V-shaped / Volatile)

**Trigger**: ≥1 YoY decline > 5%, followed by recovery to ≥ pre-decline level.

**Framing keywords**: industrial resilience, proven recovery, global disruption (for the dip year), post-recovery momentum, stronger position.

**Narrative structure** (4–6 sentences):
1. Open with overall CAGR showing long-term growth despite short-term volatility.
2. Frame the dip year as "global disruption" or "supply chain recalibration" — never as a local failure.
3. Emphasize the rebound: *"demonstrating the deep resilience of <country>'s <industry> sector"*.
4. Position now as the recovery growth phase: *"Having weathered global headwinds, the sector is now operating from a position of proven strength — making this the optimal moment to expand digital export channels."*

#### Scenario C — "Pivot to Digital" (Recent Decline)

**Trigger**: Most recent 2+ years show YoY decline, OR latest value > 10% below peak.

**Framing keywords**: traditional channels under pressure, digital transformation opportunity, B2B e-commerce as breakthrough, market shift, first-mover advantage in digital.

**Narrative structure** (4–6 sentences):
1. Acknowledge "evolving landscape" and "shifting trade patterns" — never say "decline".
2. Frame as: *"Traditional offline export channels are facing headwinds, creating a clear opportunity for digital-first exporters"*.
3. Position the trend as why Alibaba.com matters now: *"As the market restructures, businesses that establish a strong B2B digital presence now will capture disproportionate share of the recovery"*.
4. End with urgency: *"This is the precise moment when digital export platforms like Alibaba.com become the critical growth engine."*

### Tone

Optimistic, data-driven. Numbers are king. Always cite sources at section bottom.

---

## Chapter 02: About Alibaba.com

**Purpose**: Establish platform scale and credibility.

**Data source**: Hardcoded — these are stable platform facts. **Do not regenerate or web-search them.** Updated approximately once per year.

### Fixed platform stats (8 items)

```
50M+        Active buyers
200,000+    Suppliers (Gold Suppliers)
200+        Countries and regions
200M+       Products
26+         Years of industry experience
40          Industry categories
7,600+      Product categories
16          Languages supported
```

### Fixed company milestones (7 items, 1999–2024)

```
1999  — Alibaba.com officially established
2010  — Launches global trade-related services like customs, currency exchange, and taxes
2014  — Introduces the world's first B2B third-party protection service: Trade Assurance
        (logo: trade-assurance)
2017  — Upgrades to a one-stop digital cross-border trading service platform
2020  — Implements ESG business practices, aiming to create sustainable business value
        for global buyers and sellers
2023  — Launches the first AI-powered innovation tool for international trading: Smart Assistant
        (logo: smart-assistant)
2024  — Introduces the first B2B "Half-Escrow Service," known as Alibaba Guaranteed
        (logo: alibaba-guaranteed)
```

Brand-mark logos **must** be used for the three milestones — reference as `assets/logos/trade-assurance.png`, `assets/logos/smart-assistant.png`, `assets/logos/alibaba-guaranteed.png` (relative form; render-deck.py resolves against the skill dir and inlines). These are real brand assets — do not substitute self-drawn SVG approximations.

### Translation

Translate descriptive text per output language. **Keep brand names untranslated** in any language: Alibaba.com, Trade Assurance, Smart Assistant, Alibaba Guaranteed.

### Tone

Authoritative, slightly aspirational. The numbers do most of the work — keep narrative short.

---

## Chapter 03: Seller Success Stories

**Purpose**: Social proof — testimonial-style quotes from real Alibaba.com sellers in the client's industry.

**Data source**: `ggs-crm crm-industry-success-story -t <token> -i <lv1_id> -c <CC>`. This tool only accepts lv1.

**MANDATORY fallback before skipping** (per the corrected fallback chain at the top of this document):

1. If the prospect's primary lv1 returns `total:0` AND `values:[]`, **DO NOT skip yet**.
2. Retry with **at least 2 neighboring lv1 IDs** that semantically overlap. Common neighborhoods:
   - i=5 (Electrical) ↔ **i=2 (Machinery)** ↔ i=13 (Lights & Lighting)
   - Furniture ↔ Home & Garden ↔ Building Materials
   - Apparel ↔ Textile ↔ Sport
3. Only if **all** retries return empty arrays → cross-source search (via `ggs-sales-knowledge-base` skill or platform web search) for verified testimonials. **Note**: knowledge-base testimonials lack `logoUrl` → either skip the chapter, or render with gradient placeholder (never silently render a card with no visual).
4. Real-world example: lead 4288629424 (VN, Electrical distributor) — lv1=5 and lv1=13 both returned `total:0`, but **lv1=2 (Machinery) returned 3 valid testimonials with logoUrl**. Always try the neighbor before declaring "no data".

### Raw CRM response shape

```json
{
  "data": {
    "total": 3,
    "values": [
      {
        "summary": "Reflecting on my journey with Alibaba.com, I'm struck by the profound impact...",
        "logoUrl": "https://sc04.alicdn.com/kf/H09126508fd324bd7b916f2bb60629467e.png"
      },
      // ...
    ]
  }
}
```

**Important — the CRM only returns `summary` and `logoUrl`.** It does NOT return company name, country, category, or any quantified outcome. Earlier versions of this document described those fields; that was wrong. Don't try to extract them and don't fabricate them.

### Fields per story

| CRM field | Use as | Notes |
|---|---|---|
| `summary` | Quote / testimonial text | First-person quote from the seller. Display as-is, possibly in quotation marks. |
| `logoUrl` | Story image / logo | `_meta`: 成功故事配图/Logo URL. A remote image for the card — may be a seller logo **or** a generic story illustration; the meta doesn't promise it's the seller's company logo. **Use as the visual element** of the testimonial card; don't caption it as "{company}'s logo". |

### Card design — testimonial style

Because the data is just *quote + logo*, success stories are presented as **testimonial cards**, not "case study cards". Each card shows:

- The story image (`logoUrl` — seller logo or generic illustration; top of card or left side)
- The quote (the `summary` text), possibly with leading quotation mark for visual emphasis
- No company name, no country tag, no category tag, no quantified-outcome line — these fields don't exist in the response

If `logoUrl` is missing or fails to load, fall back to a gradient color block.

**Never fabricate company names, countries, or categories** to fill in card structure. If you need more visual content for the card, work within what the CRM gave you.

### Tone

Let the quotes speak for themselves. The summaries are already first-person and authentic. Don't paraphrase or "improve" them — display verbatim.

### Translation

The `summary` field is already in the original seller's language (often English or the seller's local language). If the deck language differs, you may translate the summary into the deck's language while keeping the quoted feel — but mark translated quotes implicitly, e.g. by quoting them as paraphrase. Native-language summaries are stronger than translated ones; if the deck is in the same language as the summary, prefer verbatim.

---

## Chapter 04: Local Industry Outlook

**Purpose**: Move from generic platform credibility to *specific industry opportunity on Alibaba.com*.

Two sub-sections, each from its own CRM tool. Either or both may be present.

### Sub-section A: Traffic Trends

**Data source**: `ggs-crm crm-industry-traffic` (lv3→lv2→lv1→skip fallback applies — see "Empty-data fallback" above).

**Raw CRM response shape**:

```json
{
  "data": {
    "total": 12,
    "values": [
      {
        "ds": "20260430",
        "currentCountryData": {
          "idx_12m_shop_pv_30d":   "4776.69...",
          "idx_12m_imps_shop_30d": "50.0",
          "idx_12m_ab_cnt_30d":    "3617.02..."
        },
        "allCountryData": {
          "idx_12m_shop_pv_30d":   "2767.98...",
          "idx_12m_imps_shop_30d": "65.90...",
          "idx_12m_ab_cnt_30d":    "3252.20..."
        },
        "main_cate_lv1_desc": "Food & Beverage",
        "main_cate_lv2_desc": "Dairy Products"
      },
      // ... 11 more, one per month
    ]
  }
}
```

**Field meanings**:

| CRM field | Use as | Notes |
|---|---|---|
| `ds` | Month label | Format `YYYYMMDD`. Each row is end-of-month — convert to `YYYY-MM` for display. |
| `currentCountryData.idx_12m_shop_pv_30d` | Country shop PV (primary series) | The target country's monthly shop page views in the industry, expressed as a normalized index. **String**, parse to float. |
| `allCountryData.idx_12m_shop_pv_30d` | Global benchmark shop PV (benchmark series) | `_meta`: 全球汇总的流量指标数据 — a **global aggregate** in the same industry, same index scale. **String**, parse to float. (The skill elsewhere labels this "GGS"; the meta only says "全球汇总" and does not state whether mainland CN is excluded — treat "GGS" as a working label, not a meta guarantee.) |
| `currentCountryData.idx_12m_imps_shop_30d` | Shop impressions (current country) | Monthly shop-level impression index. ⚠️ **Unreliable for the latest 1–2 months** (see "imps latest-month trap" below) — do not chart as-is. Optional secondary metric. |
| `allCountryData.idx_12m_imps_shop_30d` | Shop impressions (global GGS) | Cross-country shop impression benchmark. Same latest-month caveat. Optional secondary metric. |
| `currentCountryData.idx_12m_ab_cnt_30d` | Active buyers (current country) | Monthly active buyer index for the target country. Optional secondary metric. |
| `allCountryData.idx_12m_ab_cnt_30d` | Active buyers (global GGS) | Cross-country active buyer benchmark. Optional secondary metric. |

**Building the 12-month series**:

1. Sort `values` by `ds` ascending.
2. Extract `currentCountryData.idx_12m_shop_pv_30d` and `allCountryData.idx_12m_shop_pv_30d` into two parallel arrays.
3. Convert `ds` to month labels (e.g. `"20250531"` → `"2025-05"`).

> ⚠️ **口径待确认**: `idx_12m_` 前缀字段在底表中定义为归一化指数（范围 0–10000，基于过去 12 个月的 min/max），而非常规"滚动均值"。相邻月份值可能完全相同（如连续 4 个月 `1515.96`）——这是指数归一化到固定 scale 后的正常行为，**不是数据造假**。DA 正在确认精确计算公式。当前使用时应关注**趋势方向**而非绝对值。

**Axis rule — conditional, NOT always dual-axis**: First compute the max of the country series and the max of the global GGS series. Then:
- If the two maxima differ by **more than one order of magnitude (≥10×)** → use **dual Y-axes** so the smaller series isn't flattened.
- If they are the **same order of magnitude** (the common case — observed in both TW Cycling and VN Fresh Fruit, where country PV ≈ 4000–7800 and global GGS PV ≈ 5700–7900) → use a **single shared axis**. Forcing dual axes here visually inflates the client's small market up to the global benchmark line, which is misleading and a client can spot it.

⚠️ **imps latest-month trap**: the `idx_12m_imps_shop_30d` series is systematically broken for the most recent 1–2 snapshots — it collapses to a near-zero value (~18–52) while every earlier month sits at ~5000–8000. Observed in both samples (TW: latest month = 18; VN: latest two months = 40/38). The `shop_pv` and `ab_cnt` series for those same months are normal — only `imps` is affected. If you chart impressions, **drop the incomplete trailing month(s)** (any imps value that is <10% of the prior month's, when surrounding pv/ab look normal) or omit the imps series entirely. Never render the raw imps tail — it draws a fake "exposure collapse" cliff.

**Narrative angle**: focus on **trend slope**. Is the client's country growing faster than the platform average? Compute and call out per-period growth, not just absolute numbers.

**Skip if**: fewer than 4 monthly rows returned, or all `idx_12m_shop_pv_30d` values are 0.

### Sub-section B: Buyer Country Distribution

**Data source**: `ggs-crm crm-industry-buyer-country` (lv3→lv2→lv1→skip fallback applies — see "Empty-data fallback" above).

**Raw CRM response shape**:

```json
{
  "data": {
    "total": 5,
    "values": [
      {
        "byr_country_id": "KW",
        "idx_12m_shop_pv_30d": "2000.0",
        "idx_12m_shop_pv_30d_yoy": null,
        "main_cate_lv1_desc": "Food & Beverage",
        "main_cate_lv2_desc": "Dairy Products"
      },
      {
        "byr_country_id": "PK",
        "idx_12m_shop_pv_30d": "0.0",
        "idx_12m_shop_pv_30d_yoy": "-99.66%",
        ...
      },
      // ...
    ]
  }
}
```

**Field meanings**:

| CRM field | Use as | Notes |
|---|---|---|
| `byr_country_id` | Country code (ISO 2-letter) | Convert to display name in the deck's language (e.g. `"KW"` → `"科威特"` / `"Kuwait"`). |
| `idx_12m_shop_pv_30d` | Buyer-country IPV | **Absolute value, not a percentage.** String, parse to float. |
| `idx_12m_shop_pv_30d_yoy` | YoY growth | **String with `%` suffix or `null`** (e.g. `"-99.66%"`, `null`). Parse the percent or skip the YoY column for that row. |

**Important — there is NO `share` percentage field in the CRM response.** Earlier versions of this document described a `share` field; that was wrong. Display the absolute IPV value. If you want a horizontal bar, scale each bar's width relative to the largest value in the result set (the top country becomes 100% width).

**Sorting**: sort `values` by `idx_12m_shop_pv_30d` descending. Drop rows where IPV is 0 — they have no signal.

**Noise filtering (client-ready, not just "non-zero")**:
- The CRM returns a long tail of micro-markets that are statistically real but commercially meaningless for a client deck. Observed (VN Fresh Fruit): the top non-zero rows included **South Sudan (SS), Somalia (SO)** alongside Spain/Malaysia. Surfacing "South Sudan is a top growth market for your fruit" damages credibility.
- After dropping 0-IPV rows, **keep at most the top 5–6 by IPV**, and prefer markets that are plausible buyers for the client's product (major economies / known import hubs). When a tiny-base market only ranks because of a small absolute index, drop it.
- **Huge YoY values are usually small-base artifacts, not stories.** Observed YoY up to `+1741%`, `+1838%` on markets with low absolute IPV. Do **not** headline a `+1800%` figure — it reads as fabricated. Only call out YoY when the country also has non-trivial absolute IPV. A large *negative* YoY on a country with real residual IPV is still a legitimate "structural demand exists" angle (see below); a large *positive* YoY on a near-zero base is noise.

**Best practices**:
- Show **the rows with non-zero IPV**, sorted descending, after the noise filter above. `total`/`values` length varies (observed 13–17 rows) — count `values.length`, never `total`.
- A country with **non-trivial PV but very negative YoY** (e.g. `-99.66%`) is a story in itself — call it out in the AI summary as an opportunity (the buyer base used to be larger; the demand still exists structurally).

### Skip behavior for Chapter 04

- If `traffic_trends` is empty after the full fallback chain → skip just that sub-section.
- If `buyer_analysis` returns 0 rows or all rows have `idx_12m_shop_pv_30d = 0` → skip that sub-section.
- **If both empty → skip the entire Industry Outlook chapter** (no section divider, nothing).

### Tone

Insight-flavored. Annotate one observation per chart. *"Buyers from US and Germany account for 47% of demand — strong fit for FOB exporters."* Never just "data dump" a chart.

### Translation

Translate section titles, ai_summary, axis titles, legends. Do not translate country names, numbers, percentages, month labels, or "IPV"/"GGS".

---

## Chapter 05: Trending Product Insights

**Purpose**: Hyper-specific value. Show what buyers are searching for in the client's category right now. Often the **most actionable chapter** for a manufacturer.

**Data source**: `ggs-crm crm-industry-product` (lv3→lv2→lv1→skip fallback applies — see "Empty-data fallback" above).

**Strongly recommended**: post-process raw CRM output with `scripts/map-crm-product.js`. The CRM response uses different field names (`prod_name`, `main_img_url`, `leaf_category_name`, `high_demand_visitor_cnt`, etc.) than the deck-friendly schema, and the image URL field is easy to drop during hand-mapping — causing all product thumbnails to render broken.

```bash
cd <SKILL_DIR>
node scripts/map-crm-product.js --input <RUN_DIR>/crm-industry-product.json --output <RUN_DIR>/trending.json
```

### Raw CRM response shape

The CRM response top-level structure:

```json
{
  "success": true,
  "data": {
    "total": 0,
    "values": {
      "topSearchProducts":   [...],
      "highGrowthProducts":  [...],
      "highDemandProducts":  [...]
    }
  }
}
```

**Note on `total: 0`**: the top-level `total` field can be 0 even when the three product arrays inside `values` have rows. **Don't treat `total: 0` as "empty"** — check the three arrays directly.

Each array has slightly different fields:

#### `topSearchProducts[]` (top hot keywords)

| Field | Type | Meaning |
|---|---|---|
| `prod_name` | string | Product name |
| `main_img_url` | string | Product thumbnail URL |
| `prod_detail_url` | string | Alibaba.com product detail page (use for the "view details" link if needed) |
| `top3_hot_kw` | string | Top 3 hot keywords, pipe-separated (e.g. `"food\|milk\|ice cream"`) |
| `idx_12m_imps_cnt_30d` | string | Impressions index — parse to float |
| `country` | string | Country code |

#### `highGrowthProducts[]`

| Field | Type | Meaning |
|---|---|---|
| `prod_name` | string | Product name |
| `main_img_url` | string | Product thumbnail URL |
| `prod_detail_url` | string | Detail page URL |
| `high_growth_received_gmv` | string | Growth GMV — parse to float |
| `country` | string | Country code |

#### `highDemandProducts[]`

| Field | Type | Meaning |
|---|---|---|
| `prod_name` | string | Product name |
| `main_img_url` | string | Product thumbnail URL |
| `prod_detail_url` | string | Detail page URL |
| `high_demand_visitor_cnt` | string | Demand visitor count — parse to float |
| `country` | string | Country code |

### Image URL handling — never edit

`main_img_url` is the **only source of truth** for product images. The URL must be:
- **Copied verbatim** from the raw JSON
- **Never modified, never typed by hand** (case-sensitive, hash-like; one wrong character = 404)
- **Never invented** — if the CRM didn't return a URL for a row, leave the image cell empty or skip the row

⚠️ **`main_img_url` presence is category-dependent — sometimes present on every row, sometimes absent on the whole response.** Observed: VN Fresh Fruit returned `main_img_url` on *every* product row; TW Cycling returned *no* image field at all on any row. Both are valid responses. So:
- **When present** → preserve verbatim, this is exactly why `map-crm-product.js` exists.
- **When the entire response has no image field** → this is NOT a render bug and NOT grounds to fabricate. Fall back to the **text-only variant** of the sub-section (see "Image rules" below). The QA visual-integrity check explicitly exempts text-only sub-sections whose CRM source carried no image field.

Use `scripts/map-crm-product.js` to auto-map; manual mapping has historically dropped or mistyped URLs.

The CLI may emit a Python warning line on stderr; if you parse stdout, strip everything before the first `{`.

### Mapped sub-section structure (after `map-crm-product.js`)

> **Reality check (validated against live responses):** the CRM returns **only** the fields documented in the three per-array tables above. There is **no** `search_idx`, `click_idx`, `ctr`, `supply_idx`, `opportunity_index`, `demand_idx`, `category`/`leaf_category_name`, or `yoy` field anywhere in the response. Do not reference, compute, or display them. Map only what exists.

Each sub-section in the deck-friendly schema looks like:

```json
{
  "items": [...],
  "data_source": "Data source: Alibaba.com Platform Analytics, <month year>",
  "data_note": "<optional italic explanatory line>",
  "ai_summary": "<≤100 word positive narrative>"
}
```

Three sub-sections map 1:1 from the three CRM arrays:

#### `hot_categories.items[]` ← `topSearchProducts[]`

> ⚠️ **Naming caveat**: the sub-section key is historically `hot_categories`, but `_meta` defines `topSearchProducts` as **"热搜商品列表" (hot-search *products*), not categories.** Each row is a product carrying its top-3 hot keywords. Present it as "top searched products / hot keywords," not as a category ranking. (Renaming the key is out of scope here — just don't mislabel it in client copy.)

| Field | Source CRM field | Meaning |
|---|---|---|
| `rank` | (position) | 1–N |
| `keywords` | `top3_hot_kw` | `_meta`: Top3 热搜关键词（竖线分隔）. **The real signal of this array** — display as keyword chips, not a fake "category" label. |
| `name` | `prod_name` | `_meta`: 商品名称 (sanitize per rules below). |
| `image` | `main_img_url` | `_meta`: 商品主图 URL. Only when `has_images: true`. |
| `imps_idx` | `idx_12m_imps_cnt_30d` | `_meta`: 过去12个月商品月度曝光指数. Parse to float, round for display. The only numeric metric this array carries. |

#### `high_growth.items[]` ← `highGrowthProducts[]`

| Field | Source CRM field | Meaning |
|---|---|---|
| `rank` | (position) | 1–N |
| `name` | `prod_name` | Product name (sanitize). |
| `image` | `main_img_url` | Remote URL. |
| `gmv` | `high_growth_received_gmv` | `_meta`: 高增长商品的收款金额（**美元**). **The one real signal of this array — must be mapped and displayed**, USD, no ÷7.2. See "GMV display" below. |

#### `high_demand.items[]` ← `highDemandProducts[]`

| Field | Source CRM field | Meaning |
|---|---|---|
| `rank` | (position) | 1–N |
| `name` | `prod_name` | `_meta`: 商品名称 (sanitize). |
| `image` | `main_img_url` | `_meta`: 商品主图 URL. |
| `demand_cnt` | `high_demand_visitor_cnt` | `_meta`: 高需求商品的访客数. Parse to float. The real demand signal here. |

### GMV display (`high_growth.items[].gmv`)

`high_growth_received_gmv` is already in USD (no RMB conversion). Observed range in one response: `0.0` up to `19580.0`, highly skewed.
- Drop rows where `gmv == 0` (no signal).
- Desensitize like other amounts: `>=1000` → `~{round/1000}K` (19580 → "~20K"); `<1000` → show rounded (`150.01` → "~$150").
- The values are skewed — do **not** put a tiny-GMV row next to a `~20K` row implying parity. Sort descending by `gmv` and show the top rows; lead the narrative with the strongest one.

### Demand signal (no supply field exists)

The CRM does **not** return any supply/listings index, so the old "demand ÷ supply ratio" is **not computable — remove it from any narrative.** Use the absolute signals each array actually provides: `demand_cnt` (high_demand), `gmv` (high_growth), `imps_idx` (hot_categories). Compare *within* an array (rank order), not across fictional ratios.

### Image rules

Thumbnails are remote HTTPS URLs from Alibaba CDN. Render as `<img src="https://..." style="width: 24pt; height: 24pt;">`; `render-deck.py` handles inlining.

- **Single row missing image, others present** → render a small gray square placeholder for that row (don't drop it — the data is still meaningful).
- **Whole sub-section / whole response has no image field** (e.g. the TW Cycling case) → switch that sub-section to the **text-only variant** (product name + keywords/metric, no image column). This is the sanctioned degraded layout — it is **not** a QA failure. Set `has_images: false` so the renderer and the QA visual-integrity check both treat it as text-only-by-design rather than "broken cards."

### Product filtering & sanitization (client-ready, run before composing)

The raw arrays contain rows that are statistically valid but **embarrassing on a client deck**. Apply in order:

1. **Drop zero-signal rows**: `high_demand_visitor_cnt == 0`, `high_growth_received_gmv == 0`, or `idx_12m_imps_cnt_30d == 0`. (Observed: a "high-demand" juice with 0 visitors; "high-growth" products with 0 GMV.)
2. **Drop category-bleed rows**: the lv2 leaf is loose, so off-category items leak in. Observed under "Fresh Fruit": bottled **juice drinks** (`350ml ... Juice Drink`, `Sparkling ... Juice`), **frozen/IQF** items, and **foreign-origin** products (`Australia Fresh Seedless Grapes` in a VN query). Keep only rows whose `prod_name` is plausibly the prospect's lv2/lv3 product; drop processed/beverage/foreign-origin items unless the prospect actually sells them.
3. **Sanitize `prod_name` before display** (do this, despite the general "verbatim" rule — that rule is about not *rewriting meaning*, not about leaking junk):
   - **Strip trailing seller contact strings**: phone / WhatsApp numbers and `W/A:`, `WA`, `_WA`, bare `0084…`/`+84…` tails. Observed: `"... VIETNAM FRESH W/A: 0084909740687"`, `"... _WA84972678053"`, `"... 0084947900124"`. These leak a third party's contact info and look like spam.
   - **Demote promo-noise titles**: rows whose name leads with `CHEAP`, `BEST SELLER`, `Flash Sale`, `FREE SAMPLE`, etc. — either trim the promo word or prefer a cleaner row for the same keyword. `"CHEAP PRICE FRESH BANANA"` undercuts a premium-positioning deck.
   - Keep the core product description intact; only remove contact tails and leading promo shouting.
4. After filtering, if a sub-section drops below ~3 usable rows, treat it as empty and skip that sub-section.

### YoY coloring

Where a signed percentage is shown, positive → green (design-tokens positive color), negative → red. Don't display ambiguous black numbers when the sign matters. (Note: the product arrays carry **no** YoY field — this applies only where a signed value genuinely exists, e.g. buyer-country YoY.)

### Skip behavior

If a sub-section's `items` array is empty after the full fallback chain → skip just that sub-section. If all 4 sub-sections are empty → skip the whole Trending Products chapter.

### Tone

Actionable. Lead each table/section with a **1-sentence summary** of what the data means for the client. *"Top opportunities for <country> sellers right now: outdoor furniture and acacia-wood OEM."*

**Never fabricate** keyword or product data. If a sub-table has no data, don't fill it with plausible-sounding made-up keywords.

### Translation

Translate section titles, column headers, ai_summary, data_source prefix, data_note. Do not translate numbers, percentages, ranks, image URLs, or keyword chips (`top3_hot_kw` content).

---

## Chapter 06: Active Buyer Demand

**Purpose**: Demand is real and it's now. Show the prospect that **specific overseas buyers in their industry are actively sending purchase inquiries this week** — the most concrete proof that joining the platform yields opportunity, not just exposure.

This chapter pairs with Chapter 05 (what buyers search for) and Chapter 04 (where buyers come from) to complete the "supply meets demand" arc: 04 shows the macro market, 05 shows the product appetite, 06 shows the actual purchase requests happening *right now*.

**Data source**: `ggs-crm crm-rfq-query -t <token> -i <cate_id>`. Accepts lv1 / lv2 / lv3 cate-id; fixed 5-day window (no date parameters).

**Fallback**: lv3 → lv2 → lv1. If lv1 returns `total:0`, **skip the chapter** — the fallback chain at the top of this document applies, but with the caveat that "no recent RFQs in a narrow category" is **common and expected** (RFQs are sparse for niche industries). Do not over-fallback to unrelated neighboring industries — better to skip than to show RFQs that have nothing to do with the prospect's business.

### Raw CRM response shape

```json
{
  "success": true,
  "data": {
    "success": true,
    "total": 5,
    "values": [
      {
        "rfq_id": "<rfq_id>",
        "rfq_name": "<product / inquiry title>",
        "rfq_detail_desc": "<buyer's detailed request, free text>",
        "req_qty": "<numeric string>",
        "req_qty_unit": "<unit string, e.g. MT, Piece/Pieces>",
        "country_cn_name": "<Chinese country name>",
        "crt_time": "<YYYY-MM-DD HH:MM:SS>",
        "cate_id": "<category id>",
        "cate_desc": "<category description, may include parenthetical suffix>"
      }
    ],
    "dateline": 1778505004941
  }
}
```

### Fields per RFQ card

| CRM field | Use as | Notes |
|---|---|---|
| `rfq_name` | Card title (product / inquiry name) | Display verbatim — no rewriting, no translation embellishment |
| `req_qty` + `req_qty_unit` | Quantity line | Concatenate as `"<qty> <unit>"`. Units arrive in varied forms (e.g. "MT", "Metric Ton/Metric Tons", "Piece/Pieces") — preserve the CRM value, don't normalize across cards |
| `country_cn_name` | Buyer country tag | CRM returns **Chinese country name** (e.g. `肯尼亚`, `加拿大`, `中国台湾`). Translate to deck language. See "Country name translation" below |
| `crt_time` | Inquiry date | Format `YYYY-MM-DD HH:MM:SS` — display only the date portion (`YYYY-MM-DD`), drop the time |
| `rfq_detail_desc` | Body / expandable detail | Long free text. Show first ~120 chars or first sentence; rest collapsed. Display verbatim — see "Detail description handling" below |
| `cate_desc` | (Optional) chapter footnote | If the cate_desc resolved via fallback differs from the prospect's exact category, it can clarify scope in a small footnote; never on each card |
| `rfq_id` / `cate_id` | **Do not display** | Internal identifiers — see "Privacy rules" below |

### Card design — RFQ card

Top-line summary above the cards (one sentence):
> "Over the past 5 days, X buyers worldwide have posted RFQs in this category — including the following:"

(Translate to deck language. X = number of cards actually shown.)

Then **N cards**, each:
- **Title**: `rfq_name` (product / inquiry name)
- **Meta row** (one line): `<quantity> <unit> · <buyer country> · <date>`
- **Body**: truncated `rfq_detail_desc` (first sentence or ~120 chars) + "..." if cut off

Visual treatment: simple framed cards, no buyer logos (RFQs are anonymous — there is no logo). A small icon (e.g. envelope or shopping-cart) suggests an "incoming inquiry"; not a company.

### Sorting and limits

- **Sort**: descending by `crt_time` (newest first)
- **Show count**:
  - 3 ≤ `total` ≤ 5: show all
  - `total` > 5: show top 5 only
  - `total` < 3: **skip the chapter** (insufficient signal — three RFQs is the minimum "this is a pattern, not a fluke" bar)
  - `total` = 0 after lv3→lv2→lv1: skip the chapter

### Country name translation

The CRM returns `country_cn_name` in Chinese (`肯尼亚`, `加拿大`, `中国台湾`, etc.). The deck might be in English / Vietnamese / Korean / etc.

- English deck → translate to standard English country name ("Kenya", "Canada", "Taiwan, China")
- Vietnamese / Korean / other localized decks → translate to that language's standard country name
- **For "中国台湾"**: render as `Taiwan, China` in English; do not shorten to `Taiwan` alone (regional naming convention applies to all Alibaba materials)
- Never display the raw Chinese country name in non-Chinese decks

### Detail description handling

`rfq_detail_desc` is buyer-authored free text. It may contain:
- Long-form specifications
- Encoding artifacts (e.g. mojibake from buyer-side character-set mismatches)
- Phrases like "Looking for verified manufacturer", certification requirements, sample requirements

**Rules**:
- Display verbatim — do **not** clean up encoding artifacts (this is the buyer's actual words; rewriting risks distortion)
- Do **not** translate the detail body into the deck language, even if the deck is non-English. The buyer's request stands on its own; translating it makes it look fabricated. If the deck audience needs a translation, add it as a separate UI affordance (tooltip / footnote), not by replacing the original
- Do **not** rewrite or summarize for "clarity" — buyer terminology is part of the signal
- If you must truncate for layout, truncate at a sentence boundary and append `…`; do not invent a summary

### Privacy rules

RFQs on Alibaba.com are **anonymous to suppliers** — the buyer's identity is intentionally not disclosed pre-engagement. Therefore:

- **Never** display `rfq_id` anywhere in the deck (it is an internal identifier that could be used to reverse-lookup the buyer profile)
- **Never** infer or claim buyer identity from `rfq_detail_desc` even if the description seems to leak hints (e.g. "We are XYZ Trading, a leading...") — what the buyer wrote in detail_desc is their disclosure choice for *engagement*, not for republication in a sales deck
- **Never** present the RFQ as "an inquiry from [Country Name] sent to [prospect's company]" — RFQs are platform-broadcast, not addressed to any specific seller
- Frame as "buyers are searching", "demand is being expressed", "the market is asking" — not as "this person wants to buy from you"

### Skip behavior for Chapter 06

Skip Chapter 06 entirely if any of:
- `total: 0` after lv3→lv2→lv1 fallback
- `total > 0` but `total < 3`
- RFQ data exists but none of the rows have a meaningful `rfq_name` (defensive — should not happen)
- API failure / network error after retries

When skipped, renumber subsequent chapters per the global Skipping rules (e.g. if 06 is dropped, 07 Benchmarks becomes 06 in display, 08 Action Plan becomes 07).

### Tone

Factual, present-tense, present-the-evidence. Don't oversell — the data is doing the work. Examples:

- ✅ "Three buyers across multiple countries have posted RFQs in this category over the past 5 days. The market is actively sourcing right now."
- ✅ "*Quantity, country, date* — these are real inquiries currently on the platform."
- ❌ "Look at all this demand!" / "Buyers are desperate for suppliers!" — overselling undermines the data's credibility
- ❌ "If you join Alibaba.com today, you can win these deals" — direct call-to-action belongs in Chapter 08 (Action Plan), not here

### Translation

Translate section title, top-line summary, card field labels (e.g. "Quantity", "Buyer country", "Inquiry date"), and any chapter narrative.

**Do not translate**:
- The `rfq_name` (product / inquiry title)
- The `rfq_detail_desc` body (per "Detail description handling" above)
- Numbers and units within quantities (e.g. "56 MT" stays "56 MT")

---

## Chapter 07: Industry Leaders & Benchmarks

**Purpose**: Competitive pressure. *"Your peers are already on this platform and winning."*

**Data source**: `ggs-crm crm-industry-benchmark` (lv3→lv2→lv1→skip fallback applies — see "Empty-data fallback" above).

### Raw CRM response shape

```json
{
  "data": {
    "total": 1,
    "values": [
      {
        "comp_name": "Vietnam Dairy Products JSC",
        "comp_url": "http://vinamilkofficial.trustpass.alibaba.com",
        "country_id": "VN",
        "main_cate_lv1_desc": "Food & Beverage",
        "main_cate_lv2_desc": "Dairy Products",
        "main_cate_lv3_desc": "Milk",
        "main_cate_lv4_desc": "Yogurt",

        "shop_pv_180d":         "9317",
        "shop_uv_180d":         "3654",
        "oversea_ab_cnt_180d":  "290",
        "valid_prod_cnt":       "635",
        "good_prod_cnt":        "38",
        "prod_rel_cnt_180d":    "10",
        "ma_login_days_180d":   "64",
        "avg_reply_time_180d":  "5.127323791666666",
        "duv_ab_rate_180d":     "0.07936507936507936",
        "cpab_180d":            "3.3904724896678213",
        "prepay_mord_cnt_180d": "0",

        "rcvd_amt_180d":   "0.0",
        "p4p_cost_180d":   "0.0",
        "total_cost_180d": "983.2370220036682"
      }
    ]
  }
}
```

### Fields per peer

| CRM field | Display as | Notes |
|---|---|---|
| `comp_name` | Peer name | **Apply masking before display.** Never show the real name in client-facing decks. See "Masking — non-negotiable" below. |
| `comp_url` | (don't display) | For AI reference only. |
| `country_id` | (don't display) | The peer's country (often same as the target country). |
| `main_cate_lv2_desc` / `lv3_desc` / `lv4_desc` | Profile bullet (conditional) | ⚠️ Peers are filtered at **lv2 only**, so `lv3`/`lv4` can describe a *completely different* business (see "Peer relevance filter" below). Only write "Specializes in {lv2} — {lv3}/{lv4}" when lv3/lv4 are consistent with the prospect's category. If lv3/lv4 are off-category (e.g. Animal Feed / Bamboo / Rice under a Fresh Fruit lv2), **omit the lv3/lv4 bullet** and describe the peer by its storefront metrics instead. |
| `shop_pv_180d` | Storefront highlight | "{N} storefront page views in the last 180 days" |
| `shop_uv_180d` | Storefront highlight | "{N} unique visitors in 180 days" |
| `oversea_ab_cnt_180d` | Profile bullet | "{N} active overseas buyers in 180 days" |
| `valid_prod_cnt` | Core strategy bullet | "{N} active SKUs" |
| `good_prod_cnt` | Core strategy bullet | "{N} of those rated as 'good'" |
| `prod_rel_cnt_180d` | Profile bullet | "{N} new products released in the last 180 days" |
| `ma_login_days_180d` | Profile bullet | `_meta`: 近180天登录天数 — "{N} login days in the last 180 days", an indicator of how actively the storefront is managed. (`ma` prefix not expanded in meta.) |
| `avg_reply_time_180d` | Storefront highlight | Hours; round to 1 decimal. "{X} hr average reply time". **This is the arithmetic mean** (sum ÷ count), not median. |
| `duv_ab_rate_180d` | Visitor→buyer conversion rate | `_meta`: 访客转化为买家的转化率. Range 0–1, e.g. `0.079` ≈ 7.9% of visitors became active buyers. (The `duv` prefix is not expanded in the meta — don't assert "Daily Unique Visitor"; just call it visitor→buyer conversion.) |
| `cpab_180d` | Cost Per Active Buyer (USD) | `_meta`: 获客成本，每活跃买家花费，**美元**. Equals `total_cost_180d ÷ oversea_ab_cnt_180d`. Display as `~$X/AB` (no ÷7.2). Lower = more efficient. |
| `prepay_mord_cnt_180d` | (use sparingly) | Prepay order count in last 180 days. Often 0; skip when zero. |
| `rcvd_amt_180d` | Received amount, 180d (USD) — frame carefully | `_meta`: 收款金额，**美元**. Observed small ($0–$3,112 over 180d) even for peers with 1,500–4,000 buyers. **The meta does not say what's included**; a likely reason it's small is that it captures only on-platform settled/escrow orders while most B2B settles off-platform — but that is a **hypothesis (DA to confirm), not stated by the meta.** So: you may show it as "platform-recorded order value," but **do NOT assert it is the peer's total revenue/business volume**, and don't label it "Trade Assurance" as fact. Skip when 0. |
| `total_cost_180d` | Total platform spend, 180d (USD) | `_meta`: 总花费，**美元**. Display in USD, no ÷7.2. Annualize ×2 if you want a yearly figure, then desensitize (e.g. 1051 → ~$2K/yr). |
| `p4p_cost_180d` | P4P + 聚量 ad spend, 180d (USD) | `_meta`: P4P 直通车花费，**美元**. Same handling as `total_cost_180d`. Skip the line when 0. |

### Masking — non-negotiable

`comp_name` MUST be masked before display, in **every** deck, **every** time. There are no exceptions. "Well-known industry leader" is **not** an exception. "Public company" is **not** an exception. "Real name needed for credibility" is **not** an exception.

The masking algorithm is in the "Common Conventions" section above (see "Company name masking" + the worked-examples table). Apply it deterministically by counting length first:

- `Viet Seafarm` (12 chars) → `Vie***farm` (9–16 rule: first 3 + last 4)
- `Vietnam Dairy Products JSC` (26 chars) → `Viet***s JSC` (>16 rule: first 4 + last 5)
- Exact format depends on length; follow the table, not your eye.

If you find yourself reasoning *"this is a well-known company so I'll show the real name"* — STOP. That reasoning is not in this document. Mask it.

### Peer count

- The CRM may return as few as **1 peer** (`total: 1`) or as many as several. Earlier versions of this document said "2–5 peers"; the real range is "0 or more, depending on industry coverage".
- **1 peer**: render as a single peer card. The chapter is still valuable.
- **2–5 peers**: stack as multiple cards.
- **6+**: truncate to top 5 (the CRM order is already by relevance).
- **0**: skip the chapter.
- Count peers by `values.length`, not `total` (observed mismatch elsewhere; don't trust `total`).

### Peer relevance filter (run before rendering cards)

Peers are matched at **lv2 only**, so the result set can include companies whose actual business (lv3/lv4) is unrelated. Real example (VN, lv2 = Fresh Fruit) returned 7 peers whose lv3/lv4 were: Fresh Citrus, Fresh Coconuts, Other Fresh Fruit — **but also Animal Feed, Rice, Bamboo Raw Materials, and one company (`comp_name` = a pharmaceutical JSC) tagged Bamboo.** Showing a pharma/feed/bamboo company as a "Fresh Fruit benchmark" to a fruit prospect is wrong and a client will notice.

Rule:
1. Prefer peers whose `lv3_desc`/`lv4_desc` are consistent with the prospect's category. Rank those first.
2. For peers retained only on lv2 match but with off-category lv3/lv4 → keep at most as filler, **omit their lv3/lv4 profile bullet**, and describe them purely by storefront metrics (PV/UV/overseas buyers/SKUs/reply time).
3. If *every* returned peer is off-category, prefer to show the 1–2 closest and lean on metrics, or fall back to the Regional Benchmarks; never assert an off-category company "specializes in {prospect's category}".

### Cost fields are USD — do NOT divide by 7.2

The benchmark cost fields are documented in the tool `_meta` as **USD already** (每…花费/金额，美元). The old rule that divided them by 7.2 (treating them as RMB) was wrong and shrank every cost ~7.2×.

Validation against live VN data, **read correctly as USD**:
- `Viet Seafarm`: `total_cost_180d` = **$1,051 / 180 days** → annualized ×2 ≈ **~$2K/yr**; `cpab_180d` = 1051 ÷ 1520 = **~$0.69 per active buyer** (already USD, no further math). These are plausible, displayable figures.
- `MEDIPHARCO …`: `total_cost_180d` ≈ **$1,844 / 180d** (~$3.7K/yr), `p4p_cost_180d` ≈ **$808**, `cpab` ≈ **$0.46/AB**.

Rules:
1. **Display these in USD verbatim — no ÷7.2.** Desensitize per the "Amount desensitization" rule (e.g. `1844 → ~$2K`).
2. `cpab_180d` is already USD/active-buyer — show as `~$0.69/AB`; lower = more efficient. It is a real, citable number.
3. `total_cost_180d` / `p4p_cost_180d` are 180-day USD. To show an annual figure, annualize ×2 (≈360-day approximation; the 365/180 ≈ 2.028 refinement is a precision nicety, not a blocker). Skip any line whose value is 0 (e.g. most `p4p_cost_180d` are 0).
4. **`rcvd_amt_180d` is "收款金额（美元）" per meta — a USD received-amount figure.** It looks small; the escrow-only explanation is a hypothesis, not meta. Show it (if at all) as "platform-recorded order value," never as the peer's total revenue. Skip when 0.
5. ⚠️ **Cross-chapter consistency (QA Check 2)**: `total_cost_180d` is the peer's *own platform spend* (~$2–4K/yr), which is a different thing from a *GGS membership tier price* quoted in Optional Chapter B. If both appear, label them distinctly so they don't read as a contradiction; for any price quoted *to the prospect*, the source of truth is `ggs-sales-knowledge-base`.

### `roi_takeaways` writing rules

The `roi_takeaways` paragraph is **AI-generated**, not a CRM field. Write 50–80 words synthesizing:
- Open with the peer's strongest signal (high `oversea_ab_cnt_180d`, high `valid_prod_cnt`, fast `avg_reply_time_180d`, strong `duv_ab_rate_180d`).
- 2–3 specific insights tied to numbers. Use `duv_ab_rate_180d` (visitor-to-buyer conversion) and `cpab_180d` (cost per active buyer, **USD** — cite the figure, e.g. "~$0.69/buyer") as efficiency signals. `rcvd_amt_180d` only as a platform-recorded order value, never as total revenue.
- Close with one actionable recommendation for the client.

Tone: analytical but constructive. **Forbidden framing words**: `threat`, `danger`, `beat`, `destroy`. Frame everything as `learning opportunity`, `best practice`, `benchmark`.

Numbers must be from CRM data — never fabricate them.

### Tone

Specific and slightly competitive. *"With 290 active overseas buyers and 635 active SKUs, this peer demonstrates a deep catalog strategy."* beats *"did well"*.

### Translation

Translate section title, subtitle prefix ("Peer:"), all card labels, card body, and any cost/cooperation labels. Do **not** translate the masked peer name (it's already masked) or numbers. Use language-appropriate amount format (Chinese "约2千" / English "~$2K").

---

## Chapter 08: Your Action Plan

**Purpose**: Tell the client exactly what to do next. The whole deck has earned the right to give this advice.

**Data source**: LLM-generated based on synthesis of all earlier chapters. **Not from CRM.**

### Fields

```json
{
  "action_plan": {
    "subtitle": "<optional, defaults to 'Recommended next steps for {company_name}'>",
    "steps": [
      { "title": "<4–7 word title>", "description": "<1–2 short sentences explaining why>" }
    ]
  }
}
```

- `subtitle`: optional. If omitted, default to `"Recommended next steps for " + company_name`.
- `steps`: empty array → skip the chapter entirely.
  - Recommended: **4 steps**.
  - >6 steps: feels crowded; trim or split.

### Authoring rules

- **Tailor to this specific client**, drawing on earlier chapters. *"Given your strong outdoor furniture line (SWOT) and the 47% US buyer share (Outlook), prioritize Q1 listings optimized for US buyers."*
- Each step is a **concrete action**, not a vague suggestion. *"Open a Gold Supplier Storefront"* — good. *"Improve marketing"* — too vague.
- `description` explains the **why** (expected outcome / business value), not just restate the title.
- `title` 4–7 words. `description` 1–2 short sentences.
- Order steps by **sequence or priority** (most important / earliest first).

### Tone

Imperative but supportive. *"Open a Gold Supplier storefront"* beats *"Consider exploring premium tier options"*.

### Localization

`STEP NN` label is localized per output language. **Write step titles and descriptions directly in the target language** — don't generate in English and post-translate. Native-language phrasing reads more naturally.

---

## When the client asks for data the CRM doesn't return

The current 5 CRM tools cover **buyer traffic + buyer countries + trending products + benchmark peers + success stories**.

For requests like:
- Number of sellers in the same industry by lv1/lv2/lv3 category
- Buyer count broken down by category (not country)
- Buyer level (L1+ / L3+ membership tier) breakdown
- Trade Assurance adoption rate / TA-specific YoY growth
- Top sellers by region (Asia, EU, etc.) with traffic ranking
- Minisite (storefront) traffic comparison across regions

These are not currently exposed by `ggs-crm`. Three options:

1. **Web search** for publicly available platform stats (Alibaba investor reports, industry articles).
2. Tell the user this data isn't available in current CRM tools; ask if they want to skip that section or supply data directly.
3. Forward the request to the GGS data team to add to a future CRM tool.

Never invent numbers to fill these gaps.

---

## Regional Industry Benchmarks (Fallbacks)

Use these verified data points as grounding when CRM data is unavailable for these specific regions/industries.

### Vietnam (VN) - Electrical & Construction
- **Avg. Reply Time**: ≤ 6 hours (Gold Supplier standard).
- **Market Growth (2026)**: ~533% YoY inquiry growth in the Electrical Supplies category for early 2026.
- **Top Local Peers (Reference)**: Lioa (Stabilizers/Accessories), Cadivi (Cables), Hoa Phat (Construction/Steel), Techviet (Electronics).
- **Success Patterns**: From local distributor to 25+ country exporter via digital storefront and Trade Assurance.

---

## Optional Chapter A: Same-Country Supplier Gap (供给侧缺口)

**Purpose**: Show the prospect how crowded (or empty) their domestic competitive field is on Alibaba.com. A "low/zero same-country supplier" finding is one of the strongest sales hooks.

**When to include**: Optional. Recommended when (a) the prospect is in an export-promotion country (VN, ID, IN, TR, etc.) AND (b) CRM data shows < 50 same-country suppliers in the lv2 leaf category.

### Data source — strict rules

- **MUST come from CRM**. Acceptable tools: `crm-industry-benchmark` (peer count), or any future `industry-supplier-stat` endpoint.
- **MUST NOT come from web-search keyword reverse-counting** (e.g. "搜索 'led light vietnam' 出来 0 条 → 0 个供应商"). This method produces false positives because of category mapping, language, and pagination noise — it has been explicitly banned.
- If CRM returns 0 same-country peers, do not present "0 competitors" as a literal claim. Use language such as "Alibaba.com has not yet indexed any Gold Supplier in {country} for {lv3_category} — first-mover window is open."

### Display rules

- Single number (peer count) + 1-line interpretation.
- Side-by-side comparison: Same-country peers vs. Global GGS peers in same lv2 (if both available from CRM).
- Forbidden: any claim of "唯一" / "the only" / "sole" — Alibaba.com indexing ≠ market-wide supplier count.

### Skip behavior

If CRM peer endpoint is empty AND no `industry-supplier-stat` data → **skip the chapter entirely**. Do not fall back to web search.

---

## Optional Chapter B: Trade Show vs Alibaba.com (会展对比)

**Purpose**: Reframe the prospect's prior trade-show spend as ROI argumentation for the platform. Particularly effective when the user's CRM tag indicates "EuMW", "Canton Fair", "VietBuild" or similar event participation.

**When to include**: Optional. Trigger when the prospect has any documented offline-show participation (CRM `customer-info` tags, web search, or user input).

### Required structure (3-column comparison table)

| Dimension | Traditional Trade Show | Alibaba.com |
|---|---|---|
| Cost (per year) | Booth fee + travel + materials, typically $20K-100K | $X starting (use real GGS membership tier) |
| Buyer exposure days | 3-5 days per event | 365 days |
| Avg. leads per event | 30-200 (manual collection) | RFQ + IPV-driven; CRM benchmark applies |
| Geographic reach | Visitors physically on-site | 200+ buyer countries |
| Follow-up | Manual, slow | TM / Trade Assurance / built-in CRM |

### Authoring rules

- **Cost number for Alibaba.com side MUST be the real current GGS membership tier price** (verify via `ggs-sales-knowledge-base` skill). Do not invent.
- **Lead numbers MUST come from CRM** (`industry-benchmark` peer averages) — never invent "300+ inquiries/month".
- Closing line: "Alibaba.com extends your trade show investment 365 days a year." (translate per output language).

### Skip behavior

- If neither user input nor CRM tag indicates prior trade-show participation → **skip**. Don't insert this chapter generically — it loses impact when not contextualized.

---

## Output Validation (Phase 4 QA Self-Check)

Run this check **after deck.html is composed but before render**, and once again after render. Fail-fast: if any HARD check fails, fix before delivering to the user.

### Check 1 — Data provenance (HARD)

Every number, percentage, peer name, success story, and quoted statistic in the deck MUST be traceable to one of:

- A CRM tool response (cite tool name in a comment near the data, e.g. `<!-- src: crm-industry-benchmark -->`)
- A static fallback in this `data-and-rules.md` (cite "Regional Benchmarks Fallback")
- A user-provided figure (cite "user input")

If a number appears in the deck without a traceable source → **FAIL**. Replace or remove.

### Check 1b — Visual integrity (HARD)

For every chapter that is designed to render imagery (success stories, hot products, peer cards, etc.), verify the actual rendered HTML contains visual elements:

- **Success stories chapter**: each card MUST contain at least one of: `<img>` tag with non-empty `src`, OR a CSS gradient placeholder block (e.g. `success-image-wrap` with a colored background). A card containing only text → **FAIL**.
- **Hot products chapter**: when the CRM response carried `main_img_url` (e.g. VN Fresh Fruit), each product card MUST contain `<img>` with that original URL — a card with text + a dropped URL → **FAIL**. **Exception**: if the whole response carried *no* image field (e.g. TW Cycling) and the sub-section was rendered as the sanctioned **text-only variant** (`has_images: false`), that is **PASS, not FAIL** — there is nothing to render and fabricating an image is forbidden. The failure condition is a *dropped* URL, not a *never-existed* one.
- **Peer benchmark cards**: optional logos; if `logoUrl` is present in CRM data, it MUST be rendered.

**Distinguish "dropped" from "never existed"**: FAIL only when CRM gave an image URL and the deck lost it. When CRM gave no image field at all, text-only is correct.

**Why this check exists**: a real incident — chapter 03 was rendered as text-only after CRM returned `total:0` and the agent fell back to knowledge base content (which has no images). Knowledge base fallback content MUST either be re-checked against the corrected fallback chain (try neighboring lv1 first), or get a gradient placeholder block, before being rendered.

**Quick scan command**:
```bash
# Count <img> tags inside each <section>
awk '/<section/,/<\/section>/' deck.html | grep -c "<img"
```

If a rendering chapter shows 0 `<img>`: FAIL **only if** CRM returned image URLs that were dropped → re-fetch / re-map. If CRM returned no image field for that segment, the text-only variant is acceptable — PASS.

### Check 2 — Cross-chapter consistency (HARD)

Same metric must not contradict across chapters. Common conflict points:

- **Peer reply time** — if Chapter 07 says "5.1 hr avg" and Chapter 08 action plan says "respond within 24h" without acknowledging the gap, fix.
- **Active buyers / RFQ counts** — must be the same number on every slide it appears.
- **Country coverage** — "200+ countries" must not later become "220+".
- **Market forecast / CAGR** — endpoint values must be mathematically consistent (`end = start × (1 + CAGR)^years`, ±5%).
- **Currency** — the same metric in two chapters must use the same currency unit.

**Rule**: pick one authoritative source per metric, use it everywhere.

### Check 3 — Math accuracy (HARD)

| Common Error | Correct Form |
|---|---|
| "Increased X times" vs "Grew to X times" | "Grew to 3.7×" means final = start × 3.7. "Increased by 3.7×" means final = start × 4.7. Use only one phrasing per language. |
| Percentage of total > 100% | Sum of shares for any pie/breakdown must be ≤ 100%. |
| YoY math | If "from $100M to $300M YoY", growth = +200%, not +300%. |
| CAGR math | end = start × (1+CAGR)^years. Verify within ±5%. |

### Check 4 — Locale vocabulary (HARD when target locale is set)

Before delivery, scan every chapter against the **Locale Vocabulary** table below for the target output language. Any banned term → fix.

### Check 5 — Completeness (SOFT)

- [ ] Cover slide has correct date.
- [ ] Company name spelled correctly throughout (mask peer names; never mask the prospect's name).
- [ ] No placeholder text (`[Company]`, `[Country]`, `TBD`, `TODO`).
- [ ] 无任何面向销售/内部的过程性文字(“建议销售…”、“暂未在 KB 维护”、工具/CLI 名、`[internal:]`/`[web:]` tag、QA 备注、版本号)。deck 是给客户的成品。
- [ ] Each data-heavy chapter has a 1-line `ai_summary` callout.
- [ ] Each chapter that uses CRM data shows a `data_source:` footer (e.g. "Data source: Alibaba.com Platform Analytics, 2026-05") **plus a field-explanation footnote** for every displayed metric (see "Field-explanation footnote" convention).
- [ ] Closing CTA is concrete (specific action + low barrier), not vague.

### QA output format

Run these checks mentally (or via a sub-agent), then output internally:

```
QA Report: {customer_id} v{N}
- Provenance:    PASS | FAIL ({issues})
- Consistency:   PASS | FAIL ({issues})
- Math:          PASS | FAIL ({issues})
- Locale:        PASS | FAIL ({issues})
- Completeness:  PASS | FAIL ({issues})
Overall: PASS | FAIL ({total issues})
```

If `Overall: FAIL`, fix all HARD issues before declaring the report ready. Note any SOFT issues to the user but do not block delivery.

---

## Locale Vocabulary Guide

When the deck output language is one of the following locales, scan against these banned terms before rendering. Replace with the suggested correct forms.

### Taiwan (zh-Hant) — Banned Mainland China Terms

| Banned (大陆用语) | Use Instead (台灣) | Meaning |
|---|---|---|
| 同比 | 年增 / 較去年同期 | Year-over-year |
| 环比 | 較上期 / 月增 | Month-over-month |
| 增速 | 成長率 | Growth rate |
| 智能 | 智慧 | Smart / intelligent |
| 赋能 | 賦能 / 助力 / 協助 | Empower |
| 抓手 | 著力點 / 切入點 | Leverage point |
| 落地 | 落實 / 實施 | Implement |
| 打法 | 策略 / 做法 | Strategy |
| 品牌出海 | 品牌拓展海外 / 外銷 | Going global |
| 私域 | 自有客群 | Private traffic |
| 视频 | 影片 | Video |
| 信息 | 資訊 | Information |

Also: prefer Traditional Chinese throughout (繁體). Numbers and platform terms (IPV, GGS, Trade Assurance) stay in original form.

### Vietnam (vi) — Tone & Diacritics

- All Vietnamese text MUST carry full diacritics (à, ả, ã, ạ, etc.). Stripping diacritics is unacceptable.
- B2B address: use **"Anh/Chị"**, never **"Bạn"**.
- Company reference: **"Quý công ty"** (formal), **"công ty mình"** (casual peer-to-peer).
- Brand names (Alibaba.com, Trade Assurance, Smart Assistant) stay in English.

### Korea (ko) — Honorifics & Formality

- Use **합니다 / 입니다** (formal) level. Avoid **해요 / 이에요** (casual).
- Add **님** suffix to personal names.
- Company reference: **귀사** (貴社) for the prospect; the rep's company refers to itself as **저희 알리바바닷컴**.
- Numbers stay Arabic; KPIs (IPV, RFQ) stay in English.

### India / Pakistan (en) — South Asia B2B English

- Currency: use **USD** for all pricing; never CNY/RMB.
- Greeting: **"Dear Sir/Madam"** is still the standard for first contact.
- Spelling: prefer **British English** (organisation, colour, optimise) for both India and Pakistan.
- Avoid US-only colloquialisms ("ballpark", "no-brainer").

### Hong Kong (zh-Hant / en mixed) — Code-Switching Acceptable

- Use Traditional Chinese script (same as Taiwan).
- Code-switching with English business terms (RFQ, KPI, ROI) is acceptable and expected.
- 公司 vs 企業: either is fine in HK context.

### Default (English / Simplified Chinese)

- Apply general AI-summary writing rules (forbidden words: decline, drop, collapse, threat, etc.).
- For Simplified Chinese, none of the Taiwan-specific bans apply.
