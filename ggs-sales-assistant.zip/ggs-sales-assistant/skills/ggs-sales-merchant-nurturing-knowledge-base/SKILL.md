---
name: ggs-sales-merchant-nurturing-knowledge-base
description: >
  越南站（VN）商家培育知识库检索工具。通过百炼 RAG 检索越南 Seller Ops 培训资料，覆盖产品发布与优化（PIS/Product Growth System/Ready to Ship/Showcase）、星级评分（Star Rating & SR Task）、RFQ 报价与询盘管理、广告投放、Livestream、Trade Assurance、Minisite 店铺装修、数据分析、关键词优化、Verified Supplier、Smart Assistant、进出口流程、买家画像、团队搭建等全链路运营主题。
  当越南销售或运营问到 Alibaba.com 商家运营培训相关问题时使用。
version: 1.0.0
---

# GGS Sales Merchant Nurturing Knowledge Base

## When to Use

当用户提问涉及以下越南商家培育/运营培训主题时触发：

- **产品发布与优化**：发品（product posting）、批量发品、PIS 更新、Product Growth System、Ready to Ship、Showcase Products、Similar Tag、产品图片优化
- **星级评分**：Star Rating 规则、SR Task、星级优化方法、Star Rating Lite 更新
- **询盘与 RFQ**：回复 Inquiry、RFQ 报价技巧、询盘管理、报价优化、客户谈判
- **广告与流量**：Quảng cáo/Advertising、P4P、免费流量（organic traffic）、High Demand Products、关键词优化
- **店铺与品牌**：Minisite/Trang thông tin doanh nghiệp、Verified Supplier 认证
- **交易保障**：Trade Assurance 支付工具、TA 知识库
- **Livestream**：直播操作指南
- **数据分析**：Phân tích dữ liệu、账户绩效评估（Đánh giá hiệu suất）、Data Analytics
- **Smart Assistant**：智能助手使用
- **出口与市场**：越南出口市场、进出口手续（Xuất Nhập Khẩu）、数字化转型
- **团队管理**：运营团队搭建（Xây dựng đội nhóm）
- **买家洞察**：买家画像（Chân dung người mua）
- **最新培训录播**：AI Search、Sourcing Trends、New Product Growth、Business Opportunities 等周期性 Seller Ops Training 内容
- 用户明确要求"搜索知识库"、"查培训资料"、"查百炼"、"RAG 检索"

**不触发（由其他 Skill 处理）：**
- CRM 客户操作 → ggs-sales-crm-tools
- 批量找线索/leads → ggs-sales-leads-finder
- 单家公司调研 → ggs-sales-enrichment
- 写开发信/触达 → ggs-sales-outreach
- 行业流量/买家市场/热门品数据 → ggs-sales-industry-insights
- 平台规则/销售策略/提成政策 → ggs-sales-knowledge-base

## Steps

### 1. 确定业务场景

当前仅支持一个 bizScene：

| bizScene | 适用场景 | 知识库内容 |
|----------|---------|-----------|
| `sales_qa_VN` | 越南商家培育 & 销售运营 Q&A | Seller Ops 培训视频/PPT/PDF，覆盖产品发布、星级评分、RFQ、广告、Livestream、Trade Assurance、数据分析等全链路 |

### 2. 执行检索命令

```bash
ggs-crm knowledge-query \
  -q "<用户问题或提取的关键词>" \
  -b "sales_qa_VN" \
  -k <返回数量，默认10> \
  -s <相似度阈值，建议0.5>
```

**参数说明：**

| 参数 | 说明 | 建议值 |
|------|------|--------|
| `-q, --query` | 检索查询内容，直接使用用户原始问题或提取的核心关键词 | 用户原文或关键短语 |
| `-b, --biz-scene` | 业务场景标识 | 固定 `sales_qa_VN` |
| `-k, --top-k` | 返回文档数量上限 | 5（精确问题）~ 10（宽泛问题） |
| `-s, --score-threshold` | 最低相似度阈值，过滤低质量结果 | 0.5（一般）、0（宽泛搜索） |

**示例：**

```bash
# 产品发布相关
ggs-crm knowledge-query -q "Tối ưu đăng tài sản phẩm" -b "sales_qa_VN" -k 5 -s 0.5

# Star Rating 优化
ggs-crm knowledge-query -q "Star Rating optimization task" -b "sales_qa_VN" -k 5 -s 0.5

# RFQ 报价
ggs-crm knowledge-query -q "RFQ báo giá hiệu quả" -b "sales_qa_VN" -k 5 -s 0.5

# 广告投放
ggs-crm knowledge-query -q "quảng cáo P4P boost traffic" -b "sales_qa_VN" -k 8 -s 0.5
```

### 3. 解析返回数据

`ggs-crm knowledge-query` 底层调用[阿里云百炼 Retrieve API](https://help.aliyun.com/zh/model-studio/api-bailian-2023-12-29-retrieve)，返回 JSON 格式：

```json
{
  "success": true,
  "tool": "knowledge_query_tool",
  "data": [
    {
      "id": "d8de0fbb-45a7-38a9-83a8-1bece76e1c2d",
      "content": "文档正文内容片段...",
      "score": 0.65,
      "metadata": {
        "doc_name": "文档名称.pdf",
        "doc_url": "原始文档 OSS 签名链接（临时，会过期）",
        "title": "章节标题",
        "hier_title": "文档名 > 一级标题 > 二级标题",
        "page_number": [0, 1],
        "image_url": ["图片OSS签名链接1", "图片OSS签名链接2"],
        "video_url": ["视频OSS签名链接"],
        "audio_url": ["音频OSS签名链接"],
        "exist_page_snapshot": true,
        "workspace_id": "llm-xxx",
        "pipeline_id": "xxx"
      }
    }
  ],
  "error": null
}
```

**关键字段说明：**

| 字段 | 类型 | 说明 |
|------|------|------|
| `data` | array | 命中的文本切片列表，按相似度降序排列 |
| `data[].content` | string | **核心字段**：文本切片正文内容，基于此内容回答用户问题 |
| `data[].score` | float | 相似度得分（0~1），越高越相关 |
| `data[].metadata` | object | 文本切片的元数据 Map |

**Metadata 子字段说明：**

| 字段 | 类型 | 说明 |
|------|------|------|
| `doc_name` | string | 来源文档名称，用于标注出处 |
| `title` | string | 命中内容所属的章节标题 |
| `hier_title` | string | 层级标题路径（如 `文档名 > 一级标题 > 二级标题`） |
| `image_url` | array | 图片链接列表（OSS 签名链接）。**非空时必须在回答中嵌入展示** |
| `video_url` | array | 视频链接列表（OSS 签名链接） |
| `audio_url` | array | 音频链接列表（OSS 签名链接） |
| `page_number` | array | 命中的页码列表（PDF/PPT 类文档） |
| `doc_url` | string | 原始文档 OSS 签名链接（临时链接，**不要直接展示给用户**） |

### 4. 基于检索结果回答用户

**核心原则：基于检索到的内容，结合多模态数据（图片、视频），给出图文并茂、结构清晰的回答。**

#### 4.1 内容组织规则

1. **综合多个片段**：将多个相关片段按主题归类整合，不要逐条罗列
2. **利用层级标题**：参考 `hier_title` 和 `title` 理解原文结构，组织回答章节
3. **去重合并**：来自同一文档不同页的片段合并为同一段落
4. **保留原文关键术语**：越南语、英语术语保持原样，必要时附中文解释

#### 4.2 多模态展示规则

**图片展示（最重要）：**
- 当 `metadata.image_url` 数组**非空**时，**必须**使用 Markdown 图片语法嵌入：`![<图片描述>](<image_url>)`
- 图片放在与内容最相关的文字段落旁边

**视频展示：**
- 当 `metadata.video_url` 数组非空时：`🎬 [点击观看：<视频主题>](<video_url>)`
- 视频链接放在相关内容段落末尾

**结构化数据：**
- 对比、步骤、指标等优先使用表格
- 操作类内容使用有序列表
- 用加粗标注关键数据和结论

#### 4.3 来源标注

在回答末尾统一标注来源，格式要求：

1. 以 `**参考来源：**` 开头
2. 每条来源独占一行，使用 `>` 引用格式
3. 按引用顺序从 [1] 编号
4. 根据 `content` 和 `hier_title` 生成一句话简述
5. `doc_name` 必须是超链接：`[<doc_name>](<url>)`
6. 链接地址优先级：`video_url` > `audio_url` > `doc_url`
7. 图标区分类型：文档 📄，视频 🎬，音频 🎧

**正确格式：**

```
---

**参考来源：**

> 📄 [1] 介绍了产品发布批量操作流程 — [Tối ưu đăng tài sản phẩm hàng loạt.pdf](https://oss-xxx.aliyuncs.com/...)
>
> 🎬 [2] Star Rating 最新规则讲解视频 — [Hướng dẫn tối ưu chỉ số sao – Star rating Phần 1](https://oss-xxx.aliyuncs.com/...)
```

#### 4.4 置信度处理

| 场景 | 处理方式 |
|------|---------|
| 高相关（score ≥ 0.7） | 直接基于内容回答，语气确定 |
| 中等相关（0.5 ≤ score < 0.7） | 回答内容，开头注明"以下信息供参考" |
| 无相关结果或 score < 0.5 | 回复"培训知识库中暂未找到直接相关内容"，建议换关键词 |
| 请求失败（success=false） | 回复"知识库检索暂时不可用，请稍后重试"，展示 error |

## Pitfalls

- **bizScene 写错**：当前唯一支持的值是 `sales_qa_VN`，不要填其他值
- **query 过长**：百炼检索对过长 query 效果不好，应提取核心关键词（5-20 字为佳）
- **OSS 签名链接过期**：`doc_url` 等链接有时效性，不要缓存或在后续回答中复用旧链接
- **来源格式错误**：严禁将多条来源写在同一行；doc_name 必须包含超链接
- **图片遗漏**：`image_url` 非空时必须嵌入展示，这是用户体验的关键

## Verification

1. 执行 `ggs-crm knowledge-query` 后确认返回 `"success": true`
2. 确认 `data` 数组非空且至少有 score ≥ 0.5 的结果
3. 回答中检查：图片已嵌入、来源格式正确（每条独占一行、有超链接）
