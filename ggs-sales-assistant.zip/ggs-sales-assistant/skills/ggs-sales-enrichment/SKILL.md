---
name: ggs-sales-enrichment
description: >
  【触发】用户意图是对**单家、几家或一批**公司做**外部数据补全 / 调研**:
  - 单家："调研 xx 公司"、"xx 公司什么情况"、"扒一下 xx"
  - 单家："补全这条线索的联系方式"、"找 xx 公司的邮箱/手机/地址"
  - 单家："找 xx 公司的 KP / 关键人 / 联系方式"（含外部挖取）
  - 单家："xx 公司是不是出口商"、"xx 公司主营什么"、"xx 公司规模多大"
  - 批量："调研 ABC、DEF、GHI 这三家公司"、"补全这 N 家公司的联系方式"
  - 批量："对刚才那批 leads 做深度调研 / 一键补全"（从 leads-finder 列表 hand-off 而来）
  - 批量：用户上传一份公司名/线索列表（CSV、文本、聊天里粘贴）让 enrichment 处理

  【单家 vs 批量的区分】用户给了**明确的目标列表**（无论 1 家还是 N 家）→ enrichment；用户描述 ICP 让 skill 去发现 → leads-finder。**数量本身不是边界**（226 家明确公司名也是 enrichment）。

  【处理流程】只做外网调研，输出综合画像 + Data Provenance Table，**末尾附 CRM 判重结果**作为画像的一部分。
  根据 dedup 结果给用户展示状态 + 建议下一步:
  - `not_repeat`（不在 CRM）→ 建议"新增到 CRM"，用户确认后调 `crm-add`
  - `public_repeat` / `channel_repeat`（公海）→ 建议"捡入并补全"，用户确认后调 `crm-pickup` → `crm-refine`
  - `depot_repeat`（已在他人私海）→ 仅展示，无法写入
  - `manager_repeat`（经理库）→ 仅展示，需联系经理

  【不触发——由 ggs-sales-leads-finder 兜底】
  - 用户描述 ICP 让 skill 去发现新 leads（无明确目标列表）→ leads-finder
  - "帮我找 N 个 xx 类客户"、"找一批 xx" → leads-finder

  【不触发——由 ggs-sales-crm-tools 兜底】
  - 仅看 CRM 已有字段（无补全意图）: "看下 xx 在 CRM 里有什么"、"看下 xx 的 KP"（仅查 CRM 现有联系人）→ crm-tools
  - 写操作（添加、释放、捡入、打标）→ crm-tools

  【边界判断】
  - "找/挖/调研 KP"动词强 → enrichment
  - "看/查 CRM 里的 KP"动词弱 → crm-tools
  - 用户重点在"外部深度调研" → enrichment
  - 用户重点在"批量发现+列表"（无明确目标）→ leads-finder
  - 用户重点在"CRM 已有内容查询" → crm-tools

  【硬性约束】
    1. FIRST ACTION 必须是 Read 本 SKILL.md 全文（激活校验逻辑）,禁止先执行搜索。
    2. 必须先完成意图理解与目标公司列表识别,以自然语言向用户确认后再执行。
    3. 严禁通用 web_search 裸跑,必须按国家策略文件执行。
    4. **本 skill 不调 crm-search 查 CRM 里有没有这家公司**——只做外部调研 + crm-dedup 判重 + 经用户确认后的 crm-add / crm-pickup / crm-refine 写回。如需先看 CRM 现有数据（拜访、联系人、字段），让用户先去 ggs-sales-crm-tools 查到再回来。
    5. **批量场景的写回必须一次性预览 + 一次性确认**，不要逐家询问用户。

  【交付红线】
    - 必须严格遵循 references/countries/{country_code}.md 规定的字段与输出格式。
      > ⚠️ 路径基准:`skills/ggs-sales-enrichment/references/countries/`(调研策略),勿与 `skills/ggs-sales-leads-finder/references/countries/`(批量发现策略)混淆。
---

# ggs-sales-enrichment

单家、几家或一批公司的外部数据补全与综合调研。**不查 CRM 现有数据**（如需，先去 ggs-sales-crm-tools）。

---

## 核心工作准则 (Golden Rules)

1. **本地化优先**：执行搜索前，必须先将关键词翻译为目标国家的官方语言。
2. **拒绝编造**：缺失字段必须标注 N/A，严禁基于常识猜测联系方式或注册号。
3. **三位一体验证**：每个外网补全的字段必须经过 [第三方平台发现] → [官网/社媒提取] → [官方工商数据校验] 的交叉验证。
4. **语言镜像**：所有面向用户的输出必须使用**用户输入的语言**作答。搜索关键词可使用目标国语言，但呈现给用户的内容语言须与输入一致。
5. **Tool Contract 为准**：工具的可执行行为以实际 CLI 参数为准，不得凭流程文档假设不存在的能力。
6. **Source Attribution**：每个事实必须按 `prompt.md <source_attribution>` 内部 tag 来源——`[source: URL]` / `[skill: ggs-sales-enrichment.inferred]` / `[unverified]` 等。
7. **PII 字段处理**：所有邮箱/电话按数据源返回值**原样展示，不做任何额外打码/脱敏/隐藏**——外部公开渠道抓到的如此，dedup 命中已有客户时 CRM 返回的字段也如此（返回什么展示什么，合规处理由数据源/CRM 服务端负责）。

---

## 文件引用与加载时机

| 文件 | 加载时机 | 用途 |
|------|---------|------|
| references/countries/{country_code}.md | Phase 2 国家路由后 | 该国专属字段补全指引、去重主键、联系方式校验、CRM 写回字段规范、用户输出格式 |
| `../ggs-sales-leads-finder/references/countries/{country_code}.md` Part 1 | Phase 4 外网调研时 | 该国专属数据源清单（masothue.com、Bizno、FindBiz 等） |
| `../ggs-sales-leads-finder/references/auth-guidance.md` | Phase 4 执行前（涉及需登录平台时） | 平台授权与登录引导 |
| `../ggs-sales-leads-finder/references/platform-sop.md` | Phase 4 执行跨国平台抓取时 | Google Maps、LinkedIn、Facebook 等通用平台 SOP |

工具调用前可使用命令查询参数详细说明：
> ```bash
> ggs-crm show-docs <tool_name>
> ```

---

## 调用规则（任何 ggs-crm CLI 调用前必读）

> ⚠️ **本文档示例只展示调用方式和最常见参数，不是完整 contract**。
> 调用任何 ggs-crm 工具前**必须先查 show-docs**拿当前最权威的参数定义：
>
> ```bash
> ggs-crm show-docs <tool_name>
> ```
>
> 适用所有工具:`crm-roles` / `crm-dedup` / `crm-add` / `crm-refine` / `crm-pickup` / `crm-address` / `industry-mapping` 等。
>
> show-docs 返回的字段定义、必填性、参数互斥性是**权威**——本文档示例可能滞后于实际 CLI 版本。
>
> **失败处理：** 任何 ggs-crm 命令报错（unknown field / missing required / invalid value 等），**第一反应是 show-docs 拿当前权威 contract**，不要凭错误信息猜测改了重试。

---

## 环境与认证

环境准备（Python/pip/ggs-crm-cli 安装）、Token 认证流程、调用方式回退，参考 `prompt.md <crm_auth>`（含 Environment Prep 与 Authentication），本文档不再重复。

> ⚠️ 本 skill 内部 CRM 调用直接走 ggs-crm-cli（按 `prompt.md <chained_execution>` 中的"自有领域内 → skill 自己处理"原则），**不切到 ggs-sales-crm-tools**。

---

## 主流程概览

```
Phase 0  触发与入口约束
Phase 1  意图理解（含目标公司列表识别）
Phase 2  国家识别与 CRM Family 路由
Phase 3  CRM 上下文准备（认证/角色——dedup 与写回都需要）
Phase 4  外网调研补全（每家循环；可并发）
Phase 5  综合画像输出（按 batch_size 分流：1 家详情卡 / N 家 xlsx + Markdown 预览；含 batch crm-dedup 判重）
Phase 6  可选 CRM 写回（批量预览 + 一次性确认 → 分流到 crm-add / crm-pickup → crm-refine）
```

本 skill 不调 crm-search 查 CRM 现有数据，但 Phase 5 末尾必做 crm-dedup 判重，作为画像的一部分。

---

## Phase 0：触发与入口约束

**入口校验：** 进入本 skill 前，必须确认意图属于"对单家、几家或一批公司做字段补全/调研/综合画像"。

**触发表达：**
- "调研 xx 公司"、"xx 公司什么情况"、"扒一下 xx"
- "补全这条线索的联系方式"、"找 xx 的邮箱/手机/地址"
- "找 xx 的 KP / 关键人 / 联系方式"
- "xx 是不是出口商"、"xx 主营什么"

**不应进入本 skill 的场景：**
- 用户要批量找新 leads（"找 10 家 xx 类公司"）→ ggs-sales-leads-finder
- 用户仅看 CRM 已有字段（"看下我的私海"、"xx 在 CRM 里有什么"）→ ggs-sales-crm-tools
- 用户要做写操作（捡入、新增、释放、打标）→ ggs-sales-crm-tools

---

## Phase 1：意图理解

### 1.1 目标公司列表识别

从用户输入提取**目标公司列表**（1 家或 N 家）。每家公司按以下优先级取标识符：

| 优先级 | 标识符 | 说明 |
|--------|--------|------|
| 1 | `globalId` | 用户引用 CRM 内已有客户（如从 leads-finder 列表点过来）|
| 2 | 注册号 / VAT / MST / 統編 / 사업자등록번호 | 国家专属唯一标识 |
| 3 | 公司全名（含国家） | 最常见情况 |
| 4 | 域名 / 官网 URL | 用户给的是网址 |

每家同时给多个标识符时按优先级取最强的。

**列表来源识别：**
- **聊天文本**：用户在消息里列出公司（"调研 ABC、DEF、GHI"）
- **粘贴的 CSV / 表格**：用户把公司名表格粘贴进来
- **上传的文件**：用户上传 CSV、xlsx 等
- **从 leads-finder hand-off**：用户在 leads-finder 列表后面说"对这批做深度调研"，列表里每条 `globalId` / `companyName` / `country` 都已经具备

**列表去重**：识别完做一次去重（按 globalId 优先 / 注册号次之 / 公司名+国家兜底）。

### 1.2 补全范围识别

判断用户想补全哪些字段：

| 用户表达 | 补全范围 |
|---------|---------|
| "调研 xx"、"xx 什么情况" | **全字段**（按 country 文件 Part 1 的 P0+P1 全集） |
| "找 xx 的邮箱/手机" | 仅联系方式字段 |
| "xx 的 KP" | 仅关键人（CEO / 联系人 / 关键决策人）|
| "xx 是出口商吗" | 仅 is_exporter 字段 |
| "xx 规模多大" | 仅 employees / revenues 字段 |

默认范围：全字段（用户没明确缩小时）。

### 1.3 写回意图识别

判断用户是否需要写回 CRM（取值 `auto | ask | skip`，与 Phase 5.3 / Intent Struct 字段一致）：

| 信号 | writeback_intent |
|------|-----------------|
| "调研后帮我补到 CRM"、"补全这条线索"、"更新 xx"、"**导入 xx 到 CRM**"、"**加到 CRM**"、"**新增 xx**" | `auto` |
| "帮我看下 xx"、"调研 xx"、"找 xx 的 KP" | `ask`（默认，Phase 5 输出后询问一次） |
| 用户明确说"只看不写"、"先别写 CRM" | `skip` |

### 1.4 Intent Struct 构造

```json
{
  "raw_query": "原始用户输入",
  "target_companies": [
    {
      "globalId": null,
      "register_number": null,
      "company_name": "ABC Corp",
      "domain": null,
      "country": "VN"
    }
  ],
  "batch_size": 1,
  "enrichment_scope": "full | contact-only | key-person | exporter | size",
  "extra_fields": [],
  "writeback_intent": "auto | ask | skip",
  "primary_country": "VN",
  "industry_hint": null
}
```

**字段说明：**
- `target_companies`：目标公司列表，1 家或 N 家。
- `batch_size`：列表中**有效**目标公司数量（去重 + 跳过完全无法识别的之后）。
- `extra_fields`：用户额外要求补全的字段或偏好（如"也找一下主要出口国 / ISO 认证 / 领英粉丝数"）。这些字段**没有预定义列**——Phase 4 把它们当作额外补全目标（同样走 ①-⑤ 源级联 + Provenance），Phase 5 输出时由脚本按采集顺序**动态追加为附加列**（见 country 文件 4.2 动态扩展）。CRM 写回阶段，映射不到 CRM 字段的额外字段不写回，仅留在交付表里。
- `primary_country`：列表里所有公司的主国家。如果列表跨多国，取出现最多的；少数派进各自国家分支并行处理。

**澄清：** 如果列表中**所有**公司国家都不明确、或某家公司目标完全不可识别，向用户澄清。少数几家不明确不阻断流程——可处理列表的剩余部分，并在最终输出中标注哪些被跳过。

---

## Phase 2：国家识别与 CRM Family 路由

1. 从 Intent Struct 识别 country
2. 若用户输入中**有明确国家信息**：
   - 根据 country 确定 crm_family：HK / TW → HKTW，其他 → Global
3. 若用户输入中**无国家信息**：
   - **先执行 Phase 3**（获取 crm-roles），根据角色的组织信息判断 CRM Family
   - 若角色属于 HKTW 组织 → crm_family = HKTW，country 根据组织推断为 TW 或 HK
   - 若角色属于 Global 组织 → crm_family = Global，country 从公司信息或账号默认市场推断
   - 若仍无法确定 → 向用户澄清
4. 加载 country strategy：`references/countries/{country_code}.md`（无则 default.md）

> 本 skill 写回时（crm-add / crm-refine）会用到 country 字段映射；但读 CRM 现有数据的 crm-search 在本 skill 不调用，因此不需要加载 schema 字段白名单。

---

## Phase 3：CRM 上下文准备

**前置检查：** 执行 Phase 3 前，必须确认环境已就绪（详见 `prompt.md <crm_auth>` 的 Environment Prep）。

1. 验证 Token（按 `prompt.md <crm_auth>` 的 Authentication：CLI 自动读缓存，缺失/过期时 `ggs-crm sales-auth` 浏览器登录）
2. 调用 crm-roles 获取当前角色（参数详见 `ggs-crm show-docs crm-roles`）
   - 单角色 → 直接使用
   - 多角色 → 展示列表让用户选择
   - 空/失败 → 提示检查 token，中断流程
3. 缓存 sales-id 和 org-id 供后续使用
4. **CRM Family 反推（当 Phase 2 未确定 country 时）：** 根据角色的组织名称/路径判断是否属于 HKTW 组织，若是则设定 crm_family = HKTW 并回填 country，然后回到 Phase 2 第 4 步加载对应文件

> 角色信息在会话中缓存一次。用户明确要求切换角色时重新调用。

---

## Phase 4：外网调研补全

**执行条件：** 所有 enrichment 请求都执行（外网是唯一数据源）。

**批量场景**：对 `target_companies` 列表里的**每家**公司分别执行 4.1-4.5 全流程。**可并发**（建议并发上限 5-10 家，避免触发外部数据源限流）。每家失败不影响其他家——失败的家在 Phase 5 输出里标记 `enrichment_status=failed` 并附 reason。

### 4.1 工具分层

| 工具 | 用途 | 何时用 |
|------|------|--------|
| `web_search` | 公开信息搜索 | 所有外网调研的第一步 |
| `web_fetch` | 已知 URL 取页面内容 | 有具体链接时 |
| `sessions_spawn` (`agent_id="browser"`) | 登录态页面访问 | Facebook Page、LinkedIn 等需登录平台；`web_fetch` 遇登录墙时升级 |
| `product_supplier_search` | 阿里巴巴供应商搜索 | 排除已入驻 Alibaba 的公司（已入驻 = 非目标客户） |
| `google-map`（ggs-crm） | 地理位置搜索 | 补充地址验证 |

### 4.2 字段补全流程

按 `references/countries/{country_code}.md` Part 1 的字段补全指引，对每个目标字段（已有的跳过）按以下顺序执行：

```
① 工商库查询 → ② 社媒查询 → ③ 官网爬取 → ④ Web Search 兜底 → ⑤ LLM 推断
```

**具体规则由 country 文件控制。**每一步"去哪个网站、用什么关键词、怎么验证、何时阻断"全部由当前 `references/countries/{country_code}.md` Part 1 控制。

例如：
- 越南：masothue.com 查 MST → Facebook Page → 官网 → google-search → is_exporter 推断
- 意大利：官网 Footer 找 P.IVA → reportaziende.it 查营收 → P.IVA 找不到则阻断营收查询
- 韩国：官网 Footer 找 사업자등록번호 → FTC 验证 → NAVER 补充
- 台湾：FindBiz 查統編 → 貿易署查出口級距 → 104/1111 人力銀行查员工数

### 4.3 数据源清单

每国的具体数据源（网站 URL、API、关键词翻译表）见 `../ggs-sales-leads-finder/references/countries/{country_code}.md` Part 1。

### 4.4 跨国平台 SOP

涉及 LinkedIn、Facebook、Google Maps 等通用平台的抓取步骤见 `../ggs-sales-leads-finder/references/platform-sop.md`。

需登录平台时优先 `sessions_spawn` with `agent_id="browser"` 访问。遇 CAPTCHA → 停止该平台，告知用户，降级到 `web_search` 取摘要。

### 4.5 LLM 推断字段

基于前序步骤采集内容做推断（具体判断依据见 country 文件）：

**行业映射：** 自然语言 → 行业 ID（使用 `ggs-crm industry-mapping`）

**是否出口（is_exporter）：**
- confirmed：明确提到海外客户、出口业务、FOB/CIF 等
- inferred：官网有英文版、参加国际展会、产品含国际认证
- unknown：信息不足

**是否 B2B（is_b2b）：** Yes / No / Unknown

> 中间字段（industry_raw / activity_signals / export_signals）不对外输出。

**产出：** enriched fields，每个字段标注采集来源。

---

## Phase 5：综合画像输出

按 `batch_size` 分流输出格式：

| `batch_size` | 输出形态 |
|---|---|
| 1（单家） | 详情卡（5.1 描述） |
| ≥ 2（批量） | xlsx + Markdown 预览（5.2 描述） |

### 5.1 单家输出：详情卡

按当前 `references/countries/{country_code}.md` Part 4.1 字段定义 + Part 4.3 输出要求执行。

**详情卡内容结构：**

| 区域 | 内容 | 必出 |
|------|------|------|
| 公司基础信息 | Company Name、注册号、Website、Address、Industry | ✅ |
| **外网调研发现** | Phase 4 补全的所有字段 | ✅ |
| Industry / Is Exporter / Is B2B | LLM 推断结果（含 confirmed / inferred / unknown 标识） | ✅ |
| AI Summary | 兜底摘要：成立年份、主要客户、特殊业务说明等 | ✅ |
| Data Provenance Table（5.4）| 关键字段的验证来源 | ✅ |

### 5.2 批量输出：xlsx + Markdown 预览

按当前 `references/countries/{country_code}.md` Part 4.2 列定义构造 xlsx。

**⚠ 强制：xlsx 唯一合法生成方式 = 调用 `../ggs-sales-leads-finder/scripts/leads-to-xlsx.py`。**
- **禁止**自行用 openpyxl / pandas / csv / 手写表头等任何方式拼 xlsx——只有脚本能保证 21 列基线、`crm_status` 合并、动态追加、防编造校验生效。
- **禁止**把 CRM 原始字段名（`global_id` / `busi_reg_number` / `crm_comp_name` / `tax_code` 等）直接当表头。所有字段必须先按 Part 4.2 键名归一到统一 schema（如 `tax_id` / `company_name_en` / `key_person_name`），再交给脚本。
- **禁止**为同一信息开多个同义列（多个公司名列 / 多个税号列）——同义信息合并到对应的单一 baseline 键。
- 脚本自带防编造前置校验；自行拼表会绕过校验，等于放行编造数据。

- **xlsx 文件**：由 leads-finder 的脚本 `../ggs-sales-leads-finder/scripts/leads-to-xlsx.py` 生成（输入 JSON 数组，输出 xlsx，所有字段写为文本，含逗号的字段不拆分），**调 storage 工具上传 OSS** 拿到下载链接。
- **调用方式（任务目录隔离，防跨会话错引）：**

  > ⚠️ 工作空间跨会话共享。本次任务的所有过程产物**必须**写入本任务专属目录，**禁止**用固定文件名写工作空间根目录或裸 /tmp。
  > 任务标识 `{task-slug}`：单家调研用公司名 slug（如 `hanoi-wood-jsc`），批量场景用批次来源 slug（如 `excel-batch1`）。slug **不含国家代码**（国家统一由命名中的 `{country}` 段承担，避免 `vn-vn-` 式重复）；整个任务内保持同一个值。

  ```bash
  # 1. 创建本任务专属目录（只创建一次，后续步骤复用）
  TASK_DIR=enrichment-{country}-{task-slug}-{YYYYMMDD-HHMM}
  mkdir -p $TASK_DIR

  # 2. 批次 JSON 与结果 xlsx 都写入本任务目录，文件名带 {task-slug}
  cat > $TASK_DIR/enrichment-batch.json << 'EOF'
  [ {<record 1>}, {<record 2>}, ... ]
  EOF

  python3 <SKILL_DIR>/../ggs-sales-leads-finder/scripts/leads-to-xlsx.py \
    --input $TASK_DIR/enrichment-batch.json \
    --output $TASK_DIR/enrichment-{country}-{task-slug}-{YYYYMMDD-HHMM}.xlsx
  ```

  引用产物一律走 `$TASK_DIR` 内路径；工作空间里其他目录的同名文件属于别的任务，**不读取、不复用**。

- **Markdown 预览**：聊天里展示**前 3-5 条** + xlsx 下载链接。用户在 `extra_fields` 里额外要求的字段，按 Part 4.1 的动态扩展规则追加到预览表末（与 xlsx 一致），不只落 xlsx。
- **每条记录附 `enrichment_status` 列**：`success` / `partial`（部分字段未补全）/ `failed`（整条失败，附 reason）。
- **每条记录附 `dedup_status` 列**：来自 5.3 的 batch dedup 结果（`not_repeat` / `public_repeat` / `channel_repeat` / `depot_repeat` / `manager_repeat` / `error`）。
- **批量场景下 Data Provenance Table** 仅对**关键聚合事实**给（如"X 家有官方注册号"、"Y 家从 LinkedIn 找到 KP"），不逐条列。完整字段来源在 xlsx 的对应列里标注。

### 5.3 CRM 判重（必做，作为画像的一部分）

输出综合画像（详情卡或 xlsx）的同时，调 `crm-dedup` 判断每家公司在 CRM 中的状态。**crm-dedup 是 batch 接口**——单家场景传 1 条 payload，批量场景一次性传 N 条。

按当前 `references/countries/{country_code}.md` Part 5 的 dedup payload 字段映射构造请求：

```bash
ggs-crm crm-dedup -t {token} --sales-id {sid} --org-id {oid} \
  -p '[
    {"uid":"1","companyName":"<英文/本地名>","country":"<COUNTRY>","email":"<可选>","registerNumber":"<可选>"},
    {"uid":"2", ...},
    ...
  ]'
```

**完整参数** 详见 `ggs-crm show-docs crm-dedup`。

### 5.4 Data Provenance Table（强制）

| 事实点 | 声明内容 | 验证来源 | 验证状态 |
|:---|:---|:---|:---|
| 企业在营状态 | [结果] | [URL/Tool] | Verified / Not Found |
| 税号/注册号 | [结果] | [官方系统] | Verified / Not Found |
| 核心联系方式 | [结果] | [来源路径] | Verified / Not Found |

单家场景逐条字段给；批量场景给聚合事实（X 家 Verified / Y 家 Not Found）。

### 5.5 PII 字段处理

所有邮箱/电话按数据源返回值**原样展示**，不做任何额外打码/脱敏/隐藏——外部公开渠道抓到的如此，dedup 命中已有客户时 CRM 返回的字段也如此。返回什么展示什么，不省略、不星号化。

### 5.6 判重结果展示与下一步建议

**单家场景** —— 直接展示该家的状态 + 建议下一步：

| `deduplicationStatus` | 返回 `pool` | 给用户展示的状态 | 建议的下一步 |
|----------------------|------------|----------------|------------|
| `not_repeat` | — | "✅ 该公司不在 CRM 中" | "要新增到 CRM 吗？（会调 `crm-add`）" |
| `public_repeat` / `channel_repeat` | `public` | "✅ 该公司在 CRM 公海" | "要捡入并补全吗？（会调 `crm-pickup` → `crm-refine`）" |
| `depot_repeat` | `private`（已有归属销售） | "⚠️ 该公司已在他人私海，无法操作" | 不提供写回选项，结束 |
| `manager_repeat` | — | "⚠️ 该公司在经理库，需联系经理" | 不提供写回选项，结束 |

**批量场景** —— 给汇总统计 + 详情表 + 写回 candidates：

> **批量统计模板：**
> ```
> 共 226 家：
>   - 88 家可新增（dedup_status=not_repeat）→ 写回候选
>   - 60 家可捡入（dedup_status=public_repeat / channel_repeat）→ 写回候选
>   - 50 家已在他人私海（depot_repeat）→ ⚠️ 已从写回候选移除
>   - 20 家在经理库（manager_repeat）→ ⚠️ 已从写回候选移除
>   - 8 家 dedup 调用失败（error）→ ⚠️ 已从写回候选移除
> ```

> 详情：每条 dedup_status 在 xlsx 的对应列里。

> 写回候选 = `not_repeat + public_repeat + channel_repeat` = 148 家。其余进入 Phase 6 后**不参与写回**。

> **不论单家批量场景**，都根据 Phase 1.3 识别的 `writeback_intent`：
> - `auto`（用户已明确要写回）：可直接进入 Phase 6 执行（仍展示判重结果给用户知悉）
> - `ask`（默认）：展示判重结果 + 建议后等用户**一次性**确认（批量场景下不要逐家问）
> - `skip`（用户只想看画像）：仅展示判重结果，不询问写回

---

## Phase 6：可选 CRM 写回

**执行条件：** Phase 5.3 调过 dedup，且：
1. 至少 1 家公司的 dedup 结果允许写回（`not_repeat` / `public_repeat` / `channel_repeat`）
2. 用户基于 Phase 5.6 的状态展示，确认了具体写回动作

### 6.1 写回路径分流

按每家公司 Phase 5.3 已拿到的 dedup 结果分流：

| dedup 结果 | 写回工具链 | 必填字段来源 |
|-----------|-----------|-------------|
| `not_repeat` | `crm-add` | country 文件 Part 3（含国家级 override 必填） |
| `public_repeat` / `channel_repeat` | `crm-pickup` 捡入 → `crm-refine` 补全 | country 文件 Part 3 |
| `depot_repeat` / `manager_repeat` / `error` | （不写回，跳过） | — |

> **完整字段映射**：每个国家的 `crm-add` / `crm-refine` 必填字段 override 详见对应 country 文件 Part 3（如 VN 的 `registerNumber` 必填、phone `+84` 格式、province/city 必须先调 `crm-address` 转码）。

### 6.2 批量预览 + 一次性确认

**单家场景** —— Phase 5.6 已经直接问过"要新增/捡入吗"，用户回 Yes 直接进入 6.3 执行。

**批量场景** —— 必须给用户**完整预览**后**一次性确认**，不要逐家询问。

预览模板：

```
即将执行的写回（共 148 家）：
  ▸ crm-add 新增：88 家
    （前 5 家：ABC Corp, DEF Ltd, GHI Inc, JKL Co, MNO ...）
    [完整列表见 xlsx: <下载链接>]
  ▸ crm-pickup → crm-refine：60 家
    （前 5 家：PQR Co, STU Inc, VWX Ltd, YZA Corp, BCD ...）
    [完整列表见 xlsx: <下载链接>]

  另有 78 家不参与写回：
    - 50 家在他人私海
    - 20 家在经理库
    - 8 家 dedup 失败

  字段校验：所有候选公司的国家专属必填字段已齐全 ✓
  （如有缺失字段，会列出"X 家因 registerNumber 缺失无法 crm-add，已从候选移除"）

  确认全部执行？（Yes / No / 让我先调整字段）
```

用户回 Yes 后进入 6.3。**用户给的若是部分确认（"只 add 不 pickup"等），按要求过滤后执行。**

### 6.3 写回执行

| 动作 | 工具 | 完整参数 |
|------|------|---------|
| 新增客户 | `crm-add` | `ggs-crm show-docs crm-add` |
| 捡入公海客户 | `crm-pickup` | `ggs-crm show-docs crm-pickup` |
| 补全已有客户字段 | `crm-refine` | `ggs-crm show-docs crm-refine` |

执行 `crm-add` / `crm-refine` 前用国家专属规范（country 文件 Part 3）做必填字段校验：

- **单家场景**：缺失则**阻断写回，告知用户具体缺失字段**，不静默失败
- **批量场景**：缺失字段的家**从本次执行中跳过**（在 6.4 写回结果里列出），不阻断其他家

地址字段必须先通过 `crm-address` 转码。

**批量执行**：可并发（建议并发上限 5-10，避免 CRM API 限流）。每家失败不影响其他家。

### 6.4 写回后

**单家场景：**
- 成功：告知用户操作成功，附上写入字段清单 + CRM 详情页链接（来自 `crm-add`/`crm-pickup` 返回的 `globalId`/`detailUrl`）
- 失败：展示错误信息，**不自动重试**，等用户指示

**批量场景：**
- 给执行报告汇总：成功 X 家 / 失败 Y 家 / 跳过（字段缺失）Z 家
- 失败和跳过的明细在 xlsx 里附 `writeback_status` + `failure_reason` 列
- **不自动重试任何失败**


## 异常处理

| 异常场景 | 处理方式 |
|---------|---------|
| Token 验证失败 / 401 | 按 `prompt.md <crm_auth>` 重跑 `ggs-crm sales-auth` 获取新 Token |
| crm-roles 返回空 | 提示检查 token，中断流程 |
| Phase 1 目标公司识别不出 | 提示用户提供完整公司名 + 国家 |
| Phase 4 主数据源访问失败 | 按 country 文件 Fallback 策略处理 |
| Phase 4 CAPTCHA / 强制登录墙 | 立即停止该平台，告知用户并附截图，降级或跳过 |
| Phase 4 多源都未命中 | 告知用户"未找到该公司公开信息"，不编造 |
| Phase 5.3 crm-dedup 返回 `depot_repeat` | 在画像里展示"已在他人私海"，不进入 Phase 6 |
| Phase 5.3 crm-dedup 返回 `manager_repeat` | 在画像里展示"在经理库，需联系经理"，不进入 Phase 6 |
| Phase 5.3 crm-dedup 调用失败（批量场景）| 该家标记 `dedup_status=error`，不进入 Phase 6，其他家继续 |
| crm-add / crm-pickup / crm-refine 失败 | 展示错误信息，不重试，等用户指示 |
| sessions_spawn (browser) 不可用 | 降级为 web_search + web_fetch + ggs-crm CLI；FB/LinkedIn 走搜索摘要 |
