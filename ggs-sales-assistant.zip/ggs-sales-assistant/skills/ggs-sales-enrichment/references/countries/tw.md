# Taiwan (TW) - enrichment 国家策略文件

本文件是台湾（TW）地区在 **ggs-sales-enrichment** skill 中的执行知识库。
当 enrichment skill Phase 2 路由结果为 `country=TW` 时加载本文件。

**CRM 注意：** TW 属于 HKTW CRM family。CRM 内部查询/判重/写回均可用。

> **数据源在哪里：** 本文件不重复台湾数据源清单。数据源（政府公示、競對 B2B/電商平台、行業協會、展會、社媒）见 `../../../ggs-sales-leads-finder/references/countries/tw.md` Part 1（SSOT）。

---

## Part 1: 字段补全指引

### 核心原则

1. **穷尽数据源再说"找不到"**：每个字段都有定义好的来源优先级与 fallback。**必须按顺序逐级试过**才能标 `N/A`。"AI 犯懒"在此项目零容忍——只要 Part 1 列出的来源还有没試過的，就**不允许**输出 `N/A`。
2. **聯絡人 ≠ 負責人**：負責人是商工登记的法人代表，聯絡人是实际跟进对接的业务人员（经理级以上 / 外銷、電商、新事業部門 行銷/業務人員）。P0「個人電話/手機」「個人 Email」**指向聯絡人**，不是負責人。
3. **去重主键优先级**：`統一編號` > `website（域名）` > `公司全名（繁中）+ 縣市`

---

### P0 級別字段（必查；缺失阻斷或標記低置信度）

#### 1. 公司全名（繁體中文）

- **要求**：包含完整法律後綴（如「股份有限公司」、「有限公司」）。
- **容錯**：找不到精確匹配時，檢查標點符號差異（如「ABC科技」vs「A.B.C. 科技」）或簡繁體轉換。若名稱差異過大則不予填寫。
- **來源**：FindBiz、官網 Footer。

#### 2. 統一編號（公商註冊號）【去重主键 + 阻斷條件】

- **定義**：8 位數字，台灣企業唯一身份證。
- **來源**：經濟部商工登記公示查詢 (findbiz.nat.gov.tw)。
- **【阻斷規則】**：**沒有統編 → 停止該筆資料開發**（不是单纯阻断 CRM 写回——是直接放弃这条线索，因为后续 P1 出口級距無法查詢）。

#### 3. 負責人姓名

- **定義**：商工登記的法人代表。
- **來源**：FindBiz「負責人姓名」字段。
- **核對**：若官網標註的創辦人與登記負責人不同，**以商工登記之官方負責人為準**。

#### 4. 聯絡人姓名

- **定義**：實際跟進對接的業務人員。
- **目標角色**：經由社媒匹配該企業高階主管（經理級以上）、或**外銷、電商、新事業部門**之**行銷或業務人員**。
- **來源優先級**（按以下順序逐級試）：
  1. LinkedIn 公司頁 → 員工列表 → 按職稱關鍵字篩選（外銷經理 / Export Manager / 業務經理 / Sales Manager / 國際業務 / 電商總監等）
  2. 官網「團隊」/「關於我們」頁
  3. 競業 B2B 平台旺鋪頁底部聯絡窗口（台灣經貿網、Global Sources、CENS——詳見 leads-finder/tw.md 1.4）
  4. Facebook 公司粉專 About + 貼文署名

#### 5. 個人電話 / 手機（指向聯絡人）

- **格式**：
  - 手機：`886+9xx-xxx-xxx`（去掉首位 0）
  - 固話：`886+區碼+電話`（如「886+2+12345678」）
- **來源優先級**（按以下順序穷尽逐級試）：
  1. **B2B 競業平台旺鋪頁**：台灣經貿網（taiwantrade.com）公司頁「Contact Us」/ Global Sources 公司頁「Contact Supplier」/ CENS 公司頁底部聯絡資訊
  2. **C2C/B2C 平台卖场**：蝦皮（shopee.tw）賣場「賣家資訊」/ MOMO（momoshop.com.tw）廠商資訊頁——常含客服 LINE 或手機
  3. **Google 搜索**：`"{公司名}" "聯絡" OR "電話" OR "經理"` 散在新聞稿、公開資料中
  4. **官網「聯絡我們」頁**：公司主線電話（兜底，非個人）
  5. **104 / 1111 / Yes123 廠商介紹頁** 的招聘聯絡窗口
  6. **LinkedIn 聯絡人個人頁**：經理級以上的公開聯絡方式
  7. **Facebook 個人頁 / 粉專 About**：負責人 / 業務經理的 LINE QRcode、個人手機

- **【反偷懶硬約束】**：必須先尋找**聯絡人個人行動電話**（`09` 或 `+8869` 開頭）。**僅在以上 7 個來源全部穷尽仍無個人手機時**，才能退到公司主線（座機）作為次選。**不允许跳过任何来源直接标 `N/A`**——AI 必须在 aiSummary 中标注"已穷尽 X/7 来源"。

#### 6. 個人 Email（指向聯絡人）

- **優先級**：個人郵箱（`@gmail.com` / `@yahoo.com.tw` / 公司郵箱中的個人前綴 `name@company.com.tw`）> 部門郵箱 > 通用 `info@` 郵箱。
- **來源優先級**（按以下順序逐級試）：
  1. **B2B 競業平台旺鋪頁**「Contact Us」聯絡窗口郵箱
  2. **LinkedIn 聯絡人個人頁**「聯絡資訊」段
  3. **Facebook 粉專 About 頁 + 個人頁** 公開郵箱
  4. **官網「聯絡我們」頁** 部門郵箱（如 `sales@company.com.tw`）
  5. **104 / 1111 廠商招聘頁** 招聘聯絡窗口郵箱
  6. **官網 info@ 通用郵箱**（最後兜底）

- **【反偷懶硬約束】**：**嚴禁僅使用通用的 `info@` 郵箱敷衍**。必須全量遍歷以上 6 個來源中的前 5 個提取個人或聯絡人郵箱，**前 5 個全部空才允許使用 info@**，並在 aiSummary 中標注"已穷尽 5/6 来源，僅獲得 info@ 郵箱"。

#### 7. 地址

- **來源**：FindBiz「公司所在地」字段——用於識別分發給哪個區域銷售跟進。
- **格式**：保留完整地址（縣市 + 區 + 路段 + 號）。

#### 8. 在營狀態

- **來源**：FindBiz「登記現況」字段。
- **接受值**：`核准登記` / `營業中` → 在營；其他狀態（如「歇業」「停業」「解散」）→ **停止該筆資料開發**（已停業的公司沒有開發價值）。

---

### P1 級別字段（重要，必查）

#### 9. 職稱（聯絡人職稱）

- **來源優先級**：
  1. LinkedIn 個人檔案職稱（中文或英文）
  2. 競業平台旺鋪頁聯絡窗口署名
  3. 官網團隊頁
- **抓取規則**：根據 LinkedIn 個人檔案中的正確中文或英文職稱填入（如「外銷經理」、「Export Manager」、「電商總監」）。

#### 10. LINE

- **定義**：LINE ID 或 LINE 加好友連結。台灣 B2B/B2C 第一 IM 渠道，**只要找到就必須填**。
- **格式**：LINE ID 形式為 `@example_tw`（含 @）或 `lin.ee/xxx` 加好友連結。
- **來源優先級**（按以下順序逐級試）：
  1. **競業電商平台賣場客服資訊**：蝦皮（shopee.tw）賣家資訊頁 / MOMO（momoshop.com.tw）廠商客服欄
  2. **官網「聯絡我們」/ 頁尾**：LINE 加好友 QRcode 或連結
  3. **Facebook 粉專 About + 貼文**：LINE QRcode 圖片或文字 ID
  4. **Google 搜索** `"{公司名}" LINE` → 散在新聞、論壇、目錄頁
- **【反偷懶硬約束】**：**不允许跳过任何来源直接标 `N/A`**——必须在 aiSummary 中标注"已穷尽 X/4 来源"。找不到時填 `N/A`，**不要用 FB/Email 替代**。

#### 11. 資本額

- **來源**：FindBiz「核定資本額」或「實收資本額」字段。
- **格式**：以新台幣 (TWD) 為單位（如「50,000,000 TWD」或「5,000 萬 TWD」）。

#### 12. 產業

- **分類邏輯**：交叉以下兩個來源歸納至對應類別（如：工業機械、電子零組件、食品飲料等）：
  1. 官網「產品」頁
  2. FindBiz「營業項目」代碼
- **嚴禁僅憑公司名猜測產業**。

#### 13. 社媒資訊

- **接受**：Facebook、Instagram、LinkedIn。
- **格式要求**：必須是**完整 URL**（如 `https://www.linkedin.com/company/example-tw`），**禁止只寫「FB」或「LinkedIn」**。

#### 14. 出口級距

- **定義**：判斷該客戶是否為優質對標對象的關鍵指標。
- **來源**：貿易署《出進口廠商資料》(fbfh.trade.gov.tw)，輸入 8 位統編查詢 2025 年出口實績級距。
- **級距標準**：A 級（1,000 萬 USD+）/ B 級（500 萬–1,000 萬 USD）/ C 級（500 萬 USD 以下）。
- **依賴**：必須先有統編（見 P0 #2）。

---

### P2 級別字段（參考）

#### 15. 員工人數

- **來源優先級**：
  1. LinkedIn 公司專頁的規模區間
  2. 104 / 1111 人力銀行廠商介紹頁
  3. 上市櫃公司：公開資訊觀測站 (mops.twse.com.tw) 年度財報
- **格式**：盡量提供具體數字（如「85 人」）；若僅獲得區間（如「51-100 人」），保留區間表述。

#### 16. 公司網站

- **規則**：找出官方網站域名。
- **【排除規則】**：**嚴禁選擇** Amazon、Shopee、MOMO、Pinkoi、阿里巴巴國際站等任何平台店鋪鏈結作為公司網站。這些是賣場頁，不是公司官網。
- **格式**：移除 `www.` 與 `https://`，僅保留主域名（如 `example.com.tw`）。

---

### AI Summary

- 必須在此欄記錄「**已穷尽哪些來源**」（按 P0 #5 和 #6 的反偷懶約束要求）。
- 若無額外信息且所有來源已試過，填 `N/A`。

---

## Part 2: 字段规范 - 去重主键 + 联系方式校验

### 2.1 去重主键字段

| 优先级 | 字段 | 说明 |
|-------|------|------|
| 1 | 統一編號 | 8 位數字 |
| 2 | website（域名） | 去除協議頭與 www 後比較 |
| 3 | 公司全名（繁中）+ 縣市 | — |

### 2.2 联系方式校验

| 项目 | 规则 |
|------|------|
| 號碼識別/分流 | 由 `scripts/phone-normalize.py`（libphonenumber, region=TW）判定：`type=MOBILE`→行動電話(primary)；`FIXED_LINE`→固話(secondary)；`FIXED_LINE_OR_MOBILE`→按可作 primary 處理 |
| 固話處理 | helper 判 `FIXED_LINE` 的號不填 primary phone，固話資訊記入 AI Summary |
| 寫回格式 | 取 helper 的 `e164`/`international`（自動加 886、去首 0），不手工拼接 |
| 多號處理 | 多個手機號逗號分隔，第一個為 primary；固話寫入 secondary，不填入 primary phone 字段 |
| 主要 IM 渠道 | LINE > Facebook Messenger > Instagram DM |
| Email 校驗 | 基本格式校驗；個人郵箱（如 `@gmail.com`、`@yahoo.com.tw`）優先於通用 `info@` 郵箱 |

---

## Part 3: CRM 写回字段规范（TW 专属 override）

> ⚠️ **HKTW family 的 `country` 字段值在不同 CRM 工具下不一致（重要！）：**
> - **crm-search**：HKTW CRM 查询条件中**不传 `country` 字段**（org-id/sales-id 自动限定范围）
> - **crm-dedup payload**：传 `"country": "TW"`（dedup 工具用 country 区分港台）
> - **crm-add / crm-refine payload**：固定为 `"country": "CN"`（HKTW family 内部统一）
> - **crm-address --country 参数**：传 `TW`（地址转码工具的国家参数，与字段值无关）

完整的 write-back 参数说明见 `ggs-crm show-docs crm-add` / `ggs-crm show-docs crm-refine`。以下为台湾的国家级 override，同时适用于 crm-add（leads-finder Phase 9 新增）和 crm-refine（leads-finder Phase 9 捡入后补全 / enrichment Phase 6 已有客户补全）：

| 规则 | 说明 |
|------|------|
| `registerNumber` **必填** | 台湾线索写回时統一編號为必填。**沒有統編 → 停止該筆資料開發**（不是单纯阻断写回——是直接放弃这条线索）|
| `province` / `city` 需转码 | 不能直接写入"台北市"，必须先调 `crm-address --country TW` 获取编码 |
| `phone` 格式 | 調 `scripts/phone-normalize.py`（libphonenumber，TW region）取 `e164`/`international` 寫回；`primary_ok=true` 的號作 primary |

> ⚠️ **HKTW family 必填字段比 Global 多。** 除 `registerNumber` 外，CLI 还会要求 `mobilePhone`/`phoneNumber` 配套国家区号字段、完整的 `province + provinceCode` / `city + cityCode` / `area + areaCode` / `address` 等。**调用 crm-add / crm-refine 前必须先 `ggs-crm show-docs crm-add` / `crm-refine` 拿当前权威必填列表**——本文档不复制 CLI 字段清单，避免文档与 CLI 不同步。
>
> 任何字段缺失时，**阻断写回**并向用户列出缺失字段请求补充，不要凭空猜测填值。

---

## Part 4: 用户输出规范

### 4.1 用户输出字段（TW 专属）

向用户交付台湾线索时，使用以下字段定义：

| 公司全名 | 統一編號 | 負責人 | 聯絡人 | 職稱 | 產業 | 個人電話/手機 | 個人 Email | LINE | 地址 | 在營狀態 | 員工人數 | 資本額 | 出口級距 | 社媒資訊 | 網站 | CRM 詳情 | AI Summary |
|----------|----------|--------|--------|------|------|--------------|-----------|------|------|---------|----------|--------|----------|----------|------|----------|-----------|
| 範例股份有限公司 | 12345678 | 王大明 | 陳怡君 | 外銷經理 | 電子零組件 | +886 912 345 678 | yichun.chen@example.com.tw | @example_tw | 台北市內湖區範例路 100 號 | 營業中 | 85 | 50,000,000 TWD | A級 | https://linkedin.com/company/example-tw | example.com.tw | [詳情](https://crm.alibaba-inc.com/crmagent/romeo/public-sea/customer-detail.html?globalId=xxx) | 已穷尽 7/7 来源，從 LinkedIn 獲得聯絡人手機 |

**动态扩展：** 实际预览列 = 上表策展列 + 用户额外要求的字段（Intent Struct `extra_fields`，如 ISO 认证 / 主要出口国 / 领英粉丝数），按采集顺序追加到表末。与 xlsx 输出保持一致——不在策展列内的用户要求字段在聊天预览里也显示，不只落 xlsx。

### 4.2 xlsx 列定义

由 `../../../ggs-sales-leads-finder/scripts/leads-to-xlsx.py` 生成，以下 21 列为**基线参考列**（floor，不是上限；所有国家一致，始终输出）：

```
index, source,
company_name_en, company_name_local,
country, province, city, address,
industry, tax_id,
phone, email, website, im_account,
key_person_name, key_person_title,
confidence, qualityTags, dataSources, aiSummary,
crm_status
```

**说明：**
- `tax_id`: 各国通用税号 / 注册号（VN: MST；KR: 사업자등록번호；TW: 統一編號；IT: P.IVA；ES: NIF/CIF）
- `im_account`: 各国 IM 平台合并为一列（`Zalo: xxx; FB: yyy` / `KakaoTalk: xxx` / `LINE: xxx`）
- `key_person_name`: 单列存放完整姓名（如 KR 姓+名拼接）
- `crm_status`: CRM 内部字段（globalId/pool/orgId/ownerId/detailUrl）合并为一列——命中 CRM 显示「池 + 详情链接」，外部新线索为 N/A
- 已移除默认输出的内部列：`industryId` / `aiMatcher` / `commandResult`（需要时由 record 显式带上才作动态列出现）


所有字段在 xlsx 中作为**文本**写入（避免 Excel 把税号 / 电话当数字处理；含逗号的字段不拆分）。

**动态扩展（重要）：** 上述 21 列是**基线(floor)，不是上限(cap)**。实际输出列 = 基线非空列 + 本次 enrich/发现到的额外字段 + 用户额外要求的字段。脚本数据驱动：记录里任何不在基线的 key 会按**首次出现顺序**自动追加为附加列，**不再丢弃**；被 `im_account` 合并消费的 key（zalo/facebook_url/line/kakaotalk/whatsapp）不重复出列。

### 4.3 输出要求

1. `統一編號` 保持 8 位數字格式顯示。
2. 缺失字段填 `N/A`，**但 P0 #5 個人電話、P0 #6 個人 Email 和 P1 LINE 標 N/A 前必須先穷尽 Part 1 列出的所有來源**，並在 AI Summary 中記錄。
3. 附 Result Summary + Data Provenance Table。
4. Phone 必須為 `886+9xx-xxx-xxx`（手機）或 `886+區碼+電話`（固話）格式。
5. 統編阻斷：如果某條線索沒有統編 → **停止該筆資料開發**，置信度標記為 `low`，不進入交付列表。
6. 在營阻斷：如果 FindBiz 顯示「歇業」「停業」「解散」等非營業狀態 → **停止該筆資料開發**。
7. 網站欄嚴禁填入 Amazon / Shopee / MOMO / Pinkoi / Alibaba 卖场链结——若公司只有这些电商店铺无独立官网，網站欄填 `N/A`。
8. **LINE 欄**：填 LINE ID（如 `@example_tw`）或 LINE 個人帳號連結。LINE 是台灣 B2B/B2C 第一 IM 渠道，**只要找到就必須填**；找不到時填 `N/A`，不要用 FB/Email 替代。
9. **Markdown 預覽表 LINE 是獨立欄**；**xlsx 輸出**中 LINE 合併進 `im_account` 列（格式 `LINE: @example_tw`）——由 `scripts/leads-to-xlsx.py` 自動處理，無需手動拼接。
10. **CRM 詳情列**：僅 CRM 內已有客戶（`globalId` 非空）展示詳情頁連結（`detailUrl`），外部新發現的線索填 `N/A`。連結使用 Markdown 格式 `[詳情](url)` 展示。

---

## Part 5: crm-dedup 字段选择（TW payload）

在 enrichment Phase 5.3 调用 `crm-dedup` 时，台湾线索优先提供以下字段：

```json
{
  "uid": "序号",
  "companyName": "公司英文名或繁中名",
  "country": "TW",
  "email": "联系邮箱",
  "registerNumber": "統一編號（如已获取）"
}
```

完整 CLI 参数详见 `ggs-crm show-docs crm-dedup`。
