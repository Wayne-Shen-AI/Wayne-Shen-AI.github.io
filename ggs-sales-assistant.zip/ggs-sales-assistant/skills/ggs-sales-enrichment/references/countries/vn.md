# Vietnam (VN) - enrichment 国家策略文件

本文件是越南（VN）地区在 **ggs-sales-enrichment** skill 中的执行知识库。
当 enrichment skill Phase 2 路由结果为 `country=VN` 时加载本文件。

---

## Part 1: 字段补全指引

> **联系方式类字段的通用优先级：** Phone / Zalo / Email 等联系方式字段，优先从 Facebook（Page 和行业群组）提取，其次从官网，最后从其他平台补充。工商类字段（MST / Address / Industry）仍按各自权威来源优先。

### 去重主键优先级

`MST（Mã số thuế）` > `website（域名）` > `company_name_local（越南语全称）`

### P0 级别字段（核心）

#### 1. Business Registration No. (MST / Mã số thuế) 【去重主键】

- **定义：** 越南企业税号，10 位或 13 位数字。
- **补全指引：**
  - 来源 1：`masothue.com` — `web_search "{company_name} mã số thuế"` → `web_fetch` 详情页。镜像冗余：hosocongty.vn / infodoanhnghiep.com（缓解 masothue 反爬单点）
  - 来源 2：dangkykinhdoanh.gov.vn（国家工商登记门户，权威）
  - 来源 3：公司官网 Footer，寻找 "Mã số thuế" 或 "MST"
- **阻断规则：** 如果找不到 MST，无法验证企业合法性，应标记风险或放弃后续依赖 MST 的查询（如工商详情）。

#### 2. Company Name Local (Tên công ty)

- **定义：** 越南语全称，通常包含 "Công ty TNHH"（有限公司）或 "Công ty Cổ phần"（股份公司）。
- **补全指引：** 从 masothue.com 或官网提取。

#### 3. Phone (Điện thoại)

- **定义：** 联系电话。**手机号为 primary**，固话降级为 secondary。
- **补全指引（按优先级）：**
  1. Facebook Page / 行业群组的 About 页面
  2. 官网 Contact 页面
  3. masothue.com 或其他企业目录
- **手机 vs 固话分流：** 一律调 `scripts/phone-normalize.py`（libphonenumber, region=VN）判定，不手工判前缀——`type=MOBILE`→手机号(primary)；`FIXED_LINE`→固话,不填 phone 主字段,记入 AI Summary；`FIXED_LINE_OR_MOBILE`→可作 primary。多个手机号逗号分隔填入，CRM 写回取第一个。
- **格式：** 取 helper 的 `e164`/`international`（自动去首 0、加 +84），不手工拼接。
- ⚠ 如果只找到固话没有手机号，固话作为唯一联系方式仍记入 phone 字段，标注 `(landline)`。

#### 4. Social Media (Zalo / Facebook)

- **定义：** 越南最核心的通讯与社媒渠道。
- **Facebook：** 搜公司名找到官方 Page（输出**完整 URL**，如 `https://www.facebook.com/abccompany`）。LinkedIn 优先级低于前两者，仅补充。

**FB / Zalo 联系方式提取（事实性指引）**

*查找位置*（FB Page 上联系方式可能出现处，逐一查看）：
- Page 的 **Intro / About / "Giới thiệu"** 区（电话/邮箱/网站的标准存放位）
- **"Liên hệ"（联系）** 标签页；封面图 / 头图上的文字
- 置顶帖 / 近期帖正文 / 公司自己的评论回复

*号码识别*（越南号码规则）：
- 手机：`0` + `3/5/7/8/9` 开头共 10 位（也可能写成 `0912.345.678` / `+84 912…`）
- 固话：`02x` 开头（028 HCM / 024 HN / 0274 Bình Dương）
- 一律过 `scripts/phone-normalize.py` 判定，不手工分流

*Zalo 记录（仅凭页面字面证据，不得推断）*：
- Zalo 账号绑定手机号、且默认不公开显示号码——只有公司主动放出才可见
- 记 `zalo` 的依据**只能是页面字面出现的**：`Zalo: <号>` / `<号> (Zalo)` 标注、`zalo.me/<…>` 或 `oa.zalo.me/<…>` 链接、标注 Zalo 的二维码（图片读不到则记"有 Zalo QR，号见手机字段"）
- **只有手机号、无任何 Zalo 标记 → `zalo` 填 N/A，不得由手机号推断**

*FB 抓取策略*：
1. **首选**：`sessions_spawn` with `agent_id="browser"` → 登录态完整读取 Page About/帖子
2. **browser 不可用时降级**：
   - `web_search "{公司名} facebook"` → 取 Page URL + 摘要
   - `web_search "{公司名} zalo"` / `"{公司名} hotline"`
   - 公司官网 Contact / Footer
   - 第三方名录（vietfactory.com / yellowpages.com.vn）

#### 5. Website

- **定义：** 官方独立域名。严禁使用 B2B 平台商铺链接代替官网。
- **补全指引：** 从官网、Google 搜索或 Facebook Page 中的链接提取。
- **输出格式：** 用户输出表保留**完整 URL**（如 `https://abc.com.vn`），方便直接访问。CRM 写回时 strip 为纯域名（`abc.com.vn`）。

### P1 级别字段（重要补充）

#### 6. Email

- **补全指引：** 从 Facebook Page 的 About 页面或官网 Footer 提取。

#### 7. Address (Địa chỉ)

- **补全指引：** 从 masothue.com 提取官方注册地址。注意识别是否位于重点工业园区（KCN）内。

#### 8. Industry & Products (Ngành nghề)

- **补全指引：** 通过官网产品页或所在的行业协会/展会类别判断。
- **行业 ID 映射：** 将自然语言描述映射到 CRM 行业 ID（调 `ggs-crm industry-mapping` 获取完整 lv1/lv2/lv3 行业 ID 表，LLM 语义匹配）。

#### 9. Company Size / Employees

- **补全指引：** 通过 vietnamworks.com 或 careerbuilder.vn 的招聘信息估计员工数量。

#### 10. Is Exporter (是否出口商)

- **判断依据：**
  - `confirmed`：明确提到海外客户、出口业务、FOB/CIF 等贸易术语
  - `inferred`：官网有英文版、参加国际展会、产品含国际认证
  - `unknown`：信息不足

#### 11. Is B2B

- **判断依据：**
  - `Yes`：描述中提到批发、供应商、B2B、wholesale；有企业客户案例
  - `No`：明确只面向个人消费者
  - `Unknown`：信息不足

#### 12. Key Person (关键人)

- **定义：** 能拍板的对接人（老板 / 外贸经理 / 跨境负责人）+ 直接联系方式。
- **补全指引（逐级）：** LinkedIn 公司页员工(职称过滤 Export/Sales Manager、`Giám đốc xuất khẩu`) → Facebook Page 管理员/发帖署名、招聘帖联系人 → 官网 About/Liên hệ → 同行 B2B 平台公司页 contact person → 工商库法人代表(兜底)。
- **输出：** 姓名 + 职位 + 直接联系方式，走动态列（采到才出）；找不到在 AI Summary 标注已穷尽来源。

#### 13. Current Platform Presence (当前平台存在性)

- **定义：** 该公司当前线上销售存在，用于入驻资格分级。VN 固定字段 `current_platform_presence`。
- **判断指引：**
  - **Alibaba**：`product_supplier_search "{公司名}"` → 命中则已入驻（非目标客户，标记排除）
  - **竞品平台**：`web_search "{公司名} site:globalsources.com"` / `site:made-in-china.com` 等

#### AI Summary（兜底摘要）

- **定义：** 承载用户意图中要求但不在预定义字段内的额外信息（如主要客户、成立年份），以及采集中发现的高价值补充信息。
- **补全指引：** 若无额外信息，填 `N/A`。

---

## Part 2: 字段规范 - 去重主键 + 联系方式校验 + 工商验证

### 2.1 去重主键字段

按优先级顺序尝试匹配：

| 优先级 | 字段 | 说明 |
|-------|------|------|
| 1 | MST（Mã số thuế） | 10 位或 13 位数字，越南唯一企业标识 |
| 2 | website（域名） | 去除协议头和 www 后比较 |
| 3 | company_name_local + province | 越南语全称 + 省份组合 |

### 2.2 联系方式校验

| 项目 | 规则 |
|------|------|
| 号码识别/分流 | 由 `scripts/phone-normalize.py`（libphonenumber, region=VN）判定：`type=MOBILE`→手机号(primary)；`FIXED_LINE`→固话(secondary)；`FIXED_LINE_OR_MOBILE`→按可作 primary 处理 |
| 固话处理 | helper 判 `FIXED_LINE` 的号不填 phone 主字段，记入 AI Summary 备注 |
| 号码格式 | 取 helper 的 `e164`/`international`（自动去首 0、加 +84），不手工拼接 |
| 多号处理 | 多个手机号逗号分隔填入，第一个为 primary（CRM 写回用） |
| 主要 IM 渠道 | **Zalo**（权重等同手机号）> Facebook Messenger > LinkedIn |
| Email 校验 | 基本格式校验，去重时作为辅助匹配键 |

### 2.3 工商验证

| 字段 | 本地名称 | 格式 | 说明 |
|------|---------|------|------|
| 税号/营业执照号 | Mã số thuế (MST) | 10 位或 13 位数字 | 越南的营业执照号 = 税号，同一编号 |

---

## Part 3: CRM 写回字段规范（VN 专属 override）

完整的 write-back 参数说明见 `ggs-crm show-docs crm-add` / `ggs-crm show-docs crm-refine`。以下为越南的国家级 override，同时适用于 crm-add（leads-finder Phase 9 新增）和 crm-refine（leads-finder Phase 9 捡入后补全 / enrichment Phase 6 已有客户补全）：

> **字段名与必填性以 `ggs-crm show-docs crm-add` / `crm-refine` 运行时返回为准，本文档不复制 CLI 字段清单（避免与 CLI drift）。** 下表是采集字段 → CRM 的映射意图与业务约束；写回前按 show-docs 拿当前权威必填列表，缺失则阻断并向用户列出。

| 采集字段 | 映射意图 | 业务约束 |
|---------|---------|---------|
| MST（税号）| → 注册号字段 | **MST 缺失 → 阻断写回**（越南业务硬规则）|
| phone | → 手机字段 | 调 `scripts/phone-normalize.py`（libphonenumber）取 `e164`/`international` 写回；`primary_ok=true` 的号作 primary；**只写手机，固话不回写** |
| website | → 官网字段 | strip 为纯域名（去 `www.` / `http(s)://`）；用户输出表保留完整 URL |
| province / city | → 地址字段 | 先调 `crm-address --country VN` 转码 |

---

## Part 4: 用户输出规范

### 4.1 用户输出字段（VN 专属）

向用户交付越南线索时，使用以下字段定义：

| Company Name (Local) | MST (Tax ID) | Phone | Zalo / FB | Email | Website | Address / KCN | Industry / Products | Platform Presence | CRM Detail | AI Summary |
|----------------------|--------------|-------|-----------|-------|---------|---------------|---------------------|-------------------|------------|------------|
| Công ty TNHH ABC | 0312345678 | +84 123456789, +84 987654321 | [Zalo: +84 123456789] / https://facebook.com/abcvn | info@abc.vn | https://abc.com.vn | KCN Sóng Thần 1, Bình Dương | Furniture | 竞品: GlobalSources（未在 Alibaba） | [详情](https://crm.alibaba-inc.com/crmagent/romeo/public-sea/customer-detail.html?globalId=xxx) | 固话: +84 274 1234567 |

**动态扩展：** 实际预览列 = 上表策展列 + 用户额外要求的字段（Intent Struct `extra_fields`，如 ISO 认证 / 主要出口国 / 领英粉丝数），按采集顺序追加到表末。与 xlsx 输出保持一致——不在策展列内的用户要求字段在聊天预览里也显示，不只落 xlsx。

### 4.2 xlsx 列定义

由 `../../../ggs-sales-leads-finder/scripts/leads-to-xlsx.py` 生成。以下 21 列为**基线参考列**（floor，不是上限；所有国家一致，始终输出）：

```
index, source,
company_name_en, company_name_local,
country, province, city, address,
industry, tax_id,
phone, email, website, im_account,
key_person_name, key_person_title,
confidence, qualityTags, dataSources, aiSummary,
crm_status
```

**说明：**
- `tax_id`: 各国通用税号 / 注册号（VN: MST；KR: 사업자등록번호；TW: 統一編號；IT: P.IVA；ES: NIF/CIF）
- `im_account`: 各国 IM 平台合并为一列（`Zalo: xxx; FB: yyy` / `KakaoTalk: xxx` / `LINE: xxx`）
- `key_person_name`: 单列存放完整姓名（如 KR 姓+名拼接）
- `crm_status`: CRM 内部字段（globalId/pool/orgId/ownerId/detailUrl）合并为一列——命中 CRM 显示「池 + 详情链接」，外部新线索为 N/A
- 已移除默认输出的内部列：`industryId` / `aiMatcher` / `commandResult`（需要时由 record 显式带上才作动态列出现）


所有字段在 xlsx 中作为**文本**写入（含逗号的字段不拆分）。

### 4.3 输出要求

1. 缺失字段一律填 `N/A`。
2. Markdown 预览表使用 4.1 的字段定义（越南专属）。
3. 表格下方附 `Result Summary`（50 字），说明数据来源和质量情况。
4. 必须附 Data Provenance Table（结构见 SKILL.md 输出 Phase 中的 Data Provenance Table 段）。采集中使用的黄页(trangvangvietnam.com)等数据源链接在此表中体现。
5. Phone 必须为 `+84` 国际格式。Phone 列填手机号（primary），固话记入 AI Summary。多个手机号逗号分隔。
6. Facebook / Website 列填写完整可点击 URL。
7. MST 阻断：如果某条线索既没有 MST 也没有官网，置信度标记为 `low`。
8. **CRM Detail 列**：仅 CRM 内已有客户（`globalId` 非空）展示详情页链接（`detailUrl`），外部新发现的线索填 `N/A`。链接使用 Markdown 格式 `[详情](url)` 展示。

---

## Part 5: crm-dedup 字段选择（VN payload）

在 enrichment Phase 5.3 调用 `crm-dedup` 时，越南线索优先提供以下字段：

```json
{
  "uid": "序号",
  "companyName": "公司英文名或本地名",
  "country": "VN",
  "email": "联系邮箱",
  "registerNumber": "MST（如已获取）"
}
```

完整 CLI 参数详见 `ggs-crm show-docs crm-dedup`。
