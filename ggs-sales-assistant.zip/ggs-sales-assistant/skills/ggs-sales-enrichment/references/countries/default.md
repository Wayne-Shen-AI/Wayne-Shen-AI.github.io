# Default / Global - enrichment 国家策略文件（Fallback）

本文件是 **ggs-sales-enrichment** skill 的通用 Fallback 知识库。当用户意图中的国家未匹配到专属配置文件（如 VN、IT、TW、KR、ES 等）时，加载本文件。

---

## Part 1: 字段补全指引

### 去重主键优先级

`website（域名）` > `company_name + country`

### 必须补全的字段

#### 1. Company Name 【去重主键辅助】

- **补全指引：** 优先从官网或 LinkedIn 公司主页提取官方名称。

#### 2. Website 【去重主键】

- **补全指引：** 移除 `www.` 和协议头。严禁使用 B2B 平台商铺链接代替官网。

#### 3. Contact Email & Phone

- **补全指引：** 访问官网 Contact 页面。电话必须包含国际区号。

#### 4. Is Exporter

- **判断依据：** 检查官网文本是否包含 FOB、CIF、MOQ、Export、Global Shipping 等外贸术语。

#### 5. Industry

- **补全指引：** 从官网产品页或搜索结果推断。映射到 CRM 行业 ID（调 `ggs-crm industry-mapping` 获取完整 lv1/lv2/lv3 行业 ID 表，LLM 语义匹配）。

#### AI Summary

- 若无额外信息，填 `N/A`。

---

## Part 2: 字段规范 - 去重主键 + 联系方式校验

### 2.1 去重主键字段

| 优先级 | 字段 | 说明 |
|-------|------|------|
| 1 | website（域名） | 通用最可靠标识 |
| 2 | company_name + country | 名称 + 国家组合 |

### 2.2 联系方式校验

| 项目 | 规则 |
|------|------|
| 电话校验/格式 | 由 `scripts/phone-normalize.py`（libphonenumber，按记录 country 作 region）校验并取 `e164`/`international` |
| 主要 IM 渠道 | 因国家而异，无默认偏好 |

---

## Part 3: CRM 写回字段规范（通用 override）

完整的 write-back 参数说明见 `ggs-crm show-docs crm-add` / `ggs-crm show-docs crm-refine`。以下为通用 override，同时适用于 crm-add（leads-finder Phase 9 新增）和 crm-refine（leads-finder Phase 9 捡入后补全 / enrichment Phase 6 已有客户补全）：

> **字段名与必填性以 `ggs-crm show-docs crm-add` / `crm-refine` 运行时返回为准，本文档不复制 CLI 字段清单（避免与 CLI drift）。** 下表是采集字段 → CRM 的映射意图与业务约束；写回前按 show-docs 拿当前权威必填列表，缺失则阻断并向用户列出。

| 采集字段 | 映射意图 | 业务约束 |
|---------|---------|---------|
| 注册号 / 税号 | → 注册号字段 | 通用 fallback 下 CRM 不强制；有则提供 |
| phone | → 电话字段 | 调 `scripts/phone-normalize.py`（libphonenumber）取 `e164`/`international` 写回；`primary_ok=true` 的号作 primary（按记录 country 作 region）|
| province / city | → 地址字段 | 先调 `crm-address --country {country}` 转码 |

---

## Part 4: 用户输出规范

### 4.1 用户输出字段（通用）

向用户交付通用线索时，使用以下字段定义：

| Company Name | Website | Phone | Email | Industry | Is Exporter | Confidence | CRM Detail | AI Summary |
|--------------|---------|-------|-------|----------|-------------|------------|------------|------------|
| Example Corp | example.com | +1 234 567 8900 | info@example.com | Manufacturing | Yes | High | [详情](https://crm.alibaba-inc.com/crmagent/romeo/public-sea/customer-detail.html?globalId=xxx) | N/A |

**动态扩展：** 实际预览列 = 上表策展列 + 用户额外要求的字段（Intent Struct `extra_fields`，如 ISO 认证 / 主要出口国 / 领英粉丝数），按采集顺序追加到表末。与 xlsx 输出保持一致——不在策展列内的用户要求字段在聊天预览里也显示，不只落 xlsx。

### 4.2 xlsx 列定义

由 `../../../ggs-sales-leads-finder/scripts/leads-to-xlsx.py` 生成。以下 21 列为**基线参考列**（floor，不是上限；所有国家一致，始终输出）：

```
index, source,
company_name_en, company_name_local,
country, province, city, address,
industry, tax_id,
phone, email, website, im_account,
key_person_name, key_person_title,
confidence, qualityTags, dataSources, aiSummary,
crm_status
```

**说明：**
- `tax_id`: 各国通用税号 / 注册号（VN: MST；KR: 사업자등록번호；TW: 統一編號；IT: P.IVA；ES: NIF/CIF）
- `im_account`: 各国 IM 平台合并为一列（`Zalo: xxx; FB: yyy` / `KakaoTalk: xxx` / `LINE: xxx`）
- `key_person_name`: 单列存放完整姓名（如 KR 姓+名拼接）
- `crm_status`: CRM 内部字段（globalId/pool/orgId/ownerId/detailUrl）合并为一列——命中 CRM 显示「池 + 详情链接」，外部新线索为 N/A
- 已移除默认输出的内部列：`industryId` / `aiMatcher` / `commandResult`（需要时由 record 显式带上才作动态列出现）


所有字段在 xlsx 中作为**文本**写入（含逗号的字段不拆分）。

### 4.3 输出要求

1. 缺失字段填 `N/A`。
2. 附 Result Summary + Data Provenance Table。
3. Phone 必须为国际格式（含 + 国家码）。
4. **CRM Detail 列**：仅 CRM 内已有客户（`globalId` 非空）展示详情页链接（`detailUrl`），外部新发现的线索填 `N/A`。链接使用 Markdown 格式 `[详情](url)` 展示。

---

## Part 5: crm-dedup 字段选择（通用 payload）

在 enrichment Phase 5.3 调用 `crm-dedup` 时，通用 fallback 线索优先提供以下字段：

```json
{
  "uid": "序号",
  "companyName": "公司英文名或本地名",
  "country": "<ISO 国家码>",
  "email": "联系邮箱"
}
```

> 通用 fallback 无统一国别注册号，dedup 主要靠 `companyName + country` 与 `website`（域名）。

完整 CLI 参数详见 `ggs-crm show-docs crm-dedup`。
