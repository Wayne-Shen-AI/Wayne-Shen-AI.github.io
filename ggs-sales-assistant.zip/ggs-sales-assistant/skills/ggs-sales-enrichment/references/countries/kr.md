# South Korea (KR) - enrichment 国家策略文件

本文件是韩国（KR）地区在 **ggs-sales-enrichment** skill 中的执行知识库。
当 enrichment skill Phase 2 路由结果为 `country=KR` 时加载本文件。

---

## Part 1: 字段补全指引

### 去重主键优先级

`사업자등록번호（Business Registration No.）` > `website（域名）` > `회사명（公司韩文名）+ 地区`

### P0 级别字段（核心 / 阻断字段）

#### 1. 회사명 (Company Name) 【起始字段】

- **定义：** 企业韩文法定名称及英文名称。在平台爬取阶段采集，是后续所有补全的起点。
- **补全指引：** 优先从 FTC 登记信息或官网 Footer 提取。需包含 "(주)"（株式会社）等法律后缀。
- **匹配规则：**
  - 允许法律后缀差异：주식회사 / (주) / Co.,Ltd / Inc. 等
  - 允许标点差异：空格、句号(.)、连字符(-)
  - 例：`한국무역 주식회사` ↔ `한국무역(주)`
- **标准化：** 搜索前移除 주식회사、유한회사、(주)、(유) 等后缀。
- **阻断规则：** 若差异无法用上述规则解释 → 停止，不继续执行。
- **已知挑战：**
  - 大量公司同名 → 需使用地址辅助匹配
  - 品牌名 ≠ 法人实体名 → 品牌搜索可能无法匹配工商记录

#### 2. 사업자등록번호 (Business Registration No.) 【去重主键】

- **定义：** 韩国商业登记号，固定 10 位数字，格式 `XXX-XX-XXXXX`。
- **补全指引（按优先级）：**
  1. 官网页脚 — 关键词：사업자등록번호、사업자번호、Business Registration No.
  2. Bizno.net / Moneypin.biz — 按公司名搜索
  3. LLM 解析页脚非结构化文本（补充正则遗漏）
- **标准化：** 格式 `XXX-XX-XXXXX`（10 位数字，含连字符）。注意页脚边缘情况：ㅡ 代替 -、混合特殊字符、数字间有空格。
- **阻断规则：** 若无法确认 VAT 号 → 停止，不继续执行。
- ⚠ 纯 AI 采集准确率 < 30%，**必须**通过 Bizno/Moneypin 验证。
- ⚠ Bizno/Moneypin 频繁访问会封 IP → 需 IP 轮换。

#### 3. 회사 홈페이지 (Website)

- **定义：** 公司独立域名。韩国企业常用 `.co.kr` 或 `.kr`。
- **补全指引（按优先级）：**
  1. 平台爬取阶段已采集（约 10%，因平台而异）
  2. Naver 地图注册信息（约 3%）
  3. Naver 搜索 API — LLM 根据标题 + 摘要 + 公司名选择官网
  4. Bizno.net / Moneypin.biz
- **标准化：** 仅保留域名，去掉 `www.` / `http(s)://`。排除电商及招聘平台 URL：Coupang、Gmarket、Saramin、Jobkorea 等。严禁使用 B2B 平台商铺链接代替官网。
- ⚠ 约 70% 的韩国企业没有官网 — 找不到则留空。

### P1 级别字段（重要联系字段）

#### 4. 연락처 이메일 (Contact Email)

- **补全指引（按优先级）：**
  1. 平台爬取阶段已采集
  2. 官网爬取 — 页脚、联系页(Contact)、客服页(고객센터)、关于我们(About Us)、隐私政策页面
  3. Naver 地图爬取
  4. Bizno / Moneypin 邮箱字段
- **标准化：** 排除无效域名：CS 中心、no-reply、noreply、webmaster。
- ⚠ 退信率约 10%。批量发送到 Naver/Gmail 域名有被标记为垃圾邮件的风险。
- ⚠ 邮箱可能属于已离职员工。
- ⚠ 很多邮箱以图片或 JS 渲染 — 目前不支持提取（可通过 @sparticuz/chromium 解决）。
- 找不到则留空。

#### 5. 전화번호 (Phone Number)

- **补全指引（按优先级）：**
  1. 平台爬取阶段已采集（展会参展商列表）
  2. **Naver 本地 API — 大部分电话号码的主要来源**
  3. 官网页脚 — 关键词：전화、TEL、연락처
  4. Bizno / Moneypin 电话字段
- **标准化：**
  - 010 号码（个人手机）→ 排除在公司电话之外，单独分类
  - 采集时保留本地格式：区号-号码（如 `02-XXXX-XXXX` / `031-XXX-XXXX`）
  - CRM 写回时转为国际格式：首尔 `02-1234-5678` → `+82 2 1234 5678`；手机 `010-1234-5678` → `+82 10 1234 5678`
- ⚠ 官网解析经常返回无效数据（号码缺失或嵌入图片中）。
- ⚠ 总机号码接通转化率低 — 优先获取个人直线。
- 找不到则留空。

#### 6. 대표자명 (CEO / Representative Name)

- **补全指引（按优先级）：**
  1. Bizno.net 代表人字段 — 通过 VAT 号查询
  2. Moneypin.biz 代表人字段
  3. 官网 关于/公司介绍 页面，寻找"대표자"或"CEO"
- **姓名拆分规则：**
  - 第一个字 → 姓（Family Name）
  - 其余 → 名（Given Name）
  - 例：홍길동 → 姓：홍 / 名：길동
- ⚠ Bizno/Moneypin 的 IP 封锁问题同样适用。
- ⚠ 共同代表人或家族传承企业的信息可能已过时。
- ⚠ 多位代表人同名时存在歧义。

#### 7. 지역 (Region)

- **补全指引（按优先级）：**
  1. 平台爬取 / Bizno / Moneypin 采集公司名时附带的地址
  2. Naver 本地 API — 公司名 + 地址匹配确认地区
  3. 官网页脚地址
- **标准化：** 提取 시/도 + 시/군/구 级别。例：경기도 시흥시 / 서울 강남구。
- ⚠ 注册地址可能与实际经营地不同。
- ⚠ 同地区同名企业 → 存在错误匹配风险。

#### 8. 산업 (Industry)

- **补全指引（按优先级）：**
  1. 官网产品/服务分类及关键词分析
  2. Bizno / Moneypin 行业分类字段
  3. Naver 地图行业类别
  4. LLM 基于官网内容的分类映射
- **行业 ID 映射：** 将自然语言描述映射到 CRM 行业 ID（调 `ggs-crm industry-mapping` 获取完整 lv1/lv2/lv3 行业 ID 表，LLM 语义匹配）。
- **分类标准：** KSIC（韩国标准产业分类，统计厅）+ NTS 事业分类码（国税厅）。KSIC 不可用时使用平台自有分类。
- ⚠ 韩国企业注册时倾向登记最多行业码 → 注册行业 ≠ 实际经营。
- ⚠ 多品类公司难以映射到单一类目。

#### AI Summary

- 承载用户意图中要求但不在预定义字段内的额外信息，以及采集中发现的高价值补充信息。
- 若无额外信息，填 `N/A`。

---

## Part 2: 字段规范 - 去重主键 + 联系方式校验 + 工商验证

### 2.1 去重主键字段

| 优先级 | 字段 | 说明 |
|-------|------|------|
| 1 | 사업자등록번호 | 10 位数字，格式 XXX-XX-XXXXX |
| 2 | website（域名） | .co.kr / .kr 域名 |
| 3 | 회사명 + 지역 | 韩文全称 + 地区 |

### 2.2 联系方式校验

| 项目 | 规则 |
|------|------|
| 号码识别/格式 | 由 `scripts/phone-normalize.py`（libphonenumber, region=KR）判 type 并取 `e164`/`international`（自动 +82、去首 0）；`MOBILE`→primary，`FIXED_LINE`→记入 AI Summary |
| 固话格式 | +82 + 区号（去 0）+ 号码 |
| 010 处理 | 个人手机号排除在公司电话之外，单独分类 |
| 主要 IM 渠道 | KakaoTalk > LinkedIn |
| 邮箱校验 | 排除 no-reply/noreply/webmaster；退信率约 10% |

### 2.3 工商验证

| 字段 | 本地名称 | 格式 | 说明 |
|------|---------|------|------|
| 事业者登录番号 | 사업자등록번호 | XXX-XX-XXXXX（10 位数字） | 韩国企业唯一标识，CRM 写回时去掉连字符 |

---

## Part 3: CRM 写回字段规范（KR 专属 override）

完整的 write-back 参数说明见 `ggs-crm show-docs crm-add` / `ggs-crm show-docs crm-refine`。以下为韩国的国家级 override，同时适用于 crm-add（leads-finder Phase 9 新增）和 crm-refine（leads-finder Phase 9 捡入后补全 / enrichment Phase 6 已有客户补全）：

> **字段名与必填性以 `ggs-crm show-docs crm-add` / `crm-refine` 运行时返回为准，本文档不复制 CLI 字段清单（避免与 CLI drift）。** 下表是采集字段 → CRM 的映射意图与业务约束；写回前按 show-docs 拿当前权威必填列表，缺失则阻断并向用户列出。

| 采集字段 | 映射意图 | 业务约束 |
|---------|---------|---------|
| 사업자등록번호（税号）| → 注册号字段 | **缺失 → 阻断写回**（韩国业务硬规则）；写回去连字符、保留 10 位数字 |
| phone | → 电话字段 | 调 `scripts/phone-normalize.py`（libphonenumber）取 `e164`/`international` 写回；`primary_ok=true` 的号作 primary（KR region）|
| province / city | → 地址字段 | 先调 `crm-address --country KR` 转码 |

---

## Part 4: 用户输出规范

### 4.1 用户输出字段（KR 专属）

向用户交付韩国线索时，使用以下字段定义：

| Company Name (Korean) | Company Name (Eng) | Business Reg No. | CEO Name | Phone | Email | Website | Region | Industry/Products | CRM Detail | AI Summary |
|-----------------------|--------------------|------------------|----------|-------|-------|---------|--------|-------------------|------------|------------|
| (주)예시 | Example Inc. | 123-45-67890 | 김민수 | +82 2 1234 5678 | minsu.kim@example.co.kr | example.co.kr | 서울 용산구 | Cosmetics | [详情](https://crm.alibaba-inc.com/crmagent/romeo/public-sea/customer-detail.html?globalId=xxx) | N/A |

**动态扩展：** 实际预览列 = 上表策展列 + 用户额外要求的字段（Intent Struct `extra_fields`，如 ISO 认证 / 主要出口国 / 领英粉丝数），按采集顺序追加到表末。与 xlsx 输出保持一致——不在策展列内的用户要求字段在聊天预览里也显示，不只落 xlsx。

### 4.2 xlsx 列定义

由 `../../../ggs-sales-leads-finder/scripts/leads-to-xlsx.py` 生成。以下 21 列为**基线参考列**（floor，不是上限；所有国家一致，始终输出）：

```
index, source,
company_name_en, company_name_local,
country, province, city, address,
industry, tax_id,
phone, email, website, im_account,
key_person_name, key_person_title,
confidence, qualityTags, dataSources, aiSummary,
crm_status
```

**说明：**
- `tax_id`: 各国通用税号 / 注册号（VN: MST；KR: 사업자등록번호；TW: 統一編號；IT: P.IVA；ES: NIF/CIF）
- `im_account`: 各国 IM 平台合并为一列（`Zalo: xxx; FB: yyy` / `KakaoTalk: xxx` / `LINE: xxx`）
- `key_person_name`: 单列存放完整姓名（如 KR 姓+名拼接）
- `crm_status`: CRM 内部字段（globalId/pool/orgId/ownerId/detailUrl）合并为一列——命中 CRM 显示「池 + 详情链接」，外部新线索为 N/A
- 已移除默认输出的内部列：`industryId` / `aiMatcher` / `commandResult`（需要时由 record 显式带上才作动态列出现）


所有字段在 xlsx 中作为**文本**写入（含逗号的字段不拆分）。

### 4.3 输出要求

1. `Business Reg No.` 保持 `XXX-XX-XXXXX` 格式显示。
2. 缺失字段填 `N/A`。
3. 附 Result Summary + Data Provenance Table。
4. Phone 必须为 `+82` 国际格式。
5. VAT 阻断：如果某条线索没有 VAT 号且没有官网，置信度标记为 `low`。
6. **CRM Detail 列**：仅 CRM 内已有客户（`globalId` 非空）展示详情页链接（`detailUrl`），外部新发现的线索填 `N/A`。链接使用 Markdown 格式 `[详情](url)` 展示。

---

## Part 5: crm-dedup 字段选择（KR payload）

在 enrichment Phase 5.3 调用 `crm-dedup` 时，韩国线索优先提供以下字段：

```json
{
  "uid": "序号",
  "companyName": "公司英文名或本地名",
  "country": "KR",
  "email": "联系邮箱",
  "registerNumber": "사업자등록번호（去连字符 10 位，如已获取）"
}
```

完整 CLI 参数详见 `ggs-crm show-docs crm-dedup`。
