---
name: ggs-sales-knowledge-base
description: >
  CRITICAL MUST-USE TOOL. This is the authoritative knowledge base for Alibaba.com (阿里国际站) Global Gold Supplier (GGS) business. 
  You MUST trigger this tool to answer ANY user query related to the following topics:
  1. Platform Rules & Compliance: 限售, 禁售, 侵权, 违规扣分, EPR (如德国包装法), CE, FDA, REACH, 以及针对欧美等各国的出口合规政策.
  2. Sales Strategy & Performance: 销售策略, 提成计算, 薪酬考核, 绩效, 激励, 客户开发, Leads规则, 库容, 公海. (Regions include Korea, Japan, Taiwan, HK, Vietnam, Turkey, India, Pakistan, etc.)
  3. Platform Tools & AI: 生意助手 (Smart Assistant), AI发品, 标题优化, PIS, RTS, 橱窗, 商品运营, 诊断工具.
  4. Order & Finance: 信保 (Trade Assurance), 纠纷处理, 退款, 账单, OBS, CRM系统操作, 基础服务费 (Service Fee).
  5. Membership & Events: 出口通 (Gold Supplier), 金品诚企 (Verified Supplier), 星等级评定, 三月新贸节 (March Expo), 采购节, 平台大促.
  Do NOT rely on your general training data for Alibaba policies. Always use this skill for 国际站, GGS, or B2B cross-border e-commerce questions.
metadata:
  version: 2.0.0
---

## When to Use

- User asks about Alibaba.com / GGS platform features, rules, or operations
- User needs guidance on product listing, RFQ, Trade Assurance, star rating, or marketing
- User asks about compliance rules, prohibited items, or IP violations
- User needs help with store optimization, buyer communication, or promotions
- Internal sales staff needs product knowledge, pricing, sales kits, or lead management
- Questions about country-specific rules, commission, or sales strategies

## How to Use

0. **确保 references 就绪（必须先执行，不可跳过）**：
   使用 bash 工具执行本 skill 目录下的 Python 脚本：
   ```
   python3 <SKILL_DIR>/scripts/ensure-references.py
   ```
   - 输出以 `OK:` 开头 → references 已就绪，继续步骤 1。
   - 输出包含 `ERROR` → 知识库文件暂时不可用，告知用户"知识库资源加载失败，请稍后重试"，终止后续步骤。
   - 首次执行会从远程下载（约 1MB），后续执行会直接跳过，无额外耗时。

1. Identify the knowledge domain from the user's question
2. Load the corresponding reference file using the routing table below
3. Apply metadata filters (region, merchant type, language) to narrow down relevant entries
4. If no matching knowledge found: Reply "目前没有找到确切信息，建议咨询人工客服"

## Quick Reference

知识库分为两层：**顶层汇编文件**（按业务领域聚合的知识条目）和 **子目录详细文档**（按主题/地区组织的独立文档）。AI 应根据用户问题的关键词，按下表路由到对应文件。

### 查找策略

1. **先判断是否涉及特定地区/市场** → 直接查 "地区路由表"
2. **再判断业务领域** → 查 "顶层汇编文件" 获取聚合知识
3. **如需更深入的专题文档** → 查 "子目录索引" 中的 INDEX.md，再定位具体文件
4. **跨领域/不确定时** → 先读 `references/MASTER-INDEX.md` 获取全局导航

---

### 一、顶层汇编文件（按业务领域聚合，适合快速查找）

| 领域 | 文件路径 | 条目数 | 关键词触发（用户提到这些词时查此文件） |
|------|---------|--------|--------------------------------------|
| 会员 | `references/membership.md` | 35 | 出口通, Gold Supplier, 会员续费, 会员权益, 到期, 基础服务费, Service Fee, 开通, 套餐 |
| 风控规则 | `references/risk-control.md` | 103 | 违规, 扣分, 处罚, 降权, 屏蔽, 侵权, 知产, IPR, 账号限制, 申诉, 整改 |
| 认证 | `references/certification.md` | 11 | BV认证, SGS, 验厂, Verified Supplier, 金品诚企, 证书, 深度认证 |
| 商品 | `references/product.md` | 39 | 发品, 商品发布, 类目, 标题优化, 关键词, 主图, 详情页, 产品评分, 商品诊断 |
| Leads管理 | `references/leads-management.md` | 12 | Leads, 线索, 公海, 库容, 分配规则, ReLead, 线索回收 |
| 旺铺 | `references/storefront.md` | 18 | 旺铺, 店铺装修, 橱窗, 公司介绍, 店铺评分, Mini Site |
| 服务 | `references/service.md` | 17 | 客服, 工单, 账号问题, 开户, 子账号, 权限, 认证审核 |
| 商家成长 | `references/merchant-growth.md` | 34 | 数据分析, 访客分析, 关键词分析, 流量, 曝光, 点击, 转化, 商家等级, 运营诊断 |
| 星级直达 | `references/star-direct.md` | 3 | 星等级, 星级评定, L1-L4, 买家层级 |
| 交易履约 | `references/trade-fulfillment.md` | 15 | 信保, Trade Assurance, 发货, 物流, 报关, 纠纷, 退款, 信用额度 |
| 广告 | `references/advertising.md` | 22 | P4P, 直通车, 全效推广, 竞价, 推广, 广告投放, CPC, 关键词出价 |
| 买家产品 | `references/buyer-products.md` | 2 | 术语词典, RFQ, 买家, ABpro, 采购意向 |
| 营销广告 | `references/marketing-ads.md` | 21 | 品牌广告, 粉丝通, 视频营销, 社交媒体, 内容营销, 直播 |
| 方案包 | `references/packages.md` | 5 | 方案包, 套餐组合, 增值服务, 解决方案 |
| 沟通 | `references/communication.md` | 6 | TM, 旺旺, 即时沟通, 询盘, 回复率, 发票, Invoice |
| 销售策划 | `references/sales-planning.md` | 21 | 销售策略, 客户开发, 拜访, 话术, 签单, 续签, 转化策略 |
| 售中 | `references/in-sales.md` | 9 | 售中服务, 订单跟进, 样品, 付款方式 |
| 活动大促 | `references/promotions.md` | 7 | 三月新贸节, March Expo, 采购节, 大促, 平台活动 |
| 生意助手 | `references/smart-assistant.md` | 9 | 生意助手, Smart Assistant, AI发品, 一键翻新, AI接待 |
| 促销规则 | `references/promo-rules.md` | 5 | 优惠券, Coupon, 满减, 限时折扣, 促销设置 |
| Sales Kits | `references/sales-kits.md` | 1 | 销售物料, Sales Kit |

---

### 二、子目录索引（按主题/地区组织的详细文档）

> **使用方式：** 先读对应子目录的 `INDEX.md` 获取文档列表和摘要，再按需加载具体文件。

#### 合规与禁限售规则

| 适用市场 | 索引路径 | 文档数 | 关键词触发 |
|----------|---------|--------|-----------|
| 欧盟/英国 | `references/compliance-rules/eu/INDEX.md` | 42 | EPR, CE, REACH, 欧盟, 德国包装法, EU Responsible Person, 欧洲合规 |
| 美国 | `references/compliance-rules/us/INDEX.md` | 20 | FDA, CPSC, FCC, 美国合规, 婴儿用品, 儿童安全, 美国限售 |
| 通用/全平台 | `references/compliance-rules/general/INDEX.md` | 22 | 禁售, 限售, 化妆品, 食品, 激光, 危化品, 酒类, 地图, 铅锭 |
| 其他市场(AU/CA/BR) | `references/compliance-rules/other-markets/INDEX.md` | 5 | 澳洲, 加拿大, 巴西, 医疗器械, 电信产品 |

#### 销售策略（按地区）

| 地区 | 索引路径 | 文档数 | 关键词触发 |
|------|---------|--------|-----------|
| 全球/跨区域 | `references/sales-strategy/global/INDEX.md` | 5 | FY26 Lead规则, 全球Leads, GGS Order FAQ, Verified Supplier, Dlocal支付 |
| 韩国 | `references/sales-strategy/korea/INDEX.md` | 4 | 韩国, Korea, KMD, 韩国佣金, 韩国Leads, 韩国退款 |
| 日本 | `references/sales-strategy/japan/INDEX.md` | 3 | 日本, Japan, Alijapan, 日本TS, 日本Leads |
| 台湾 | `references/sales-strategy/taiwan/INDEX.md` | 7 | 台湾, Taiwan, 台灣, 成功客户, 域名更改, 台湾付款 |
| 香港 | `references/sales-strategy/hongkong/INDEX.md` | 1 | 香港, HK, VA账户 |
| 越南 | `references/sales-strategy/vietnam/INDEX.md` | 9 | 越南, Vietnam, VN, ABCD分组, OBS Roadmap, 反对意见处理 |
| 土耳其 | `references/sales-strategy/turkey/INDEX.md` | 2 | 土耳其, Turkey, TR, Account Diagnosis |

#### 其他专题

| 专题 | 索引路径 | 文档数 | 关键词触发 |
|------|---------|--------|-----------|
| 通用参考/术语表 | `references/general-reference/INDEX.md` | 12 | 术语, 词典, 活动折扣报名, 流量场景, 资金管理, 违规整改建议, 买家层级 |
| 会员/成长/认证 | `references/membership-growth/INDEX.md` | 9 | 新品成长, 星级任务, 会员对比, BV认证, GGS Lite, 验证证书 |
| OBS/CRM系统 | `references/obs-crm/INDEX.md` | 6 | OBS, CRM, 服务费发票, PIS, 代理商操作, CRM SOP |
| 商品运营 | `references/product-operations/INDEX.md` | 8 | 重复铺货, RTS发品, 发品指南, 欧洲本地备货, 虚假定价, 样品服务, 商品分层 |
| 活动大促 | `references/promotions-events/INDEX.md` | 1 | 自主促销设置 |
| 工具/AI/生意助手 | `references/tools-ai/INDEX.md` | 9 | AI发品, 生意助手, 智能诊断, 批量编辑, AI一键翻新, AI Copilot, AI接待, AI店铺设计 |
| 交易/订单/支付 | `references/trade-orders/INDEX.md` | 9 | 信保下单, 查看订单, 支付, 提现, Chargeback, 售后纠纷, 发货履约, 信用额度 |

---

### 三、地区路由快速表

当用户问题涉及特定国家/地区时，同时查阅 **销售策略** 和 **合规规则** 两个维度：

| 地区 | 销售策略路径 | 合规规则路径 |
|------|-------------|-------------|
| 韩国 | `sales-strategy/korea/` | `compliance-rules/general/` |
| 日本 | `sales-strategy/japan/` | `compliance-rules/general/` |
| 台湾 | `sales-strategy/taiwan/` | `compliance-rules/general/` |
| 香港 | `sales-strategy/hongkong/` | `compliance-rules/general/` |
| 越南 | `sales-strategy/vietnam/` | `compliance-rules/general/` |
| 土耳其 | `sales-strategy/turkey/` | `compliance-rules/general/` |
| 欧盟/英国 | `sales-strategy/global/` | `compliance-rules/eu/` |
| 美国 | `sales-strategy/global/` | `compliance-rules/us/` |
| 澳洲/加拿大/巴西 | `sales-strategy/global/` | `compliance-rules/other-markets/` |
