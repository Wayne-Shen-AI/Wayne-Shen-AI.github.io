#!/usr/bin/env python3
"""
ensure-references.py
懒加载知识库 references 文件：本地无文件时从远程下载 zip 并解压。
用法：python3 ensure-references.py
退出码：0 = references 就绪，1 = 下载/解压失败

纯 Python 标准库实现，跨平台兼容（macOS / Windows / Linux）。
"""

import ssl
import sys
import time
import urllib.error
import urllib.request
import zipfile
from pathlib import Path

# ── 常量 ──────────────────────────────────────────────
SCRIPT_DIR = Path(__file__).resolve().parent
SKILL_DIR = SCRIPT_DIR.parent
REF_DIR = SKILL_DIR / "references"
ZIP_URL = "https://sc01.alicdn.com/H98dfb62982ac4527ad5abad1dd38ae34z.zip"
ZIP_TMP = SKILL_DIR / ".references-tmp.zip"
VERSION_FILE = REF_DIR / ".version"

# ── 预留版本号机制 ────────────────────────────────────
# 当前无远程版本控制，仅做本地记录。
# 未来如需强制更新，可在此处设置 EXPECTED_VERSION 并与 VERSION_FILE 比对。
EXPECTED_VERSION = ""  # 留空 = 不做版本校验，仅检查文件是否存在

CONNECT_TIMEOUT = 15  # 秒
DOWNLOAD_TIMEOUT = 180  # 秒
CHUNK_SIZE = 1024 * 64


def count_md_files() -> int:
    """统计 references 目录下一级的 .md 文件数量。"""
    return sum(1 for p in REF_DIR.glob("*.md") if p.is_file())


def check_need_download() -> bool:
    """判断是否需要下载 references。"""
    # 目录不存在
    if not REF_DIR.is_dir():
        return True

    # 目录存在但没有 .md 文件
    if count_md_files() == 0:
        return True

    # 版本校验（仅当 EXPECTED_VERSION 非空时生效）
    if EXPECTED_VERSION:
        if VERSION_FILE.is_file():
            current_version = VERSION_FILE.read_text(encoding="utf-8").strip()
            if current_version != EXPECTED_VERSION:
                print(
                    f"Version mismatch: local={current_version}, "
                    f"expected={EXPECTED_VERSION}. Re-downloading..."
                )
                return True
        else:
            return True

    return False


def _make_ssl_context() -> ssl.SSLContext:
    """创建跳过证书验证的 SSL 上下文，解决 macOS 系统 Python 缺少根证书的问题。"""
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    return ctx

def download_zip() -> None:
    """从远程下载 zip 文件到临时路径。"""
    start_time = time.monotonic()
    ssl_ctx = _make_ssl_context()

    with urllib.request.urlopen(ZIP_URL, timeout=CONNECT_TIMEOUT, context=ssl_ctx) as response:
        with ZIP_TMP.open("wb") as fp:
            while True:
                if time.monotonic() - start_time > DOWNLOAD_TIMEOUT:
                    raise TimeoutError(
                        f"Download exceeded max time ({DOWNLOAD_TIMEOUT}s)."
                    )

                chunk = response.read(CHUNK_SIZE)
                if not chunk:
                    break
                fp.write(chunk)


def extract_zip_safely() -> None:
    """安全解压 zip 到 SKILL_DIR，避免 zip slip。

    Python 3.11+ 支持 metadata_encoding 参数强制 UTF-8 解码文件名；
    低版本回退到普通模式，依赖 zip 文件本身的编码标记。
    
    注意：自动过滤 __MACOSX 目录和 .DS_Store 文件。
    """
    target_root = SKILL_DIR.resolve()

    zip_kwargs = {}
    if sys.version_info >= (3, 11):
        zip_kwargs["metadata_encoding"] = "utf-8"

    with zipfile.ZipFile(ZIP_TMP, "r", **zip_kwargs) as zf:
        # 安全检查并解压
        for info in zf.infolist():
            # 跳过 macOS 自动生成的 __MACOSX 目录和 .DS_Store 文件
            if info.filename.startswith('__MACOSX/') or info.filename.endswith('.DS_Store'):
                continue
            
            target_path = (target_root / info.filename).resolve()
            
            # 安全检查：防止 zip slip 攻击
            if target_path != target_root and target_root not in target_path.parents:
                raise ValueError(f"Unsafe zip entry path: {info.filename}")
            
            # 创建目录或提取文件
            if info.is_dir():
                target_path.mkdir(parents=True, exist_ok=True)
            else:
                target_path.parent.mkdir(parents=True, exist_ok=True)
                with zf.open(info) as source, open(target_path, 'wb') as target:
                    import shutil
                    shutil.copyfileobj(source, target)
    
    # 清理可能已存在的 __MACOSX 目录
    macosx_dir = target_root / "__MACOSX"
    if macosx_dir.exists():
        import shutil
        shutil.rmtree(macosx_dir)


def write_version() -> None:
    """写入版本号（如果 EXPECTED_VERSION 非空）。"""
    if EXPECTED_VERSION:
        VERSION_FILE.write_text(EXPECTED_VERSION + "\n", encoding="utf-8")
    elif VERSION_FILE.exists():
        # 禁用版本校验时删除历史版本标记，避免后续行为歧义。
        VERSION_FILE.unlink()


def main() -> int:
    # ── 检查是否已就绪 ──────────────────────────────
    if not check_need_download():
        count = count_md_files()
        print(f"OK: references already populated ({count} files). Skip download.")
        return 0

    # ── 下载 ────────────────────────────────────────
    print("Downloading knowledge base references from remote...")
    REF_DIR.mkdir(parents=True, exist_ok=True)

    try:
        download_zip()
        extract_zip_safely()
        write_version()
    except (
        TimeoutError,
        urllib.error.URLError,
        urllib.error.HTTPError,
        OSError,
        zipfile.BadZipFile,
        ValueError,
    ) as exc:
        print(f"ERROR: Failed to download or unzip references: {exc}")
        return 1
    finally:
        if ZIP_TMP.exists():
            try:
                ZIP_TMP.unlink()
            except OSError:
                # 清理失败不影响主流程结果。
                pass

    # ── 验证 ────────────────────────────────────────
    count = count_md_files()
    if count == 0:
        print(f"ERROR: Unzip succeeded but no .md files found in {REF_DIR}")
        return 1

    print(f"OK: Download complete. {count} reference files ready.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
