---
name: ggs-sales-outreach
description: >
  当销售想生成多渠道招商触达草稿时使用——只到草稿不发送。
  覆盖：开发信 / 冷启动邮件、Zalo / WhatsApp / LINE / KakaoTalk 即时消息、电话话术、跟进序列。
  触发词："写开发信"、"起草触达"、"冷启动话术"、"给这批 leads 写邮件"、"写电话开场"、"写跟进文案"。
  钩子来源：内部行业数据（RFQ/流量/买家国）+ 外部公开变化（政策关税/汇率/买家国需求/展会等）+ 同行谱图，三者按"越具体越贴客户关心"择强。
  会从 先富 / Orion CRM 拉客户基础信息和拜访记录学习语气。
  不处理：批量发现新潜客（用 ggs-sales-leads-finder）、单家深度调研/补全（用 ggs-sales-enrichment）、生成调研报告或 deck（用 ggs-sales-report）。
metadata:
  version: 2.1.0
---

> **通用约定见 [prompt.md](../../prompt.md)**——本 plugin 内部所有 skill 共享的认证、环境准备、写操作确认、跨 skill 编排、来源追溯等规则。本 SKILL.md 不重复 prompt.md 已定义的内容。

# 起草触达内容（国际站招商版）

多渠道（Email / IM / 电话 / LinkedIn）触达起草。专为阿里巴巴国际站销售设计，邀请本国工厂、贸易商、品牌商入驻国际站。

核心逻辑：**调研同行谱图 → 选钩子（内部数据 / 外部变化 / 定性，择强）→ 按目标国渠道起草**。

> 各国渠道、礼仪、模板见 `countries/{country}.md`。
> 钩子（内部行业数据 + 外部公开变化）的话术映射与字段异常处理见 `references/data-hook-guide.md`。

---

## 调用规则（任何 ggs-crm CLI 调用前必读）

本 skill 内部会调 `ggs-crm crm-search` / `ggs-crm crm-visit-query` 等 CLI 命令读取 CRM 数据（仅当需要拉客户基础信息和拜访记录学语气时）。

> 🚨 **硬前置：环境准备走 prompt.md，不可跳过。**
> 执行任何 ggs-crm 命令（含 `show-docs`）之前，必须先按 `prompt.md <crm_auth>` 的「环境准备」完成 CLI 就绪检查。
>
> ⚠️ **必须使用绝对路径**（基于 `repo_root_path`）：
> ```bash
> python3 {repo_root_path}/skills/ggs-sales-crm-tools/scripts/ensure-crm-cli.py
> ```
>
> 该脚本是环境准备的**唯一来源**（自带版本查询 / 比对 / 安装升级 / 校验，幂等 + 24h 缓存）。本 SKILL.md **不重复**任何手动 `--version` / `pip install` 步骤。
> - 解析返回 JSON：`status` 为 `ready` / `installed` / `upgraded` → 继续；`failed` → 停下，把 `message` 如实告诉用户，**不要继续 eval 任何 ggs-crm 命令、不要凭训练记忆模拟 CRM 数据**。
> - **后续所有 CRM CLI 调用必须用 JSON 里返回的 `invoke_prefix`**，不要用裸 `ggs-crm`（可能不在 PATH 上）。本文档下文为简洁用 `ggs-crm` 代指，实际执行请替换为 `invoke_prefix`。
> - 同一会话内只需跑一次；中途若出现 `command not found` / `unknown command`，重跑该脚本即可（脚本会判断是否需要升级）。

认证（Token / sales-id / org-id）流程同样见 `prompt.md <crm_auth>`，本文档不重复。

> ⚠️ **本文档可能展示简化的调用方式，不是完整 contract**。调用任何 ggs-crm 工具前**必须先查 show-docs** 拿当前最权威的参数定义：
>
> ```bash
> ggs-crm show-docs <tool_name>
> ```
>
> show-docs 返回的字段定义、必填性、参数互斥性是**权威**——本文档示例可能滞后于实际 CLI 版本。
>
> **失败处理：** 任何 ggs-crm 命令报错（unknown field / missing required / invalid value 等），**第一反应是 show-docs 拿当前权威 contract**，不要凭错误信息猜测改了重试。

---

## 业务背景

阿里巴巴国际站是全球 B2B 跨境电商平台。销售目标：帮助本国**工厂、贸易商、品牌商**入驻平台获取海外买家询盘。

| 客户类型 | 触达重点 |
|---|---|
| 制造商/工厂 | 平台帮你找海外买家，0 经验也能做 |
| 贸易公司/外贸商 | 流量大、成本比展会/独立站低，作为增量渠道 |
| 品牌商/跨境卖家 | B2B 客单价高、稳定性强，拓宽 B2C 之外的渠道 |
| 无经验的中小企业主 | 完整培训和运营支持，门槛低 |

---

## 钩子选择

钩子分**三个来源**，并行可用，原则始终是「**越具体、越贴客户当下关心的事 = 越强**」。单封触达只用 **1-2 个钩子**，不堆砌。

### 来源 A：内部行业数据钩子（P0-P4）
来自上游 `ggs-sales-industry-insights` 的内部数据。按 `references/data-hook-guide.md` 第 1 节把字段（实时买家询盘 RFQ、流量指数、买家国、热搜词、同行标杆）转化为话术。**P0（真实买家询盘）是最强钩子——有就优先用。** 字段为 null/0/负值时按 guide 第 2 节降级，严禁直接输出原始数值。

### 来源 B：外部变化钩子（网搜，本 skill 自己抓，**来源开放**）
**降低对内部数据的依赖**——客户关心的外部公开变化都能当钩子。围绕「客户行业 + 目标买家国」搜近期变化，**搜哪个角度、去哪儿挖、搜多深，都交给判断**：够一条新的、能当钩子的可溯源事实即止。

- **角度开放**：`references/data-hook-guide.md` 第 3 节列的分类（政策/关税、汇率、买家国需求、展会/季节性、原材料/物流、同行动作、行业新闻）**是举例，不是穷举**——清单外只要对这家客户当下是真钩子的变化（如目标买家国某项进口配额放开、某港口中断影响交期）都可以用。
- **来源开放**：官网、行业协会、海关/贸易统计、当地商业新闻、平台公开数据等都可用——由判断决定去哪儿找，但偏向权威源、对 SEO 软文存疑。
- **硬规则不放开**：归属、可信度、不洗白等所有钩子通用的硬规则见 `references/data-hook-guide.md` 第 0 节，逐条遵守。

### 来源 C：定性钩子（兜底，不依赖任何外部取数即可用）

**🥇 同行谱图（最有效）** — "你周围/同行里做外贸的，很多都已经在国际站了"
挖掘方法：
1. 在 Alibaba.com 上搜索客户主营产品 + 客户所在国，记录供应商数量
2. 找到代表性同行（最好同城/同省）
3. 网络搜索：该行业是否有出口趋势/新闻（这一步可顺带产出"来源 B"的外部钩子）
4. 构造表述：**同城 > 同省 > 同国 > 同行业**，越具体越好

**🥈 市场询盘机会** — "这个行业海外买家询盘量大，但同地区卖家还不够多"

**🥉 平台价值（兜底）** — "国际站在这个品类的流量和买家质量，其他平台很难替代"

> **择强原则**：内部 P0（真实 RFQ）和一条精准的外部变化（如针对目标买家国的关税利好）都可能是顶级钩子。三个来源不是优先级链，而是"哪个对这家客户更具体、更戳当下关心，就用哪个"。内部数据取不到时，外部变化钩子完全可以独立撑起一封触达（"也够了"）。

---

## Phase 0：策略上下文软依赖检测

**起草前先检查**：上下文里是否有 ggs-sales-strategy 的 JSON 输出（销售刚跑过 strategy）。

### 有 strategy JSON 输出 → 增强模式

**关键**：增强模式不替代下面的 Step 1-7，而是在 Step 1-7 之上**加一层阶段套路约束**：

| 元素 | 哪里决定 |
|---|---|
| **格式（段数 / 长度 / CTA 类型）** | Phase 0 增强模式 — 按客户阶段路由 `references/stage-playbooks.md` |
| **钩子选择（内部 P0-P4 + 外部变化 + 同行谱图）** | Step 1-7 原有逻辑（但优先用 strategy.diagnosis.pain_points 决定哪个钩子最匹配卡点）|
| **正文核心叙事** | strategy.playbook.steps 落地到具体动作 |
| **异议预防** | strategy.deal_probability.risks → `references/objection-prevention.md` |
| **套餐提及** | strategy.package_match.primary_directions（仅给方向，不点名产品）|

**执行顺序**：
1. 读 strategy JSON 的 `customer_stage.stage` → 决定走哪个阶段套路（cold / awareness / interest_evaluation / decision_closing）
2. 加载对应阶段套路 `references/stage-playbooks.md` 段
3. 仍然按下面 Step 1-7 走完整流程（钩子 + 同行谱图 + 数据预检），但格式遵循阶段套路约束

按 `references/stage-playbooks.md` 路由到对应客户阶段的内容套路：
- `cold` → 超短 + 1 钩子 + 软 CTA
- `awareness` → 3 段（钩子 + 行业/对你影响 + 案例）+ CTA
- `interest_evaluation` → 4 段（同行案例 + 买家画像 + ROI + CTA）
- `decision_closing` → 5 段（套餐对比方向 + 限时 + ROI + 异议预防 + 强 CTA）

消费 strategy JSON 的字段：
- `customer_stage.stage` — 决定走哪个阶段套路
- `diagnosis.pain_points` — 钩子选择的依据（客户卡点 → 平台卖点方向 / 外部变化方向 → 钩子内容）
- `playbook.steps` — 路径里的关键动作 → 邮件正文核心叙事
- `deal_probability.risks` + `deal_probability.key_questions` — 按 `references/objection-prevention.md` 在邮件里主动预防 / 在 CTA 引导客户提供
- `package_match.primary_directions` — 邮件提及套餐方向时按此（**不点名具体产品**——按 strategy 设计，具体产品是 KB 决定的）

### 无 strategy JSON 输出 → 默认模式（原 Step 1-7）

继续按下面"执行顺序"原 7 步执行 —— 钩子选择走原三来源（内部 P0-P4 + 外部变化 + 同行谱图）逻辑。

**关键**：起草开头加一行温和提示给销售（不在邮件正文里）：
> 💡 如果先用 strategy 盘下这家客户的整体打法，这封邮件会更贴客户视角（客户阶段 / 卡点 / 路径都能针对）。当前是基于行业数据 + 外部变化 + 同行谱图的通用模式。

提示**只说一次**——销售可能就是不想盘，连续提多次反而烦。

### Phase 0 兼容性原则

- 软依赖**不强制** — 销售可以一直在"无 strategy"模式工作
- 阶段套路里**仍然**调用原有的钩子选择 / data-hook-guide / 同行谱图 / 外部变化 —— 阶段套路是"用什么节奏 + 什么长度 + 什么 CTA"，钩子内容仍走原有逻辑
- 失败时退化 — strategy JSON 不完整 / 阶段标识符无效 → 退到"无 strategy"模式 + 提示销售

---

## 执行顺序

1. **解析目标**:客户类型、目标国、主营产品、行业 → 加载 `countries/{country}.md`

2. **客户上下文预检(Option a:直接调 CLI)**:看上下文是否已有客户基础信息和拜访记录
   - 已有(用户传入或之前已查) → 直接进 Step 3
   - 没有但有 lead_id 或公司名 → **本 skill 内部直接调 `ggs-crm crm-search` 或 `ggs-crm crm-visit-query`**(按 `prompt.md <crm_auth>` 鉴权 + 环境准备;字段语义见 `ggs-crm show-docs crm-search-global-fields` / `crm-search-hktw-fields`)
     - **命令参数(pool / sales-id / org-id / conditions JSON / global-id 等)详见 `../ggs-sales-crm-tools/SKILL.md` 的「1. 查询私海/公海列表」和「3. 查询拜访记录」章节**——本 skill 不复制命令文档,直接读 ggs-sales-crm-tools 那边的权威定义,不要凭记忆传参
     - 身份配置(sales-id / org-id / role-id)按 `prompt.md <crm_auth>`「Identity Config」走 `crm-roles` + `config` 持久化;持久化后续命令可省略 `--sales-id` / `--org-id`(CLI 自动读取),本文档不重复该流程
     - CRM Family 路由(Global vs HKTW)按 ggs-sales-crm-tools/SKILL.md「CRM Family 路由」章节判断
   - 取数失败/超时 → 不要重试、不要卡死,直接进 Step 3 用现有信息
   - 完全没有客户标识(裸 query) → 中断,问用户

3. **钩子数据预检(强烈推荐,非阻塞)**:看上下文是否已有钩子素材,内部 + 外部并行
   - **内部行业数据(P0-P4)**:上下文已有 → 用;没有 → 按 `prompt.md <chained_execution>` 同向连贯规则**切到 ggs-sales-industry-insights**取得后回来(这是跨 skill 编排)。取不到/无该行业数据 → 不重试不卡死,转下一项
   - **外部变化(来源 B)**:为客户行业 + 目标买家国搜近期外部事实(政策/汇率/需求/展会等,角度与来源开放、深度按判断),抓 1 条能当钩子的。每条必须有 `[source: URL]` + 大致时间;搜不到就按 searched_but_empty 跳过,**不编**。所有钩子通用的归属/可信度硬规则见 `references/data-hook-guide.md` 第 0 节
   - **两者都拿不到** → 退到 Step 4 的同行谱图 / 定性钩子,完全够用

4. **调研同行谱图**:始终做(即使有内部 P0-P4 或外部钩子也补这一层定性内容,越具体越有说服力)。这一步的网搜可顺带产出 Step 3 的"外部变化"

5. **选钩子**:三来源择强(见「钩子选择」)。单封最多 1-2 个——内部 P0 / 一条精准外部变化 / 同行谱图,挑对这家客户最具体、最戳当下关心的

6. **按目标国渠道起草**:查 `countries/{country}.md` 取渠道偏好与模板

7. **输出完整草稿包**(见下)

> 内部行业数据与外部变化钩子比纯定性钩子说服力高,但对触达来说都是 strong preference 而非 blocker。若用户明确要求"快速出稿不取数"或上游反复失败,直接进定性钩子即可。

> ⚠️ **本 skill 仅产出草稿,不写 CRM、不发邮件。** 用户问"怎么发"或"帮我发"→ 按 `prompt.md <scope_honesty>` 说明发送不在能力范围内。
> 用户问"记一笔到 CRM"等写操作 → 按 `prompt.md <chained_execution>` 跨意图必停规则,先汇报草稿,等用户点头后切到 ggs-sales-crm-tools 走 `<read_vs_write>` 确认流程。
> 用户要"深挖这家公司背景 / 补全联系人字段"→ 这是 `ggs-sales-enrichment` 的活,按跨意图必停提示切过去,不要在本 skill 里做深度外部调研。

信息缺失时(如不知道客户主营产品、不知道目标国),**直接中断流程,用自然语言向用户提问**,不要瞎编。

---

## 输出格式

```markdown
# 触达草稿：[姓名/公司] @ [国家]
**主渠道：** [Zalo/WhatsApp/Email/LINE/KakaoTalk/电话]（见对应国家文档）
**选用钩子：** [同行谱图 / 市场询盘 / 平台价值 / P0 RFQ / P1 流量 / P2 买家 / P3 热搜词 / P4 标杆 / 外部变化（政策·汇率·需求·展会…）]

## 同行谱图摘要
- 平台同行数量：[Alibaba.com 上该国 + 该产品供应商数]
- 同城/同省同行：[越具体越好]
- 行业趋势：[出口增长迹象/新闻]
- （如有）内部行业数据：[流量指数 / 买家国 / 热搜词 / 同行标杆——只引用 guide 处理过的话术]
- （如有）外部变化：[政策/关税·汇率·买家国需求·展会等——附来源链接 + 大致时间]

## 主渠道文案
[纯文本格式，无 Markdown]

## 备选渠道文案
[纯文本格式，无 Markdown]

## 跟进序列（3 步）
- 第 2 天：[补充一个具体同行案例/数据截图]
- 第 5 天：[换角度——询盘机会 / 平台工具价值 / 一条相关外部变化]
- 第 10 天：[收尾，给具体时间选项推动决策]

## 事实审计表(Source Attribution 对外呈现)

按 `prompt.md <source_attribution>` 内部 tag,呈现时翻译成自然语言:

| 核心事实 | 文案引用 | 数据源 |
|---|---|---|
| 客户基础信息(行业、地址、规模) | [引用值] | CRM(lead_id=xxx) / 官网 / 用户输入 |
| 拜访记录摘要(如有) | [引用值] | CRM 拜访记录 |
| 同行数量 | [引用值] | Alibaba.com 搜索链接 |
| 内部行业数据(流量/买家国/热搜词) | [引用值] | ggs-sales-industry-insights 内部数据库 |
| 外部变化(政策/汇率/需求/展会) | [引用值] | 公开来源 URL + 大致时间 |
| 客户背景 | [引用值] | 官网/招聘网/工商网链接 |

**禁止:**
- 不输出方括号内部 tag 给用户(`[CRM: xxx]` / `[source: URL]` 是内部思考标记)
- 不能溯源的事实**不出现在文案里**(也不出现在审计表里)
- 上游取数失败时如实说"行业数据没取到,本次用外部变化 / 定性钩子",不编一个数据
- 外部变化搜不到时如实说"未找到可靠来源",不编政策/数字/时间
```

---

## 写作通用规范

1. **简洁有力** — 开场 1-2 句说到点
2. **禁用 Markdown** — IM/邮件正文用纯文本（不用星号、加粗、标题），段落短（2-3 句）
3. **IM 消息要短** — 用户不会读完长篇
4. **同行数据要具体** — "胡志明市有 X 家同行入驻" 比 "很多同行在做" 强
5. **外部变化要新且可溯源** — 引用政策/汇率/需求变化时，注明大致时间，事实落到来源链接；不做关税/法律/投资解读，只当聊起来的由头
6. **语言本地化** — 触达文案语言由目标客户国决定（见各国文档）
7. **语言镜像（强制）** — 与用户的对话层面（提问、澄清、摘要、跟进说明）使用**用户输入的语言**。文案本身的语言由目标客户国决定，对话与文案语言可以不同。

---

## 禁止事项

- "您好，打扰了……"（不自信）
- "我们是全球最大的……"（自我介绍太长）
- "我注意到您在做外贸"（不够具体）
- 一上来就讲套餐价格（还没引发兴趣）
- IM 消息超过字数限制
- **直接输出 null / 0 / 负值原始数据**（按 data-hook-guide 降级）
- **编造外部变化**（政策、关税税率、汇率数字、展会时间等）——搜不到就不用，绝不凭训练记忆补
- 把外部变化写成关税/法律/投资建议（只当钩子，不当顾问）

---

## 销售配置（用户自定义）

```
- 我的姓名：[]
- 负责地区：[越南 / 韩国 / 台湾 / 香港 / 印度 / 巴基斯坦 / 日本 / 土耳其]
- 联系方式：[手机 / WhatsApp / Zalo / LINE / KakaoTalk]

CTA 偏好：
- 默认："方便的话，我们抽空聊一下？"
- 较轻："我发给您一份同行入驻数据参考？"
- 具体："这周三或四，哪个时间方便通话？"
```

---

## 各国文档索引

| 国家/地区 | 主渠道 | 文件 |
|---|---|---|
| 越南 | Zalo | `countries/vietnam.md` |
| 韩国 | Email + 电话 | `countries/korea.md` |
| 台湾 | LINE | `countries/taiwan.md` |
| 香港 | WhatsApp + Email | `countries/hongkong.md` |
| 印度 | WhatsApp | `countries/india.md` |
| 巴基斯坦 | WhatsApp | `countries/pakistan.md` |
| 日本 | Email *（仅邮件，多渠道待补）* | `countries/japan.md` |
| 土耳其 | Email *（仅邮件，多渠道待补）* | `countries/turkey.md` |
