# 印度市场配置

## 渠道优先级

| 优先级 | 渠道 | 使用场景 |
|--------|------|----------|
| 🥇 首选 | **WhatsApp** | 印度商务沟通绝对主渠道，几乎所有老板都在用 |
| 🥈 次选 | **电话** | WhatsApp 无回应后直接致电，接受度高 |
| 🥉 补充 | **Email** | 正式场合、大企业、需要附件时 |

> **印度特点：** WhatsApp 在印度是名副其实的"全民 IM"，B2B 场景下谈生意、发报价单、确认订单全在 WhatsApp 上完成。印度商人普遍接受陌生商务联系，直接、简洁的英语是最佳风格。印度制造业有明显的产业集群（见下方），"你们城市/邦的同行都在做"这个角度非常有效。**建议 WhatsApp 消息要短，不要冗长。**

---

## 同行谱图挖掘方法（印度专项）

### 数据来源优先级
1. **Alibaba.com 直接搜索** — 搜索产品关键词，筛选 `India` 供应商，记录数量和代表企业
2. **CRM（如接入）** — 印度该行业的入驻数量、询盘量、近期新增数
3. **网络搜索** — `"[product] India supplier alibaba"` 或印度出口数据
4. **印度贸易数据** — Volza / Zauba Corp 查该行业出口商集中区

### 地理颗粒度参考（印度）
- 孟买/浦那（Maharashtra）：化工、制药、纺织、工程产品
- 德里/NCR：电子、机械、皮革、珠宝
- 班加罗尔（Karnataka）：科技、机械、丝绸
- 苏拉特（Gujarat）：钻石切割、纺织、化工（Gujarat 是印度最大出口邦）
- 阿姆利则/勒克瑙（Punjab/UP）：纺织、手工艺品
- 金奈（Tamil Nadu）：汽车配件、皮革、纺织
- 海德拉巴（Telangana）：制药、IT、珠宝

### 构造同行数据表述示例
```
"There are already a significant number of Indian [product]
suppliers on Alibaba.com — many of them from Gujarat/Maharashtra.
They're receiving steady inquiries from US and EU buyers."

"Suppliers in [City/State] similar to yours have been
joining the platform recently and getting international
orders within the first few months."
```

---

## 消息模板

### 模板 A：WhatsApp × 钩子"同行谱图"

```
Hi [Name],

I'm [Your Name] from Alibaba.com.

Just wanted to share — there are already many Indian
[product] suppliers on our platform, including many from
[Gujarat / Maharashtra / their state].
They're getting inquiries from US, EU, and Middle East buyers.

Would [Company Name] be open to exploring this? Happy to
share more in a 15-minute call.

[Your Name] | Alibaba.com
WhatsApp: [your number]
```

### 模板 B：WhatsApp × 钩子"市场询盘机会"

```
Hi [Name],

[Your Name] here from Alibaba.com.

[Product] is one of our high-demand categories right now —
lots of B2B buyers from Europe and the Middle East actively
sourcing from Indian suppliers.

Thought [Company Name] would be a great fit. Worth a
15-minute chat this week?

[Your Name] | Alibaba.com
```

### 模板 C：WhatsApp × 无外贸经验的小企业主

```
Hi [Name],

I'm [Your Name] from Alibaba.com — the leading B2B
export platform.

Many [product] manufacturers from India with no prior
export experience have started receiving international
orders through us within a short period.

The platform handles buyer matching, translation, and
negotiation tools — you just focus on your product.

Interested to learn more? A 15-minute chat is all it takes.

[Your Name] | Alibaba.com
```

### 模板 D：电话话术框架

```
[开场]
"Hi, am I speaking with [Name]? This is [Your Name] calling
from Alibaba.com International."

[确认对方后]
"I'll be very brief — I'm reaching out to [product]
suppliers in [City/State]. We have a lot of B2B buyers
from Europe and the US actively looking for Indian
suppliers in this category."

[对方感兴趣]
"Could we set up a 15-minute call this week? I can walk
you through what suppliers similar to yours are doing
on the platform."
```

### 模板 E：Email × 大企业正式场合

```
Subject: Export opportunity for [Company Name] — Alibaba.com

Dear [Name],

I'm reaching out from Alibaba.com International regarding
an export opportunity for [Company Name].

[Product] is currently one of our high-demand categories,
with strong buyer interest from Europe, the US, and the
Middle East. Indian suppliers in this category — including
those in [State] — are seeing solid inquiry volumes.

I'd love to share specific data on buyer demand and how
similar companies have approached this. Would you have
15 minutes for a call this week?

Best regards,
[Your Name]
Alibaba.com International
WhatsApp: [number] | Email: [email]
```

---

## 跟进序列（印度）

| 时间 | 渠道 | 内容 |
|------|------|------|
| Day 1 | WhatsApp | 发送首条消息（模板 A） |
| Day 2 | 电话 | 直接致电，接受度很高 |
| Day 5 | WhatsApp | 补发该产品类目的买家需求截图或数据 |
| Day 10 | WhatsApp | 分享一个印度同行的成功案例（简短） |
