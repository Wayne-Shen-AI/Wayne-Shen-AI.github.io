# 越南市场配置

## 渠道优先级

| 优先级 | 渠道 | 使用场景 |
|--------|------|----------|
| 🥇 首选 | **Zalo** | 越南本地 IM，B2B 商务沟通最主流 |
| 🥈 次选 | **Facebook Messenger** | 年轻老板、时尚/消费品行业更活跃 |
| 🥉 备选 | **Email** | 正式场合、大企业、附件发送 |
| 补充 | **电话** | Zalo/FB 无回复后跟进 |

> **越南特点：** Zalo 在越南的渗透率极高，B2B 场景下很多老板直接用 Zalo 谈生意。Facebook 在越南中小企业主中也非常活跃，尤其是消费品、家具、服装行业。建议 Zalo + Facebook 双线并行，不要只用邮件。

---

## 同行谱图挖掘方法（越南专项）

### 数据来源优先级
1. **Alibaba.com 直接搜索** — 搜索产品关键词，筛选 `Vietnam` 供应商，记录数量
2. **CRM（如接入）** — 越南该行业的入驻数量、近期新增数、询盘量
3. **网络搜索** — `"[产品] Vietnam export" site:alibaba.com` 或越南出口新闻
4. **越南工商数据** — masothue.com / doanhnghiep.biz 查同行公司集中地

### 地理颗粒度参考（越南）
- 胡志明市：电子、家具、纺织、食品加工产业集中
- 河内：制造业、工业品
- 平阳/同奈：工厂集中区，制造业密集
- 岘港：中部，木材/家具产业带

### 构造同行数据表述示例
```
"越南做家具出口的工厂，在我们平台上已经有相当规模的同行入驻，
其中胡志明市的供应商占了大头。"

"平阳省做塑料制品的工厂，最近半年在国际站新入驻的
就有不少，接到的询盘主要来自美国和欧洲。"
```

---

## 消息模板

### 模板 A：Zalo × 钩子"同行谱图"（越南语）

```
Chào [Tên],

Tôi là [Tên bạn] từ Alibaba.com.

Công ty bạn đang sản xuất [sản phẩm] - mình thấy ở
[TP.HCM / Bình Dương / Hà Nội] đã có khá nhiều nhà máy
cùng ngành đang nhận inquiry từ Mỹ và EU qua nền tảng
của mình rồi.

Bạn đã từng cân nhắc mở gian hàng trên Alibaba.com chưa?
Chỉ cần một chút thời gian để mình chia sẻ thêm.

[Tên bạn] | Alibaba.com
Zalo: [số của bạn]
```

### 模板 B：Zalo × 钩子"同行谱图"（中文版，适用于越南华商）

```
您好 [姓名]，

我是阿里巴巴国际站的 [你的名字]。

看到贵司在做 [产品]，[胡志明市/平阳] 同行里已经有不少
工厂在我们平台上接海外订单了，来自欧美的询盘最近也挺多。

您有没有考虑过入驻国际站？我们 15 分钟聊一下？

[你的名字] | 阿里巴巴国际站
Zalo: [你的号码]
```

### 模板 C：Facebook Messenger × 钩子"同行谱图"

```
Xin chào [Tên],

Mình thấy page của công ty bạn - [sản phẩm] của các bạn
trông rất chất lượng!

Hiện tại trên Alibaba.com, các nhà cung cấp [sản phẩm]
từ Việt Nam đang nhận được khá nhiều đơn từ buyer quốc tế.
Nhiều đơn vị cùng ngành ở [khu vực] cũng đã bắt đầu rồi.

Bạn có muốn tìm hiểu thêm không? 😊

[Tên bạn] | Alibaba.com
```

### 模板 D：Email × 正式场合

```
Kính gửi [Tên] / 敬启者,

Tôi là [Tên bạn], đại diện Alibaba.com tại Việt Nam.

Được biết quý công ty chuyên sản xuất [sản phẩm]. Hiện tại
trền nền tảng của chúng tôi, nhu cầu từ buyer quốc tế đối
với mặt hàng này đang tăng mạnh, trong khi số lượng nhà
cung cấp Việt Nam vẫn còn hạn chế.

Tôi muốn chia sẻ một số dữ liệu thị trường liên quan.
Quý vị có thể dành 15 phút cho một cuộc trao đổi ngắn không?

Trân trọng,
[Tên bạn] | Alibaba.com
```

---

## 跟进序列（越南）

| 时间 | 渠道 | 内容 |
|------|------|------|
| 第 2 天 | Zalo | 发一张该产品类目的 Alibaba.com 买家需求截图 |
| 第 5 天 | Facebook / Zalo | 分享一个越南同行的入驻成功简介（脱敏） |
| 第 10 天 | 电话 | 直接致电，简短确认是否有兴趣进一步了解 |
