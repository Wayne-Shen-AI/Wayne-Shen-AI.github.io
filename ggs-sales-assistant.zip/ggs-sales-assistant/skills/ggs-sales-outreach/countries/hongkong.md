# 香港市场配置

## 渠道优先级

| 优先级 | 渠道 | 使用场景 |
|--------|------|----------|
| 🥇 首选 | **WhatsApp** | 香港 IM 绝对主渠道，商务场景普遍 |
| 🥇 首选 | **Email** | 正式触达，与 WhatsApp 并行 |
| 🥈 次选 | **电话** | WhatsApp/Email 无回应后跟进 |

> **香港特点：** 香港商人节奏快、效率优先，沟通要直接、简洁。WhatsApp 和 Email 可同时发出。香港贸易公司和中间商多，许多已经有出口经验，"同行在用"的角度要结合平台具体的增量价值（如 AI 工具、买家质量、类目扩展），不要强调"0 经验也能做"。**组合：WhatsApp 首触（简短） → Email 跟进（附资料） → 电话推进决策。**

---

## 语言规范

- **首选：繁体中文**（香港本地商人）
- **英语**：适合外资背景、多国企业联系人；对方用英语回复就切换到英语
- **粤语书面表达**（如"係"、"唔"）：只在非常熟悉后使用，初次触达用正式书面中文
- 语气比台湾稍正式，但比韩国/印度更注重效率
- WhatsApp 控制在 80 字以内，香港商人不会读长消息

---

## 同行谱图挖掘方法（香港专项）

### 数据来源优先级
1. **Alibaba.com 直接搜索** — 搜索产品关键词，筛选 `Hong Kong` 供应商，记录数量
2. **CRM（如接入）** — 香港该行业入驻数、询盘转化率
3. **网络搜索** — `"[product] Hong Kong B2B export alibaba"` 或香港贸发局行业数据

### 香港客户特殊考量
- 香港是全球贸易枢纽，**很多香港公司是贸易中间商而非制造商**（工厂常在大陆），香港注册公司 + 大陆生产的架构在国际站的供应商角色依然成立
- 主要行业聚落：珠宝、电子产品、成衣、钟表、玩具、食品贸易
- 切入角度：**增量渠道**（"除了现有渠道，国际站可以触达更多买家"）或 **AI 工具价值**（"平台 AI 工具可以省运营时间"）
- 触达前应挖掘：目标公司的主营业务（是否有外贸/贸易背景）、平台上同类香港供应商数量

---

## 消息模板

### 模板 A：WhatsApp × 繁体中文 × 钩子"同行谱图"

```
您好 [姓名]，

我是阿里巴巴國際站的 [你的名字]。

想跟您分享個訊息——香港做 [產品] 的供應商，
在我們平台上已有不少，近期也有新的同行陸續入駐，
主要接來自歐洲和中東的 B2B 詢盤。

不知道您有沒有考慮過把國際站作為額外的外貿渠道？
抽空聊一下？

[你的名字] | 阿里巴巴國際站
WhatsApp: [號碼]
```

### 模板 B：WhatsApp × 钩子"贸易商角色"（针对香港贸易商）

```
您好 [姓名]，

我是阿里巴巴國際站的 [你的名字]。

香港有不少貿易公司透過我們的平台，把內地工廠的產品
賣給全球的 B2B 買家——特別是歐美和中東的採購商。

[公司名] 有沒有在考慮這個方向？15 分鐘聊聊？

[你的名字] | 阿里巴巴國際站
```

### 模板 C：WhatsApp × 英语 × 简洁版

```
Hi [Name],

[Your Name] from Alibaba.com here.

[Product] is seeing strong buyer demand from Europe and
the Middle East on our platform — might be worth exploring
as an additional channel for [Company Name].

Worth a 15-minute chat?

[Your Name] | Alibaba.com
```

### 模板 D：Email × 英语 × 正式场合

```
Subject: Additional B2B export channel for [Company Name] — Alibaba.com

Hi [Name],

I'm [Your Name] from Alibaba.com, reaching out to
established Hong Kong traders and suppliers.

Given [Company Name]'s experience in [product], I thought
it worth sharing — buyers from Europe, the Middle East,
and Southeast Asia are actively sourcing in this category
on our platform, and Hong Kong suppliers with strong product
backgrounds tend to perform well here.

This could work as a complementary channel alongside
what you're already doing. Happy to walk you through
the numbers briefly if you're curious.

Best,
[Your Name] | Alibaba.com
WhatsApp: [number] | Email: [email]
```

### 模板 E：Email × 繁体中文 × 正式场合

```
主旨：[公司名] × 阿里巴巴國際站合作機會

您好 [姓名] 先生/女士，

我是阿里巴巴國際站的 [你的名字]，負責香港市場。

目前平台上做 [產品/行業] 的香港供應商正在穩定接收
來自歐美、中東的 B2B 採購詢盤。不少與 [公司名]
規模相近的香港企業，已透過國際站建立起穩定的海外客源。

如有興趣，可否安排 15 分鐘的簡短介紹？

謝謝。
[你的名字] | 阿里巴巴國際站
聯絡方式：[電話 / WhatsApp]
```

---

## 跟进序列（香港）

| 时间 | 渠道 | 内容 |
|------|------|------|
| Day 1 | WhatsApp + Email | 同时发出（香港节奏快，双线触达） |
| Day 3 | WhatsApp | 跟进，补发相关买家需求数据 |
| Day 7 | 电话 | 直接致电，简短确认 |
| Day 12 | WhatsApp | 收尾，给出具体时间选项 |
