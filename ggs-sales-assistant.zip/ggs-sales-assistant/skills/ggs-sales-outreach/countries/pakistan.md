# 巴基斯坦市场配置

## 渠道优先级

| 优先级 | 渠道 | 使用场景 |
|--------|------|----------|
| 🥇 首选 | **WhatsApp** | 巴基斯坦商务沟通绝对主渠道 |
| 🥈 次选 | **电话** | WhatsApp 无回应后直接致电 |
| 🥉 补充 | **Email** | 正式场合、大企业 |

> **巴基斯坦特点：** 与印度类似，WhatsApp 是巴基斯坦 B2B 沟通的核心渠道，商人接受陌生商务联系的意愿较高。巴基斯坦出口产业相对集中（纺织占出口约 60%），产业聚落非常明显，"本地同行"角度效果显著。英语是商务沟通通用语，不需要乌尔都语模板（但如有本地销售可酌情使用）。

---

## 同行谱图挖掘方法（巴基斯坦专项）

### 数据来源优先级
1. **Alibaba.com 直接搜索** — 搜索产品关键词，筛选 `Pakistan` 供应商，记录数量
2. **CRM（如接入）** — 巴基斯坦该行业入驻数量、询盘量
3. **网络搜索** — `"[product] Pakistan export alibaba"` 或 TDAP（贸易促进机构）数据

### 地理颗粒度参考（巴基斯坦）
- 卡拉奇（Karachi）：巴基斯坦最大商业城市，纺织、皮革、化工、贸易公司集中
- 拉合尔（Lahore）：纺织、食品加工、制造业
- 法萨拉巴德（Faisalabad）：巴基斯坦"纺织之城"，全国最大纺织产业基地
- 西阿尔科特（Sialkot）：体育用品、外科器械、皮革手套（全球重要出口基地）
- 古杰拉特（Gujrat）：家具、陶瓷

### 构造同行数据表述示例
```
"There are already a significant number of Pakistani [product]
suppliers on Alibaba.com, with many from Sialkot / Faisalabad /
Karachi doing regular business with European buyers."

"Suppliers in Sialkot similar to yours have been very
active on our platform — sports goods and surgical
instruments are among our highest-demand categories."
```

---

## 消息模板

### 模板 A：WhatsApp × 钩子"同行谱图"

```
Hi [Name],

I'm [Your Name] from Alibaba.com.

Wanted to share — [Sialkot / Faisalabad / Karachi] already
has many [product] suppliers doing good business on our
platform, receiving orders from Europe, the US, and the
Middle East.

Would [Company Name] be interested in exploring this?
A quick 15-minute call would tell us if it's a fit.

[Your Name] | Alibaba.com
WhatsApp: [your number]
```

### 模板 B：WhatsApp × 钩子"市场询盘机会"

```
Hi [Name],

[Your Name] here from Alibaba.com.

[Product] demand from international B2B buyers has been
strong on our platform. Pakistani suppliers in this
category are well-positioned to capture this.

Interested in a 15-minute call to see how [Company Name]
can benefit?

[Your Name] | Alibaba.com
```

### 模板 C：电话话术框架

```
"Hi, is this [Name]? I'm [Your Name] calling from
Alibaba.com International."

"I'll be very brief — I'm contacting [product] suppliers
in [City]. We have international buyers from Europe and
the Middle East actively looking for Pakistani suppliers
in this category, and [City] has some great ones already."

"Would it be possible to schedule a short 15-minute
call this week?"
```

---

## 跟进序列（巴基斯坦）

| 时间 | 渠道 | 内容 |
|------|------|------|
| Day 1 | WhatsApp | 首条消息（模板 A） |
| Day 2 | 电话 | 致电跟进 |
| Day 5 | WhatsApp | 补发产品类目买家需求数据 |
| Day 10 | WhatsApp | 分享巴基斯坦同行成功案例 |
