#!/usr/bin/env python3
"""
leads-to-xlsx.py — Generate a formatted xlsx file from a leads JSON input.

Produces the user-facing xlsx deliverable for ggs-sales-leads-finder and
ggs-sales-enrichment. All cells are written as text so that tax IDs and
phone numbers keep leading zeros, and commas inside a field (e.g.
"Co., Ltd.") are never split across cells.

Behavior:
  - Reads a JSON array of lead records (or {"leads": [...]} wrapper)
  - Writes a single xlsx with the unified baseline columns plus any extra fields
  - All cells written as text (no number coercion)
  - Header row bolded with bilingual labels
  - Sensible column widths
  - Empty fields filled with "N/A"

Usage:
  python3 leads-to-xlsx.py --input leads.json [--output leads.xlsx] [--country VN]

Output naming default: leads-{country}-{YYYYMMDD}-{HHMM}.xlsx (in current dir).

Exit codes:
  0  success
  1  runtime error
  2  bad input / validation failure
"""

import argparse
import datetime
import json
import re
import sys
from pathlib import Path

try:
    import openpyxl
    from openpyxl.styles import Alignment, Font, PatternFill
    from openpyxl.utils import get_column_letter
except ImportError:
    print(
        "ERROR: openpyxl not found. It ships with the ggs-crm-cli "
        "environment — run the environment prep from prompt.md <crm_auth> "
        "(ensure-crm-cli.py) before calling this script.",
        file=sys.stderr,
    )
    sys.exit(1)


# ── Column schema ────────────────────────────────────────────────────
# Unified baseline columns (21). Extra record keys are appended dynamically.
# Each tuple = (field_key, header_label, width). header_label is "English / 中文".
COLUMNS = [
    ("index",              "#",                            5),
    ("source",             "Source / 来源",                 14),
    ("company_name_en",    "Company (EN) / 英文公司名",       40),
    ("company_name_local", "Company (Local) / 本地公司名",    40),
    ("country",            "Country / 国家",                10),
    ("province",           "Province / 省州",               16),
    ("city",               "City / 城市",                   16),
    ("address",            "Address / 地址",                40),
    ("industry",           "Industry / 行业",               24),
    ("tax_id",             "Tax ID / 税号",                 22),
    ("phone",              "Phone / 电话",                  22),
    ("email",              "Email / 邮箱",                  28),
    ("website",            "Website / 网站",                30),
    ("im_account",         "IM Account / 即时通讯",          30),
    ("key_person_name",    "Key Person / 关键人",            22),
    ("key_person_title",   "Title / 职位",                  22),
    ("confidence",         "Confidence / 置信度",            12),
    ("qualityTags",        "Quality Tags / 质量标签",        24),
    ("dataSources",        "Data Sources / 数据来源",        40),
    ("aiSummary",          "AI Summary / 综合摘要",          50),
    ("crm_status",         "CRM Status / CRM 状态",          36),
]

# Keys folded into 'crm_status' — merged, never re-emitted as their own columns.
CRM_SOURCE_KEYS = ("globalId", "pool", "orgId", "ownerId", "detailUrl")

# Keys removed from default output entirely (internal/debug). Not shown as
# baseline columns and not auto-appended as dynamic columns.
SUPPRESSED_KEYS = ("industryId", "aiMatcher", "commandResult")

# Alias map: collapse common CRM-style / synonym keys onto baseline keys so a
# record that arrives with raw CRM field names (or several synonyms for the
# same thing) does not explode into many duplicate columns. First non-empty
# value wins; later synonyms only fill if the canonical key is still empty.
KEY_ALIASES = {
    "official_name": "company_name_en",
    "legal_name": "company_name_en",
    "crm_comp_name": "company_name_en",
    "local_name": "company_name_local",
    "vietnamese_name": "company_name_local",
    "busi_reg_number": "tax_id",
    "tax_code": "tax_id",
    "business_registration_number": "tax_id",
    "official_address": "address",
    "main_industry": "industry",
    "industry_products": "industry",
    "facebook": "facebook_url",
    "facebook_page": "facebook_url",
    "representative": "key_person_name",
    "legal_representative": "key_person_name",
    "platform_presence": "current_platform_presence",
    "global_id": "globalId",
    "ai_summary": "aiSummary",
    "data_sources": "dataSources",
    "quality_tags": "qualityTags",
}


def apply_key_aliases(record):
    """
    Fold synonym / CRM-style keys onto their canonical baseline key.
    Canonical value takes priority; an alias only fills an empty canonical.
    """
    if not isinstance(record, dict):
        return record
    out = dict(record)
    for alias, canon in KEY_ALIASES.items():
        if alias not in out:
            continue
        val = out.pop(alias)
        if not _present(out.get(canon)) and _present(val):
            out[canon] = val
    return out


# ── Helpers ──────────────────────────────────────────────────────────
def parse_args():
    parser = argparse.ArgumentParser(
        description="Generate xlsx from leads JSON",
        add_help=True,
    )
    parser.add_argument("--input", required=True, help="Path to leads JSON file")
    parser.add_argument(
        "--output",
        default=None,
        help="Output path (default: leads-{country}-{YYYYMMDD}-{HHMM}.xlsx)",
    )
    parser.add_argument(
        "--country",
        default=None,
        help="Country code for filename (e.g. VN, KR). If omitted, "
             "inferred from the first lead record.",
    )
    parser.add_argument(
        "--no-screen",
        action="store_true",
        help="Disable the anti-fabrication pass (not recommended).",
    )
    return parser.parse_args()


def stringify(value):
    """Convert any JSON value to a text cell. Empty / None → 'N/A'."""
    if value is None or value == "":
        return "N/A"
    if isinstance(value, list):
        # Lists (e.g. dataSources, qualityTags) → comma-separated
        items = [stringify(v) for v in value if v is not None and v != ""]
        return ", ".join(items) if items else "N/A"
    if isinstance(value, dict):
        # Dicts → "key: value; ..." (rare; defensive)
        parts = [f"{k}: {stringify(v)}" for k, v in value.items()]
        return "; ".join(parts) if parts else "N/A"
    if isinstance(value, bool):
        return "Yes" if value else "No"
    return str(value)


# Keys consumed by merge_im_account — folded into 'im_account' and therefore
# never re-emitted as their own dynamic extra columns.
IM_SOURCE_KEYS = ("zalo", "facebook_url", "kakaotalk", "line", "whatsapp")

BASELINE_KEYS = {key for key, _, _ in COLUMNS}


def merge_im_account(record):
    """
    Combine country-specific IM fields into a single 'im_account' string.
    If 'im_account' is already present, use it as-is.
    Otherwise merge from known per-country keys (zalo, facebook_url,
    kakaotalk, line, whatsapp).
    """
    if record.get("im_account"):
        return record["im_account"]

    parts = []
    if record.get("zalo"):
        parts.append(f"Zalo: {record['zalo']}")
    if record.get("facebook_url"):
        parts.append(f"FB: {record['facebook_url']}")
    if record.get("kakaotalk"):
        parts.append(f"KakaoTalk: {record['kakaotalk']}")
    if record.get("line"):
        parts.append(f"LINE: {record['line']}")
    if record.get("whatsapp"):
        parts.append(f"WhatsApp: {record['whatsapp']}")
    return "; ".join(parts) if parts else None


def _present(value):
    return value not in (None, "", "N/A")


def _present_val(value):
    return _present(value)


def merge_crm_status(record):
    """
    Collapse the CRM-internal fields (globalId / pool / orgId / ownerId /
    detailUrl) into one human-readable 'CRM Status' value.

    External (not-in-CRM) leads have none of these → 'N/A'. Leads matched in
    CRM show the pool + detail link; raw internal IDs are not surfaced.
    """
    if record.get("crm_status"):
        return record["crm_status"]
    if not _present(record.get("globalId")):
        return None  # external new lead → stringify() will render N/A
    parts = []
    if _present(record.get("pool")):
        parts.append(str(record["pool"]))
    if _present(record.get("detailUrl")):
        parts.append(str(record["detailUrl"]))
    return " | ".join(parts) if parts else "in CRM"


def humanize_key(key):
    """Turn a raw extra-field key into a readable header label."""
    return key.replace("_", " ").strip().title()


def collect_dynamic_columns(records):
    """
    Build the final column list = baseline columns (fixed order) followed by
    any *extra* keys present in the records, in first-appearance order.

    This makes the schema a reference floor rather than a fixed cap: enriched
    fields, discovered fields, and user-requested extra fields all survive
    into the xlsx instead of being silently dropped. Keys folded into
    'im_account' / 'crm_status', and explicitly suppressed internal keys, are
    not duplicated as their own columns.
    """
    columns = list(COLUMNS)
    seen = (set(BASELINE_KEYS) | set(IM_SOURCE_KEYS)
            | set(CRM_SOURCE_KEYS) | set(SUPPRESSED_KEYS))
    for record in records:
        if not isinstance(record, dict):
            continue
        for key in record.keys():
            if key in seen:
                continue
            seen.add(key)
            columns.append((key, humanize_key(key), 24))
    return columns


def screen_fabrication(records):
    """
    Deterministic anti-fabrication pass. Sets fabricated-looking contact /
    identity values to None (rendered as N/A) and returns a list of report
    strings. NEVER invents values — only blanks suspicious ones.

    Checks (simple, machine-only):
      1. phone/zalo invalid per libphonenumber (e.g. "0000016")
      2. value's digits == this record's row index (e.g. "0000016" at row 16,
         "lead_016")
      3. batch: a field's embedded integers form a consecutive run (≥3 rows)
      4. placeholder-template emails (lead_/test_/sample_ + digits)
      5. batch: ≥80% of websites are a mechanical slug of the company name
      6. constant placeholder values (example.com / all-same / all-zero)

    A single, well-crafted fake that is not patterned can still slip through —
    that is backstopped by the "no source → N/A" provenance rule, not here.
    """
    report = []
    n = len(records)
    if n == 0:
        return records, report

    # lazy import — phone check degrades gracefully if lib missing
    try:
        import phonenumbers as _pn
        have_pn = True
    except ImportError:
        have_pn = False
        report.append("phonenumbers 不可用，跳过电话有效性检查")

    PLACEHOLDER_LOCAL = re.compile(
        r"^(lead|leads|test|sample|demo|example|user|contact|company|abc|xyz)[_\-]?\d*$",
        re.I,
    )
    PLACEHOLDER_DOMAIN = re.compile(
        r"^(example|test|sample|demo|fake|domain|email)\.(com|net|org|vn)$", re.I
    )

    def digits(v):
        return re.sub(r"\D", "", str(v)) if v else ""

    def blank(rec, field, reason):
        if _present_val(rec.get(field)):
            rec[field] = None
            report.append(f"#{rec.get('_row')} {field}: {reason}")

    # tag rows for reporting
    for i, r in enumerate(records, start=1):
        if isinstance(r, dict):
            r["_row"] = i

    # ── per-value checks ───────────────────────────────────────────
    for i, rec in enumerate(records, start=1):
        if not isinstance(rec, dict):
            continue
        region = (rec.get("country") or "").upper() or None

        # 1 + 2: phone / zalo
        for field in ("phone", "zalo"):
            val = rec.get(field)
            if not _present_val(val):
                continue
            d = digits(val)
            # 2: digits equal the row index (zero-padded counter)
            if d and d.lstrip("0") and int(d) == i and len(d) <= 8:
                blank(rec, field, "号码=行号(疑似自增构造)")
                continue
            if d and set(d) <= {"0"}:
                blank(rec, field, "号码全为 0(占位)")
                continue
            # 1: libphonenumber validity (first number if comma-separated)
            if have_pn:
                first = str(val).split(",")[0].strip()
                try:
                    parsed = _pn.parse(first, region)
                    if not _pn.is_valid_number(parsed):
                        blank(rec, field, "号码未通过 libphonenumber 校验")
                except _pn.NumberParseException:
                    blank(rec, field, "号码无法解析")

        # 2 + 4: email
        email = rec.get("email")
        if _present_val(email) and "@" in str(email):
            local, _, domain = str(email).partition("@")
            ld = digits(local)
            if ld and ld.lstrip("0") and int(ld) == i:
                blank(rec, "email", "邮箱含行号(疑似自增构造)")
            elif PLACEHOLDER_LOCAL.match(local):
                blank(rec, "email", "邮箱为占位模板(lead_/test_ 等)")
            elif PLACEHOLDER_DOMAIN.match(domain):
                blank(rec, "email", "邮箱域名为占位(example.com 等)")

        # website: only flag clearly-fake hosts (placeholder domain or row
        # index in host). Name-based domains are NOT flagged — a real
        # company's site is usually its name, indistinguishable offline.
        web = rec.get("website")
        if _present_val(web):
            host = re.sub(r"^https?://", "", str(web).lower())
            host = re.sub(r"^www\.", "", host).split("/")[0]
            label = host.split(".")[0] if host else ""
            hd = digits(label)
            if PLACEHOLDER_DOMAIN.match(host):
                blank(rec, "website", "网址为占位域名(example.com 等)")
            elif hd and hd.lstrip("0") and int(hd) == i:
                blank(rec, "website", "网址含行号(疑似自增构造)")

    # ── batch checks (need ≥3 rows) ────────────────────────────────
    if n >= 3:
        # 3: consecutive integer run in email local-part or phone
        for field, extract in (
            ("email", lambda r: digits((r.get("email") or "").split("@")[0])),
            ("phone", lambda r: digits(r.get("phone"))),
        ):
            nums = []
            for rec in records:
                if not isinstance(rec, dict):
                    continue
                d = extract(rec)
                nums.append(int(d) if d and len(d) <= 8 else None)
            present = [x for x in nums if x is not None]
            if len(present) >= 3:
                s = sorted(present)
                steps = sum(1 for a, b in zip(s, s[1:]) if b - a == 1)
                if steps >= len(s) * 0.6:
                    for rec in records:
                        if isinstance(rec, dict) and _present_val(rec.get(field)):
                            rec[field] = None
                    report.append(
                        f"整批 {field} 构成连续序列(疑似批量构造)，已全部置 N/A"
                    )

        # 6: a single value repeated across most rows
        for field in ("email", "phone", "website"):
            vals = [str(r.get(field)) for r in records
                    if isinstance(r, dict) and _present_val(r.get(field))]
            if len(vals) >= 3:
                most = max(set(vals), key=vals.count)
                if vals.count(most) >= len(vals) * 0.8:
                    for r in records:
                        if isinstance(r, dict) and str(r.get(field)) == most:
                            r[field] = None
                    report.append(f"{field} 多条重复同一值「{most}」(占位)，已置 N/A")

    # strip the temporary row tag
    for r in records:
        if isinstance(r, dict):
            r.pop("_row", None)

    return records, report


def write_workbook(records, output_path: Path):
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Leads"

    # Baseline columns + any extra fields present in the data (dynamic).
    columns = collect_dynamic_columns(records)

    # Header row
    header_font = Font(bold=True, color="FFFFFF")
    header_fill = PatternFill(
        start_color="1A56DB", end_color="1A56DB", fill_type="solid"
    )
    header_align = Alignment(
        horizontal="left", vertical="center", wrap_text=True
    )

    for col_idx, (_, label, width) in enumerate(columns, start=1):
        cell = ws.cell(row=1, column=col_idx, value=label)
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = header_align
        ws.column_dimensions[get_column_letter(col_idx)].width = width

    ws.row_dimensions[1].height = 30
    ws.freeze_panes = "A2"  # Freeze header

    # Data rows
    body_align = Alignment(vertical="top", wrap_text=True)
    for row_idx, record in enumerate(records, start=1):
        # Merge IM-related per-country fields first
        merged = dict(record)
        merged["im_account"] = merge_im_account(record)
        merged["crm_status"] = merge_crm_status(record)
        # Auto-fill index if not provided
        if "index" not in merged or merged["index"] in (None, "", "N/A"):
            merged["index"] = row_idx

        for col_idx, (key, _, _) in enumerate(columns, start=1):
            value = merged.get(key)
            text = stringify(value)
            cell = ws.cell(row=row_idx + 1, column=col_idx, value=text)
            cell.alignment = body_align
            # Force all cells to text format — prevents Excel from
            # auto-interpreting tax IDs / phones as numbers.
            cell.number_format = "@"

    wb.save(output_path)


def derive_country_code(records):
    """Look at first record's country field."""
    for r in records:
        c = r.get("country")
        if c:
            return str(c).upper()
    return "XX"


def default_output_name(country):
    now = datetime.datetime.now()
    return Path(f"leads-{country}-{now:%Y%m%d-%H%M}.xlsx")


# ── Main ─────────────────────────────────────────────────────────────
def main():
    args = parse_args()
    input_path = Path(args.input)
    if not input_path.is_file():
        print(f"ERROR: input not found: {args.input}", file=sys.stderr)
        sys.exit(2)

    try:
        raw = json.loads(input_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as e:
        print(f"ERROR: input is not valid JSON: {e}", file=sys.stderr)
        sys.exit(2)

    # Accept either a bare array or {"leads": [...]}
    if isinstance(raw, dict) and "leads" in raw:
        records = raw["leads"]
    elif isinstance(raw, list):
        records = raw
    else:
        print(
            'ERROR: input must be a JSON array, or an object with "leads": [...]',
            file=sys.stderr,
        )
        sys.exit(2)

    if not records:
        print("ERROR: no records in input", file=sys.stderr)
        sys.exit(2)

    country = args.country or derive_country_code(records)
    output_path = Path(args.output) if args.output else default_output_name(country)

    print()
    print("═══════════════════════════════════════════════════════════════")
    print(" Leads → xlsx")
    print("═══════════════════════════════════════════════════════════════")
    print(f"  Input:   {input_path}")
    print(f"  Records: {len(records)}")
    print(f"  Country: {country}")
    print(f"  Output:  {output_path}")
    print("───────────────────────────────────────────────────────────────")

    # Normalize synonym / CRM-style keys onto canonical baseline keys first,
    # so a record with raw CRM field names doesn't explode into duplicate cols.
    records = [apply_key_aliases(r) for r in records]

    # Anti-fabrication pass (auto, unless --no-screen). Only blanks suspicious
    # values to N/A; never invents. Always reports what it changed.
    if not args.no_screen:
        records, report = screen_fabrication(records)
        if report:
            print(f"⚠ 防编造校验：{len(report)} 项被置 N/A")
            for line in report:
                print(f"    - {line}")
            print("───────────────────────────────────────────────────────────────")
        else:
            print("✓ 防编造校验：未发现疑似批量构造")

    output_path.parent.mkdir(parents=True, exist_ok=True)
    write_workbook(records, output_path)
    print(f"\n✅ Wrote {len(records)} record(s) to: {output_path}")


if __name__ == "__main__":
    try:
        main()
    except SystemExit:
        raise
    except Exception as e:
        import traceback
        print(f"\nERROR: {e}", file=sys.stderr)
        traceback.print_exc()
        sys.exit(1)
