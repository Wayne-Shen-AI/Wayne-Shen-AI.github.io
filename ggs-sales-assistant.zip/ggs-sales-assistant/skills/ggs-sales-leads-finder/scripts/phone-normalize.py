#!/usr/bin/env python3
"""
phone-normalize.py — Deterministic phone validation / classification /
formatting via Google libphonenumber (the `phonenumbers` Python port).

Used by:
  - Part 2.2 contact validation  → classify MOBILE vs FIXED_LINE
                                    (mobile → primary phone, landline → AI Summary)
  - Part 3 write-back            → format to E.164 / international

The region comes from the country already routed in Phase 2; numbers already
in +<cc> form are parsed without needing a region.

CLI:
  python3 phone-normalize.py --number "0912345678" --region VN
  python3 phone-normalize.py --number "+84912345678"
  echo '[{"number":"0912345678","region":"VN"}, ...]' | python3 phone-normalize.py --stdin

Output: JSON. Single number → one object; --stdin → array (same order).

Result object:
  {
    "input": "<raw input>",
    "region": "<region used or null>",
    "valid": true|false,            # is_valid_number — plausible per numbering plan
    "type": "MOBILE"|"FIXED_LINE"|"FIXED_LINE_OR_MOBILE"|"...|UNKNOWN",
    "is_mobile": true|false|null,   # null when type is FIXED_LINE_OR_MOBILE (ambiguous)
    "primary_ok": true|false,       # safe to use as the primary phone field
    "e164": "+84912345678"|null,
    "international": "+84 91 234 5678"|null,
    "national": "091 234 5678"|null,
    "error": null|"<reason>"
  }

Classification contract (matches the skill's Part 2.2 logic):
  - type == MOBILE                 → is_mobile=true,  primary_ok=true
  - type == FIXED_LINE             → is_mobile=false, primary_ok=false  (→ AI Summary)
  - type == FIXED_LINE_OR_MOBILE   → is_mobile=null,  primary_ok=true   (ambiguous
        numbering plan, e.g. US; treated as usable-for-primary per the documented
        fallback rather than forcing a mobile/landline guess)
  - anything else / invalid        → is_mobile=null,  primary_ok=false

Exit codes: 0 success · 1 runtime error · 2 bad input
"""

import argparse
import json
import sys

try:
    import phonenumbers as pn
    from phonenumbers import PhoneNumberType as _T
except ImportError:
    print(
        "ERROR: phonenumbers not found. It ships with the ggs-crm-cli "
        "environment — run the environment prep from prompt.md <crm_auth> "
        "(ensure-crm-cli.py) before calling this script.",
        file=sys.stderr,
    )
    sys.exit(1)

# int enum value → name, e.g. 1 → "MOBILE"
_TYPE_NAME = {
    getattr(_T, n): n
    for n in dir(_T)
    if not n.startswith("_") and isinstance(getattr(_T, n), int)
}


def normalize(number, region=None):
    raw = number
    result = {
        "input": raw,
        "region": region,
        "valid": False,
        "type": "UNKNOWN",
        "is_mobile": None,
        "primary_ok": False,
        "e164": None,
        "international": None,
        "national": None,
        "error": None,
    }
    if number is None or str(number).strip() == "":
        result["error"] = "empty number"
        return result
    try:
        # If the number already carries a +<cc> prefix, region is optional.
        parsed = pn.parse(str(number), region)
    except pn.NumberParseException as e:
        result["error"] = f"parse failed: {e}"
        return result

    valid = pn.is_valid_number(parsed)
    ntype = pn.number_type(parsed)
    type_name = _TYPE_NAME.get(ntype, "UNKNOWN")
    result["valid"] = valid
    result["type"] = type_name

    if valid:
        result["e164"] = pn.format_number(parsed, pn.PhoneNumberFormat.E164)
        result["international"] = pn.format_number(
            parsed, pn.PhoneNumberFormat.INTERNATIONAL
        )
        result["national"] = pn.format_number(
            parsed, pn.PhoneNumberFormat.NATIONAL
        )

    if type_name == "MOBILE":
        result["is_mobile"] = True
        result["primary_ok"] = bool(valid)
    elif type_name == "FIXED_LINE":
        result["is_mobile"] = False
        result["primary_ok"] = False
    elif type_name == "FIXED_LINE_OR_MOBILE":
        # Numbering plan can't distinguish (e.g. US). Documented fallback:
        # usable as primary; do not guess mobile/landline.
        result["is_mobile"] = None
        result["primary_ok"] = bool(valid)
    else:
        result["is_mobile"] = None
        result["primary_ok"] = False

    return result


def parse_args():
    p = argparse.ArgumentParser(description="Normalize phone numbers via libphonenumber")
    p.add_argument("--number", help="A single phone number to normalize")
    p.add_argument("--region", default=None, help="ISO region (e.g. VN, KR, TW). "
                   "Optional if the number is in +<cc> form.")
    p.add_argument("--stdin", action="store_true",
                   help='Read a JSON array of {"number","region"} from stdin')
    return p.parse_args()


def main():
    args = parse_args()
    if args.stdin:
        try:
            items = json.loads(sys.stdin.read())
        except json.JSONDecodeError as e:
            print(f"ERROR: stdin is not valid JSON: {e}", file=sys.stderr)
            sys.exit(2)
        if not isinstance(items, list):
            print("ERROR: stdin must be a JSON array", file=sys.stderr)
            sys.exit(2)
        out = [normalize(it.get("number"), it.get("region")) for it in items]
        print(json.dumps(out, ensure_ascii=False, indent=2))
        return
    if args.number is None:
        print("ERROR: provide --number or --stdin", file=sys.stderr)
        sys.exit(2)
    print(json.dumps(normalize(args.number, args.region), ensure_ascii=False, indent=2))


if __name__ == "__main__":
    try:
        main()
    except SystemExit:
        raise
    except Exception as e:
        import traceback
        print(f"\nERROR: {e}", file=sys.stderr)
        traceback.print_exc()
        sys.exit(1)
