# 通用平台操作 SOP (Platform SOP)

本文档定义跨国界通用平台（Google Maps、LinkedIn、Facebook、ImportYeti、企业官网、Exa Search）的操作级 SOP。Phase 4-5 执行跨平台抓取时加载。

**可用工具：**
- Accio 原生：`web_search`、`web_fetch`
- ggs-crm CLI：`google-search`、`google-map`、`web-scrape`
- Browser Agent：`browser`（含 open / snapshot / act / screenshot / scroll）
- 语义搜索：Exa Search（如可用）

---

## 1. Google Maps

**目的：** 获取企业基础信息（名称、地址、电话、网站、评分）。

### 方式 A：ggs-crm CLI（推荐）

```bash
# 按城市搜索
ggs-crm google-map --city "{city}" -c {country} --company-type "{industry}"

# 按经纬度搜索
ggs-crm google-map --latitude {lat} --longitude {lng} --radius {meters} -c {country} --company-type "{industry}"
```

### 方式 B：Browser Agent

1. `browser(action='open', targetUrl='https://www.google.com/maps/search/{keyword}+in+{city}')`
2. `browser(action='snapshot')` 分析列表
3. 点击进入详情，提取 name / address / phone / website / rating
4. `browser(action='scroll', scrollDirection='down')` 翻页

**注意：** Google Maps 通常只有 20-60 条结果，不支持深度翻页。电话格式需按目标国规则清洗。

---

## 2. LinkedIn (Company Search)

**目的：** 获取公司官网、员工规模、行业分类、关键联系人。

**前提：** 用户已登录 LinkedIn（必须有登录态）。如未登录，读 `auth-guidance.md` 引导。

**操作步骤：**
1. `browser(action='open', targetUrl='https://www.linkedin.com/search/results/companies/?keywords={keyword}+{country}')`
2. `browser(action='snapshot')` 获取公司名和主页链接
3. 进入目标公司主页，提取 About 页面的 website / company size / industry
4. 寻找关键人（可选）：点击 "People"，搜索 CEO / Founder / Export Manager

**频率控制：** 每次最多抓取 10 个公司主页。两次访问间隔至少 3 秒。

**降级：** 限流或未登录 → `web_search "site:linkedin.com/company {keyword} {country}"`，仅提取摘要。

---

## 3. Facebook (Page Search)

**目的：** 获取联系方式（Phone / Email / Zalo / WhatsApp）、判断企业活跃度。

**前提：** 用户已登录 Facebook（未登录时手机号等信息常被隐藏）。

**操作步骤：**
1. 寻找主页：
   - 方式 A：`web_search "site:facebook.com {company_name} {city}"`
   - 方式 B：`browser(action='open', targetUrl='https://www.facebook.com/search/pages/?q={keyword}+{city}')`
2. 进入 Page 后点击 "About"，提取 Phone / Email / Website / Address
3. 检查是否有 WhatsApp 或 Zalo 直达链接

**降级：** 未登录 → `web_search "{company_name} facebook"` 获取 Page URL → `web_fetch` 提取公开信息。

---

## 4. ImportYeti (出口记录验证)

**目的：** 验证企业是否具有真实出口行为，获取主要出口目的地。

**操作步骤：**
1. `browser(action='open', targetUrl='https://www.importyeti.com/search?q={company_name}&country={country_name}')`
2. `browser(action='snapshot')` 检查 shipment 记录
3. 有记录 → 提取 target_market

**认知边界：** ImportYeti 数据主要基于美国海关记录，覆盖范围有限。**无记录不等于非出口商。**

---

## 5. 企业官网 (Website)

**目的：** 补全联系方式、寻找出口信号、确认主营产品。

### 方式 A：ggs-crm CLI

```bash
# 首页
ggs-crm web-scrape -u "{website}" -t text

# 批量抓取子页面（最多 3 个）
ggs-crm web-scrape --urls "{contact_url},{about_url},{team_url}" -t text
```

### 方式 B：Accio 原生

```json
{"tool": "web_fetch", "params": {"urls": ["{website}", "{contact_url}", "{about_url}"], "max_chars": 30000}}
```

### 方式 C：Browser Agent

1. `browser(action='open', targetUrl='{website}')`
2. `browser(action='snapshot')` 寻找 Contact / About Us / Products 导航链接
3. 进入 Contact 页面提取 phone / email / address
4. 进入 About 页面提取 company_size / industry / main_products

**出口信号词：** FOB, CIF, MOQ, Export, International Trade, OEM, ODM, ISO, Wholesale, Global Shipping

**Tip：** 注意检查 Footer——欧洲企业的税号和邮箱常在页脚。韩国企业的사업자등록번호也在 Footer。

---

## 6. Exa Search (语义搜索)

**目的：** 利用语义理解快速发现高质量企业、寻找相似公司。

**操作：**
1. 基础搜索：`mcp_call(exa_web_search_exa, query='...', category='company', numResults=20)`
2. 深度调研：`mcp_call(web_search_exa, query='{company_name} news funding products', type='deep')`
3. 相似公司：`mcp_call(find_similar_pages_exa, url='{competitor_website}', numResults=10)`
4. 直接问答：`mcp_call(exa_answer, query='...')`

**适用场景：** `web_search` 噪音太大时使用；寻找"新技术""精密制造"等特定领域工厂效果好。

**注意：** Exa 可用性依赖运行时环境。不可用时 fallback 到 `google-search` + `web-scrape`。

---

## 7. 通用 Fallback 降级链路

| 失败场景 | 降级路径 |
|---------|---------|
| 地图类失败 | `web_search "{industry} {city} {country}"` → 通过搜索结果中的官网或 Facebook 提取 |
| LinkedIn 失败（未登录/限流） | `web_search "site:linkedin.com/company {keyword} {country}"` → 仅提取摘要 |
| Facebook 失败（未登录） | `web_search "{company_name} facebook"` → `web_fetch(Page URL)` 提取公开信息 |
| Exa 不可用 | `google-search` + `web-scrape` 替代 |
| Browser Relay 完全不可用 | 所有操作降级为 `web_search` + `web_fetch` + ggs-crm CLI。告知用户"因浏览器未连接，部分深度信息无法获取" |
