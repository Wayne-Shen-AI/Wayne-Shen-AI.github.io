# South Korea (KR) - leads-finder 国家策略文件

本文件是韩国（KR）地区在 **ggs-sales-leads-finder** skill 中的执行知识库。
当 Phase 2 路由结果为 `country=KR` 时加载本文件。

---

## Part 1: 数据源与外网搜索策略

韩国互联网生态高度封闭。**搜索 / 地图 / 本地服务必须优先 NAVER,不要默认走 Google**——Google 在韩国本土数据(中小企业、本地店铺、电话、地址)的覆盖远弱于 NAVER。数据源分为搜索引擎、政府公示系统、企业信息平台、垂直品类平台、行业协会与地方政府、展会以及 B2B 竞对平台。

### 1.0 强制原则:NAVER 优先

韩国市场所有"搜索 / 找企业 / 找联系方式 / 找地图位置"操作 → **先 NAVER,失败再 Google / Exa / 其他**。

- ❌ 直接 `google-map` 按城市搜索韩国小厂(多数搜不到 / 搜到但电话错)
- ❌ 直接 Exa 搜韩国公司(优先级低于 NAVER 域名发现)
- ✅ NAVER 搜索 / 地图打头,Google 只做补漏验证

理由:NAVER 在韩国本土数据(中小企业、本地店铺、电话、地址)的覆盖度和准确度远高于 Google;Google 在韩国数据稀疏且常缺失中小企业。

### 1.1 采集数据源意图映射

| 用户意图 | 主数据源 | 采集方式 | Fallback |
|---------|---------|---------|----------|
| 某地区工厂/企业 | **NAVER 地图(主)** | NAVER 地图按城市搜索 | Google Maps 仅在 NAVER 缺失时;最后 fallback `accio-mcp-cli call web_search_exa --query "..." --num_results 15` |
| 出口商 | Exa Search / TradeKorea | `accio-mcp-cli call web_search_exa --query "{韩语行业} 수출업체" --num_results 15` + `web_fetch` 抓取 TradeKorea | EC21 / Global Sources 韩国板块 |
| 竞品发现 | Exa Similar | `accio-mcp-cli call find_similar_pages_exa --url "{参照公司官网}" --num_results 10` | Kompass Korea |
| 企业工商验证 | Bizno.net / Moneypin.biz | `web-scrape` 或 `web_fetch` 按公司名/VAT 搜索 | 官网 Footer / FTC |
| 联系方式补全 | Naver 本地 API / 企业官网 | Naver 本地 API 为电话主要来源；官网多页面爬取 | Bizno / Moneypin |
| 域名发现 | Naver 搜索 API | LLM 根据标题+摘要+公司名选择官网 | Naver 地图（约 3% 覆盖率） |
| 展会参展商 | KINTEX / COEX 官网 | `web_fetch` 抓取参展商列表 | — |

### 1.2 关键词本地化规则

**强制要求：** 搜索前必须将关键词翻译为韩语。

| 英文 | 韩语 |
|------|------|
| manufacturer | 제조업체 |
| factory | 공장 |
| exporter | 수출업체 |
| cosmetics | 화장품 |
| electronics | 전자제품 |
| textiles | 섬유 |
| trading company | 무역회사 |

### 1.3 核心数据源

| 数据源 | URL | 用途 |
|--------|-----|------|
| NAVER 搜索 API | developers.naver.com | 域名发现（每 key 每日 25,000 次调用） |
| Naver 本地 API | developers.naver.com | 电话号码、地区确认 |
| Naver 地图 | map.naver.com | 域名、电话（约 3% 覆盖率） |
| Bizno.net | bizno.net | VAT 号、代表人、行业分类 |
| Moneypin.biz | moneypin.biz | VAT 号、代表人、营收区间 |
| 韩国公平交易委员会 (FTC) | ftc.go.kr | 工商注册验证、通信销售业申报 |
| FactoryOn 工厂登记 | factoryon.go.kr | 工厂登记信息 |

> ⚠ **Bizno/Moneypin IP 封锁：** 频繁访问会被封 IP，需 IP 轮换服务（如 Scraper API）。

### 1.4 垂直品类网站

| 行业 | 网站 | URL |
|------|------|-----|
| 机械/工业 | Komachine | komachine.com/ko |
| 机械 | Daara | mc.daara.co.kr |
| 美妆/护肤 | StyleKorean | stylekorean.com |
| 美妆 | SelfCos | selfcos.com |
| 纺织/服装 | KTextile | ktextile.net |
| 化工 | ChemKnock | chemknock.co.kr |
| 农业/食品 | Tridge | tridge.com/ko |

### 1.5 协会与认证

| 机构 | URL | 领域 |
|------|-----|------|
| Hi Seoul 优秀企业 | hiseoul.sba.kr | 首尔综合 |
| 首尔贸易平台 | tradeon.sba.kr | 首尔出口 |
| 韩国食药处 | nedrug.mfds.go.kr | 医药/医疗器械 |
| 新能源联盟 | ref.or.kr | 新能源 |
| 素部装 | sobujang.net | 材料/零部件/设备 |

### 1.6 B2B 平台

| 平台 | URL | 说明 |
|------|-----|------|
| TradeKorea | tradekorea.com | 韩国贸易协会官方 B2B |
| EC21 | ec21.com | 韩国 B2B |
| Kompass Korea | kr.kompass.com | 全球企业目录韩国站 |
| TradeWheel | tradewheel.com/suppliers/south-korea/ | 韩国供应商 |

---

## Part 2: 字段规范 - 去重主键 + 联系方式校验 + 工商验证

### 2.1 去重主键字段

| 优先级 | 字段 | 说明 |
|-------|------|------|
| 1 | 사업자등록번호 | 10 位数字，格式 XXX-XX-XXXXX |
| 2 | website（域名） | .co.kr / .kr 域名 |
| 3 | 회사명 + 지역 | 韩文全称 + 地区 |

### 2.2 联系方式校验

| 项目 | 规则 |
|------|------|
| 号码识别/格式 | 由 `scripts/phone-normalize.py`（libphonenumber, region=KR）判 type 并取 `e164`/`international`（自动 +82、去首 0）；`MOBILE`→primary，`FIXED_LINE`→记入 AI Summary |
| 固话格式 | +82 + 区号（去 0）+ 号码 |
| 010 处理 | 个人手机号排除在公司电话之外，单独分类 |
| 主要 IM 渠道 | KakaoTalk > LinkedIn |
| 邮箱校验 | 排除 no-reply/noreply/webmaster；退信率约 10% |

### 2.3 工商验证

| 字段 | 本地名称 | 格式 | 说明 |
|------|---------|------|------|
| 事业者登录番号 | 사업자등록번호 | XXX-XX-XXXXX（10 位数字） | 韩国企业唯一标识，CRM 写回时去掉连字符 |

---

## Part 3: CRM 写回字段规范（KR 专属 override）

完整的 write-back 参数说明见 `ggs-crm show-docs crm-add` / `ggs-crm show-docs crm-refine`。以下为韩国的国家级 override，同时适用于 crm-add（leads-finder Phase 9 新增）和 crm-refine（leads-finder Phase 9 捡入后补全 / enrichment Phase 6 已有客户补全）：

> **字段名与必填性以 `ggs-crm show-docs crm-add` / `crm-refine` 运行时返回为准，本文档不复制 CLI 字段清单（避免与 CLI drift）。** 下表是采集字段 → CRM 的映射意图与业务约束；写回前按 show-docs 拿当前权威必填列表，缺失则阻断并向用户列出。

| 采集字段 | 映射意图 | 业务约束 |
|---------|---------|---------|
| 사업자등록번호（税号）| → 注册号字段 | **缺失 → 阻断写回**（韩国业务硬规则）；写回去连字符、保留 10 位数字 |
| phone | → 电话字段 | 调 `scripts/phone-normalize.py`（libphonenumber）取 `e164`/`international` 写回；`primary_ok=true` 的号作 primary（KR region）|
| province / city | → 地址字段 | 先调 `crm-address --country KR` 转码 |

---

## Part 4: 用户输出规范

### 4.1 用户输出字段（KR 专属）

向用户交付韩国线索时，使用以下字段定义：

| Company Name (Korean) | Company Name (Eng) | Business Reg No. | CEO Name | Phone | Email | Website | Region | Industry/Products | CRM Detail | AI Summary |
|-----------------------|--------------------|------------------|----------|-------|-------|---------|--------|-------------------|------------|------------|
| (주)예시 | Example Inc. | 123-45-67890 | 김민수 | +82 2 1234 5678 | minsu.kim@example.co.kr | example.co.kr | 서울 용산구 | Cosmetics | [详情](https://crm.alibaba-inc.com/crmagent/romeo/public-sea/customer-detail.html?globalId=xxx) | N/A |

**动态扩展：** 实际预览列 = 上表策展列 + 用户额外要求的字段（Intent Struct `extra_fields`，如 ISO 认证 / 主要出口国 / 领英粉丝数），按采集顺序追加到表末。与 xlsx 输出保持一致——不在策展列内的用户要求字段在聊天预览里也显示，不只落 xlsx。

### 4.2 xlsx 列定义

由 `scripts/leads-to-xlsx.py` 生成，以下 21 列为**基线参考列**（floor，不是上限；所有国家一致，始终输出）：

```
index, source,
company_name_en, company_name_local,
country, province, city, address,
industry, tax_id,
phone, email, website, im_account,
key_person_name, key_person_title,
confidence, qualityTags, dataSources, aiSummary,
crm_status
```

**说明：**
- `tax_id`: 各国通用税号 / 注册号（VN: MST；KR: 사업자등록번호；TW: 統一編號；IT: P.IVA；ES: NIF/CIF）
- `im_account`: 各国 IM 平台合并为一列（`Zalo: xxx; FB: yyy` / `KakaoTalk: xxx` / `LINE: xxx`）
- `key_person_name`: 单列存放完整姓名（如 KR 姓+名拼接）
- `crm_status`: CRM 内部字段（globalId/pool/orgId/ownerId/detailUrl）合并为一列——命中 CRM 显示「池 + 详情链接」，外部新线索为 N/A
- 已移除默认输出的内部列：`industryId` / `aiMatcher` / `commandResult`（需要时由 record 显式带上才作动态列出现）


所有字段在 xlsx 中作为**文本**写入（避免 Excel 把税号 / 电话当数字处理；含逗号的字段不拆分）。

**动态扩展（重要）：** 上述 21 列是**基线(floor)，不是上限(cap)**。实际输出列 = 基线非空列 + 本次 enrich/发现到的额外字段 + 用户额外要求的字段。脚本数据驱动：记录里任何不在基线的 key 会按**首次出现顺序**自动追加为附加列，**不再丢弃**；被 `im_account` 合并消费的 key（zalo/facebook_url/line/kakaotalk/whatsapp）不重复出列。


### 4.3 输出要求

1. `Business Reg No.` 保持 `XXX-XX-XXXXX` 格式显示。
2. 缺失字段填 `N/A`。
3. 附 Result Summary + Data Provenance Table。
4. Phone 必须为 `+82` 国际格式。
5. VAT 阻断：如果某条线索没有 VAT 号且没有官网，置信度标记为 `low`。
6. **CRM Detail 列**：仅 CRM 内已有客户（`globalId` 非空）展示详情页链接（`detailUrl`），外部新发现的线索填 `N/A`。链接使用 Markdown 格式 `[详情](url)` 展示。

---

## Part 5: crm-dedup 字段选择（KR payload）

在 Phase 6 调用 `crm-dedup` 时，韩国线索优先提供以下字段：

```json
{
  "uid": "序号",
  "companyName": "英文名或韩文名",
  "country": "KR",
  "email": "联系邮箱",
  "registerNumber": "사업자등록번호（如已获取）"
}
```

完整 CLI 参数详见 `ggs-crm show-docs crm-dedup`。
