# Taiwan (TW) - leads-finder 国家策略文件

本文件是台湾（TW）地区在 **ggs-sales-leads-finder** skill 中的执行知识库。
当 Phase 2 路由结果为 `country=TW` 时加载本文件。

**CRM 注意：** TW 属于 HKTW CRM family。CRM 内部查询/判重/写回均可用。

> 本文件 Part 1（数据源）同时被 `ggs-sales-enrichment` skill 引用——是台湾数据源的单一信源（SSOT）。

---

## Part 1: 数据源与外网搜索策略

台湾的数据源分為四大類：政府公示系統、競對/B2B 電商平台、行業協會、展會。聯絡方式（特別是聯絡人個人手機/Email）的挖掘高度依賴**競對/電商平台旺鋪頁**——这是台湾 B2B 销售挖联系方式的核心路径。

### 1.1 采集数据源意图映射

根據用戶意圖選擇對應數據源。優先使用 Accio 原生工具（`web_search` / `web_fetch`），ggs-crm CLI 工具（`google-search` / `google-map` / `web-scrape`）作為補充/兜底。

| 用戶意圖 | 主數據源 | 採集方式 | Fallback |
|---------|---------|---------|----------|
| 泛搜某行業工廠/製造商 | Exa Search | `accio-mcp-cli call web_search_exa --query '"{industry}" 台灣 製造商' --num_results 15` | Google 搜索 + FindBiz 按行業關鍵字 |
| 出口商/有海外業務的廠商 | 貿易署出進口廠商資料 + 台灣經貿網 | 先有統編 → 貿易署查出口級距；無統編 → 台灣經貿網（taiwantrade.com）按行業分類瀏覽 | Exa Search `"{industry}" 台灣 出口商` |
| 已知出口/電商標竿賣家 | Amazon Global Open 台灣賣家招募頁 | gs.amazon.com.tw 看標竿案例 → 反查公司資訊 | Global Sources 台灣供應商頁 |
| 競品發現 | Exa Similar | `accio-mcp-cli call find_similar_pages_exa --url "{參照公司官網}" --num_results 10` | — |
| 精準校驗（已有統編）| FindBiz | findbiz.nat.gov.tw 輸入統編 | — |
| 出口級距查詢（已有統編）| 貿易署 | fbfh.trade.gov.tw 輸入統編 | — |
| **聯絡人個人手機/Email/LINE** | **競業 B2B/電商平台旺鋪頁**（見 1.4）| 按公司名搜索旺鋪 → 「聯絡我們」/「賣家資訊」 | LinkedIn 個人頁 + FB 粉專 About |
| 行業協會會員 | 行業協會官網（見 1.5）| `web_fetch` 抓取會員名錄 | — |
| 展會參展商 | 展會官網（見 1.6）| `web_fetch` 抓取參展商列表 | — |
| 員工人數驗證 | 104 / 1111 人力銀行 廠商介紹頁 | `web_search` 公司名 + 「人力銀行」→ `web_fetch` 廠商頁 | Yes123 / LinkedIn 公司頁規模區間 |
| 上市櫃公司財務數據 | 公開資訊觀測站 | mops.twse.com.tw 按公司代號 | 公司年報 PDF |

### 1.2 關鍵詞本地化規則

**強制使用繁體中文。** 搜索前必須將關鍵詞翻譯為繁體中文，並同時以英文並發搜索取結果並集。

| 英文 | 繁體中文 |
|------|---------|
| manufacturer | 製造商 |
| factory | 工廠 |
| exporter | 出口商 |
| trading company | 貿易商 |
| electronics | 電子零組件 |
| machinery | 機械 |
| textiles | 紡織 |
| hardware tools | 五金工具 |
| auto parts | 汽車零件 |
| bicycle parts | 自行車零件 |

### 1.3 核心政府數據源（必查）

| 數據源 | URL | 用途 |
|--------|-----|------|
| 經濟部商工登記公示查詢 (FindBiz) | findbiz.nat.gov.tw | **全量企業名單**：統一編號、負責人、資本額、地址、營業項目、登記現況（在營/歇業）|
| 貿易署 出進口廠商資料查詢 | fbfh.trade.gov.tw | 2025 年出口實績級距（A 級 / B 級 / C 級）——須先有統編 |
| 台灣精品獎 | taiwanexcellence.org/tw/award/product | 獲獎廠商名單——優質出口廠商的標竿池 |

### 1.4 競對 / B2B 電商平台（聯絡方式挖掘核心）

**这些平台是挖掘聯絡人個人手機/Email/LINE 的主路径**。台湾 B2B 销售实战中，聯絡人個人聯絡方式很难从官网或政府数据源直接拿到——必须从**廠商在競業平台的旺鋪頁底部聯絡資訊**抓取。

#### B2B 平台（找聯絡人 / 業務經理）

| 平台 | URL | 抓取目標 |
|------|-----|---------|
| 台灣經貿網 | taiwantrade.com | 公司頁「Contact Us」→ 聯絡窗口姓名、電話、Email |
| 環球資源 Global Sources | globalsources.com | 公司頁「Contact Supplier」→ 業務窗口 |
| 中經社 CENS | cens.com | 公司頁底部聯絡資訊 → 經理級窗口 |

#### C2C / B2C 平台（找在做電商的中小廠商客服 LINE / 手機）

| 平台 | URL | 抓取目標 |
|------|-----|---------|
| 蝦皮 台灣 | shopee.tw | 賣場「賣家資訊」→ 客服 LINE / 手機 |
| MOMO | momoshop.com.tw | 廠商資訊頁 → 客服電話 |
| Amazon Global Open（台灣賣家）| gs.amazon.com.tw | 標竿案例頁 → 反查公司資訊（非聯絡方式直接源）|

#### 通用搜索與官網

| 來源 | 用途 |
|------|------|
| 公司官網「聯絡我們」/「Contact Us」頁 | 公司主線電話、info@ 郵箱（非個人但是必查兜底）|
| Google 搜索 `"{公司名}" "聯絡" OR "電話" OR "經理"` | 散在新聞稿、公開資料中的聯絡資訊 |

#### 社媒（找負責人/經理個人 LINE / 手機）

| 平台 | 抓取目標 |
|------|---------|
| LinkedIn 個人頁 + 公司頁 | 經理級以上的職稱 + 公開聯絡方式 |
| Facebook 粉專 About + 個人頁 | 公司負責人 / 業務經理的 LINE QRcode、個人手機 |
| Instagram 營業帳號 | 中小品牌的客服 LINE / DM 聯絡 |

### 1.5 重點行業協會

協會會員名錄是穩定的優質線索來源。

| 協會 | 領域 | 官網 | 會員名錄路徑 |
|------|------|------|------------|
| 台北市進出口商業同業公會 | 跨行業出口商 | ieatpe.org.tw | /qry/query.aspx（按公司名/HSCODE 查詢）|
| 台中手工具協會 | 五金/手工具 | taiwanhandtools.com.tw | /html/company.php |
| 台灣車輛工業同業公會 | 汽車零件 | ttvma.org.tw | /member |
| 台灣工具機暨零組件工業同業公會 | 工具機 / 機械零組件 | tmba.org.tw | /zh-TW/member-search |

### 1.6 重點展會

展會參展商名錄是**已驗證有出口意圖**的線索池——優先級高。

| 展會 | 領域 | 官網 | 參展商頁面 |
|------|------|------|----------|
| Taiwan International Trade Shows（總站）| 跨行業總覽 | taiwantradeshows.com.tw | /en_US/show-list-calendar/005.html |
| TIMTOS | 工具機 | timtos.com.tw | /zh-tw/exhibitor/company-name-data/index.html |
| Taipei Cycle | 自行車 | taipeicycle.com.tw | /zh-tw/exhibitor/brand-name-data/index.html |
| 台北國際自動化工業大展 | 自動化 / 工業機械 | automationtaipei.chanchao.com.tw | /VisitorExhibitor/Detail |

---

## Part 2: 字段规范 - 去重主键 + 联系方式校验

### 2.1 去重主键字段

| 优先级 | 字段 | 说明 |
|-------|------|------|
| 1 | 統一編號 | 8 位數字，台灣企業唯一身份證 |
| 2 | website（域名）| 去除協議頭與 www 後比較 |
| 3 | 公司全名（繁中）+ 縣市 | 容錯：標點符號差異、簡繁體轉換差異需處理 |

### 2.2 联系方式校验

| 项目 | 规则 |
|------|------|
| 號碼識別/分流 | 由 `scripts/phone-normalize.py`（libphonenumber, region=TW）判定：`type=MOBILE`→行動電話(primary)；`FIXED_LINE`→固話(secondary)；`FIXED_LINE_OR_MOBILE`→按可作 primary 處理 |
| 固話處理 | helper 判 `FIXED_LINE` 的號不填 primary phone，固話資訊記入 AI Summary |
| 寫回格式 | 取 helper 的 `e164`/`international`（自動加 886、去首 0），不手工拼接 |
| 多號處理 | 多個手機號逗號分隔，第一個為 primary；固話寫入 secondary，不填入 primary phone 字段 |
| 主要 IM 渠道 | LINE > Facebook Messenger > Instagram DM |
| Email 校驗 | 基本格式校驗；個人郵箱（如 `@gmail.com`、`@yahoo.com.tw`）優先於通用 `info@` 郵箱 |

---

## Part 3: CRM 写回字段规范（TW 专属 override）

> ⚠️ **HKTW family 的 `country` 字段值在不同 CRM 工具下不一致（重要！）：**
> - **crm-search**：HKTW CRM 查询条件中**不传 `country` 字段**（org-id/sales-id 自动限定范围）
> - **crm-dedup payload**：传 `"country": "TW"`（dedup 工具用 country 区分港台）
> - **crm-add / crm-refine payload**：固定为 `"country": "CN"`（HKTW family 内部统一）
> - **crm-address --country 参数**：传 `TW`（地址转码工具的国家参数，与字段值无关）

完整的 write-back 参数说明见 `ggs-crm show-docs crm-add` / `ggs-crm show-docs crm-refine`。以下为台湾的国家级 override，同时适用于 crm-add（leads-finder Phase 9 新增）和 crm-refine（leads-finder Phase 9 捡入后补全 / enrichment Phase 6 已有客户补全）：

| 规则 | 说明 |
|------|------|
| `registerNumber` **必填** | 台湾线索写回时統一編號为必填。**沒有統編 → 停止該筆資料開發**（不是单纯阻断写回——是直接放弃这条线索）|
| `province` / `city` 需转码 | 不能直接写入"台北市"，必须先调 `crm-address --country TW` 获取编码 |
| `phone` 格式 | 調 `scripts/phone-normalize.py`（libphonenumber，TW region）取 `e164`/`international` 寫回；`primary_ok=true` 的號作 primary |

> ⚠️ **HKTW family 必填字段比 Global 多。** 除 `registerNumber` 外，CLI 还会要求 `mobilePhone`/`phoneNumber` 配套国家区号字段、完整的 `province + provinceCode` / `city + cityCode` / `area + areaCode` / `address` 等。**调用 crm-add / crm-refine 前必须先 `ggs-crm show-docs crm-add` / `crm-refine` 拿当前权威必填列表**——本文档不复制 CLI 字段清单，避免文档与 CLI 不同步。
>
> 任何字段缺失时，**阻断写回**并向用户列出缺失字段请求补充，不要凭空猜测填值。

---

## Part 4: 用户输出规范

### 4.1 用户输出字段（TW 专属）

向用户交付台湾线索时，使用以下字段定义：

| 公司全名 | 統一編號 | 負責人 | 聯絡人 | 職稱 | 產業 | 個人電話/手機 | 個人 Email | LINE | 地址 | 在營狀態 | 員工人數 | 資本額 | 出口級距 | 社媒資訊 | 網站 | CRM 詳情 | AI Summary |
|----------|----------|--------|--------|------|------|--------------|-----------|------|------|---------|----------|--------|----------|----------|------|----------|-----------|
| 範例股份有限公司 | 12345678 | 王大明 | 陳怡君 | 外銷經理 | 電子零組件 | +886 912 345 678 | yichun.chen@example.com.tw | @example_tw | 台北市內湖區範例路 100 號 | 營業中 | 85 | 50,000,000 TWD | A級 | https://linkedin.com/company/example-tw | example.com.tw | [詳情](https://crm.alibaba-inc.com/crmagent/romeo/public-sea/customer-detail.html?globalId=xxx) | 已穷尽 7/7 来源，從 LinkedIn 獲得聯絡人手機 |

**动态扩展：** 实际预览列 = 上表策展列 + 用户额外要求的字段（Intent Struct `extra_fields`，如 ISO 认证 / 主要出口国 / 领英粉丝数），按采集顺序追加到表末。与 xlsx 输出保持一致——不在策展列内的用户要求字段在聊天预览里也显示，不只落 xlsx。

### 4.2 xlsx 列定义

由 `scripts/leads-to-xlsx.py` 生成，以下 21 列为**基线参考列**（floor，不是上限；所有国家一致，始终输出）：

```
index, source,
company_name_en, company_name_local,
country, province, city, address,
industry, tax_id,
phone, email, website, im_account,
key_person_name, key_person_title,
confidence, qualityTags, dataSources, aiSummary,
crm_status
```

**说明：**
- `tax_id`: 各国通用税号 / 注册号（VN: MST；KR: 사업자등록번호；TW: 統一編號；IT: P.IVA；ES: NIF/CIF）
- `im_account`: 各国 IM 平台合并为一列（`Zalo: xxx; FB: yyy` / `KakaoTalk: xxx` / `LINE: xxx`）
- `key_person_name`: 单列存放完整姓名（如 KR 姓+名拼接）
- `crm_status`: CRM 内部字段（globalId/pool/orgId/ownerId/detailUrl）合并为一列——命中 CRM 显示「池 + 详情链接」，外部新线索为 N/A
- 已移除默认输出的内部列：`industryId` / `aiMatcher` / `commandResult`（需要时由 record 显式带上才作动态列出现）


所有字段在 xlsx 中作为**文本**写入（避免 Excel 把税号 / 电话当数字处理；含逗号的字段不拆分）。

**动态扩展（重要）：** 上述 21 列是**基线(floor)，不是上限(cap)**。实际输出列 = 基线非空列 + 本次 enrich/发现到的额外字段 + 用户额外要求的字段。脚本数据驱动：记录里任何不在基线的 key 会按**首次出现顺序**自动追加为附加列，**不再丢弃**；被 `im_account` 合并消费的 key（zalo/facebook_url/line/kakaotalk/whatsapp）不重复出列。

### 4.3 输出要求

1. `統一編號` 保持 8 位數字格式顯示。
2. 缺失字段填 `N/A`。
3. 附 Result Summary + Data Provenance Table。
4. Phone 必須為 `886+9xx-xxx-xxx`（手機）或 `886+區碼+電話`（固話）格式。
5. 統編阻斷：如果某條線索沒有統編 → **停止該筆資料開發**，置信度標記為 `low`，不進入交付列表。
6. **LINE 欄**：填 LINE ID（如 `@example_tw`）或 LINE 個人帳號連結。LINE 是台灣 B2B/B2C 第一 IM 渠道，**只要找到就必須填**；找不到時填 `N/A`，不要用 FB/Email 替代。LINE 來源優先：競業電商平台賣場客服資訊（蝦皮/MOMO）> 官網 LINE 加好友連結 > FB 粉專貼文 LINE QRcode > Google 搜索 `"{公司名}" LINE`。
7. **Markdown 預覽表 LINE 是獨立欄**；**xlsx 輸出**中 LINE 合併進 `im_account` 列（格式 `LINE: @example_tw`）——由 `scripts/leads-to-xlsx.py` 自動處理，無需手動拼接。
8. **CRM 詳情列**：僅 CRM 內已有客戶（`globalId` 非空）展示詳情頁連結（`detailUrl`），外部新發現的線索填 `N/A`。連結使用 Markdown 格式 `[詳情](url)` 展示。

---

## Part 5: crm-dedup 字段选择（TW payload）

在 Phase 6 调用 `crm-dedup` 时，台湾线索优先提供以下字段：

```json
{
  "uid": "序号",
  "companyName": "公司英文名或繁中名",
  "country": "TW",
  "email": "联系邮箱",
  "registerNumber": "統一編號（如已获取）"
}
```

完整 CLI 参数详见 `ggs-crm show-docs crm-dedup`。
