# Spain (ES) - leads-finder 国家策略文件

本文件是西班牙（ES）地区在 **ggs-sales-leads-finder** skill 中的执行知识库。
当 Phase 2 路由结果为 `country=ES` 时加载本文件。

---

## Part 1: 数据源与外网搜索策略

西班牙企业数据补全采用分层执行策略。Exa Search（`accio-mcp-cli call web_search_exa`）优先用于发现出口型（Exportadores）工厂。

### 1.1 采集数据源意图映射

| 用户意图 | 主数据源 | 采集方式 | Fallback |
|---------|---------|---------|----------|
| 泛搜工厂 | Exa Search | `accio-mcp-cli call web_search_exa --query '"{industry}" fábrica fabricación españa' --num_results 15` | Google 搜索 |
| 出口商 | Exa Search | `accio-mcp-cli call web_search_exa --query '"{industry}" exportadores fabricantes españa' --num_results 15` | — |
| 竞品发现 | Exa Similar | `accio-mcp-cli call find_similar_pages_exa --url "{参照公司官网}" --num_results 10` | — |
| 营收/员工查询 | Iberinform | www.iberinform.es，输入 9 码 VAT/NIF | — |
| 企业工商验证 | 官网 Footer | 寻找 "NIF" 或 "IVA" | Google 搜索 "{company} NIF" |

### 1.2 关键词本地化规则

**强制使用西班牙语。**

| 英文 | 西班牙语 |
|------|---------|
| factory / manufacturer | fábrica / fabricante |
| exporter | exportador |
| furniture | muebles |
| company | empresa |
| revenue | facturación |
| employees | empleados |

---

## Part 2: 字段规范 - 去重主键 + 联系方式校验

### 2.1 去重主键字段

| 优先级 | 字段 | 说明 |
|-------|------|------|
| 1 | VAT (NIF) | 9 位字符，去掉 ES 前缀 |
| 2 | website（域名） | .es 域名常见 |
| 3 | company_name + city | — |

### 2.2 联系方式校验

| 项目 | 规则 |
|------|------|
| 电话校验/格式 | 由 `scripts/phone-normalize.py`（libphonenumber, region=ES）校验并取 `e164`/`international` |
| 主要 IM 渠道 | WhatsApp > LinkedIn |

---

## Part 3: CRM 写回字段规范（ES 专属 override）

完整的 write-back 参数说明见 `ggs-crm show-docs crm-add` / `ggs-crm show-docs crm-refine`。以下为西班牙的国家级 override，同时适用于 crm-add（leads-finder Phase 9 新增）和 crm-refine（leads-finder Phase 9 捡入后补全 / enrichment Phase 6 已有客户补全）：

> **字段名与必填性以 `ggs-crm show-docs crm-add` / `crm-refine` 运行时返回为准，本文档不复制 CLI 字段清单（避免与 CLI drift）。** 下表是采集字段 → CRM 的映射意图与业务约束；写回前按 show-docs 拿当前权威必填列表，缺失则阻断并向用户列出。

| 采集字段 | 映射意图 | 业务约束 |
|---------|---------|---------|
| VAT（NIF/CIF）| → 注册号字段 | CRM **不强制必填**，但强烈建议提供；写回前去 "ES" 前缀、保留 9 位字符 |
| phone | → 电话字段 | 调 `scripts/phone-normalize.py`（libphonenumber）取 `e164`/`international` 写回；`primary_ok=true` 的号作 primary（ES region）|
| province / city | → 地址字段 | 先调 `crm-address --country ES` 转码 |

---

## Part 4: 用户输出规范

### 4.1 用户输出字段（ES 专属）

向用户交付西班牙线索时，使用以下字段定义：

| Company Name | Domain | VAT (NIF) | Revenues | Employees | Industry | First Name | Last Name | Email | Phone | CRM Detail | AI Summary |
|--------------|--------|-----------|----------|-----------|----------|------------|-----------|-------|-------|------------|------------|
| Ejemplo S.L. | ejemplo.es | B12345678 | € 1M - 2M | 10 - 50 | Furniture | Javier | Pérez | javier.perez@ejemplo.es | +34 91 123 4567 | [详情](https://crm.alibaba-inc.com/crmagent/romeo/public-sea/customer-detail.html?globalId=xxx) | N/A |

**动态扩展：** 实际预览列 = 上表策展列 + 用户额外要求的字段（Intent Struct `extra_fields`，如 ISO 认证 / 主要出口国 / 领英粉丝数），按采集顺序追加到表末。与 xlsx 输出保持一致——不在策展列内的用户要求字段在聊天预览里也显示，不只落 xlsx。

### 4.2 xlsx 列定义

由 `scripts/leads-to-xlsx.py` 生成，以下 21 列为**基线参考列**（floor，不是上限；所有国家一致，始终输出）：

```
index, source,
company_name_en, company_name_local,
country, province, city, address,
industry, tax_id,
phone, email, website, im_account,
key_person_name, key_person_title,
confidence, qualityTags, dataSources, aiSummary,
crm_status
```

**说明：**
- `tax_id`: 各国通用税号 / 注册号（VN: MST；KR: 사업자등록번호；TW: 統一編號；IT: P.IVA；ES: NIF/CIF）
- `im_account`: 各国 IM 平台合并为一列（`Zalo: xxx; FB: yyy` / `KakaoTalk: xxx` / `LINE: xxx`）
- `key_person_name`: 单列存放完整姓名（如 KR 姓+名拼接）
- `crm_status`: CRM 内部字段（globalId/pool/orgId/ownerId/detailUrl）合并为一列——命中 CRM 显示「池 + 详情链接」，外部新线索为 N/A
- 已移除默认输出的内部列：`industryId` / `aiMatcher` / `commandResult`（需要时由 record 显式带上才作动态列出现）


所有字段在 xlsx 中作为**文本**写入（避免 Excel 把税号 / 电话当数字处理；含逗号的字段不拆分）。

**动态扩展（重要）：** 上述 21 列是**基线(floor)，不是上限(cap)**。实际输出列 = 基线非空列 + 本次 enrich/发现到的额外字段 + 用户额外要求的字段。脚本数据驱动：记录里任何不在基线的 key 会按**首次出现顺序**自动追加为附加列，**不再丢弃**；被 `im_account` 合并消费的 key（zalo/facebook_url/line/kakaotalk/whatsapp）不重复出列。


### 4.3 输出要求

1. `VAT (NIF)` 保持 9 位字符格式显示，去掉 ES 前缀。
2. 缺失字段填 `N/A`。
3. 附 Result Summary + Data Provenance Table。
4. Phone 必须为 `+34` 国际格式。
5. **CRM Detail 列**：仅 CRM 内已有客户（`globalId` 非空）展示详情页链接（`detailUrl`），外部新发现的线索填 `N/A`。链接使用 Markdown 格式 `[详情](url)` 展示。

---

## Part 5: crm-dedup 字段选择（ES payload）

在 Phase 6 调用 `crm-dedup` 时，西班牙线索优先提供以下字段：

```json
{
  "uid": "序号",
  "companyName": "英文名或西语名",
  "country": "ES",
  "email": "联系邮箱",
  "registerNumber": "VAT/NIF（如已获取）"
}
```

完整 CLI 参数详见 `ggs-crm show-docs crm-dedup`。
