# Vietnam (VN) - leads-finder 国家策略文件

本文件是越南（VN）地区在 **ggs-sales-leads-finder** skill 中的执行知识库。
当 Phase 2 路由结果为 `country=VN` 时加载本文件。

---

## Part 1: 数据源与外网搜索策略

目标客户 = 想做 / 在做出口、但还没在 Alibaba 国际站的越南卖家。越南 SME 线上化程度低（约仅 25% 有官网），大量企业只在社媒（尤其 Facebook / Zalo）活动，故数据源按**入驻意图信号强弱**排序，而非名录全不全。

> **工具约束：**
> - **主力**：`web_search` + `web_fetch`
> - **登录态场景**：`sessions_spawn` with `agent_id="browser"`（Facebook Page、LinkedIn 等需登录平台）
> - **地理搜索**：`google-map`（用户有经纬度/工业区意图时）
> - **Alibaba 排除**：`product_supplier_search`（已入驻 = 非目标客户，直接排除）

### 1.1 采集总则 + 采集前快速判断

- **意图优先**：招聘 / 社媒外贸帖 / 同行 B2B 平台 / 展会参展 / 海关出口记录——这些都隐含"正在做外贸、愿花钱获客"，转化率高于全量工商名录。
- **类目快速判断（轻量）**：默认按下方意图源走（服务**工业 / B2B + 农产**，即越南出口主力）。**例外**：若目标是**自有品牌消费品**（美妆 / 香水 / 宠物食品 / 保健品 / 时尚配饰——越南出口商里少见但存在），把**社媒（优先 Facebook/IG/TikTok）+ 独立站**提到首位，因为这类不太出现在 B2B 平台 / 海关 / 协会名录里。
- **关键词强制本地化**：见 1.5。

### 1.2 Tier A — 高意图发现源（主力）

| 意图信号 | 数据源 | 采集方式 |
|---------|--------|--------------------------------------|
| 在招外贸 / 出口 / 跨境岗 | topcv.vn、vietnamworks.com（jobsgo.vn / careerbuilder.vn 兜底） | `web_search "tuyển nhân viên xuất khẩu {行业} site:topcv.vn"` 等 → `web_fetch` 招聘页取公司名 + 联系人。**岗位关键词过滤**：`nhân viên xuất khẩu` / `xuất nhập khẩu` / `thương mại điện tử xuyên biên giới` / `Alibaba/Amazon 运营` |
| 社媒发招聘 / 外贸帖 | **Facebook**（公司 Page / 行业 Group） | `web_search "tuyển ... xuất khẩu {行业} facebook"`、`"tìm khách hàng nước ngoài {行业}"`、`"xuất khẩu đi Mỹ/EU {行业}"` → `web_fetch` Page/帖子取联系方式 |
| 已在同行 B2B 平台挂牌 | globalsources.com、made-in-china.com、ec21.com、tradekey.com | `web_search "{行业} vietnam supplier site:globalsources.com"`（各平台同理）→ `web_fetch` 供应商页 |
| 参展出口型展会 | 单展参展商名录 + 展会聚合站（见 1.7） | `web_search` 参展商列表页 → `web_fetch` |
| 有实际出口记录 | 公开提单 / 出口信息（web search 可见部分） | `web_search "{公司名} exporter bill of lading"` / `"{行业} vietnam exporter shipment"` → `web_fetch`（不依赖付费平台权限） |

### 1.3 当前平台存在性判断（入驻资格核心）

对每条线索判断当前线上销售存在，决定开发策略，落到固定字段 **`current_platform_presence`**：
- **在竞品平台（GlobalSources / Made-in-China 等）但不在 Alibaba** → 最高优先，主攻转化
- **只有 FB / 官网、无任何 B2B 平台** → 新客培育

判断方式：
- **Alibaba**：`product_supplier_search "{公司名}"` → 命中则**排除**（已入驻 = 非目标客户）
- **竞品平台**：`web_search "{公司名} site:globalsources.com"` / `site:made-in-china.com` 等

### 1.4 关键人（KP）挖掘

找能拍板的人（老板 / 外贸经理 / 跨境负责人），来源逐级试：
1. **LinkedIn** 公司页 → 员工 → 职称过滤（Export/Sales Manager、`Giám đốc xuất khẩu`、`Trưởng phòng kinh doanh quốc tế`）：`web_search "{公司名} export manager site:linkedin.com"`
2. **Facebook** Page 管理员 / 发帖署名、**招聘帖里的联系人**（常带手机 / Zalo）
3. 官网 About / Liên hệ 页
4. 同行 B2B 平台公司页的 contact person
5. 工商库法人代表（兜底，可能非实际对接人）

KP 字段：姓名 + 职位 + 直接联系方式（手机 / Zalo / 邮箱），走动态列（采到才出）；找不到时在 aiSummary 标注已穷尽来源。

**FB / Zalo 联系方式提取（事实性指引）**

- *查找位置*（逐一查看）：FB Page 的 **Intro / About / "Giới thiệu"** 区、**"Liên hệ"** 标签页、封面/头图文字、置顶帖 / 近期帖正文 / 公司自己的评论回复。
- *号码识别*：手机 `0` + `3/5/7/8/9` 开头 10 位（也写作 `0912.345.678` / `+84 912…`）；固话 `02x` 开头（028 HCM / 024 HN / 0274 Bình Dương）。一律过 `scripts/phone-normalize.py` 判定。
- *Zalo 记录（仅凭字面证据，不得推断）*：Zalo 号绑手机、默认不公开显示，只有公司主动放出才可见。记 `zalo` 的依据**只能是页面字面出现的** `Zalo: <号>` / `<号> (Zalo)` 标注、`zalo.me/<…>` 或 `oa.zalo.me/<…>` 链接、标注 Zalo 的二维码。**只有手机号、无 Zalo 标记 → `zalo` 填 N/A，不由手机号推断。**
- *FB 抓取策略*：
  1. **首选**：`sessions_spawn` with `agent_id="browser"` → 登录态完整读取 Page About/帖子
  2. **browser 不可用时降级**：`web_search "{公司名} facebook"` 取 Page+摘要 → `web_search "{公司名} zalo / hotline"` → 官网 Contact/Footer → 第三方名录（vietfactory.com / yellowpages.com.vn）

### 1.5 关键词本地化规则

**强制要求：** 搜索前必须将关键词翻译为越南语，生成 1 组英文 + 1 组越南语并发搜索。

| 英文 | 越南语 |
|------|--------|
| factory / manufacturer | nhà máy / nhà sản xuất |
| exporter | nhà xuất khẩu |
| import-export | xuất nhập khẩu |
| cross-border e-commerce | thương mại điện tử xuyên biên giới |
| furniture | nội thất / đồ gỗ |
| textiles / garment | dệt may |
| seafood | thủy sản |
| trading company | công ty thương mại |
| industrial zone | khu công nghiệp (KCN) |

### 1.6 重点行业协会

会员名录路径以协会官网实际为准（易变，`web_search`/`web_fetch` 确认）。

| 协会 | 领域 | 官网 |
|------|------|------|
| VASEP | 水产品出口 | vasep.com.vn |
| HAWA | 家具 / 木制品 / 手工艺（**含原 BIFA**，2025-12 合并） | hawa.vn |
| VITAS | 纺织服装 | vietnamtextile.org.vn |
| LEFASO | 皮革鞋业 | lefaso.org.vn |
| VPA | 塑料 | vpas.vn |
| VICOFA | 咖啡可可 | vicofa.org.vn |
| VINACAS | 腰果（越南世界第一） | vinacas.com.vn |
| VFA | 大米 / 粮食 | vietfood.org.vn |
| VIFOREST | 木业全国总会 | vietfores.org |
| Vinafruit | 果蔬 | vinafruit.com |
| Vietcraft | 手工艺出口 | vietcraft.org.vn |
| VASI | 配套工业（机械 / 电子 / 塑胶配件） | vasi.org.vn |
| VSA | 钢铁 | vsa.com.vn |
| VRA | 橡胶 | vra.com.vn |
| VPPA | 纸业 | vppa.vn |
| VCCI | 工商总会（跨行业，会员量最大） | vcci.com.vn |

### 1.7 重点展会

| 展会 | 领域 | 官网 |
|------|------|------|
| VIFA EXPO | 家具 | vifaexpo.com（全年在线参展商平台 vifaexpo.online） |
| VIETFISH | 水产（VASEP 主办） | vietfish.com.vn |
| VTG | 纺织服装 | vtg.chanchao.com.tw |
| ILDEX | 畜牧 | ildex-vietnam.com |
| ProPak Vietnam | 食品包装 | propakvietnam.com |
| **展会聚合站** | 跨展一次扫多个参展商 | jufair.com、vnbuyerguide.com |

### 1.8 重点工业园区 (KCN)

| 园区 | 城市/省 | 主要行业 |
|------|--------|---------|
| KCN Sóng Thần 1/2/3 | Bình Dương | 家具、机械 |
| KCN Tân Bình | HCM | 食品、塑料 |
| KCN Biên Hòa 1/2 | Đồng Nai | 电子、纺织 |
| KCN Mỹ Phước 1/2/3 | Bình Dương | 综合制造 |
| KCN Nhơn Trạch | Đồng Nai | 化工、机械 |
| KCN Long Hậu | Long An | 食品、物流 |
| KCN VSIP | Bình Dương / Bắc Ninh | 电子、精密制造 |

### 1.9 工商 / 验证源（Tier B）

| 数据源 | 角色 |
|--------|------|
| dangkykinhdoanh.gov.vn | 国家工商登记门户（权威） |
| masothue.com | 税号 / MST 查询主源 |
| hosocongty.vn、infodoanhnghiep.com | masothue 镜像冗余（缓解反爬单点） |
| doanhnghiepmoi.vn | 新注册企业 |

采集：`web_search "{公司名} mã số thuế"` → `web_fetch`。

### 1.10 名录补充（Tier C，末级 fallback）

> 数据陈旧、电话邮箱常失效，**仅用于补 MST / 地址，不作线索来源**。

- 较可靠：**VietFactory**（vietfactory.com，~5 万制造商）、**VietnamExport**（vietnamexport.com，MoIT 官方出口商库）
- 一般黄页（仅兜底）：fact-link.com.vn、ecvn.com、yellowpages.vn、yellowpages.com.vn、trangvangvietnam.com、infocom.vn、doanhnghiep.biz、tratencongty.com、congtyviet.org

---

## Part 2: 字段规范 - 去重主键 + 联系方式校验 + 工商验证

### 2.1 去重主键字段

按优先级顺序尝试匹配：

| 优先级 | 字段 | 说明 |
|-------|------|------|
| 1 | MST（Mã số thuế） | 10 位或 13 位数字，越南唯一企业标识 |
| 2 | website（域名） | 去除协议头和 www 后比较 |
| 3 | company_name_local + province | 越南语全称 + 省份组合 |

### 2.2 联系方式校验

| 项目 | 规则 |
|------|------|
| 号码识别/分流 | 由 `scripts/phone-normalize.py`（libphonenumber, region=VN）判定：`type=MOBILE`→手机号(primary)；`FIXED_LINE`→固话(secondary)；`FIXED_LINE_OR_MOBILE`→按可作 primary 处理 |
| 固话处理 | helper 判 `FIXED_LINE` 的号不填 phone 主字段，记入 AI Summary 备注 |
| 号码格式 | 取 helper 的 `e164`/`international`（自动去首 0、加 +84），不手工拼接 |
| 多号处理 | 多个手机号逗号分隔填入，第一个为 primary（CRM 写回用） |
| 主要 IM 渠道 | **Zalo**（权重等同手机号）> Facebook Messenger > LinkedIn |
| Email 校验 | 基本格式校验，去重时作为辅助匹配键 |

### 2.3 工商验证

| 字段 | 本地名称 | 格式 | 说明 |
|------|---------|------|------|
| 税号/营业执照号 | Mã số thuế (MST) | 10 位或 13 位数字 | 越南的营业执照号 = 税号，同一编号 |

---

## Part 3: CRM 写回字段规范（VN 专属 override）

完整的 write-back 参数说明见 `ggs-crm show-docs crm-add` / `ggs-crm show-docs crm-refine`。以下为越南的国家级 override，同时适用于 crm-add（leads-finder Phase 9 新增）和 crm-refine（leads-finder Phase 9 捡入后补全 / enrichment Phase 6 已有客户补全）：

> **字段名与必填性以 `ggs-crm show-docs crm-add` / `crm-refine` 运行时返回为准，本文档不复制 CLI 字段清单（避免与 CLI drift）。** 下表是采集字段 → CRM 的映射意图与业务约束；写回前按 show-docs 拿当前权威必填列表，缺失则阻断并向用户列出。

| 采集字段 | 映射意图 | 业务约束 |
|---------|---------|---------|
| MST（税号）| → 注册号字段 | **MST 缺失 → 阻断写回**（越南业务硬规则）|
| phone | → 手机字段 | 调 `scripts/phone-normalize.py`（libphonenumber）取 `e164`/`international` 写回；`primary_ok=true` 的号作 primary；**只写手机，固话不回写** |
| website | → 官网字段 | strip 为纯域名（去 `www.` / `http(s)://`）；用户输出表保留完整 URL |
| province / city | → 地址字段 | 先调 `crm-address --country VN` 转码 |

---

## Part 4: 用户输出规范

### 4.1 用户输出字段（VN 专属）

向用户交付越南线索时，使用以下字段定义：

| Company Name (Local) | MST (Tax ID) | Phone | Zalo / FB | Email | Website | Address / KCN | Industry / Products | Platform Presence | CRM Detail | AI Summary |
|----------------------|--------------|-------|-----------|-------|---------|---------------|---------------------|-------------------|------------|------------|
| Công ty TNHH ABC | 0312345678 | +84 123456789, +84 987654321 | [Zalo: +84 123456789] / https://facebook.com/abcvn | info@abc.vn | https://abc.com.vn | KCN Sóng Thần 1, Bình Dương | Furniture | 竞品: GlobalSources（未在 Alibaba） | [详情](https://crm.alibaba-inc.com/crmagent/romeo/public-sea/customer-detail.html?globalId=xxx) | 固话: +84 274 1234567 |

> **Platform Presence**（`current_platform_presence`，VN 固定字段）：当前线上销售存在判断——"竞品平台（未在 Alibaba）" / "仅 FB/官网" 等，用于入驻资格分级（见 Part 1.3）。

**动态扩展：** 实际预览列 = 上表策展列 + 用户额外要求的字段（Intent Struct `extra_fields`，如 ISO 认证 / 主要出口国 / 领英粉丝数），按采集顺序追加到表末。与 xlsx 输出保持一致——不在策展列内的用户要求字段在聊天预览里也显示，不只落 xlsx。

### 4.2 xlsx 列定义

由 `scripts/leads-to-xlsx.py` 生成，以下 21 列为**基线参考列**（floor，不是上限；所有国家一致，始终输出）：

```
index, source,
company_name_en, company_name_local,
country, province, city, address,
industry, tax_id,
phone, email, website, im_account,
key_person_name, key_person_title,
confidence, qualityTags, dataSources, aiSummary,
crm_status
```

**说明：**
- `tax_id`: 各国通用税号 / 注册号（VN: MST；KR: 사업자등록번호；TW: 統一編號；IT: P.IVA；ES: NIF/CIF）
- `im_account`: 各国 IM 平台合并为一列（`Zalo: xxx; FB: yyy` / `KakaoTalk: xxx` / `LINE: xxx`）
- `key_person_name`: 单列存放完整姓名（如 KR 姓+名拼接）
- `crm_status`: CRM 内部字段（globalId/pool/orgId/ownerId/detailUrl）合并为一列——命中 CRM 显示「池 + 详情链接」，外部新线索为 N/A
- 已移除默认输出的内部列：`industryId` / `aiMatcher` / `commandResult`（需要时由 record 显式带上才作动态列出现）


所有字段在 xlsx 中作为**文本**写入（避免 Excel 把税号 / 电话当数字处理；含逗号的字段不拆分）。

**动态扩展（重要）：** 上述 21 列是**基线(floor)，不是上限(cap)**。实际输出列 = 基线非空列 + 本次 enrich/发现到的额外字段 + 用户额外要求的字段。脚本数据驱动：记录里任何不在基线的 key 会按**首次出现顺序**自动追加为附加列，**不再丢弃**；被 `im_account` 合并消费的 key（zalo/facebook_url/line/kakaotalk/whatsapp）不重复出列。


### 4.3 输出要求

1. 缺失字段一律填 `N/A`。
2. Markdown 预览表使用 4.1 的字段定义（越南专属）。
3. 表格下方附 `Result Summary`（50 字），说明数据来源和质量情况。
4. 必须附 Data Provenance Table（结构见 SKILL.md 输出 Phase 中的 Data Provenance Table 段）。采集中使用的黄页(trangvangvietnam.com)等数据源链接在此表中体现。
5. Phone 必须为 `+84` 国际格式。Phone 列填手机号（primary），固话记入 AI Summary。多个手机号逗号分隔。
6. Facebook / Website 列填写完整可点击 URL。
7. MST 阻断：如果某条线索既没有 MST 也没有官网，置信度标记为 `low`。
8. **CRM Detail 列**：仅 CRM 内已有客户（`globalId` 非空）展示详情页链接（`detailUrl`），外部新发现的线索填 `N/A`。链接使用 Markdown 格式 `[详情](url)` 展示。

---

## Part 5: crm-dedup 字段选择（VN payload）

在 Phase 6 调用 `crm-dedup` 时，越南线索优先提供以下字段：

```json
{
  "uid": "序号",
  "companyName": "公司英文名或越南语名",
  "country": "VN",
  "email": "联系邮箱",
  "registerNumber": "MST（如已获取）"
}
```

完整 CLI 参数详见 `ggs-crm show-docs crm-dedup`。
