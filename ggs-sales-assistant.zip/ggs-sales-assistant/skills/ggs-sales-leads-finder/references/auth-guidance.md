# 平台授权与登录引导指南 (Auth Guidance)

本文档处理**外部平台**（LinkedIn / Facebook 等）的登录授权问题。Phase 4 涉及需登录平台前加载。

> **CRM 认证** 由 `ggs-sales-auth-provider` 统一处理（见 `prompt.md <crm_auth>`），不在本文档范围内。

---

## 1. 检查 Browser Relay 状态

在开始涉及浏览器的任务前，确认 Accio Browser Relay 已连接。

如果未连接，提示用户：
> 请确认您的 Chrome 浏览器插件栏中的 Accio 图标已点亮。如果提示无法访问页面，请手动点击插件图标并选择 "Allow Accio to access this page"。

**未连接时：** 降级为 `web_search` + `web_fetch` + ggs-crm CLI 工具，不使用 `browser`。

---

## 2. 关键平台登录引导

当搜索策略涉及以下平台时，**必须** 先向用户输出登录引导。

### 2.1 LinkedIn

**为什么需要：** 非登录状态下搜索结果极少，极易触发反爬。

**话术：**
> 我正准备通过 LinkedIn 搜索潜在客户。为了获取完整的公司主页和官网链接，请确保您的 Chrome 浏览器已登录 LinkedIn 账号。

### 2.2 Facebook

**为什么需要：** Page 的 About 模块中的手机号、邮箱、网站对未登录用户隐藏。

**话术：**
> 为了提取这些企业的 Facebook 联系方式（手机号/Zalo/邮箱），请在浏览器中保持 Facebook 的登录状态。

### 2.3 综合引导（同时需要多个平台时）

> 我准备去 LinkedIn 和 Facebook 帮您深入挖掘这几家公司的联系人。这两个平台需要登录才能看到手机号和官网。
> **请确认：**
> 1. 您已在 Chrome 浏览器中登录了 LinkedIn 和 Facebook；
> 2. Accio 插件已连接。
>
> 确认后，我将立刻开始自动化抓取。

---

## 3. 异常处理：验证码 (CAPTCHA)

如果在 `browser(action='snapshot')` 中发现人机验证（Cloudflare / reCAPTCHA / LinkedIn Security Check）：

1. **立即停止** 对该平台的自动化操作。**严禁静默忽略。**
2. 保存当前页面截图，发送给用户。
3. **话术：**
   > 抱歉，访问 [平台名称] 时遇到了人机验证，我暂时无法继续自动处理。请您在浏览器中手动完成验证，完成后告诉我，我会继续后续采集。
4. 等待用户期间或用户无法解决时，跳过该平台，执行 country 文件或 `platform-sop.md` 中的 Fallback 策略。
