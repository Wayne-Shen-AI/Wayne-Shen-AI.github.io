---
name: ggs-sales-leads-finder
description: >
  【触发条件】用户意图是"**批量发现新的公司或线索**"——找一批符合 ICP 的客户:
  - "帮我找几个/有什么推荐"
  - "找胡志明市的客户"、"找越南家具厂"、"附近 10 公里的工厂"
  - "看下这个网站 xx 最新注册的公司"（url-extract）
  - "找展会 leads"、"行业协会会员"
  - "找和 @xxx 类似的"、"与我刚签单的类似的"（参照搜索：skill 内部调 crm-search 解析参照对象，再按 ICP 发现新 leads）

  【不触发——由 ggs-sales-enrichment 兜底】单家或几家公司的深度调研/字段补全:
  - "调研 xx 公司"、"xx 公司什么情况" → ggs-sales-enrichment
  - "找 xx 公司的 KP / 邮箱 / 电话"（含外部挖取） → ggs-sales-enrichment
  - "补全这条线索的联系方式" → ggs-sales-enrichment

  【不触发——由 ggs-sales-crm-tools 兜底】用户要**浏览/查询 CRM 里已有的内容本身**，或做写操作:
  - "看下我的私海"、"我私海有多少客户" → ggs-sales-crm-tools（列表查询）
  - "最近放出来的（公海/分配）"、"最近 inbound 的" → ggs-sales-crm-tools（公海列表）
  - "高意向的有哪些"、"看下我的高意向客户" → ggs-sales-crm-tools（按意向等级列表）
  - "上次什么时候联系的 xxx 公司"、"xxx 公司的拜访记录" → ggs-sales-crm-tools（crm-visit-query）
  - "xxx 的 KP 是谁"（仅查 CRM 现有联系人） → ggs-sales-crm-tools（crm-contact-query）
  - "释放 / 捡入 / 新增 / 补全 / 打标" → ggs-sales-crm-tools 写工具

  【边界判断】"找新 leads" vs "调研单家":
  - 用户要**一批**符合条件的新客户 → ggs-sales-leads-finder
  - 用户要对**一家**或少数几家做**深度补全/调研** → ggs-sales-enrichment
  - 用户只想看 CRM 里已有的某个字段 → ggs-sales-crm-tools

  【硬性约束】
    1. FIRST ACTION 必须是 Read 本 SKILL.md 全文（激活校验逻辑），禁止先执行搜索。
    2. 必须先完成意图理解，以自然语言向用户确认搜索条件后再执行。
    3. 严禁仅使用通用 web_search 裸跑，必须执行国家级"发现 → 验证 → 审计"链。
    4. **crm-search 在本 skill 仅限一种用途**：参照搜索场景（"找和 @xxx 类似的"）内部调 crm-search 解析参照公司的 ICP 锚点（行业/地区/address）。**不用于**判断"CRM 里有没有这家公司"（判重一律走 crm-dedup），也**不用于**浏览私海/公海列表（列表查询归 ggs-sales-crm-tools）。

  【交付红线】
    - 必须严格遵循 references/countries/{country_code}.md 规定的字段与输出格式。
      > ⚠️ 路径基准：`skills/ggs-sales-leads-finder/references/countries/`（批量发现策略），勿与 `skills/ggs-sales-enrichment/references/countries/`（单家调研策略）或 `skills/ggs-sales-outreach/countries/`（触达模板）混淆。
    - 必须包含"事实审计表 (Data Provenance Table)"。
    - 否则视为任务失败。
---

# Leads Finder 工作流

本 Skill 通过外部 Web 发现 + CRM 判重，为销售提供新线索批量发现能力。**CRM 读操作仅限两类：crm-dedup 判重 + 参照搜索场景的 crm-search 解析锚点**；浏览 CRM 列表/记录本身仍归 ggs-sales-crm-tools。

---

## 核心工作准则 (Golden Rules)

1. **本地化优先**:执行搜索前,必须先将关键词翻译为目标国家的官方语言。
2. **三位一体验证**:每条外部线索必须经过 [第三方平台发现] → [官网/社媒提取] → [官方工商数据校验] 的交叉验证。
3. **拒绝编造**:缺失字段必须标注 N/A,严禁基于常识猜测联系方式或注册号。
4. **语言镜像**:所有面向用户的输出必须使用**用户输入的语言**作答。搜索关键词可使用目标国语言,但呈现给用户的内容语言须与输入一致。
5. **Tool Contract 为准**:工具的可执行行为以实际 CLI 参数为准,不得凭流程文档假设不存在的能力。
6. **时间戳必须程序化转换**:CRM 返回的所有 10 位 Unix 时间戳,在向用户呈现或进行时间判断(如"是否本月"、"多少天前")时,**必须使用程序化工具转换,禁止心算**。命令示例:`date -r <timestamp>` 或 `python3 -c "from datetime import datetime; print(datetime.fromtimestamp(<timestamp>))"`。
7. **Source Attribution**:每条 lead 的每个事实(公司名、税号、联系方式、行业、地址、出口判断)按 `prompt.md <source_attribution>` 内部 tag 来源——`[CRM: lead_id=xxx]` / `[source: URL]` / `[skill: ggs-sales-leads-finder.inferred]` / `[unverified]` 等。事实审计表(Data Provenance Table)即为本规则的对外呈现,见 Phase 8。

---

## 文件引用与加载时机

| 文件 | 加载时机       | 用途 |
|------|------------|------|
| references/countries/{country_code}.md | Phase 2 国家路由后 | 该国专属数据源、字段规范、CRM 写回字段规范、用户输出规范、crm-dedup payload |
| references/scoring.md | Phase 8 打分时 | 打分与排序规则 |
| references/platform-sop.md | Phase 4-5 执行跨国平台抓取时 | Google Maps、LinkedIn、Facebook 等通用平台 SOP |
| references/auth-guidance.md | Phase 4 执行前（涉及需登录平台时） | 平台授权与登录引导 |


工具调用前可使用命令查询参数详细说明:
> ```bash
> ggs-crm show-docs <tool_name>
> ```

---

## 调用规则（任何 ggs-crm CLI 调用前必读）

> ⚠️ **本文档示例只展示调用方式和最常见参数，不是完整 contract**。
> 调用任何 ggs-crm 工具前**必须先查 show-docs**拿当前最权威的参数定义：
>
> ```bash
> ggs-crm show-docs <tool_name>
> ```
>
> 适用所有工具:`crm-roles` / `crm-dedup` / `crm-add` / `crm-refine` / `crm-pickup` / `crm-address` / `industry-mapping` / `google-map` 等。
>
> show-docs 返回的字段定义、必填性、参数互斥性是**权威**——本文档示例可能滞后于实际 CLI 版本。
>
> **失败处理：** 任何 ggs-crm 命令报错（unknown field / missing required / invalid value 等），**第一反应是 show-docs 拿当前权威 contract**，不要凭错误信息猜测改了重试。

---

## 环境与认证

环境准备(Python/pip/ggs-crm-cli 安装)、Token 认证流程、调用方式回退,参考 `prompt.md <crm_auth>`（含 Environment Prep 与 Authentication）,本文档不再重复。

> ⚠️ 本 skill 内部 CRM 调用直接走 ggs-crm-cli(按 `prompt.md <chained_execution>` 中的"自有领域内 → skill 自己处理"原则),**不切到 ggs-sales-crm-tools**。ggs-sales-crm-tools 只在用户明确表达 CRM 长尾意图(且没有 workflow 接住)时被触发。

---

## 主流程概览

```
Phase 0  触发与入口约束
Phase 1  意图理解与结构化
Phase 2  国家识别与 CRM Family 路由
Phase 3  CRM 上下文准备（角色/认证/缓存）
Phase 4  外部发现
Phase 5  补全与验证
Phase 6  判重与合并（crm-dedup）
Phase 7  写回准备
Phase 8  排序与用户输出
Phase 9  可选 CRM 写回
```

本 skill 的 CRM 读操作仅限 crm-dedup 判重和参照搜索场景的 crm-search（解析参照公司 ICP 锚点，见 Phase 1.1 / 1.5），加上可选 crm-pickup/crm-add/crm-refine 写回，完成新 leads 发现。

---

## Phase 0：触发与入口约束

读完本 SKILL.md 后立即进入意图理解。禁止先执行搜索。

---

## Phase 1：意图理解与结构化

### 1.1 查询类型前置判断

语义判断，非关键词匹配。本 skill 只处理 2 类查询：

**url-extract（URL 提取）**

用户直接给了一个 URL（多为列表页或公司主页）：
- 典型表达："看下 abc.vn 最新注册的公司"、"扒一下这个展会页 xxx"
- 处理：跳过数据源匹配，直接 web-scrape 或 web_fetch

**standard-search（常规搜索）**——默认

非 url-extract 的所有查询：
- 典型表达："找越南家具厂"、"找胡志明市的工厂"、"附近 10 公里的工厂"
- **含 reference-based（参照对象搜索）**："找和 @xxx 类似的"、"与我刚签单的类似的"——作为 standard-search 的前置解析步骤处理：在 Phase 1.5 内部调 `crm-search` 解析参照公司的 industry/city/出口属性，回填 `reference_resolved_industry` / `reference_resolved_city` 后按 standard-search 执行。参照公司在 CRM 中找不到或多条匹配 → 展示候选让用户选择或澄清 ICP

> ⚠️ **不应进入本 skill 的查询类型：**
> - **company research（单家深度调研）**："调研 xx 公司" → ggs-sales-enrichment
> - **CRM record inspection（CRM 记录查看）**："看下 xx 在 CRM 里" → ggs-sales-crm-tools

### 1.2 池子判断（Pool）

leads-finder 只处理"找新 leads"，pool 简化为 2 档：

| Pool | 触发信号 | 典型表达 |
|------|---------|---------|
| external-only | 用户直接提供 URL | "看下这个网站 xxx.vn 最新注册的公司" |
| public+external | 其他所有情况（默认） | "找越南家具厂"、"展会 leads"、"附近工厂" |

> ⚠️ **以下 pool 不再由 leads-finder 处理：**
> - **private**（"我的客户"、"分给我的"）→ ggs-sales-crm-tools
> - **public-only**（"最近放出来"、"公海里的"、"最近 inbound 的"）→ ggs-sales-crm-tools
>
> 这些查询都是看 CRM 内部已有数据，应由 crm-tools 接管。

### 1.3 澄清与 ICP 引导

**何时澄清：** 除非同时满足以下条件，否则走一次 ICP 引导：
- 有效过滤条件 >= 3 个
- 且覆盖行业 + 地区 + 至少一个质量/联系方式维度

**例外：** pool 为 external-only（用户直接给 URL）时不触发澄清。

**澄清方式：** 直接向用户展示已提取的信息并请求确认或补充。

**多客户选择：** 当用户意图针对单个客户但查询返回多条匹配时，展示列表让用户选择。

### 1.4 Intent Struct 构造

从用户输入提取原始意图。原则：只提取用户明确表达的内容，不猜测补充。

```json
{
  "raw_query": "原始用户输入",
  "query_type": "standard-search | url-extract",
  "pool": "external-only | public+external",
  "country": "VN",
  "industry_hint": "家具",
  "location_hint": "胡志明市",
  "location_city": null,
  "location_lat": null,
  "location_lng": null,
  "radius_km": null,
  "quality_hint": null,
  "time_hint": null,
  "contact_hint": null,
  "activity_hint": null,
  "exporter_hint": null,
  "b2b_hint": null,
  "reference_hint": null,
  "reference_resolved_industry": null,
  "reference_resolved_city": null,
  "direct_url": null,
  "company_name_hint": null,
  "email_hint": null,
  "extra_fields": [],
  "limit": 10
}
```

**内部使用：** Intent Struct 是流程内部的语义容器，供后续 Phase 消费，不需要向用户展示原始 JSON。澄清时以自然语言向用户确认搜索条件即可。

**`extra_fields`：** 用户额外要求输出的字段或偏好（如"顺便给出主要出口国 / ISO 认证 / 领英粉丝数"）。无预定义列——发现/补全阶段当作额外采集目标，Phase 8 输出时由 `scripts/leads-to-xlsx.py` 按采集顺序**动态追加为附加列**（见 country 文件 4.2 动态扩展）；不在基线列内的字段不再被丢弃。

### 1.5 信息增强（按需工具调用）

| 情况 | 工具               | 目的                                      | Fallback |
|------|------------------|-----------------------------------------|---------|
| 参照搜索（reference_hint 非空） | `crm-search`（参数先 `ggs-crm show-docs crm-search`） | 解析参照公司的行业、地区、address，回填 `reference_resolved_industry` / `reference_resolved_city` | CRM 未找到/多条匹配 → 让用户选择或澄清 ICP；无 address → Google Places 取坐标 |
| 用户输入精确地址文本 | 模型自行推断    | 使用`ggs-crm google-map`搜索时,可文字地址转坐标做精确搜索 | 无法解析 → 降级到城市级 |
| 国别推断兜底 | crm-roles 返回的账号上下文 | 取账号默认负责市场                               | — |
| 用户给 URL | 直接标记 direct_url  | —                                       | — |

**国别推断优先级：** 地区提及 > 输入语言 > 账号默认市场

> ⚠️ 参照搜索调 `crm-search` 前需要 Token 与角色（sales-id/org-id）——此时**提前执行 Phase 3**（与"Phase 2 无法识别国家时提前执行 Phase 3"同款机制），完成后回到本步骤解析参照对象。

---

## Phase 2：国家识别与 CRM Family 路由

1. 从 Intent Struct 识别 country
2. 若用户输入中**有明确国家信息**：
   - 根据 country 确定 crm_family：HK / TW → HKTW，其他 → Global
3. 若用户输入中**无国家信息**（如"帮我找公海客户"）：
   - **先执行 Phase 3**（获取 crm-roles），根据角色的组织信息判断 CRM Family
   - 若角色属于 HKTW 组织 → crm_family = HKTW，country 根据组织推断为 TW 或 HK
   - 若角色属于 Global 组织 → crm_family = Global，country 从账号默认市场推断
   - 若仍无法确定 → 向用户澄清
4. 加载 country strategy：references/countries/{country_code}.md（无则 default.md）

> 本 skill 写回时（crm-add / crm-refine）会用到 country 字段映射。参照搜索场景调 crm-search 时按 crm-tools 的 CRM Family 规则执行：Global CRM 查询条件**必须含 `country` 字段**，HKTW 不需要；字段白名单以 `ggs-crm show-docs crm-search-global-fields` / `crm-search-hktw-fields` 为准。

---

## Phase 3：CRM 上下文准备

**前置检查：** 执行 Phase 3 前,必须确认环境已就绪(详见 `prompt.md <crm_auth>` 的 Environment Prep)。

**执行条件：** 流程涉及 CRM 查询、判重或写回时。**当 Phase 2 无法从用户输入识别国家时，Phase 3 需提前执行以辅助路由。**

1. 验证 Token(按 `prompt.md <crm_auth>` 的 Authentication:CLI 自动读缓存,缺失/过期时 `ggs-crm sales-auth` 浏览器登录)
2. 调用 crm-roles 获取当前角色(参数详见 `ggs-crm show-docs crm-roles`)
   - 单角色 → 直接使用
   - 多角色 → 展示列表让用户选择
   - 空/失败 → 提示检查 token,中断流程
3. 缓存 sales-id 和 org-id 供后续使用
4. **CRM Family 反推(当 Phase 2 未确定 country 时):** 根据角色的组织名称/路径判断是否属于 HKTW 组织,若是则设定 crm_family = HKTW 并回填 country,然后回到 Phase 2 第 4 步加载对应文件

> 角色信息在会话中缓存一次。用户明确要求切换角色时重新调用。

---

## Phase 4：外部发现

**执行条件：** 所有 query_type 都执行（standard-search / url-extract）。

### 4.1 工具分层

| 工具 | 用途 | 何时用 |
|------|------|--------|
| `web_search` | 公开信息搜索 | 所有外部发现的第一步 |
| `web_fetch` | 已知 URL 取页面内容 | 有具体链接时 |
| `sessions_spawn` (`agent_id="browser"`) | 登录态页面访问 | Facebook Page、LinkedIn 等需登录平台；`web_fetch` 遇登录墙时升级 |
| `product_supplier_search` | 阿里巴巴供应商搜索 | 排除已入驻 Alibaba 的公司（已入驻 = 非目标客户） |
| `google-map`（ggs-crm） | 地理位置搜索 | 用户有坐标/地址/工业区意图时 |

### 4.2 执行逻辑

**A. direct_url 场景：** 跳过数据源匹配，直接 web_fetch（失败则 `sessions_spawn` browser）。

**B. 地图类场景（有经纬度，工具参数详见 `ggs-crm show-docs google-map`）：**
```bash
ggs-crm google-map \
  --latitude {lat} --longitude {lng} --radius {radius_m} \
  -c {country} --company-type "{industry_hint}"
```

**C. 标准外部搜索：**
1. 读当前 countries/{country_code}.md Part 1 数据源策略
2. 按用户意图匹配数据源类型（工厂/出口商/展会/协会/工业园区等）
3. 执行本地化关键词翻译（目标国语言 + 英语并发）
4. 并发 2-3 条不同搜索取结果并集去重

**D. 需登录平台时：** 优先 `sessions_spawn` with `agent_id="browser"` 访问。遇 CAPTCHA → 停止该平台，告知用户，降级到 `web_search` 取摘要。

**产出：** external discovery results

**无结果处理：** 直接展示空状态，不放宽条件。

---

## Phase 5：补全与验证

**执行条件：** Phase 4 产出了 external discovery results。

**核心原则：** 补全 = 发现 + 验证 + 保留证据，不是填满空字段。

### 5.1 流程骨架

对每条外部记录按以下顺序执行，已有字段跳过：

```
① 工商库查询 → ② 社媒查询 → ③ 官网爬取 → ④ Web Search 兜底 → ⑤ LLM 推断
```

### 5.2 具体规则由 Country 文件控制

每一步"去哪个网站、用什么关键词、怎么验证、何时阻断"由当前 `references/countries/{country_code}.md` Part 1 数据源策略 + Part 2 字段规范控制。

> ⚠️ **leads-finder 的补全是批量场景，主要做"清洗 + 校验"**：按字段校验规则（手机号开头、固话识别、税号格式等）格式化已采集数据；具体字段从哪个数据源采集的细粒度策略由各国 Part 1 数据源映射约定。
>
> 单家深度调研场景的字段补全细则（每个字段的多源回退策略、跨字段的 Cascade 规则）参见 `ggs-sales-enrichment` 国家文件 Part 1。

### 5.3 通用操作 SOP

跨国平台操作步骤见 references/platform-sop.md。

### 5.4 LLM 推断

基于前序步骤采集内容做推断：

**行业映射：** 自然语言 → 行业 ID（使用 `ggs-crm industry-mapping`）

**是否出口（is_exporter）：**
- confirmed：明确提到海外客户、出口业务、FOB/CIF 等
- inferred：官网有英文版、参加国际展会、产品含国际认证
- unknown：信息不足

**是否 B2B（is_b2b）：** Yes / No / Unknown

> 中间字段（industry_raw / activity_signals / export_signals）不对外输出。

**产出：** enriched results

---

## Phase 6：判重与合并

**执行条件：** 存在 external 结果需要与 CRM 判重。

### 6.1 去重主键

读当前 countries/{country_code}.md Part 2.1 的去重主键优先级。

### 6.2 CRM 判重

对外部数据调用 crm-dedup。`check_params` 可用字段见 `ggs-crm show-docs crm-dedup`，各国 dedup payload 字段映射见 country 文件 Part 5。

构造 `check_params` 时：`companyName` + `country` 必填；`registerNumber` 优先填入（如 country 文件要求且已获取）；`email` 有则填入。

```bash
ggs-crm crm-dedup \
  -t {token} --sales-id {sales_id} --org-id {org_id} \
  -p '[{"uid":"1","companyName":"ABC Corp","country":"VN","email":"<EMAIL_PLACEHOLDER>"}]'
```

### 6.3 判重结果处理

`crm-dedup` 返回的 `deduplicationStatus` 与 `pool` 字段共同决定处理方式（返回字段详见 `ggs-crm show-docs crm-dedup`）：

| `deduplicationStatus` | 返回 `pool` | 含义 | 处理 | 后续动作 |
|----------------------|------------|------|------|---------|
| `not_repeat` | — | CRM 中不存在 | ✅ 保留 | 可 crm-add 新增 |
| `public_repeat` | `public` | 公海重复 | ✅ 保留 | 可 crm-pickup 捡入 |
| `channel_repeat` | `public` | 渠道公海重复 | ✅ 保留 | 可 crm-pickup 捡入 |
| `depot_repeat` | `private` | 私海重复（已有归属销售） | ❌ 移除 | — |
| `manager_repeat` | — | 经理库重复 | ✅ 保留 | 标记来源，提示用户需联系经理 |

**关键映射说明：**
- `not_repeat` = 全新线索，走 Phase 7 的 crm-add 路径
- `public_repeat` / `channel_repeat` = 公海可捡入，走 Phase 7 的 crm-pickup → crm-refine 路径
- `depot_repeat` = 已在他人私海，直接移除不展示
- `manager_repeat` = 经理库中的客户，保留展示但提示用户需通过经理操作

### 6.4 结果合并

- 外部在公海有对应记录 → 以公海记录为主体，用 enriched 字段补充 null
- 外部多源返回同一公司 → 合并为一条，字段取并集
- 多源返回组内重复 → 去重保留一条

**产出：** merged/deduped results

---

## Phase 7：写回准备

**执行条件：** 存在需写回的结果。

### 7.1 pickup（crm-pickup → crm-refine）vs add（crm-add）分流

- **crm-pickup → crm-refine**：dedup 结果为 `public_repeat` / `channel_repeat`（在公海），有可确认的 `globalId`。先 pickup 捡入，再 refine 补全。（工具参数详见 `ggs-crm show-docs crm-pickup` `ggs-crm show-docs crm-refine`）
- **crm-add**：dedup 结果为 `not_repeat`，无 `globalId`，直接新增。（工具参数详见 `ggs-crm show-docs crm-add`）

> **⚠️ 国家/地区必填项差异：** 不同国家和地区的 crm-add / crm-refine 必填字段存在差异（如税号格式、地址层级、行业分类等），详见各 country 文件 Part 3 CRM 写回字段规范。执行 crm-add 前，参数详见 `ggs-crm show-docs crm-add`，确认所有国家特定的必填字段已齐全，否则阻断写回并告知用户具体缺失字段。

### 7.2 写回映射与校验

按 country 文件 Part 3 的字段规范 + `ggs-crm show-docs crm-refine` 执行字段映射和必填性校验。写回前须满足所有必填字段，否则阻断并告知用户缺失原因。

**产出：** CRM payload candidates 或明确 blocked reason

---

## Phase 8：排序与用户输出

### 8.1 打分与排序

读 references/scoring.md 执行。

- 外部数据：意图匹配分 * 0.6 + 数据质量分 * 0.4 = 综合分
- 排序：综合分降序；同分按置信度降序

截取前 limit 条。

### 8.2 输出格式

最终产出：xlsx 文件 + Markdown 预览 + Data Provenance Table

**⚠ 强制：xlsx 唯一合法生成方式 = 调用 `scripts/leads-to-xlsx.py`。**
- **禁止**自行用 openpyxl / pandas / csv / 手写表头等任何方式拼 xlsx——只有脚本能保证 21 列基线、`crm_status` 合并、动态追加、防编造校验生效。
- **禁止**把 CRM 原始字段名（`global_id` / `busi_reg_number` / `crm_comp_name` / `tax_code` 等）直接当表头。所有字段必须先按 country 文件 Part 4.2 的键名归一到统一 schema（如 `tax_id` / `company_name_en` / `key_person_name`），再交给脚本。
- **禁止**为同一信息开多个同义列（多个公司名列 / 多个税号列）——同义信息合并到对应的单一 baseline 键。
- 脚本自带防编造前置校验（行号自增 / 连续序列 / 占位模板 / 无效号码 → 置 N/A）；自行拼表会**绕过**此校验，等于放行编造数据。

**xlsx：**
- 由 `scripts/leads-to-xlsx.py` 生成（输入 JSON 数组，输出 xlsx）
- 列结构：21 列基线（floor，可动态追加），定义见 country 文件 Part 4.2
- 所有字段写为文本（避免 Excel 把税号 / 电话当数字处理）
- 含逗号的字段（如 "Co., Ltd."）作为完整单元格写入，不拆分

**调用方式（任务目录隔离，防跨会话错引）：**

> ⚠️ 工作空间跨会话共享。本次任务的所有过程产物**必须**写入本任务专属目录，**禁止**用固定文件名写工作空间根目录或裸 /tmp。
> 任务标识 `{icp-slug}`：从 Intent Struct 提炼的短横线小写 slug，**不含国家代码**（国家统一由命名中的 `{country}` 段承担，避免 `vn-vn-` 式重复），如 `furniture-factory`、`cosmetics-exporter`。整个任务内保持同一个值。

```bash
# 1. 创建本任务专属目录（只创建一次，后续步骤复用）
TASK_DIR=leads-{country}-{icp-slug}-{YYYYMMDD-HHMM}
mkdir -p $TASK_DIR

# 2. 把当前批次结果写入本任务目录下的 JSON
cat > $TASK_DIR/leads-batch.json << 'EOF'
[ {<lead 1>}, {<lead 2>}, ... ]
EOF

# 3. 调脚本生成 xlsx——结果产物文件名同样带 {icp-slug}
python3 <SKILL_DIR>/scripts/leads-to-xlsx.py \
  --input $TASK_DIR/leads-batch.json \
  --output $TASK_DIR/leads-{country}-{icp-slug}-{YYYYMMDD-HHMM}.xlsx
```

国家代码可省略，脚本会从第一条记录的 `country` 字段推断。引用产物时一律走 `$TASK_DIR` 内路径；工作空间里其他目录的同名文件属于别的任务，**不读取、不复用**。

**上传：** 调用 storage 工具把 xlsx 写入 OSS，拿下载链接附在 Markdown 预览下方。

**Markdown 预览：** 前 3-5 条 + xlsx 下载链接。预览字段定义见当前 countries/{country_code}.md Part 4.1。用户在 `extra_fields` 里额外要求的字段，按 Part 4.1 的动态扩展规则追加到预览表末（与 xlsx 一致），不只落 xlsx。

**PII 字段处理：** 所有 lead 邮箱/手机号按数据源返回值**原样展示，不做任何额外打码/脱敏/隐藏**——Phase 4 web 发现的外部数据如此，Phase 6 dedup 命中已有客户时 CRM 返回的字段也如此（返回什么展示什么，合规处理由数据源/CRM 服务端负责）。

**Data Provenance Table（强制）：**

| 事实点 | 声明内容 | 验证来源 | 验证状态 |
|:---|:---|:---|:---|
| 企业在营状态 | [结果] | [URL/Tool] | Verified / Not Found |
| 税号/注册号 | [结果] | [官方系统] | Verified / Not Found |
| 核心联系方式 | [结果] | [来源路径] | Verified / Not Found |

**快速操作建议（按 Phase 6.3 的 `deduplicationStatus`）：**
- `not_repeat` → 建议导入 CRM（crm-add）
- `public_repeat` / `channel_repeat` → 可直接跟进或捡入（crm-pickup）
- `manager_repeat` → 提示需联系经理操作

完整输出要求（缺失填 N/A、Phone 国际格式、CRM Detail 列规则等）见当前 country 文件 Part 4.3。

---

## Phase 9：可选 CRM 写回

**执行条件：** 用户明确要求导入/补全/捡入，且 Phase 7 已准备好 payload。

### 9.1 写回执行

| 动作 | 工具 | 前提 |
|------|------|------|
| 捡入公海客户 | crm-pickup | 有 globalId + pool=public |
| 补全已有客户 | crm-refine | 捡入成功后，有 globalId + 必填字段齐全 |
| 新增客户 | crm-add | 判重 NEW + 必填字段齐全 |

写回前须确认：payload 符合 `ggs-crm show-docs crm-pickup` `ggs-crm show-docs crm-refine` `ggs-crm show-docs crm-add` 工具 contract、分流已明确、必填字段齐全（含 country 文件 Part 3 的条件必填）、地址字段已通过 `crm-address` 转码。任一条件不满足 → 停止，告知用户原因。

---

## 异常处理

| 异常场景 | 处理方式 |
|---------|---------|
| Token 验证失败 / 401 | 按 `prompt.md <crm_auth>` 重跑 `ggs-crm sales-auth` 获取新 Token |
| crm-roles 返回空 | 提示检查 token，中断流程 |
| sessions_spawn (browser) 不可用 | 降级为 web_search + web_fetch + ggs-crm CLI；FB/LinkedIn 走搜索摘要 |
| CAPTCHA / 强制登录墙 | 立即停止该平台，告知用户并附截图，降级或跳过 |
| 主数据源访问失败 | 按 country 文件 Fallback 策略处理 |
| storage 上传失败 | 如实告知用户 |
| crm-pickup/add 失败 | 展示错误信息，不重试，等用户指示 |
