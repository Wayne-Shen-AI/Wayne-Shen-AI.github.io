# Prompt: description-copy

Generates the description-banner taglines and feature-strip labels.

## description-banner

Two short lines over a banner image (Phase 4 variant 04_scene or category-typical factory image).

- `BANNER_TAGLINE_1` — 6–10 words, the customer's promise (e.g. "12 Years Manufacturing Vietnamese Distribution Boards")
- `BANNER_TAGLINE_2` — 8–14 words, supporting detail (e.g. "TCVN-certified · IP65 · Compatible with Schneider, ABB, Siemens MCB modules")

## feature-strip — 4 fixed icons

Defaults if the product/category does not strongly suggest otherwise:

- `FEATURE_1_LABEL` — "FOB Available" or "FOB {origin port}"
- `FEATURE_2_LABEL` — "OEM/ODM"
- `FEATURE_3_LABEL` — "<24h Response"
- `FEATURE_4_LABEL` — "Trade Assurance"

For **electrical / electronics** categories, swap `FEATURE_3` for "IEC / CE Compliant" if vision saw such marks.

For **apparel / consumer goods**, swap `FEATURE_4` for "Sample Available".

## Description-detail captions (per detail-image-block)

For each Phase 4 variant 03–09, generate ONE caption ≤14 words:

| Variant | Caption pattern |
|---------|----------------|
| 03_detail | "Close-up: {feature observed in macro shot}" |
| 04_scene | "In use: {use scenario}" |
| 05_multiangle | "Multi-angle view: front / 45° / top" |
| 06_packaging | "Export packaging: {carton / pallet info}" |
| 07_certifications | "Certifications: {cert list}" |
| 08_size_compare | "Dimensions: {WxHxD} cm" |
| 09_lifestyle | "Application: {industry}" |

## Voice

Second-person customer-facing where natural ("Built for your distribution panels"), but for spec-heavy text use neutral product-descriptor voice. Never first-person sales voice ("we recommend", "our pitch").
