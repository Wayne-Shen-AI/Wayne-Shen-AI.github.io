# Prompt: attribute-table

Generates the 15–20 row product specs table for `components/attribute-table.html`.

## When invoked

For fields the user did not provide in `inputs.provided.specs`. Merge user dict with this output, with user values winning on conflicts.

## Required attribute keys (always included if known)

| Key | Source priority | Common values |
|-----|----------------|---------------|
| Brand | user > "OEM" | – |
| Model Number | user > inferred from photo | – |
| Place of Origin | user > inferred origin city + country | – |
| Material | user > vision.likely_material | – |
| Color | user > vision.color_options_visible (joined) | – |
| Application | user > vision.product_kind context | – |
| Certification | user > vision.ip_or_cert_marks_visible | CE, RoHS, ISO 9001, TCVN, IEC |
| Warranty | user > "12 months" / "24 months" | – |
| Packaging Details | user > inferred from product size | – |

## Category-specific extra rows

For **Electrical Equipment** (HS 8536/8544/9405):
- Voltage, Frequency, Current rating, IP Rating, Number of poles/ways, Standard

For **Vehicles & Accessories**:
- Vehicle Compatibility (e.g. Honda Wave 110/125), OE Number, Mounting Type, Surface Finish

For **Construction Materials**:
- Dimensions, Thickness, Tolerance, Compressive Strength, Standard

## Output format

Pre-rendered HTML rows ready to drop into `{{ATTR_ROWS_HTML}}`:

```html
<tr><td>Brand</td><td>OEM</td><td>Model Number</td><td>DC-3P-24W</td></tr>
<tr><td>Place of Origin</td><td>Ho Chi Minh, Vietnam</td><td>Material</td><td>1.2mm cold-rolled steel</td></tr>
...
```

15–20 rows, two `key|value` pairs per row (4 cells per `<tr>`).

## Estimated tagging

Each row sourced from vision must have value cell suffixed with `<span class="estimated-tag">(estimated)</span>`. User-provided rows do not get the tag.
