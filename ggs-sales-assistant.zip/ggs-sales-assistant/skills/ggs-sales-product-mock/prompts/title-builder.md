# Prompt: title-builder

Generates an Alibaba.com-style product title (8–15 keyword-stuffed words, no full sentences).

## When invoked

Only when `inputs.provided.title` is null. If the user gave a title, use it verbatim.

## Title formula

`[Variant/Spec]` + `[Core Product Noun]` + `[Material/Standard]` + `[Use Case]` + `[OEM/ODM hint]`

## Examples

| Product kind | Generated title |
|--------------|------------------|
| 3-phase distribution board | `3 Phase 24-way Distribution Board, IP65 Steel Cabinet, MCB-ready, IEC 60439-3 — OEM Vietnam Manufacturer` |
| motorcycle front fairing | `Motorcycle Front Fairing for Honda Wave 110/125, ABS Plastic, Custom Color, Vietnam OEM Supplier` |
| LED panel light 600x600 | `LED Panel Light 600x600 36W, Slim Recessed Ceiling, 4000K/6500K, Office Commercial, OEM Available` |

## Rules

1. **8–15 words**, separated by spaces and commas.
2. **No marketing adjectives** like "best", "super", "premium" alone — pair with concrete spec.
3. **Capitalize Each Word** (Title Case).
4. **No emojis, no exclamation marks**.
5. **Include at least one of**: voltage / dimensions / standard / certification / material.
6. **Include OEM/ODM hint** at end if appropriate ("OEM Available", "Vietnam Manufacturer", "Custom Logo").

## Output

A single string. Cache to `<workdir>/inferred.json` as `title`. Tag rendered output with `(estimated)`.
