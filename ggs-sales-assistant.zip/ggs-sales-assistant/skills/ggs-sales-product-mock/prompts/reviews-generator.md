# Prompt: reviews-generator

Generates 3–5 mock buyer reviews for `components/reviews.html`. Reviews are illustrative ("here is what your future Alibaba reviews could read like") — must NOT be presented as real reviews of this seller.

## Source country mix

Pick 3–5 countries from the user's likely target export markets:
- If `inputs.provided.target_markets` exists → use those
- Else use category-typical: Indonesia, Philippines, Cambodia, Mexico, USA, Germany

## Review-item template

```html
<div class="review-item">
  <div class="review-head">
    <span class="reviewer-flag">{{FLAG_EMOJI}}</span>
    <strong>{{BUYER_NAME}}</strong>
    <span style="color:#6b7280">— {{BUYER_CITY}}, {{BUYER_COUNTRY}}</span>
    <span class="review-stars">★★★★★</span>
    <span style="color:#6b7280">· {{ORDER_QTY}} units · verified buyer</span>
  </div>
  <div class="review-text">"{{REVIEW_TEXT}}"</div>
</div>
```

## Distribution row template (5 bars)

```html
<div class="review-dist-row"><span>5★</span><div class="review-dist-bar"><div class="fill" style="width:{{P5}}%"></div></div><span>{{N5}}</span></div>
<div class="review-dist-row"><span>4★</span><div class="review-dist-bar"><div class="fill" style="width:{{P4}}%"></div></div><span>{{N4}}</span></div>
<div class="review-dist-row"><span>3★</span><div class="review-dist-bar"><div class="fill" style="width:{{P3}}%"></div></div><span>{{N3}}</span></div>
<div class="review-dist-row"><span>2★</span><div class="review-dist-bar"><div class="fill" style="width:{{P2}}%"></div></div><span>{{N2}}</span></div>
<div class="review-dist-row"><span>1★</span><div class="review-dist-bar"><div class="fill" style="width:{{P1}}%"></div></div><span>{{N1}}</span></div>
```

## Review text rules

1. **First-time / repeat / quality / lead-time** — cover one angle each.
2. **Mention concrete numbers** (order qty, lead-time days, %).
3. **At least one review mentions Trade Assurance** (the platform's escrow).
4. **One slightly-negative-but-recovered review** ("lead time was 22 days vs promised 18 — minor delay. Already placed second order.") — adds credibility.
5. Length 18–35 words each, plain English.

## Estimated tagging

Add a small disclaimer below the review list:
`<p class="estimated-tag" style="margin-top:14px">Reviews shown are illustrative previews, not actual reviews on this seller's account.</p>`
