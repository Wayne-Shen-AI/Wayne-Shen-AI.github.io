# Prompt: extract-product-info

Used in **Phase 2** when the user did NOT supply product info. Reads the cleanest cutout image (Phase 3 output) and infers fields.

## When invoked

Only for `inputs.provided.*` fields that are `null`. NEVER overwrite a user-supplied value.

## Vision instruction (give to image-capable model)

```
You are looking at a single product photo with its background already removed (white background).
Identify the product and output strict JSON with these keys:

{
  "product_kind": "<short noun phrase, e.g. '3-phase distribution board' / 'motorcycle front fairing'>",
  "category_l1": "<top-level Alibaba category, e.g. 'Construction & Real Estate'>",
  "category_l2": "<sub-category, e.g. 'Electrical Equipment'>",
  "category_l3": "<leaf category, e.g. 'Distribution Boxes'>",
  "key_features_visible": ["<3-6 short noun phrases observed in the photo>"],
  "likely_material": "<one phrase, e.g. 'cold-rolled steel, powder coated'>",
  "estimated_dimensions_cm": {"w": null, "h": null, "d": null},
  "estimated_weight_kg": null,
  "color_options_visible": ["<list>"],
  "ip_or_cert_marks_visible": ["<list>"]
}

Rules:
- If a field is not inferable from the photo, set it to null. NEVER guess from training data.
- Keep "product_kind" 2–5 words, no marketing adjectives.
- "category_l1/l2/l3" must use real Alibaba.com category names. Common L1s: Construction & Real Estate, Industrial Machinery, Vehicles & Accessories, Apparel, Home & Garden, Consumer Electronics, Tools & Hardware.
```

## Post-processing

- Cache the JSON to `<workdir>/inferred.json`.
- Pass downstream to title-builder, attribute-table, description-copy.
- All values from this JSON must be tagged `(estimated)` in the rendered output.
