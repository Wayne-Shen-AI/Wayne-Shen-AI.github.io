#!/usr/bin/env python3
"""Hero image relight — Pillow only, NO AI.

Why Pillow (not image_edit)?
The hero shot is a tight, zoomed view of the customer's product. Any AI
re-generation will sooner or later misspell the printed text on the body
("COOLING" → "COGLING" etc.). Pillow only modifies pixel values (brightness /
contrast / white balance / shadow), so the customer's branding stays 100%
faithful.

Usage:
    python relight_hero.py --in workdir/cutouts/IMG_xxx_alpha.png \
                           --out workdir/variants/01_white.png

Tunable knobs (all optional, sensible defaults):
    --brightness 1.18    # 1.0 = no change; > 1 brighter
    --contrast   1.08
    --warm       1.04    # R multiplier (> 1 warms image)
    --green      1.02    # G multiplier
    --cool       0.985   # B multiplier (< 1 reduces blue cast)
    --sharpness  1.15
    --shadow     0.25    # 0..1 ground-shadow opacity
    --blur       12      # shadow blur radius in px
    --shift      14      # shadow offset downward, px

Hard cap: brightness <= 1.3 (above that highlights blow out).
"""
import argparse
import os
import sys

try:
    from PIL import Image, ImageEnhance, ImageFilter, ImageChops
except ImportError:
    sys.exit("Missing dependency: Pillow. Install with: pip install pillow")


def relight(
    src_path: str,
    out_path: str,
    brightness: float = 1.18,
    contrast: float = 1.08,
    warm: float = 1.04,
    green: float = 1.02,
    cool: float = 0.985,
    sharpness: float = 1.15,
    shadow_opacity: float = 0.25,
    shadow_blur: int = 12,
    shadow_shift: int = 14,
):
    if brightness > 1.3:
        print(f"[warn] brightness {brightness} > 1.3 — clamping to 1.3 to avoid blown highlights")
        brightness = 1.3

    img = Image.open(src_path).convert("RGBA")
    W, H = img.size
    r, g, b, a = img.split()

    rgb = Image.merge("RGB", (r, g, b))
    rgb = ImageEnhance.Brightness(rgb).enhance(brightness)
    rgb = ImageEnhance.Contrast(rgb).enhance(contrast)

    # white balance
    r2, g2, b2 = rgb.split()
    r2 = r2.point(lambda x: min(255, int(x * warm)))
    g2 = g2.point(lambda x: min(255, int(x * green)))
    b2 = b2.point(lambda x: min(255, int(x * cool)))
    rgb = Image.merge("RGB", (r2, g2, b2))

    rgb = ImageEnhance.Sharpness(rgb).enhance(sharpness)
    relit = Image.merge("RGBA", (*rgb.split(), a))

    # Canvas + drop shadow
    canvas = Image.new("RGBA", (W, H), (255, 255, 255, 255))

    shadow_alpha = a.point(lambda x: int(x * shadow_opacity))
    shadow_layer = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    shadow_layer.putalpha(shadow_alpha)
    shadow_layer = shadow_layer.filter(ImageFilter.GaussianBlur(radius=shadow_blur))
    shadow_layer = ImageChops.offset(shadow_layer, 0, shadow_shift)

    canvas.alpha_composite(shadow_layer)
    canvas.alpha_composite(relit)

    canvas.convert("RGB").save(out_path, "PNG", optimize=True)
    size_kb = os.path.getsize(out_path) // 1024
    print(f"OK  → {out_path}  ({size_kb} KB)")
    print(f"     brightness={brightness}  contrast={contrast}  WB=({warm},{green},{cool})  "
          f"sharp={sharpness}  shadow=({shadow_opacity},blur{shadow_blur},shift{shadow_shift})")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--in", dest="src", required=True, help="cutout alpha PNG from remove_bg.py")
    ap.add_argument("--out", dest="out", required=True, help="output PNG (e.g. workdir/variants/01_white.png)")
    ap.add_argument("--brightness", type=float, default=1.18)
    ap.add_argument("--contrast", type=float, default=1.08)
    ap.add_argument("--warm", type=float, default=1.04)
    ap.add_argument("--green", type=float, default=1.02)
    ap.add_argument("--cool", type=float, default=0.985)
    ap.add_argument("--sharpness", type=float, default=1.15)
    ap.add_argument("--shadow", type=float, default=0.25, dest="shadow_opacity")
    ap.add_argument("--blur", type=int, default=12, dest="shadow_blur")
    ap.add_argument("--shift", type=int, default=14, dest="shadow_shift")
    args = ap.parse_args()

    os.makedirs(os.path.dirname(os.path.abspath(args.out)), exist_ok=True)
    relight(
        args.src, args.out,
        brightness=args.brightness, contrast=args.contrast,
        warm=args.warm, green=args.green, cool=args.cool,
        sharpness=args.sharpness,
        shadow_opacity=args.shadow_opacity,
        shadow_blur=args.shadow_blur,
        shadow_shift=args.shadow_shift,
    )


if __name__ == "__main__":
    main()
