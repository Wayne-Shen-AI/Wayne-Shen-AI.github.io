#!/usr/bin/env python3
"""Background removal wrapper.

Usage:
    python remove_bg.py --input path1.jpg path2.jpg --out workdir/cutouts/

Each input → 2 outputs:
    <stem>_alpha.png   transparent background, antialiased
    <stem>_white.png   composited on white #FFFFFF with soft contact shadow

Hard rule: NEVER fall back to the raw photo if rembg returns an empty mask.
Exit non-zero on any failure so the agent surfaces it instead of silently
embedding a non-cut-out image.
"""
import argparse, sys, pathlib

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", nargs="+", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--model", default="isnet-general-use",
                    help="rembg model: isnet-general-use (default) | u2net | birefnet-general")
    args = ap.parse_args()

    try:
        from rembg import remove, new_session
        from PIL import Image, ImageFilter
        import io
    except ImportError as e:
        sys.stderr.write(
            f"Missing dependency: {e}\n"
            "Install with:\n"
            "  pip3 install rembg pillow onnxruntime -i https://pypi.org/simple\n"
        )
        sys.exit(2)

    out_dir = pathlib.Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)

    session = new_session(args.model)

    failures = []
    for in_path in args.input:
        p = pathlib.Path(in_path)
        if not p.exists():
            failures.append((in_path, "file not found"))
            continue

        try:
            with open(p, "rb") as f:
                raw = f.read()
            cut = remove(raw, session=session)
            alpha = Image.open(io.BytesIO(cut)).convert("RGBA")

            # Validate mask is non-empty
            alpha_channel = alpha.getchannel("A")
            non_zero = sum(1 for px in alpha_channel.getdata() if px > 8)
            if non_zero < (alpha.width * alpha.height) * 0.01:
                failures.append((in_path, "empty mask — model could not isolate subject"))
                continue

            stem = p.stem
            alpha_out = out_dir / f"{stem}_alpha.png"
            white_out = out_dir / f"{stem}_white.png"
            alpha.save(alpha_out, "PNG")

            # White-bg composite with soft contact shadow
            w, h = alpha.size
            shadow = Image.new("RGBA", (w, h), (0, 0, 0, 0))
            shadow.paste((0, 0, 0, 60), mask=alpha_channel)
            shadow = shadow.filter(ImageFilter.GaussianBlur(radius=12))
            white = Image.new("RGB", (w, h), (255, 255, 255))
            white.paste(shadow.convert("RGB"), mask=shadow.split()[-1])
            white.paste(alpha.convert("RGB"), mask=alpha_channel)
            white.save(white_out, "PNG", quality=95)

            print(f"OK  {p.name} → {alpha_out.name}, {white_out.name}")
        except Exception as e:
            failures.append((in_path, str(e)))

    if failures:
        sys.stderr.write("\nFAILURES (do NOT fall back to raw photo):\n")
        for f, reason in failures:
            sys.stderr.write(f"  - {f}: {reason}\n")
        sys.stderr.write(
            "\nAsk the user to re-upload these photos with cleaner backgrounds, "
            "or try --model birefnet-general for trickier images.\n"
        )
        sys.exit(1)

    print(f"\nAll {len(args.input)} photo(s) cut successfully → {out_dir}")

if __name__ == "__main__":
    main()
