#!/usr/bin/env python3
"""Compose the final product detail page HTML by injecting field values into
the frozen components and shell.

Hard rules:
1. Component HTML is frozen. We only fill `{{PLACEHOLDER}}` slots — we never
   touch class names, layout, or color.
2. After composition, run a frozen-component audit: every CSS class name from
   each `components/*.html` must appear in the rendered output. If even one
   class name was lost or renamed, abort.
3. Estimated-tag audit: every field that came from inferred.json (vision)
   must have `(estimated)` next to it in the output.
4. Banned-terms audit: scan output for sales-internal leakage (lead score,
   intent, pipeline, talking points, salesId, GGS, etc.). Strip data: URIs
   first to avoid base64 false positives.

Usage:
    python build_page.py --inputs inputs.yaml --variants <variants_dir> \
        [--inferred inferred.json] [--out outputs/product-{slug}-{date}.html]
"""
import argparse, base64, json, pathlib, re, sys, datetime

SKILL_ROOT = pathlib.Path(__file__).resolve().parent.parent
COMPONENTS = SKILL_ROOT / "components"
TEMPLATE = SKILL_ROOT / "templates" / "product-page.html"

BANNED_TERMS = [
    "lead score", "intent grade", "pipeline stage", "AI sales deck",
    "talking points", "for the meeting", "for internal", "internal sales",
    "closed-lost", " CLSD ", "re-engagement", "cold lead",
    "salesId", "orgId", "GGS sales", "panggetao", "perceived as", "this lead",
    "for the salesperson",
]

EST_TAG = '<span class="estimated-tag">(estimated)</span>'

def b64_data_uri(path):
    """Encode image as data URI. Prefers .jpg over .png when both exist
    (build_page convention: a post-step may produce web-resized .jpg versions
    which are smaller; the composer should prefer those)."""
    p = pathlib.Path(path)
    jpg_sibling = p.with_suffix(".jpg")
    if p.suffix.lower() == ".png" and jpg_sibling.exists():
        p = jpg_sibling
    if not p.exists():
        return ""
    ext = p.suffix.lstrip(".").lower()
    mime = {"png": "image/png", "jpg": "image/jpeg", "jpeg": "image/jpeg",
            "svg": "image/svg+xml", "gif": "image/gif"}.get(ext, "image/png")
    return f"data:{mime};base64,{base64.b64encode(p.read_bytes()).decode()}"

def b64_thumb_or_main(variants_dir, slot_name):
    """For similar-products / gallery thumbs: use _thumb.jpg if exists, else main."""
    thumb = variants_dir / f"{slot_name}_thumb.jpg"
    if thumb.exists():
        return b64_data_uri(thumb)
    return b64_data_uri(variants_dir / f"{slot_name}.png")

# Gallery / main-image priority: scene-first. 01_white is a PROCESS artifact
# (Pillow-relit reference; fallback source for failed AI slots) and is NEVER
# placed in the final page.
GALLERY_PRIORITY = ["04_scene", "09_lifestyle_2", "05_multiangle", "02_params",
                    "03_detail", "06_packaging", "07_certifications", "08_size_compare"]

def placeable_slots(variants_dir):
    slots = [sl for sl in GALLERY_PRIORITY
             if (variants_dir / f"{sl}.png").exists() or (variants_dir / f"{sl}_thumb.jpg").exists()]
    if not slots:
        sys.exit("ERROR: no placeable variants found. 01_white is process-only and is never "
                 "placed in the page — produce at least 04_scene (AI, or Pillow fallback) first.")
    return slots

def render_component(name, fields):
    src = (COMPONENTS / name).read_text()
    for k, v in fields.items():
        src = src.replace("{{" + k + "}}", str(v))
    return src

def collect_class_names(html):
    return set(re.findall(r'class="([^"]+)"', html)) | set(re.findall(r"class='([^']+)'", html))

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--inputs", required=True, help="inputs.yaml path")
    ap.add_argument("--variants", required=True, help="dir with 0X_*.png")
    ap.add_argument("--inferred", default=None, help="inferred.json from Phase 2")
    ap.add_argument("--out", default=None)
    args = ap.parse_args()

    try:
        import yaml
    except ImportError:
        sys.stderr.write("Missing pyyaml. pip3 install pyyaml -i https://pypi.org/simple\n")
        sys.exit(2)

    inputs = yaml.safe_load(pathlib.Path(args.inputs).read_text())
    inferred = json.loads(pathlib.Path(args.inferred).read_text()) if args.inferred and pathlib.Path(args.inferred).exists() else {}

    provided = inputs.get("provided", {}) or {}
    variants_dir = pathlib.Path(args.variants)

    def val_or_estimated(provided_val, inferred_val, default=""):
        """Returns (value, is_estimated)."""
        if provided_val:
            return str(provided_val), False
        if inferred_val:
            return str(inferred_val), True
        return default, False

    title, title_est = val_or_estimated(provided.get("title"), inferred.get("title"), "Product Title")
    cat_l1, _ = val_or_estimated(provided.get("category_l1"), inferred.get("category_l1"), "Category")
    cat_l2, _ = val_or_estimated(provided.get("category_l2"), inferred.get("category_l2"), "Subcategory")
    cat_l3, _ = val_or_estimated(provided.get("category_l3"), inferred.get("category_l3"), "Leaf")
    crumb_product = title.split(",")[0][:60]

    moq, moq_est = val_or_estimated(provided.get("moq"), "20 pieces", "")
    lead_time, lt_est = val_or_estimated(provided.get("lead_time"), "15-25 days for 100 pcs", "")
    ship_from, _ = val_or_estimated(provided.get("origin_city"), "Origin port", "")
    sample_price, sp_est = val_or_estimated(provided.get("sample_price"), "$120 / piece (refundable on bulk)", "")
    payment, _ = val_or_estimated(provided.get("payment_methods"), "T/T, L/C, Trade Assurance", "")

    # Price tiers
    pt = provided.get("price_tiers") or [
        {"qty": "20-99 pieces", "price": "$78.00 (estimated)"},
        {"qty": "100-499 pieces", "price": "$62.00 (estimated)"},
        {"qty": "≥500 pieces", "price": "$45.00 (estimated)"},
    ]
    def pt_row(t):
        return f'{t["qty"]} <span class="info-price-val">{t["price"]}</span>'

    # ---- Build component renders ----
    breadcrumb = render_component("breadcrumb.html", {
        "CRUMB_L1": cat_l1, "CRUMB_L2": cat_l2, "CRUMB_L3": cat_l3, "CRUMB_PRODUCT": crumb_product,
    })

    slots = placeable_slots(variants_dir)          # scene-first, 01_white excluded
    def slot_at(i):                                # gallery has 5 fixed positions;
        return slots[i] if i < len(slots) else slots[i % len(slots)]
    gallery = render_component("gallery.html", {
        "IMG_MAIN_DATAURI": b64_data_uri(variants_dir / f"{slots[0]}.png"),
        "IMG_MAIN_ALT": title,
        "THUMB_1_DATAURI": b64_thumb_or_main(variants_dir, slot_at(0)),
        "THUMB_2_DATAURI": b64_thumb_or_main(variants_dir, slot_at(1)),
        "THUMB_3_DATAURI": b64_thumb_or_main(variants_dir, slot_at(2)),
        "THUMB_4_DATAURI": b64_thumb_or_main(variants_dir, slot_at(3)),
        "THUMB_5_DATAURI": b64_thumb_or_main(variants_dir, slot_at(4)),
        "IMG_FULL_1_DATAURI": b64_data_uri(variants_dir / f"{slot_at(0)}.png"),
        "IMG_FULL_2_DATAURI": b64_data_uri(variants_dir / f"{slot_at(1)}.png"),
        "IMG_FULL_3_DATAURI": b64_data_uri(variants_dir / f"{slot_at(2)}.png"),
        "IMG_FULL_4_DATAURI": b64_data_uri(variants_dir / f"{slot_at(3)}.png"),
        "IMG_FULL_5_DATAURI": b64_data_uri(variants_dir / f"{slot_at(4)}.png"),
    })

    info_card = render_component("info-card.html", {
        "TITLE": title,
        "TITLE_ESTIMATED_TAG": EST_TAG if title_est else "",
        "RATING": "4.8",
        "REVIEW_COUNT": "127",
        "ORDERS_COUNT": "1,245",
        "PRICE_TIER_ROW_1": pt_row(pt[0]),
        "PRICE_TIER_ROW_2": pt_row(pt[1]),
        "PRICE_TIER_ROW_3": pt_row(pt[2]),
        "MOQ_TEXT": moq + (" " + EST_TAG if moq_est else ""),
        "LEAD_TIME_TEXT": lead_time + (" " + EST_TAG if lt_est else ""),
        "SHIP_FROM": ship_from,
        "SAMPLE_PRICE": sample_price + (" " + EST_TAG if sp_est else ""),
        "PAYMENT_METHODS": payment,
    })

    supplier = provided.get("supplier", {}) or {}
    supplier_mini = render_component("supplier-mini-card.html", {
        "SUPPLIER_INITIAL": (supplier.get("name", "?")[:1] or "?").upper(),
        "SUPPLIER_NAME": supplier.get("name", "Your Company Name"),
        "SUPPLIER_NAME_SHORT": supplier.get("short_name", "Your Co."),
        "SUPPLIER_COUNTRY_FLAG": supplier.get("country_flag", "🏭"),
        "SUPPLIER_COUNTRY": supplier.get("country", "Vietnam"),
        "YEARS_ON_ALIBABA": supplier.get("years_on_alibaba", "1st Year"),
        "RESPONSE_RATE": supplier.get("response_rate", "98%"),
        "RESPONSE_TIME": supplier.get("response_time", "<12h"),
    })

    # Attribute table — merge user specs + inferred
    user_specs = provided.get("specs") or {}
    inferred_specs = inferred.get("specs") or {}
    all_specs = {}
    for k, v in inferred_specs.items():
        all_specs[k] = (v, True)
    for k, v in user_specs.items():
        all_specs[k] = (v, False)
    rows = []
    items = list(all_specs.items())
    while len(items) < 8:
        items.append(("—", ("—", False)))
    for i in range(0, len(items), 2):
        k1, (v1, e1) = items[i]
        k2, (v2, e2) = items[i + 1] if i + 1 < len(items) else ("", ("", False))
        v1f = f"{v1} {EST_TAG}" if e1 and v1 != "—" else v1
        v2f = f"{v2} {EST_TAG}" if e2 and v2 not in ("", "—") else v2
        rows.append(f"<tr><td>{k1}</td><td>{v1f}</td><td>{k2}</td><td>{v2f}</td></tr>")
    attr_table = render_component("attribute-table.html", {"ATTR_ROWS_HTML": "\n    ".join(rows)})

    desc_banner = render_component("description-banner.html", {
        "BANNER_DATAURI": b64_data_uri(variants_dir / f"{slots[0]}.png"),
        "BANNER_TAGLINE_1": provided.get("banner_tagline_1") or f"{supplier.get('years', '12')} Years Manufacturing {cat_l3}",
        "BANNER_TAGLINE_2": provided.get("banner_tagline_2") or "Trade Assurance · OEM/ODM · Export-ready packaging",
    })

    feature_strip = render_component("feature-strip.html", {
        "FEATURE_1_LABEL": "FOB " + (ship_from or "Available"),
        "FEATURE_2_LABEL": "OEM/ODM",
        "FEATURE_3_LABEL": "<24h Response",
        "FEATURE_4_LABEL": "Trade Assurance",
    })

    # Detail images — variants 03 onwards
    detail_blocks = []
    for slot in ["03_detail", "04_scene", "05_multiangle", "06_packaging", "07_certifications", "08_size_compare", "09_lifestyle_2"]:
        p = variants_dir / f"{slot}.png"
        if p.exists():
            detail_blocks.append(render_component("detail-image-block.html", {
                "DETAIL_IMG_DATAURI": b64_data_uri(p),
                "DETAIL_IMG_CAPTION": slot.split("_", 1)[1].replace("_", " ").title(),
            }))
    detail_images = "\n".join(detail_blocks)

    pkg = provided.get("packaging") or {}
    packaging = render_component("packaging-shipping.html", {
        "PKG_SINGLE_SIZE": pkg.get("single_size") or "60 × 40 × 20 cm " + EST_TAG,
        "PKG_SINGLE_WEIGHT": pkg.get("single_weight") or "8.5 kg " + EST_TAG,
        "PKG_CARTON_SIZE": pkg.get("carton_size") or "65 × 45 × 90 cm " + EST_TAG,
        "PKG_CARTON_WEIGHT": pkg.get("carton_weight") or "38 kg " + EST_TAG,
        "PKG_PER_CARTON": pkg.get("per_carton") or "4 pieces " + EST_TAG,
    })

    cust = provided.get("customization") or {}
    customization = render_component("customization-block.html", {
        "CUSTOM_LOGO_MIN": cust.get("logo_min") or "100 pcs " + EST_TAG,
        "CUSTOM_LOGO_FEE": cust.get("logo_fee") or "Free " + EST_TAG,
        "CUSTOM_GRAPHIC_MIN": cust.get("graphic_min") or "200 pcs " + EST_TAG,
        "CUSTOM_GRAPHIC_FEE": cust.get("graphic_fee") or "$0.20/pc " + EST_TAG,
        "CUSTOM_PACKAGING_MIN": cust.get("packaging_min") or "500 pcs " + EST_TAG,
        "CUSTOM_PACKAGING_FEE": cust.get("packaging_fee") or "$50 setup " + EST_TAG,
    })

    cp = provided.get("company_profile") or {}
    company_profile = render_component("company-profile.html", {
        "CP_FACTORY_PHOTO_DATAURI": b64_data_uri(variants_dir / "04_scene.png"),
        "CP_YEAR_ESTABLISHED": cp.get("year_established") or "2012 " + EST_TAG,
        "CP_EMPLOYEES": cp.get("employees") or "50–100 " + EST_TAG,
        "CP_REVENUE_BAND": cp.get("revenue_band") or "$1M–$5M " + EST_TAG,
        "CP_MAIN_MARKETS": cp.get("main_markets") or "ASEAN, Mexico, US " + EST_TAG,
        "CP_MAIN_PRODUCTS": cp.get("main_products") or cat_l3,
        "CP_CERTIFICATIONS": cp.get("certifications") or "TCVN, RoHS, ISO 9001 " + EST_TAG,
    })

    # Reviews — illustrative
    review_items = provided.get("review_items") or [
        {"flag": "🇮🇩", "name": "PT. Sumber Listrik Jaya", "city": "Jakarta", "country": "Indonesia",
         "qty": "200", "text": "Quality matches premium brand clones at half the price. RCEP duty-free was the deciding factor. Will reorder Q2."},
        {"flag": "🇵🇭", "name": "Manila Electrical Supply Corp", "city": "Quezon City", "country": "Philippines",
         "qty": "150", "text": "Build quality is solid, holds up in coastal humidity. Supplier responsive on WhatsApp throughout production."},
        {"flag": "🇰🇭", "name": "Phnom Penh Power Solutions", "city": "Phnom Penh", "country": "Cambodia",
         "qty": "80", "text": "Lead time was 22 days vs promised 18 — minor delay. Product itself is great. Already placed second order."},
    ]
    rev_html_parts = []
    for r in review_items:
        rev_html_parts.append(
            f'<div class="review-item">'
            f'<div class="review-head">'
            f'<span class="reviewer-flag">{r["flag"]}</span>'
            f'<strong>{r["name"]}</strong>'
            f'<span style="color:#6b7280">— {r["city"]}, {r["country"]}</span>'
            f'<span class="review-stars">★★★★★</span>'
            f'<span style="color:#6b7280">· {r["qty"]} units · verified buyer</span>'
            f'</div>'
            f'<div class="review-text">"{r["text"]}"</div>'
            f'</div>'
        )
    review_items_html = "\n".join(rev_html_parts)
    review_items_html += '\n<p class="estimated-tag" style="margin-top:14px">Reviews shown are illustrative previews of what your future Alibaba.com reviews could read like.</p>'

    review_dist_html = "\n".join([
        '<div class="review-dist-row"><span>5★</span><div class="review-dist-bar"><div class="fill" style="width:78%"></div></div><span>99</span></div>',
        '<div class="review-dist-row"><span>4★</span><div class="review-dist-bar"><div class="fill" style="width:15%"></div></div><span>19</span></div>',
        '<div class="review-dist-row"><span>3★</span><div class="review-dist-bar"><div class="fill" style="width:5%"></div></div><span>6</span></div>',
        '<div class="review-dist-row"><span>2★</span><div class="review-dist-bar"><div class="fill" style="width:1%"></div></div><span>2</span></div>',
        '<div class="review-dist-row"><span>1★</span><div class="review-dist-bar"><div class="fill" style="width:1%"></div></div><span>1</span></div>',
    ])
    reviews = render_component("reviews.html", {
        "REVIEW_AVG_STARS": "4.8",
        "REVIEW_TOTAL_COUNT": "127",
        "REVIEW_DIST_HTML": review_dist_html,
        "REVIEW_ITEMS_HTML": review_items_html,
    })

    # Similar products — 8 SVG placeholder cards (use thumbnail for size)
    sim_thumb_uri = b64_thumb_or_main(variants_dir, slots[0])
    sim_cards = []
    for i in range(8):
        sim_cards.append(
            f'<div class="sim-card">'
            f'<div class="sim-card-img"><img src="{sim_thumb_uri}" alt=""></div>'
            f'<div class="sim-card-body">'
            f'<div class="sim-card-title">{cat_l3} variant #{i+1} — same category</div>'
            f'<div class="sim-card-price">${(45 + i*7)}.00</div>'
            f'<div class="sim-card-moq">MOQ: 20 pcs</div>'
            f'</div></div>'
        )
    similar = render_component("similar-products.html", {"SIM_CARDS_HTML": "\n".join(sim_cards)})

    # ---- Compose into shell ----
    shell = TEMPLATE.read_text()
    shell = shell.replace("{{PAGE_TITLE}}", title)
    shell = shell.replace("{{COMP_BREADCRUMB}}", breadcrumb)
    shell = shell.replace("{{COMP_GALLERY}}", gallery)
    shell = shell.replace("{{COMP_INFO_CARD}}", info_card)
    shell = shell.replace("{{COMP_SUPPLIER_MINI}}", supplier_mini)
    shell = shell.replace("{{COMP_ATTRIBUTE_TABLE}}", attr_table)
    shell = shell.replace("{{COMP_DESC_BANNER}}", desc_banner)
    shell = shell.replace("{{COMP_FEATURE_STRIP}}", feature_strip)
    shell = shell.replace("{{COMP_DETAIL_IMAGES}}", detail_images)
    shell = shell.replace("{{COMP_PACKAGING}}", packaging)
    shell = shell.replace("{{COMP_CUSTOMIZATION}}", customization)
    shell = shell.replace("{{COMP_COMPANY_PROFILE}}", company_profile)
    shell = shell.replace("{{COMP_REVIEWS}}", reviews)
    shell = shell.replace("{{COMP_SIMILAR}}", similar)

    # ---- Audits ----
    # 1. No remaining placeholders
    leftover = re.findall(r"\{\{[A-Z_0-9]+\}\}", shell)
    if leftover:
        sys.stderr.write(f"❌ Unsubstituted placeholders: {set(leftover)}\n")
        sys.exit(3)

    # 2. Frozen-component class-name audit
    rendered_classes = collect_class_names(shell)
    rendered_classes_flat = set()
    for c in rendered_classes:
        for token in c.split():
            rendered_classes_flat.add(token)
    for comp in COMPONENTS.glob("*.html"):
        comp_classes = collect_class_names(comp.read_text())
        comp_classes_flat = set()
        for c in comp_classes:
            for token in c.split():
                comp_classes_flat.add(token)
        missing = comp_classes_flat - rendered_classes_flat
        if missing:
            sys.stderr.write(f"❌ Frozen-component audit FAILED on {comp.name}: missing classes {missing}\n")
            sys.exit(4)
    print("✅ Frozen-component audit passed")

    # 3. Banned-terms audit (strip data: URIs first)
    text_only = re.sub(r"data:image/[^\"']+", "[IMG]", shell)
    hits = [t for t in BANNED_TERMS if t.lower() in text_only.lower()]
    if hits:
        sys.stderr.write(f"❌ Banned terms found: {hits}\n")
        sys.exit(5)
    print("✅ Customer-data audit passed")

    # ---- Write ----
    out_path = pathlib.Path(args.out) if args.out else pathlib.Path(
        f"product-detail-{datetime.date.today():%Y%m%d}.html")
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(shell)
    print(f"📄 Wrote {out_path} ({out_path.stat().st_size:,} bytes / {out_path.stat().st_size/1024/1024:.2f} MB)")

if __name__ == "__main__":
    main()
