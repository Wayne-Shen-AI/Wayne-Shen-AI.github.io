#!/usr/bin/env python3
"""PIL composers for Alibaba.com-style product layout images.

Reference targets (matched to Accio Work output style):
- 360° PRODUCT VIEW: 2x2 angle grid + title bar
- CRAFTSMANSHIP DETAILS: center cutout + 4 dark callouts + orange leader lines
- SPEC CARD: brand title + cutout + 3 spec icons + flag/factory-direct badges

Hard rules:
- Never let AI render text. All text comes from PIL.ImageDraw with bundled fonts.
- Cutouts (white-bg images) are the only image asset; everything else is composed.
- Output 1080x1080 PNG suitable for an Alibaba detail-page tile.

Usage as a library:
    from compose_layouts import (
        compose_multiangle_grid,
        compose_callout_overlay,
        compose_spec_card,
    )
"""
import pathlib
from PIL import Image, ImageDraw, ImageFont, ImageFilter, ImageOps

ALIBABA_ORANGE = (255, 106, 0)
ALIBABA_ORANGE_DARK = (255, 68, 0)
DARK_PANEL = (22, 28, 38)
LIGHT_BG = (245, 247, 250)
TEXT_DARK = (26, 26, 26)
TEXT_MUTED = (107, 114, 128)
SHADOW_GREY = (200, 205, 215)


# ---- Font loading ----------------------------------------------------------

def load_font(size, bold=False):
    candidates = [
        ("/System/Library/Fonts/Supplemental/Arial Bold.ttf" if bold
         else "/System/Library/Fonts/Supplemental/Arial.ttf"),
        ("/System/Library/Fonts/Helvetica.ttc"),
        ("/Library/Fonts/Arial.ttf"),
        ("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf" if bold
         else "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"),
    ]
    for c in candidates:
        try:
            return ImageFont.truetype(c, size)
        except OSError:
            pass
    return ImageFont.load_default()


# ---- Helpers ---------------------------------------------------------------

def open_white_cutout(path):
    """Load a rembg `_white.png` and return RGB image trimmed of excess border."""
    img = Image.open(path).convert("RGB")
    # Trim near-white margins
    bbox = ImageOps.invert(img.convert("L")).getbbox()
    if bbox:
        # Add 4% padding
        w, h = img.size
        pad = int(min(w, h) * 0.04)
        x0 = max(bbox[0] - pad, 0)
        y0 = max(bbox[1] - pad, 0)
        x1 = min(bbox[2] + pad, w)
        y1 = min(bbox[3] + pad, h)
        img = img.crop((x0, y0, x1, y1))
    return img


def fit_into(img, target_w, target_h, bg=(255, 255, 255)):
    """Letterbox-fit img into target dimensions on a white background."""
    canvas = Image.new("RGB", (target_w, target_h), bg)
    cp = img.copy()
    cp.thumbnail((target_w, target_h), Image.LANCZOS)
    x = (target_w - cp.width) // 2
    y = (target_h - cp.height) // 2
    canvas.paste(cp, (x, y))
    return canvas


def draw_text_centered(draw, xy, text, font, fill):
    bbox = draw.textbbox((0, 0), text, font=font)
    tw = bbox[2] - bbox[0]
    th = bbox[3] - bbox[1]
    draw.text((xy[0] - tw // 2, xy[1] - th // 2), text, font=font, fill=fill)


def draw_text_left(draw, xy, text, font, fill):
    draw.text(xy, text, font=font, fill=fill)


def draw_rounded_pill(draw, xy0, xy1, fill, radius=14):
    draw.rounded_rectangle([xy0, xy1], radius=radius, fill=fill)


# =====================================================================
# Layout 1 — 360° MULTI-ANGLE GRID
# =====================================================================

def compose_multiangle_grid(cutout_paths, out_path, title="360° PRODUCT VIEW",
                            subtitle="Multiple Angles",
                            angle_labels=("45° View", "Side View", "45° View", "Top View"),
                            size=1080):
    """4-cell 2x2 grid. If <4 cutouts provided, generate by mirror/rotate."""
    canvas = Image.new("RGB", (size, size), (255, 255, 255))
    draw = ImageDraw.Draw(canvas)

    # Title bar
    title_h = int(size * 0.13)
    draw.rectangle([0, 0, size, title_h], fill=(255, 255, 255))
    title_font = load_font(int(size * 0.052), bold=True)
    sub_font = load_font(int(size * 0.024), bold=False)
    draw_text_centered(draw, (size // 2, int(title_h * 0.42)), title, title_font, ALIBABA_ORANGE_DARK)
    draw_text_centered(draw, (size // 2, int(title_h * 0.78)), subtitle, sub_font, TEXT_MUTED)
    # Underline accent
    accent_w = int(size * 0.08)
    draw.rectangle([(size - accent_w) // 2, title_h - 3, (size + accent_w) // 2, title_h], fill=ALIBABA_ORANGE)

    # Build 4 angle images
    base = open_white_cutout(cutout_paths[0])
    angles = [base]
    if len(cutout_paths) > 1:
        angles.append(open_white_cutout(cutout_paths[1]))
    else:
        angles.append(base.transpose(Image.FLIP_LEFT_RIGHT))
    # Slot 3: vertical mirror
    angles.append(angles[0].transpose(Image.FLIP_TOP_BOTTOM)
                  if False else  # vertical mirror looks weird for products on the floor
                  angles[1].transpose(Image.FLIP_LEFT_RIGHT))
    # Slot 4: rotated 30° to suggest top-down — fall back to base if rotation looks bad
    rot = base.rotate(-25, resample=Image.BICUBIC, expand=True, fillcolor=(255, 255, 255))
    angles.append(rot)

    # 2x2 grid layout
    cell_pad = int(size * 0.025)
    grid_top = title_h + cell_pad
    cell_w = (size - cell_pad * 3) // 2
    cell_h = (size - grid_top - cell_pad * 2) // 2

    positions = [
        (cell_pad, grid_top),
        (cell_pad * 2 + cell_w, grid_top),
        (cell_pad, grid_top + cell_h + cell_pad),
        (cell_pad * 2 + cell_w, grid_top + cell_h + cell_pad),
    ]

    label_h = int(cell_h * 0.13)
    img_area_h = cell_h - label_h

    for (x, y), ang_img, label in zip(positions, angles[:4], angle_labels):
        # Cell background — light grey panel with subtle shadow
        shadow = Image.new("RGBA", (cell_w + 16, cell_h + 16), (0, 0, 0, 0))
        sd = ImageDraw.Draw(shadow)
        sd.rounded_rectangle([8, 8, cell_w + 8, cell_h + 8], radius=14, fill=(0, 0, 0, 22))
        shadow = shadow.filter(ImageFilter.GaussianBlur(radius=7))
        canvas.paste(shadow, (x - 8, y - 8), shadow)
        draw.rounded_rectangle([x, y, x + cell_w, y + cell_h], radius=14, fill=LIGHT_BG)

        # Cutout fitted into the cell image area
        fitted = fit_into(ang_img, int(cell_w * 0.84), int(img_area_h * 0.88), bg=LIGHT_BG)
        canvas.paste(fitted, (x + (cell_w - fitted.width) // 2, y + (img_area_h - fitted.height) // 2))

        # Label band at bottom of cell
        draw.rounded_rectangle([x, y + cell_h - label_h, x + cell_w, y + cell_h],
                               radius=14, fill=(255, 255, 255))
        # Re-fill the top half of the band so the bottom corners stay rounded only
        draw.rectangle([x, y + cell_h - label_h, x + cell_w, y + cell_h - label_h + label_h // 2],
                       fill=(255, 255, 255))
        label_font = load_font(int(cell_h * 0.075), bold=True)
        draw_text_centered(draw, (x + cell_w // 2, y + cell_h - label_h // 2),
                           label, label_font, TEXT_DARK)

    canvas.save(out_path, "PNG", quality=95)
    return out_path


# =====================================================================
# Layout 2 — CRAFTSMANSHIP DETAILS (callouts)
# =====================================================================

def compose_callout_overlay(cutout_path, out_path,
                            title="CRAFTSMANSHIP DETAILS",
                            subtitle="Every detail engineered for durability",
                            callouts=None, size=1080):
    """Center cutout with 4 dark callouts at corners + orange leader lines.

    callouts = [
        {"label": "Premium Welding", "pos": "tl"},
        {"label": "Shock Absorber Spring", "pos": "tr"},
        {"label": "KM Brand Cap", "pos": "bl"},
        {"label": "Precision Mounting Holes", "pos": "br"},
    ]
    """
    if callouts is None:
        callouts = [
            {"label": "Premium Material", "pos": "tl"},
            {"label": "Reinforced Joints", "pos": "tr"},
            {"label": "Brand Stamp", "pos": "bl"},
            {"label": "Precision Tolerances", "pos": "br"},
        ]

    canvas = Image.new("RGB", (size, size), (255, 255, 255))
    draw = ImageDraw.Draw(canvas)

    # Title bar
    title_h = int(size * 0.12)
    title_font = load_font(int(size * 0.052), bold=True)
    sub_font = load_font(int(size * 0.022), bold=False)
    draw_text_centered(draw, (size // 2, int(title_h * 0.42)), title, title_font, ALIBABA_ORANGE_DARK)
    draw_text_centered(draw, (size // 2, int(title_h * 0.78)), subtitle, sub_font, TEXT_MUTED)
    accent_w = int(size * 0.08)
    draw.rectangle([(size - accent_w) // 2, title_h - 3, (size + accent_w) // 2, title_h], fill=ALIBABA_ORANGE)

    # Center cutout
    base = open_white_cutout(cutout_path)
    target_w = int(size * 0.55)
    target_h = int(size * 0.55)
    fitted = fit_into(base, target_w, target_h, bg=(255, 255, 255))
    cx = size // 2 - fitted.width // 2
    cy = title_h + (size - title_h - fitted.height) // 2
    canvas.paste(fitted, (cx, cy))
    product_box = (cx, cy, cx + fitted.width, cy + fitted.height)

    # Callout boxes at corners
    cb_w = int(size * 0.26)
    cb_h = int(size * 0.10)
    margin = int(size * 0.025)
    positions = {
        "tl": (margin, title_h + margin),
        "tr": (size - cb_w - margin, title_h + margin),
        "bl": (margin, size - cb_h - margin),
        "br": (size - cb_w - margin, size - cb_h - margin),
    }
    label_font = load_font(int(size * 0.022), bold=True)

    for c in callouts:
        x, y = positions[c["pos"]]
        # Dark rounded panel
        draw.rounded_rectangle([x, y, x + cb_w, y + cb_h], radius=10, fill=DARK_PANEL)
        # Orange accent dot/bar on the inner edge
        if c["pos"] in ("tl", "bl"):
            draw.rectangle([x, y + 8, x + 4, y + cb_h - 8], fill=ALIBABA_ORANGE)
            text_x = x + 14
        else:
            draw.rectangle([x + cb_w - 4, y + 8, x + cb_w, y + cb_h - 8], fill=ALIBABA_ORANGE)
            text_x = x + 12
        # Wrap label across 2 lines if needed
        words = c["label"].split()
        lines = []
        cur = ""
        for w in words:
            test = (cur + " " + w).strip()
            tb = draw.textbbox((0, 0), test, font=label_font)
            if tb[2] - tb[0] > cb_w - 28:
                if cur:
                    lines.append(cur)
                cur = w
            else:
                cur = test
        if cur:
            lines.append(cur)
        line_h = int(label_font.size * 1.2)
        total_h = line_h * len(lines)
        ty = y + (cb_h - total_h) // 2
        for ln in lines:
            draw.text((text_x, ty), ln, font=label_font, fill=(255, 255, 255))
            ty += line_h

        # Leader line from callout edge to product centre (orange)
        if c["pos"] == "tl":
            line_start = (x + cb_w, y + cb_h // 2)
            line_end = (product_box[0] + int((product_box[2] - product_box[0]) * 0.15),
                        product_box[1] + int((product_box[3] - product_box[1]) * 0.18))
        elif c["pos"] == "tr":
            line_start = (x, y + cb_h // 2)
            line_end = (product_box[2] - int((product_box[2] - product_box[0]) * 0.15),
                        product_box[1] + int((product_box[3] - product_box[1]) * 0.18))
        elif c["pos"] == "bl":
            line_start = (x + cb_w, y + cb_h // 2)
            line_end = (product_box[0] + int((product_box[2] - product_box[0]) * 0.18),
                        product_box[3] - int((product_box[3] - product_box[1]) * 0.15))
        else:  # br
            line_start = (x, y + cb_h // 2)
            line_end = (product_box[2] - int((product_box[2] - product_box[0]) * 0.18),
                        product_box[3] - int((product_box[3] - product_box[1]) * 0.15))
        draw.line([line_start, line_end], fill=ALIBABA_ORANGE, width=3)
        # Endpoint dot on the product
        r = 8
        draw.ellipse([line_end[0] - r, line_end[1] - r, line_end[0] + r, line_end[1] + r],
                     fill=ALIBABA_ORANGE)
        draw.ellipse([line_end[0] - r + 3, line_end[1] - r + 3,
                      line_end[0] + r - 3, line_end[1] + r - 3],
                     fill=(255, 255, 255))

    canvas.save(out_path, "PNG", quality=95)
    return out_path


# =====================================================================
# Layout 3 — SPEC CARD
# =====================================================================

# Painted country flags (avoids emoji-font rendering failures on macOS Arial)
def paint_country_flag(canvas, draw, x, y, w, h, country_code):
    """Paint a small national flag at (x,y) with given dimensions."""
    cc = country_code.upper()
    if cc == "VN":
        # Red field + central 5-point yellow star
        draw.rectangle([x, y, x + w, y + h], fill=(218, 37, 29))
        cx, cy = x + w // 2, y + h // 2
        r = int(min(w, h) * 0.34)
        # Approximate 5-point star with polygon
        import math
        points = []
        for i in range(10):
            angle = -math.pi / 2 + i * math.pi / 5
            radius = r if i % 2 == 0 else r * 0.42
            points.append((cx + radius * math.cos(angle),
                           cy + radius * math.sin(angle)))
        draw.polygon(points, fill=(255, 204, 0))
    elif cc == "CN":
        draw.rectangle([x, y, x + w, y + h], fill=(218, 37, 29))
        # large yellow star top-left + 4 small ones (simplified: just one)
        cx, cy = x + int(w * 0.30), y + int(h * 0.36)
        r = int(min(w, h) * 0.24)
        import math
        points = []
        for i in range(10):
            a = -math.pi / 2 + i * math.pi / 5
            rd = r if i % 2 == 0 else r * 0.42
            points.append((cx + rd * math.cos(a), cy + rd * math.sin(a)))
        draw.polygon(points, fill=(255, 204, 0))
    elif cc == "ID":
        draw.rectangle([x, y, x + w, y + h // 2], fill=(206, 17, 38))
        draw.rectangle([x, y + h // 2, x + w, y + h], fill=(255, 255, 255))
    elif cc == "TH":
        bands = [(165, 25, 49), (255, 255, 255), (45, 41, 99), (255, 255, 255), (165, 25, 49)]
        bh = h / 5
        for i, color in enumerate(bands):
            draw.rectangle([x, y + int(bh * i), x + w, y + int(bh * (i + 1))], fill=color)
    elif cc == "PH":
        # Blue top, red bottom, white triangle on left
        draw.rectangle([x, y, x + w, y + h // 2], fill=(0, 56, 168))
        draw.rectangle([x, y + h // 2, x + w, y + h], fill=(206, 17, 38))
        draw.polygon([(x, y), (x + int(w * 0.5), y + h // 2), (x, y + h)], fill=(255, 255, 255))
    elif cc == "MY":
        # Simplified — alternating red/white stripes + blue canton
        sh = h / 14
        for i in range(14):
            color = (204, 0, 1) if i % 2 == 0 else (255, 255, 255)
            draw.rectangle([x, y + int(sh * i), x + w, y + int(sh * (i + 1))], fill=color)
        draw.rectangle([x, y, x + int(w * 0.5), y + int(h * 0.5)], fill=(0, 0, 102))
    elif cc == "MX":
        # Vertical green/white/red
        cw = w / 3
        draw.rectangle([x, y, x + int(cw), y + h], fill=(0, 104, 71))
        draw.rectangle([x + int(cw), y, x + int(cw * 2), y + h], fill=(255, 255, 255))
        draw.rectangle([x + int(cw * 2), y, x + w, y + h], fill=(206, 17, 38))
    elif cc == "DE":
        bh = h / 3
        for i, color in enumerate([(0, 0, 0), (221, 0, 0), (255, 206, 0)]):
            draw.rectangle([x, y + int(bh * i), x + w, y + int(bh * (i + 1))], fill=color)
    elif cc == "US":
        # 13 stripes + simplified blue canton
        sh = h / 13
        for i in range(13):
            color = (191, 13, 62) if i % 2 == 0 else (255, 255, 255)
            draw.rectangle([x, y + int(sh * i), x + w, y + int(sh * (i + 1))], fill=color)
        draw.rectangle([x, y, x + int(w * 0.4), y + int(h * 7 / 13)], fill=(0, 33, 71))
    else:
        # Generic: dark grey with country code
        draw.rectangle([x, y, x + w, y + h], fill=(80, 80, 80))


def compose_spec_card(cutout_path, out_path,
                      product_name, tagline,
                      specs,            # list of {"label", "value", "icon"}
                      origin_country="Vietnam",
                      origin_country_code="VN",
                      factory_direct=True,
                      size=1080):
    """Branded spec card matching Accio Work spec-card layout (image 5)."""
    canvas = Image.new("RGB", (size, size), (255, 255, 255))
    draw = ImageDraw.Draw(canvas)

    # Top dark band with product name + tagline
    band_h = int(size * 0.18)
    draw.rectangle([0, 0, size, band_h], fill=DARK_PANEL)
    name_font = load_font(int(size * 0.040), bold=True)
    tag_font = load_font(int(size * 0.022), bold=False)
    name_lines = wrap_text(draw, product_name, name_font, size - int(size * 0.10))
    nx = int(size * 0.05)
    ny = int(band_h * 0.20)
    for ln in name_lines[:2]:
        draw.text((nx, ny), ln, font=name_font, fill=(255, 255, 255))
        ny += int(name_font.size * 1.15)
    draw.text((nx, ny + int(size * 0.005)), tagline, font=tag_font, fill=(255, 178, 130))

    # Layout: cutout on the LEFT (45% width), spec column on the RIGHT (40% width)
    # so they never overlap.
    cutout_area_w = int(size * 0.42)
    cutout_area_x0 = int(size * 0.04)
    cutout_area_y0 = band_h + int(size * 0.06)
    cutout_area_h = size - cutout_area_y0 - int(size * 0.13)  # leave room for badges
    base = open_white_cutout(cutout_path)
    fitted = fit_into(base, cutout_area_w, cutout_area_h, bg=(255, 255, 255))
    canvas.paste(fitted, (cutout_area_x0 + (cutout_area_w - fitted.width) // 2,
                          cutout_area_y0 + (cutout_area_h - fitted.height) // 2))

    # Right-side spec column
    spec_x = int(size * 0.52)
    spec_w = size - spec_x - int(size * 0.04)        # 44% of width — plenty
    spec_h = int(size * 0.13)
    gap = int(size * 0.022)
    spec_total = len(specs[:3]) * spec_h + (len(specs[:3]) - 1) * gap
    spec_y_start = band_h + ((size - band_h - int(size * 0.13) - spec_total) // 2)

    label_font = load_font(int(size * 0.018), bold=True)
    val_font = load_font(int(size * 0.024), bold=True)

    for i, spec in enumerate(specs[:3]):
        sy = spec_y_start + i * (spec_h + gap)
        draw.rounded_rectangle([spec_x, sy, spec_x + spec_w, sy + spec_h],
                               radius=12, fill=LIGHT_BG)
        # Icon box on left
        icon_box = int(spec_h * 0.55)
        ix = spec_x + int(spec_h * 0.18)
        iy = sy + (spec_h - icon_box) // 2
        draw.rounded_rectangle([ix, iy, ix + icon_box, iy + icon_box],
                               radius=8, fill=ALIBABA_ORANGE)
        glyph_font = load_font(int(icon_box * 0.6), bold=True)
        glyph = spec.get("icon", "•")
        draw_text_centered(draw, (ix + icon_box // 2, iy + icon_box // 2),
                           glyph, glyph_font, (255, 255, 255))

        # Label + value column. Limit to spec_w - icon_box - paddings.
        tx = ix + icon_box + int(spec_h * 0.18)
        max_text_w = spec_x + spec_w - tx - int(size * 0.018)
        # Label
        draw.text((tx, sy + int(spec_h * 0.18)), spec["label"].upper(),
                  font=label_font, fill=TEXT_MUTED)
        # Value (wrap to 2 lines if needed)
        v_lines = wrap_text(draw, spec["value"], val_font, max_text_w)[:2]
        vy = sy + int(spec_h * 0.42)
        for ln in v_lines:
            draw.text((tx, vy), ln, font=val_font, fill=TEXT_DARK)
            vy += int(val_font.size * 1.15)

    # Bottom badges row
    badge_h = int(size * 0.075)
    badge_y = size - badge_h - int(size * 0.035)

    # "Made in {country}" pill — painted flag + text
    badge_font = load_font(int(badge_h * 0.34), bold=True)
    flag_w = int(badge_h * 1.3)
    flag_h = int(badge_h * 0.55)
    made_text = f"Made in {origin_country}"
    mt_bbox = draw.textbbox((0, 0), made_text, font=badge_font)
    mt_w = mt_bbox[2] - mt_bbox[0]
    pill_w = flag_w + mt_w + int(size * 0.045)
    pill_x = int(size * 0.05)
    draw.rounded_rectangle([pill_x, badge_y, pill_x + pill_w, badge_y + badge_h],
                           radius=badge_h // 2, fill=DARK_PANEL)
    flag_x = pill_x + int(badge_h * 0.30)
    flag_y = badge_y + (badge_h - flag_h) // 2
    paint_country_flag(canvas, draw, flag_x, flag_y, flag_w, flag_h, origin_country_code)
    # White border around flag for contrast on dark pill
    draw.rectangle([flag_x, flag_y, flag_x + flag_w, flag_y + flag_h],
                   outline=(255, 255, 255), width=2)
    text_x = flag_x + flag_w + int(size * 0.012)
    text_y = badge_y + (badge_h - (mt_bbox[3] - mt_bbox[1])) // 2 - 2
    draw.text((text_x, text_y), made_text, font=badge_font, fill=(255, 255, 255))

    # "Factory Direct" badge — orange pill on right
    if factory_direct:
        fd_text = "Factory Direct"
        fd_bbox = draw.textbbox((0, 0), fd_text, font=badge_font)
        fd_text_w = fd_bbox[2] - fd_bbox[0]
        a_box_w = int(badge_h * 0.62)
        fd_pill_w = a_box_w + fd_text_w + int(size * 0.06)
        fd_pill_x = size - fd_pill_w - int(size * 0.05)
        draw.rounded_rectangle([fd_pill_x, badge_y, fd_pill_x + fd_pill_w, badge_y + badge_h],
                               radius=badge_h // 2, fill=ALIBABA_ORANGE)
        a_x = fd_pill_x + int(badge_h * 0.20)
        a_y = badge_y + (badge_h - a_box_w) // 2
        draw.ellipse([a_x, a_y, a_x + a_box_w, a_y + a_box_w], fill=(255, 255, 255))
        a_glyph_font = load_font(int(a_box_w * 0.65), bold=True)
        draw_text_centered(draw, (a_x + a_box_w // 2, a_y + a_box_w // 2),
                           "A", a_glyph_font, ALIBABA_ORANGE_DARK)
        draw.text((a_x + a_box_w + int(size * 0.012),
                   badge_y + (badge_h - (fd_bbox[3] - fd_bbox[1])) // 2 - 2),
                  fd_text, font=badge_font, fill=(255, 255, 255))

    canvas.save(out_path, "PNG", quality=95)
    return out_path


def wrap_text(draw, text, font, max_width):
    words = text.split()
    lines, cur = [], ""
    for w in words:
        test = (cur + " " + w).strip()
        bb = draw.textbbox((0, 0), test, font=font)
        if bb[2] - bb[0] > max_width:
            if cur:
                lines.append(cur)
            cur = w
        else:
            cur = test
    if cur:
        lines.append(cur)
    return lines


# =====================================================================
# CLI for standalone testing
# =====================================================================

if __name__ == "__main__":
    import argparse, json
    ap = argparse.ArgumentParser()
    ap.add_argument("--mode", required=True, choices=["multiangle", "callout", "spec"])
    ap.add_argument("--cutouts", nargs="+", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--config", help="JSON config file")
    args = ap.parse_args()

    cfg = {}
    if args.config and pathlib.Path(args.config).exists():
        cfg = json.loads(pathlib.Path(args.config).read_text())

    if args.mode == "multiangle":
        compose_multiangle_grid(args.cutouts, args.out,
                                title=cfg.get("title", "360° PRODUCT VIEW"),
                                subtitle=cfg.get("subtitle", "Multiple Angles"),
                                angle_labels=cfg.get("angle_labels", ("45° View", "Side View", "45° View", "Top View")))
    elif args.mode == "callout":
        compose_callout_overlay(args.cutouts[0], args.out,
                                title=cfg.get("title", "CRAFTSMANSHIP DETAILS"),
                                subtitle=cfg.get("subtitle", "Every detail engineered for durability"),
                                callouts=cfg.get("callouts"))
    elif args.mode == "spec":
        compose_spec_card(args.cutouts[0], args.out,
                          product_name=cfg.get("product_name", "Product Name"),
                          tagline=cfg.get("tagline", ""),
                          specs=cfg.get("specs", []),
                          origin_country=cfg.get("origin_country", "Vietnam"),
                          origin_country_code=cfg.get("origin_country_code", "VN"),
                          factory_direct=cfg.get("factory_direct", True))
    print(f"Wrote {args.out}")
