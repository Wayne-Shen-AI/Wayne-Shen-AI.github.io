#!/usr/bin/env python3
"""Generate Alibaba-style product image variants from rembg cutouts.

Strategy: NEVER ask AI to render text. Use PIL composers for any layout that
contains text/labels/callouts. Only use AI (image_edit) for "no-text" scene
shots (lifestyle / packaging / certification wall).

Usage:
    python gen_product_images.py --cutouts <dir> --out <variants_dir>
                                 --count 5 --config <product-config.json>

product-config.json schema:
{
  "spec_card": {                    // → 02_params  (compose_spec_card)
    "product_name": "...",
    "tagline": "...",
    "specs": [{"icon": "M", "label": "Material", "value": "..."}, ...],
    "origin_country": "Vietnam",
    "origin_country_code": "VN",
    "factory_direct": true
  },
  "craftsmanship": {                // → 03_detail (compose_callout_overlay)
    "title": "CRAFTSMANSHIP DETAILS",
    "subtitle": "...",
    "callouts": [{"label": "Premium Welding", "pos": "tl"}, ...]
  },
  "multiangle": {                   // → 05_multiangle (compose_multiangle_grid)
    "title": "360° PRODUCT VIEW",
    "subtitle": "Multiple Angles",
    "angle_labels": ["45° View", "Side View", "45° View", "Top View"]
  },
  "scene": {                        // → 04_scene (AI prompt for image_edit)
    "ai_prompt": "..."
  }
}
"""
import argparse, json, pathlib, sys, shutil

# Local import — same directory
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
import compose_layouts as CL


VARIANT_PLAN = [
    "01_white",       # rembg cutout, copied as-is
    "02_params",      # compose_spec_card
    "03_detail",      # compose_callout_overlay
    "04_scene",       # AI image_edit (PEND, agent fills via ai_jobs.json)
    "05_multiangle",  # compose_multiangle_grid
    "06_packaging",   # AI (optional)
    "07_certifications",  # AI (optional)
    "08_size_compare",    # PIL ruler overlay (optional)
    "09_lifestyle",       # AI (optional)
]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--cutouts", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--count", type=int, default=5)
    ap.add_argument("--config", required=True,
                    help="Product config JSON (spec_card / craftsmanship / multiangle / scene)")
    args = ap.parse_args()

    cut_dir = pathlib.Path(args.cutouts)
    out_dir = pathlib.Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)
    cfg = json.loads(pathlib.Path(args.config).read_text())

    whites = sorted(cut_dir.glob("*_white.png"))
    if not whites:
        sys.stderr.write(f"No *_white.png found in {cut_dir}\n")
        sys.exit(1)

    slot_keys = VARIANT_PLAN[:args.count]
    ai_jobs = []

    for slot in slot_keys:
        out_path = out_dir / f"{slot}.png"

        if slot == "01_white":
            shutil.copy(whites[0], out_path)
            print(f"OK   {slot}: copied {whites[0].name}")

        elif slot == "02_params":
            sc = cfg.get("spec_card", {})
            CL.compose_spec_card(
                str(whites[0]), str(out_path),
                product_name=sc.get("product_name", "Product"),
                tagline=sc.get("tagline", ""),
                specs=sc.get("specs", []),
                origin_country=sc.get("origin_country", "Vietnam"),
                origin_country_code=sc.get("origin_country_code", "VN"),
                factory_direct=sc.get("factory_direct", True),
            )
            print(f"OK   {slot}: spec card composed")

        elif slot == "03_detail":
            cm = cfg.get("craftsmanship", {})
            CL.compose_callout_overlay(
                str(whites[0]), str(out_path),
                title=cm.get("title", "CRAFTSMANSHIP DETAILS"),
                subtitle=cm.get("subtitle", "Every detail engineered for durability"),
                callouts=cm.get("callouts"),
            )
            print(f"OK   {slot}: craftsmanship callouts composed")

        elif slot == "05_multiangle":
            ma = cfg.get("multiangle", {})
            CL.compose_multiangle_grid(
                [str(p) for p in whites], str(out_path),
                title=ma.get("title", "360° PRODUCT VIEW"),
                subtitle=ma.get("subtitle", "Multiple Angles"),
                angle_labels=ma.get("angle_labels",
                                    ["45° View", "Side View", "45° View", "Top View"]),
            )
            print(f"OK   {slot}: multi-angle grid composed")

        elif slot == "04_scene":
            scene = cfg.get("scene", {})
            ai_jobs.append({
                "slot": slot,
                "source": str(whites[0]),
                "out": str(out_path),
                "prompt": scene.get(
                    "ai_prompt",
                    "Place this product in a category-appropriate use scene. "
                    "Photorealistic, professional product-in-use photo, soft daylight. "
                    "DO NOT render any text on the image."
                ),
                "caption": "Application scene",
                "no_text_in_output": True,
            })
            print(f"PEND {slot}: queued AI image_edit (no-text scene)")

        elif slot in ("06_packaging", "07_certifications", "09_lifestyle"):
            ai_jobs.append({
                "slot": slot,
                "source": str(whites[0]),
                "out": str(out_path),
                "prompt": cfg.get(slot, {}).get(
                    "ai_prompt",
                    f"Application context for {slot}. Photorealistic. "
                    "DO NOT render any text on the image."
                ),
                "caption": slot,
                "no_text_in_output": True,
            })
            print(f"PEND {slot}: queued AI")

        elif slot == "08_size_compare":
            # Simple ruler overlay — TODO: dedicated composer if needed
            from PIL import Image, ImageDraw, ImageFont
            img = Image.open(whites[0]).convert("RGB")
            draw = ImageDraw.Draw(img)
            try:
                font = ImageFont.truetype("/System/Library/Fonts/Supplemental/Arial Bold.ttf", 28)
            except OSError:
                font = ImageFont.load_default()
            w, h = img.size
            ruler_text = cfg.get("size_compare", {}).get("dimension", "│ ◄── 380 mm ──► │")
            bbox = draw.textbbox((0, 0), ruler_text, font=font)
            tx = (w - (bbox[2] - bbox[0])) // 2
            ty = h - 60
            draw.rounded_rectangle([tx - 12, ty - 8, tx + bbox[2] + 12, ty + bbox[3] + 8],
                                   radius=8, fill=(255, 106, 0))
            draw.text((tx, ty), ruler_text, fill=(255, 255, 255), font=font)
            img.save(out_path, "PNG", quality=92)
            print(f"OK   {slot}: size-compare overlay")

    # Write ai_jobs for agent
    jobs_file = out_dir / "ai_jobs.json"
    jobs_file.write_text(json.dumps(ai_jobs, indent=2))
    print(f"\n{len(ai_jobs)} AI image_edit job(s) → {jobs_file}")
    if ai_jobs:
        print("Next: agent reads ai_jobs.json and calls image_edit for each.")


if __name__ == "__main__":
    main()
