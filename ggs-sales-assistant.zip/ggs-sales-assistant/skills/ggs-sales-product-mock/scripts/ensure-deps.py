#!/usr/bin/env python3
"""
ensure-deps.py — Pre-flight dependency check for ggs-sales-product-mock.

Run this ONCE before any other script in the skill. It checks whether the
required Python packages (Pillow, PyYAML) are importable and installs any
that are missing. Cloud-native v2.1: rembg/onnxruntime no longer needed.

Usage:
    python3 scripts/ensure-deps.py

Output (JSON to stdout):
    {
      "status": "ready" | "installed" | "failed",
      "packages": {
        "pillow": {"import": "PIL", "installed": true, "version": "10.3.0"},
        ...
      },
      "action_taken": "already_installed" | "installed" | "failed",
      "message": "human-readable summary"
    }

Exit codes:
    0  ready (all deps present, or just installed)
    1  failed (pip unavailable, install failed, etc.)
"""

import json
import subprocess
import sys
from pathlib import Path

PYPI_INDEX = "https://mirrors.aliyun.com/pypi/simple"
PYPI_HOST = "mirrors.aliyun.com"

REQUIRED_PACKAGES = [
    {"pip_name": "pillow", "import_name": "PIL", "description": "Image processing (build_page / compose_layouts)"},
    {"pip_name": "pyyaml", "import_name": "yaml", "description": "YAML parser for inputs.yaml"},
]


def run(cmd, timeout=60):
    try:
        result = subprocess.run(
            cmd, shell=True, capture_output=True, text=True, timeout=timeout
        )
        return result.returncode, result.stdout.strip(), result.stderr.strip()
    except subprocess.TimeoutExpired:
        return 1, "", "timeout"
    except Exception as exc:
        return 1, "", str(exc)


def _is_inside_venv():
    return (
        hasattr(sys, "real_prefix")
        or (hasattr(sys, "base_prefix") and sys.base_prefix != sys.prefix)
    )


def _find_system_python():
    candidates = [
        "/usr/bin/python3",
        "/usr/local/bin/python3",
        "/opt/homebrew/bin/python3",
    ]
    code, which_result, _ = run("which -a python3")
    if code == 0 and which_result:
        for line in which_result.split("\n"):
            path = line.strip()
            if path and ".venv" not in path and "virtualenv" not in path:
                candidates.insert(0, path)

    for path in candidates:
        if Path(path).exists():
            code, stdout, _ = run(
                f'{path} -c "import sys; print(sys.prefix == sys.base_prefix)"'
            )
            if code == 0 and stdout.strip() == "True":
                return path
    return None


def _resolve_target_python():
    if not _is_inside_venv():
        return sys.executable

    system_python = _find_system_python()
    if system_python:
        print(
            f"Detected venv ({sys.prefix}). Using system Python: {system_python}",
            file=sys.stderr,
        )
        return system_python

    print(
        "Warning: inside venv but cannot find system Python, trying current interpreter.",
        file=sys.stderr,
    )
    return sys.executable


TARGET_PYTHON = _resolve_target_python()


def resolve_pip_command():
    candidate = f"{TARGET_PYTHON} -m pip"
    code, _, _ = run(f"{candidate} --version")
    if code == 0:
        return candidate

    bootstrap_code, _, _ = run(f"{TARGET_PYTHON} -m ensurepip --upgrade")
    if bootstrap_code == 0:
        code, _, _ = run(f"{candidate} --version")
        if code == 0:
            return candidate

    code, stdout, _ = run("pip3 --version")
    if code == 0 and stdout:
        code2, target_lib, _ = run(
            f'{TARGET_PYTHON} -c "import sysconfig; print(sysconfig.get_path(\'purelib\'))"'
        )
        if code2 == 0 and target_lib and target_lib in stdout:
            return "pip3"

    return None


def check_package(pkg):
    code, stdout, _ = run(
        f'{TARGET_PYTHON} -c "import {pkg["import_name"]}; '
        f'v = getattr({pkg["import_name"]}, \'__version__\', '
        f'getattr({pkg["import_name"]}, \'VERSION\', \'unknown\')); '
        f'print(v)"',
        timeout=15,
    )
    if code == 0:
        return True, stdout.strip()
    return False, None


def install_packages(pip_cmd, pip_names):
    pkgs = " ".join(pip_names)
    code, stdout, stderr = run(
        f"{pip_cmd} install {pkgs}"
        f" -i {PYPI_INDEX} --trusted-host {PYPI_HOST}",
        timeout=300,
    )
    return code == 0, stdout, stderr


def output_result(status, packages, action_taken, message):
    result = {
        "status": status,
        "packages": packages,
        "action_taken": action_taken,
        "message": message,
    }
    print(json.dumps(result, indent=2))
    sys.exit(0 if status in ("ready", "installed") else 1)


def main():
    python_version = f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
    print(f"Python: {TARGET_PYTHON} ({python_version})", file=sys.stderr)

    pip_cmd = resolve_pip_command()
    if not pip_cmd:
        output_result(
            "failed", {}, "failed",
            "pip is not available. Run: python3 -m ensurepip --upgrade"
        )
    print(f"pip: {pip_cmd}", file=sys.stderr)

    packages_status = {}
    missing = []

    for pkg in REQUIRED_PACKAGES:
        installed, version = check_package(pkg)
        packages_status[pkg["pip_name"]] = {
            "import": pkg["import_name"],
            "installed": installed,
            "version": version,
        }
        if not installed:
            missing.append(pkg["pip_name"])
        print(
            f"  {pkg['pip_name']}: {'✓ ' + (version or '') if installed else '✗ missing'}",
            file=sys.stderr,
        )

    if not missing:
        output_result(
            "ready", packages_status, "already_installed",
            f"All {len(REQUIRED_PACKAGES)} dependencies are ready."
        )

    print(f"\nInstalling {len(missing)} missing package(s): {', '.join(missing)}...", file=sys.stderr)
    ok, stdout, stderr = install_packages(pip_cmd, missing)

    if not ok:
        output_result(
            "failed", packages_status, "failed",
            f"pip install failed for: {', '.join(missing)}. Error: {stderr[:300]}"
        )

    still_missing = []
    for pkg in REQUIRED_PACKAGES:
        installed, version = check_package(pkg)
        packages_status[pkg["pip_name"]]["installed"] = installed
        packages_status[pkg["pip_name"]]["version"] = version
        if not installed:
            still_missing.append(pkg["pip_name"])

    if still_missing:
        output_result(
            "failed", packages_status, "failed",
            f"Install ran but these packages are still not importable: {', '.join(still_missing)}"
        )

    output_result(
        "installed", packages_status, "installed",
        f"Successfully installed: {', '.join(missing)}. All {len(REQUIRED_PACKAGES)} dependencies ready."
    )


if __name__ == "__main__":
    main()
