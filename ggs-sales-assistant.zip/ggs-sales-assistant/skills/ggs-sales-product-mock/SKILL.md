---
name: ggs-sales-product-mock
description: > 
  Generate a single offline-openable HTML mockup of an Alibaba.com product detail page from raw
  customer product photos. Uses image_edit (cloud-native) on original photos to produce 4–8 high-quality 
  Alibaba-style product images (white background / params callout / craftsmanship close-ups / 
  lifestyle scene / multi-angle / packaging). No local AI dependencies (rembg/onnxruntime) required. 
  Then fills the customer-provided or vision-inferred title, specs, price tiers, MOQ, lead time, 
  and reviews into a fixed 14-component framework extracted from a real Alibaba product page. 
  The framework HTML is locked (agent never regenerates layout); the agent only fills placeholders. 
  Use when a sales rep wants to show a prospect a "what your product detail page would look like on 
  Alibaba.com" preview.
version: 2.1.0 (Cloud-Native)
---

# GGS Sales Product Mock (Cloud-Native)

## Purpose

Take 1–N raw customer product photos + optional product-info dict → produce ONE offline-openable HTML file that visually replicates a real Alibaba.com product detail page using cloud-native image editing.

## Customer-facing rules — HARD CONSTRAINTS

1. **Component HTML is frozen.** Components live in `components/*.html` and you **MUST NOT regenerate** their HTML, classes, colors, or layout. Only fill `{{PLACEHOLDER}}` slots.
2. **User-supplied info wins.** If the user gave a title / specs / MOQ / price, use them verbatim. Do NOT "optimize" or rewrite. Phase-2 vision inference is ONLY for fields the user did not provide.
3. **Single-file HTML, fully offline.** All images base64-embedded. No external CDN URLs in production output.
4. **No local AI dependencies.** Do NOT use `rembg` or `onnxruntime` locally. Always use cloud `image_edit`.
5. **No sales-internal data.** No lead score, intent grade, or internal talking points in the final page.

## Image generation rules — Cloud-Native Workflow

### Core principle
Use **image_edit (cloud-native)** for all image tasks. This avoids local environment issues and provides higher quality.

### Decision matrix

| Slot | task_type | Prompt Strategy |
|------|-----------|-----------------|
| `01_white` (Main Image) | `white_background` | Pure white background. Preserves exact product details. |
| `02_params` (Callouts) | `complex_generation` | 4–6 feature callout dots+lines+labels. |
| `03_detail` (Close-ups) | `complex_generation` | 2×2 grid of zoomed product parts. |
| `04_scene` (Lifestyle) | `simple_generation` | Realistic environment (bathroom, kitchen, etc.) |
| `05_multiangle` | `complex_generation` | 2×2 grid from different angles (Front/Side/Back/Top). |
| `06_packaging` | `complex_generation` | Top-down flat-lay of product + box + accessories. |

### Mandatory prompt elements for AI
- `"preserve the EXACT shape, color, printed text, and botanical patterns of the product in the reference image — do NOT redesign it"`
- `"absolutely NO extra text, NO watermarks, NO logos other than what already exists on the product"`

## Phase 1 — Ingest

Create task private dir and build `inputs.yaml`:

```bash
TASK_DIR=mock-{slug}-{YYYYMMDD}
mkdir -p $TASK_DIR/variants
```

## Phase 2 — Vision (only for missing fields)

Infer missing info (Title, Category, Specs) from photos using vision capabilities.

## Phase 3 — Cloud Image Generation

For each slot (01–06):
1. Call `image_edit` with the appropriate `task_type`.
2. Download result to `$TASK_DIR/variants/0X_<slot>.png`.
3. If text fidelity fails, retry once or use the cleanest original shot as fallback.

## Phase 4 — Compose

```bash
python3 scripts/build_page.py --inputs $TASK_DIR/inputs.yaml --variants $TASK_DIR/variants/
```

`scripts/build_page.py` reads components, fills placeholders, and base64-embeds images into a single HTML file.


## Component manifest (frozen, do not edit per-invocation)

The shell `templates/product-page.html` has 14 component slots, in order:

1. `{{COMP_BREADCRUMB}}` → components/breadcrumb.html
2. `{{COMP_GALLERY}}` → components/gallery.html (left, 520 wide; main + thumbs)
3. `{{COMP_INFO_CARD}}` → components/info-card.html (right, 440 wide; title + price-tier + MOQ + lead-time + CTA)
4. `{{COMP_SUPPLIER_MINI}}` → components/supplier-mini-card.html (right, below info-card)
5. `{{COMP_ANCHOR_NAV}}` → fixed in shell (Product details / Company profile / Reviews / Q&A)
6. `{{COMP_ATTRIBUTE_TABLE}}` → components/attribute-table.html
7. `{{COMP_DESC_BANNER}}` → components/description-banner.html
8. `{{COMP_FEATURE_STRIP}}` → components/feature-strip.html
9. `{{COMP_DETAIL_IMAGES}}` → components/detail-image-block.html (loops over Phase 4 variants 03–09)
10. `{{COMP_PACKAGING}}` → components/packaging-shipping.html
11. `{{COMP_CUSTOMIZATION}}` → components/customization-block.html
12. `{{COMP_COMPANY_PROFILE}}` → components/company-profile.html
13. `{{COMP_REVIEWS}}` → components/reviews.html
14. `{{COMP_SIMILAR}}` → components/similar-products.html

## Triggers

This skill should activate when ANY of the following happen:

**Photo upload**: user attaches one or more product photos (JPG/PNG/HEIC) to the message, with or without text — assume the intent is a product mock unless context contradicts.

**Keywords (Chinese)**: 商品详情, 商品详情页, 产品详情页, 详情页, mock页, 商品mock, 商品mock页, 模拟阿里巴巴商品详情页, 把这几张图变成阿里巴巴详情页, 生成商品页, 做一个商品页, 商品页, 详情页面

**Keywords (English)**: product detail, product detail page, detail page mockup, Alibaba detail page, Alibaba detail page preview, show what my product page would look like on Alibaba, product mock, product mockup, product page

## Companion skills

- Optional: `ggs-sales-knowledge-base` for Trade Assurance / Gold Supplier badge wording verification.
- Optional: `ggs-sales-industry-insights` for category-typical price/MOQ when user didn't provide.

## Output

`outputs/product-detail-{slug}-{YYYYMMDD}.html` — single file, typically 15–25 MB with 6 high-quality AI variants base64-embedded. Opens offline in any browser. Customer-safe.
