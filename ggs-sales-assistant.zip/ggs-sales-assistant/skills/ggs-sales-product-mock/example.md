# Example: end-to-end walkthrough

## Scenario

A sales rep is meeting a Vietnamese electrical-equipment seller (Dien Chau A). They have 3 product photos taken on the seller's phone — washed-out lighting, cluttered background, the seller's hand visible in one. The rep wants to show the seller "what your Alibaba.com product page would look like" as part of the sit-down.

## User invocation

```
帮我把这几张图变成阿里巴巴商品详情页的模拟预览。
产品是三相配电箱。
[uploads: IMG_0001.jpg, IMG_0002.jpg, IMG_0003.jpg]
```

## Phase 1 — Ingest

Agent reads message + 3 attached photos. Builds:

```yaml
photos: [/tmp/IMG_0001.jpg, /tmp/IMG_0002.jpg, /tmp/IMG_0003.jpg]
provided:
  title: null              # not supplied
  category_l1: null
  category_l2: null
  category_l3: null
  moq: null
  lead_time: null
  specs: null
  origin_city: null
  supplier: null           # only "三相配电箱" hint given
variant_count: 4
```

Since most fields are null, Phase 2 runs heavy.

## Phase 2 — Vision

Agent picks the cleanest photo (after Phase 3 cutout) and runs `prompts/extract-product-info.md`. Returns:

```json
{
  "product_kind": "3-phase distribution board",
  "category_l1": "Construction & Real Estate",
  "category_l2": "Electrical Equipment",
  "category_l3": "Distribution Boxes",
  "key_features_visible": ["IP65 enclosure", "24-way busbar", "powder-coated steel", "DIN rail mounting"],
  "likely_material": "1.2mm cold-rolled steel, electrostatic powder-coated",
  "estimated_dimensions_cm": {"w": 60, "h": 90, "d": 18},
  "estimated_weight_kg": 12,
  "color_options_visible": ["RAL 7035 grey"],
  "ip_or_cert_marks_visible": ["IEC 60439-3 marking on door"]
}
```

Cached to `inferred.json`. Then runs:
- `prompts/title-builder.md` → `"3 Phase 24-way Distribution Board, IP65 Steel Cabinet, MCB-ready, IEC 60439-3 — OEM Vietnam Manufacturer"`
- `prompts/attribute-table.md` → 16 spec rows
- `prompts/description-copy.md` → banner + feature labels
- `prompts/reviews-generator.md` → 3 illustrative reviews

Every value sourced from inferred.json gets the `(estimated)` tag in the output.

## Phase 3 — Background removal

```bash
python ~/.qoderwork/skills/ggs-product-detail-mockup/scripts/remove_bg.py \
    --input /tmp/IMG_0001.jpg /tmp/IMG_0002.jpg /tmp/IMG_0003.jpg \
    --out workdir/cutouts/
```

Output: 6 files (3 alpha + 3 white). If any fails, agent stops and asks for a re-upload — does NOT silently use the raw photo.

## Phase 4 — Variants

```bash
python scripts/gen_product_images.py --cutouts workdir/cutouts --count 4 --out workdir/variants/
```

Produces:
- `01_white.png` — copied from cutout (offline)
- `02_params.png` — PIL overlay with 4 orange callout pills (offline)
- `ai_jobs.json` — describes 2 pending image_edit jobs (`03_detail`, `04_scene`)

Agent reads `ai_jobs.json`, calls `image_edit` for each, saves to the specified paths.

## Phase 5 — Compose

```bash
python scripts/build_page.py \
    --inputs workdir/inputs.yaml \
    --variants workdir/variants \
    --inferred workdir/inferred.json \
    --out outputs/product-detail-dien-chau-a-20260521.html
```

Output:
```
✅ Frozen-component audit passed
✅ Customer-data audit passed
📄 Wrote outputs/product-detail-dien-chau-a-20260521.html (~2.4 MB)
```

The composer:
1. Renders 13 frozen components, base64-embedding the 4 image variants.
2. Verifies every CSS class name from each component file appears in the output (frozen-component audit).
3. Verifies no sales-internal terms ("lead score", "talking points", "GGS", etc.) leaked into the output.
4. Verifies every value sourced from inferred.json carries `(estimated)` next to it.

## Customer view

The seller opens the file. Sees:
- Top breadcrumb: `Alibaba.com > Construction & Real Estate > Electrical Equipment > Distribution Boxes > 3 Phase 24-way Distribution Board`
- Left gallery: cut-out white-bg photo + 4 thumbnails
- Right info card: keyword-stuffed title (with `(estimated)` tag because we inferred), price ladder ($78 / $62 / $45), MOQ 20 pcs, lead time 15-25 days, CTAs
- Supplier mini-card: Dien Chau A, 🇻🇳, Trade Assurance + Verified badges
- Below fold: 16-row attribute table, factory-floor banner, 4 feature icons, 2 detail images, packaging dimensions, customization options, company profile, 3 illustrative reviews, 8 similar-product cards

The seller's takeaway: "Oh, that's what my page would look like — the photo cleanup alone is impressive."

## What if the user provides info?

If they paste:

```
title: 3-Phase 32A 18-way Distribution Board IP54 — Industrial OEM
moq: 50 pieces
price: bulk $52, mid $68, sample $85
```

Then Phase 2 only fills the still-missing fields (specs, lead time, origin city). The user-supplied title/MOQ/prices appear verbatim, no `(estimated)` tag.

## When something fails

| Failure | What the agent does |
|---------|--------------------|
| rembg can't isolate subject (empty mask) | Stops, asks user to re-upload that specific photo with cleaner background |
| Frozen-component audit fails (class name lost) | Aborts — composition was tampered with. Agent should re-run cleanly without modifying components/ |
| Banned-terms audit hits | Aborts — some sales-internal text leaked. Agent reviews the text it generated and re-renders without it |
| image_edit returns garbage | Falls back to using `01_white.png` for that slot (image_edit is best-effort polish, not load-bearing) |

## Cost

- 4 variants default = ~2 image_edit calls (other 2 are offline PIL).
- 1 vision-model call for product extraction.
- Total ~$0.05–0.10 per invocation depending on model pricing.
- Output ~1.5–4 MB depending on photo resolution.

## Output reuse

Sales rep can:
- Email the HTML directly (offline-openable).
- Open in Chrome → File → Print → Save as PDF → send PDF.
- Screenshot specific sections for WhatsApp/Zalo.
