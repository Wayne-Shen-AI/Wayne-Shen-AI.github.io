# Reference — Placeholder schema & frozen-component manifest

## Top-level shell placeholders (`templates/product-page.html`)

| Placeholder | Source | Notes |
|-------------|--------|-------|
| `{{PAGE_TITLE}}` | inputs.title | becomes `<title>` |
| `{{COMP_BREADCRUMB}}` | components/breadcrumb.html | rendered fragment |
| `{{COMP_GALLERY}}` | components/gallery.html | rendered fragment |
| `{{COMP_INFO_CARD}}` | components/info-card.html | rendered fragment |
| `{{COMP_SUPPLIER_MINI}}` | components/supplier-mini-card.html | rendered fragment |
| `{{COMP_ATTRIBUTE_TABLE}}` | components/attribute-table.html | rendered fragment |
| `{{COMP_DESC_BANNER}}` | components/description-banner.html | rendered fragment |
| `{{COMP_FEATURE_STRIP}}` | components/feature-strip.html | rendered fragment |
| `{{COMP_DETAIL_IMAGES}}` | components/detail-image-block.html × N | one per variant 03–09 |
| `{{COMP_PACKAGING}}` | components/packaging-shipping.html | rendered fragment |
| `{{COMP_CUSTOMIZATION}}` | components/customization-block.html | rendered fragment |
| `{{COMP_COMPANY_PROFILE}}` | components/company-profile.html | rendered fragment |
| `{{COMP_REVIEWS}}` | components/reviews.html | rendered fragment |
| `{{COMP_SIMILAR}}` | components/similar-products.html | rendered fragment |

## Component placeholders

### breadcrumb.html
- `{{CRUMB_L1}}` `{{CRUMB_L2}}` `{{CRUMB_L3}}` `{{CRUMB_PRODUCT}}` — 3 category levels + product short name

### gallery.html
- `{{IMG_MAIN_DATAURI}}` — variant 01_white base64 data URI
- `{{THUMB_1_DATAURI}}` … `{{THUMB_5_DATAURI}}` — variants 01–05 (or repeat last if <5 variants)
- `{{IMG_MAIN_ALT}}` — short alt text

### info-card.html
- `{{TITLE}}` — full Alibaba-style title (8–15 keywords)
- `{{TITLE_ESTIMATED_TAG}}` — empty string OR `<span class="estimated-tag">(estimated)</span>`
- `{{RATING}}` `{{REVIEW_COUNT}}` `{{ORDERS_COUNT}}` — typically estimated
- `{{PRICE_TIER_ROW_1}}` `{{PRICE_TIER_ROW_2}}` `{{PRICE_TIER_ROW_3}}`
- `{{MOQ_TEXT}}` — e.g. "20 pieces"
- `{{LEAD_TIME_TEXT}}` — e.g. "15-25 days for 100 pcs"
- `{{SHIP_FROM}}` — origin port/city
- `{{SAMPLE_PRICE}}` — e.g. "$120 / piece (refundable on bulk)"
- `{{PAYMENT_METHODS}}` — e.g. "T/T, L/C, Trade Assurance ✅"

### supplier-mini-card.html
- `{{SUPPLIER_NAME}}` `{{SUPPLIER_NAME_SHORT}}`
- `{{SUPPLIER_COUNTRY_FLAG}}` `{{SUPPLIER_COUNTRY}}`
- `{{YEARS_ON_ALIBABA}}` — e.g. "1st Year" if new, else "{N} yrs"
- `{{VERIFIED_BADGE}}` — empty or HTML for Verified badge
- `{{TRADE_ASSURANCE_BADGE}}` — fixed Alibaba TA badge SVG
- `{{RESPONSE_RATE}}` `{{RESPONSE_TIME}}`

### attribute-table.html
- `{{ATTR_ROWS_HTML}}` — pre-rendered `<tr><td>K</td><td>V</td></tr>` × 15–20

### description-banner.html
- `{{BANNER_DATAURI}}` — variant 04_scene OR a category-typical factory-floor image
- `{{BANNER_TAGLINE_1}}` `{{BANNER_TAGLINE_2}}`

### feature-strip.html (4 fixed icons)
- `{{FEATURE_1_LABEL}}` `{{FEATURE_2_LABEL}}` `{{FEATURE_3_LABEL}}` `{{FEATURE_4_LABEL}}`
  defaults: "FOB Available" / "OEM/ODM" / "<24h Response" / "Trade Assurance"

### detail-image-block.html (looped)
- `{{DETAIL_IMG_DATAURI}}`
- `{{DETAIL_IMG_CAPTION}}`

### packaging-shipping.html
- `{{PKG_SINGLE_SIZE}}` `{{PKG_SINGLE_WEIGHT}}`
- `{{PKG_CARTON_SIZE}}` `{{PKG_CARTON_WEIGHT}}` `{{PKG_PER_CARTON}}`

### customization-block.html
- `{{CUSTOM_LOGO_MIN}}` `{{CUSTOM_LOGO_FEE}}`
- `{{CUSTOM_GRAPHIC_MIN}}` `{{CUSTOM_GRAPHIC_FEE}}`
- `{{CUSTOM_PACKAGING_MIN}}` `{{CUSTOM_PACKAGING_FEE}}`

### company-profile.html
- `{{CP_YEAR_ESTABLISHED}}` `{{CP_EMPLOYEES}}` `{{CP_REVENUE_BAND}}`
- `{{CP_MAIN_MARKETS}}` `{{CP_MAIN_PRODUCTS}}`
- `{{CP_CERTIFICATIONS}}` (comma list)
- `{{CP_FACTORY_PHOTO_DATAURI}}` (variant 04 or category fallback)

### reviews.html
- `{{REVIEW_AVG_STARS}}` `{{REVIEW_TOTAL_COUNT}}` `{{REVIEW_DIST_HTML}}` (5-bar dist)
- `{{REVIEW_ITEMS_HTML}}` — pre-rendered `<div class="review">…</div>` × 3–5

### similar-products.html
- `{{SIM_CARDS_HTML}}` — 8 SVG-placeholder product cards (same category, different SKU concepts)

## Banned values (must NOT appear anywhere in output)

- "lead score", "intent grade", "pipeline stage"
- "AI sales deck", "talking points", "for the meeting", "for internal"
- "closed-lost", " CLSD ", "re-engagement"
- "salesId", "orgId", "GGS sales", "panggetao"
- raw filenames like "IMG_0001.jpg" (must be base64-embedded only)

## Estimated-tag rule

For any value sourced from Phase 2 vision inference (i.e. user did not provide):
- Wrap with `<span class="estimated-tag">(estimated)</span>` next to the value
- The shell CSS renders `.estimated-tag` as muted gray italic 11 px

## Variant slot defaults (when count < N)

If user requests fewer variants than slots needed:
- Gallery thumbs: pad by repeating the last variant
- Detail image block: render only existing variants; do not synthesize empty blocks

## Frozen-component audit (Phase 5)

The composer must verify that, for every file in `components/`:
- Every CSS class name in the source appears in the output
- The component's outermost element ID/class is present exactly once
- No new class names were inserted by the agent

If audit fails → abort, do not write output, report which component was tampered.
