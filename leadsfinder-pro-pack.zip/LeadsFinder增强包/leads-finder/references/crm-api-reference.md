# CRM API 参考文档

`ggs-crm-cli` 工具的 API 参数说明。

**调用方式：**
```bash
# 优先使用 CLI 命令方式
ggs-crm <command> [options]
# 若 CLI 不可用，回退到 Python 模块方式
python3 -m ggs_crm_cli <command> [options]
```
---

## 1. crm-roles（角色查询）

查询当前销售的所有角色。

| 参数 | 类型 | 必填 | 说明 |
|:---|:---|:---:|:---|
| `--token, -t` | String | ✅ | CRM 认证 Token |

```bash
ggs-crm crm-roles -t "your_token"
```

**返回：**
```json
{
  "success": true,
  "tool": "crm_roles_tool",
  "data": [
    {"salesId": "xxx", "orgId": "110019585", "orgName": "HZ Team 5", "roleId": "tp_reseller_manager", "roleName": "GGS Sales Manager", "fullIdPath": null, "fullPathName": null}
  ]
}
```

**返回字段说明：**

| 字段 | 说明 |
|:---|:---|
| `salesId` | 销售 ID（用于后续查询） |
| `orgId` | 组织 ID（用于后续查询） |
| `orgName` | 组织名称 |
| `roleId` | 角色 ID |
| `roleName` | 角色名称（可能为 null） |
| `fullIdPath` | 完整 ID 路径（可能为 null） |
| `fullPathName` | 完整路径名称（可能为 null） |

---

## 2. crm-search（客户搜索）

| 参数 | 类型 | 必填 | 说明 |
|:---|:---|:---:|:---|
| `--token, -t` | String | ✅ | CRM 认证 Token |
| `--pool` | String | ✅ | `private` / `public` / `all` |
| `--sales-id` | String | ✅ | 销售 ID |
| `--org-id` | String | ✅ | 组织 ID |
| `--conditions, -c` | String | ❌ | 查询条件 JSON 字符串 |
| `--condition-file, -f` | String | ❌ | 查询条件 JSON 文件路径 |
| `--start` | Integer | ❌ | 分页起始（默认 0） |
| `--count` | Integer | ❌ | 每页数量（默认 10） |
| `--sort` | String | ❌ | 排序，格式 `field:desc` |

### 查询条件字段（`-c` / `-f` 参数）

> **⚠️ Global CRM 与 HKTW CRM 字段不同**，使用前请先确认当前客户所属 CRM family：
> - **Global CRM**（越南、韩国、印度等）：使用下方「Global CRM 字段」，详见 `global-field-schema.md`
> - **HKTW CRM**（香港、台湾）：使用下方「HKTW CRM 字段」，详见 `hktw-field-schema.md`

---

#### ▌Global CRM 字段（非 HK/TW）

#### 客户属性

| 字段名 | 说明 | 示例值 |
|:---|:---|:---|
| `company_name` | 公司名，分词检索 | `"Alibaba"` |
| `member_id` | member_id 精确检索 | `"vnxxxxxx"` |
| `email` | 邮箱精确检索 | `"test@example.com"` |
| `country` | 国家，2 字符编码 | `"VN"` |
| `province` | 省份编码（必须通过 `crm-address` 获取，不能传自然语言） | `"916000010000000000"` |
| `city` | 城市编码（必须通过 `crm-address` 获取，不能传自然语言） | `"923302330011007000"` |
| `address` | 地址，分词检索 | `"District 1"` |
| `category_id` | 一级行业 ID（通过 `industry-mapping` 获取） | `"1503"` |
| `sub_category_id` | 二级行业 ID（仅在已明确时使用，不自造） | — |
| `is_ecommerce` | 是否有电商业务 | `true` / `false` |
| `is_exporter` | 是否从事出口贸易 | `true` / `false` |

#### 意向与质量

| 字段名 | 说明 | 示例值 |
|:---|:---|:---|
| `customer_level` | 线索等级（平台计算），字符串，4 最高 | `"4"` / `"3"` / `"2"` / `"1"` |
| `sales_degree` | 意向等级（销售人工打标） | `"AA"` / `"AB"` / `"A"` / `"BB"` / `"BA"` / `"B"` 等 |
| `sop_status` | 线索阶段 | `"NEW"` / `"QUALIFICATION"` / `"PROPOSAL"` 等 |
| `customerdistinctprototag1` | 标签 ID（通过 `crm-tag` 获取） | `"TAG001"` |

#### 活动行为

| 字段名 | 说明 | 示例值 |
|:---|:---|:---|
| `leads_origins` | 客户行为来源，支持 IN 多值查询 | `"81199,81001"` |

#### 时间（仅支持 `GE` `LE` `GT` `LT`）

| 字段名 | 说明 | 示例值 |
|:---|:---|:---|
| `member_create_time` | 会员注册时间，10 位时间戳 | `"1774540801"` |
| `distribute_time` | 公海进池时间，10 位时间戳 | `"1774540801"` |
| `latest_leads_modified` | 最后激活时间，10 位时间戳 | `"1774540801"` |
| `ggs_last_visit_time` | 最后跟进时间，10 位时间戳 | `"1774540801"` |

---

#### ▌HKTW CRM 字段（香港、台湾）

> **⚠️ 路由差异：** HKTW CRM 搜索链路中**没有国家码路由**。搜索范围由 `--org-id` 和 `--sales-id` 自动限定，`-c` 查询条件中**不需要传 `country` 字段**。
> - **公海搜索**：`--pool public` + 正确的 `--org-id`/`--sales-id`（来自 `crm-roles`）双重限定，等价于 Global 的 `--pool public` + `country=XX`
> - **私海搜索**：`--pool private` 仅返回本销售私海客户
> - 若公海结果混入私海/非本销售客户，应检查 `--org-id` 和 `--sales-id` 是否来自 Phase 3 的 `crm-roles` 返回值

##### 客户属性

| 字段名 | 说明 | 示例值 |
|:---|:---|:---|
| `province` / `city` | 省份/城市编码（必须通过 `crm-address --country TW/HK` 获取） | — |
| `contract_status` | 合作状态 | `"25"`（断约1年内）/ `"20"`（断约超1年）/ `"15"`（合同作废）/ `"10"`（未签约） |
| `willing_level` | 兴趣指数 | `"3"`（高）/ `"2"`（中）/ `"1"`（低）/ `"0"`（无） |

##### 标签（`distinctprototag` / `g06_last_leads_origin`）

HKTW 标签通过以下字段查询，具体枚举值见 `hktw-field-schema.md`：

| 查询字段 | 说明 | 示例 |
|:---|:---|:---|
| `distinctprototag` | 固定标签 ID，支持 EQ / IN | `distinctprototag` EQ 190088 |
| `g06_last_leads_origin` | 行为来源，支持 EQ / IN，通常配合 `g06_last_leads_time` 使用 | `g06_last_leads_origin` IN [30012,30014] |
| `g06_last_leads_time` | 最近 leads 时间，配合行为来源使用，10 位时间戳 | GT 180天前时间戳 |
| `target_open_time` | 强开天数（距今天数），用于"2日内强开"等 | GT 0 AND LT 3 |

##### 时间（仅支持 `GE` `LE` `GT` `LT`）

| 字段名 | 说明 | 示例值 |
|:---|:---|:---|
| `gmt_create` | 线索创建时间，10 位时间戳 | `"1774540801"` |
| `last_visit_time` | 最近拜访时间，10 位时间戳 | `"1774540801"` |
| `distribute_date` | 线索开放到公海的时间，10 位时间戳 | `"1774540801"` |
| `open_time` | 线索进入公海的时间，10 位时间戳 | `"1774540801"` |

### 排序字段（`--sort` 参数）

#### ▌Global CRM 字段（非 HK/TW）

| 字段 | 示例 | 说明 |
|:---|:---|:---|
| `latest_leads_modified` | `latest_leads_modified:desc` | 最近激活时间 |
| `sign_probability` | `sign_probability:desc` | 签单概率 |
| `gmt_create` | `gmt_create:desc` / `gmt_create:asc` | 创建时间 |

#### ▌HKTW CRM 字段（香港、台湾）

| 字段 | 示例 | 说明 |
|:---|:---|:---|
| `latest_leads_modified` | `latest_leads_modified:desc` | 最近激活时间 |
| `model_rank_score` | `model_rank_score:desc` | 按意向/按质量/高意向优先 |
| `gmt_create` | `gmt_create:desc` / `gmt_create:asc` | 创建时间 |


### 条件组结构

```json
[{"joinType":"AND","conditions":[{"key":"country","operation":"EQ","value":"VN"}]}]
```

### 使用示例

```bash
# 基础查询
ggs-crm crm-search -t "your_token" --pool private --sales-id xxx --org-id xxx

# 带条件查询
ggs-crm crm-search -t "your_token" --pool private --sales-id xxx --org-id xxx \
  -c '[{"joinType":"AND","conditions":[{"key":"country","operation":"EQ","value":"VN"}]}]'

# 按分发时间范围查询
ggs-crm crm-search -t "your_token" --pool private --sales-id xxx --org-id xxx \
  -c '[{"joinType":"AND","conditions":[{"key":"distribute_time","operation":"GT","value":"1774540801"},{"key":"distribute_time","operation":"LT","value":"1774627198"}]}]'

# 从文件读取条件
ggs-crm crm-search -t "your_token" --pool private --sales-id xxx --org-id xxx -f conditions.json
```

### 返回

```json
{"success": true, "tool": "crm_search_tool", "data": {"total": 21, "dataList": [{"companyName": "SONGSUNG", "country": "KR", "email": "xxx@gmail.com", "contactName": "ABC", "salesDegree": "CC", "status": "new"}]}}
```

---

## 3. crm-address（地址映射）

| 参数 | 类型 | 必填 | 说明 |
|:---|:---|:---:|:---|
| `--token, -t` | String | ✅ | CRM 认证 Token |
| `--country, -c` | String | ✅ | 国家代码 |

```bash
ggs-crm crm-address -t "your_token" -c VN
```

**返回：**
```json
{"success": true, "tool": "crm_address_mapping_tool", "data": [{"state": {"name": "Ho Chi Minh", "key": "HCM"}, "cityList": [{"name": "District 1", "key": "D1"}]}]}
```

---

## 4. crm-tag（标签映射）

| 参数 | 类型 | 必填 | 说明 |
|:---|:---|:---:|:---|
| `--token, -t` | String | ✅ | CRM 认证 Token |
| `--sales-id` | String | ✅ | 销售 ID |
| `--org-id` | String | ✅ | 组织 ID |

```bash
ggs-crm crm-tag -t "your_token" --sales-id xxx --org-id xxx
```

**返回：**
```json
{"success": true, "tool": "crm_tag_mapping_tool", "data": [{"tagId": "TAG001", "tagDesc": "VIP Customer"}]}
```

---

## 5. crm-dedup（批量判重）

| 参数 | 类型 | 必填 | 说明 |
|:---|:---|:---:|:---|
| `--token, -t` | String | ✅ | CRM 认证 Token |
| `--sales-id` | String | ✅ | 销售 ID |
| `--org-id` | String | ✅ | 组织 ID |
| `--check-params, -p` | String | ✅* | 待判重客户信息 JSON 字符串 |
| `--check-params-file, -f` | String | ✅* | 待判重客户信息 JSON 文件路径 |

`-p` 和 `-f` 二选一。

### check_params 字段

| 字段 | 类型 | 说明 |
|:---|:---|:---|
| `uid` | String | 唯一标识（用于关联请求和响应） |
| `companyName` | String | 公司名称 |
| `email` | String | 邮箱地址 |
| `registerNumber` | String | 注册号 |
| `country` | String | 国家代码 |
| `province` | String | 省份 |
| `globalId` | String | 全局客户 ID |

### 判重状态（`deduplicationStatus`）

| 状态值 | 说明 |
|:---|:---|
| `depot_repeat` | 私海重复 |
| `manager_repeat` | 经理库重复 |
| `channel_repeat` | 渠道公海重复 |
| `public_repeat` | 公海重复 |
| `not_repeat` | 不重复 |

### 返回字段说明（`values` 数组）

| 字段 | 说明 |
|:---|:---|
| `uid` | 对应请求中的 uid，用于关联请求和响应 |
| `deduplicationStatus` | 判重结果，见上方状态说明 |
| `matchType` | 匹配方式（重复时返回），如 `CompanyNameDeduplicateProcessValve`（公司名匹配）、`GlobalIdDeduplicateProcessValve`（GlobalId 匹配） |
| `globalId` | 已存在客户的全局 ID |
| `customerId` | 已存在客户的 Customer ID |
| `memberId` | 已存在客户的 Member ID |
| `oppId` | 商机 ID |
| `companyName` | 已存在客户的公司名 |
| `orgId` | 所属组织 ID |
| `pool` | 所在客户池（`private` 私海 / `public` 公海） |
| `ownerId1` | 客户归属销售 ID |
| `detailUrl` | CRM 客户详情页链接 |

```bash
ggs-crm crm-dedup -t "your_token" --sales-id xxx --org-id xxx \
  -p '[{"uid":"1","companyName":"Alibaba","country":"CN","email":"test@alibaba.com"}]'
```

---

## 6. crm-pickup（捡入公海客户）

仅将公海客户捡入私海，**不做信息补全**。补全信息请在捡入后调用 `crm-refine`。

| 参数 | 类型 | 必填 | 说明 |
|:---|:---|:---:|:---|
| `--token, -t` | String | ✅ | CRM 认证 Token |
| `--sales-id` | String | ✅ | 销售 ID |
| `--org-id` | String | ✅ | 组织 ID |
| `--global-id, -g` | String | ✅ | 客户全局 ID |

```bash
ggs-crm crm-pickup -t "your_token" --sales-id xxx --org-id xxx -g 1921590382
```

---

## 7. crm-refine（补全客户信息）

补全已有客户的公司信息（捡入后调用）。

| 参数 | 类型 | 必填 | 说明 |
|:---|:---|:---:|:---|
| `--token, -t` | String | ✅ | CRM 认证 Token |
| `--sales-id` | String | ✅ | 销售 ID |
| `--org-id` | String | ✅ | 组织 ID |
| `--company-data, -d` | String | ✅* | JSON 字符串 |
| `--company-data-file, -f` | String | ✅* | JSON 文件路径 |

`-d` 和 `-f` 二选一。

### companyData 字段

| 字段 | 类型 | 必填 | 说明 |
|:---|:---|:---:|:---|
| `globalId` | String | ✅ | 客户全局 ID（必填） |
| `companyNameEn` | String | ✅ | 公司英文名 |
| `country` | String | ✅ | 国家代码，如 `VN`、`CN` |
| `email` | String | ✅* | 邮箱，与 `phone` 至少提供一个 |
| `phone` | String | ✅* | 电话，与 `email` 至少提供一个 |
| `registerNumber` | String | ❌ | 注册号/税号 |
| `website` | String | ❌ | 官网 |
| `province` | String | ❌ | 省份编码（从 crm-address 获取） |
| `city` | String | ❌ | 城市编码（从 crm-address 获取） |
| `address` | String | ❌ | 详细地址 |
| `industryId` | String | ❌ | 一级行业 ID |
| `industryLevel2Id` | String | ❌ | 二级行业 ID |

```bash
ggs-crm crm-refine -t "your_token" --sales-id xxx --org-id xxx \
  -d '{"globalId":"1921590382","companyNameEn":"Test Company Ltd.","country":"VN","email":"test@abc.com","phone":"+84 912345678"}'
```

**返回：**
```json
{"success": true, "tool": "crm_customer_refine_tool", "data": {"success": true, "errorMsg": null, "errorCode": null}}
```

---

## 8. crm-add（添加全新客户）

将外部发现的全新客户（无 `globalId`）写入 CRM。

| 参数 | 类型 | 必填 | 说明 |
|:---|:---|:---:|:---|
| `--token, -t` | String | ✅ | CRM 认证 Token |
| `--sales-id` | String | ✅ | 销售 ID |
| `--org-id` | String | ✅ | 组织 ID |
| `--company-data, -d` | String | ✅* | JSON 字符串 |
| `--company-data-file, -f` | String | ✅* | JSON 文件路径 |

`-d` 和 `-f` 二选一。companyData **无 `globalId`** 字段。

| 字段 | 类型 | 必填 | 说明 |
|:---|:---|:---:|:---|
| `companyNameEn` | String | ✅ | 公司英文名 |
| `country` | String | ✅ | 国家代码，如 `VN`、`CN` |
| `email` | String | ✅* | 邮箱，与 `phone` 至少提供一个 |
| `phone` | String | ✅* | 电话，与 `email` 至少提供一个 |
| `registerNumber` | String | ✅/❌ | 注册号/税号（越南、印度、韩国必填，其他国家选填） |
| `website` | String | ❌ | 官网 |
| `province` | String | ❌ | 省份编码（从 crm-address 获取） |
| `city` | String | ❌ | 城市编码（从 crm-address 获取） |
| `address` | String | ❌ | 详细地址 |
| `industryId` | String | ❌ | 一级行业 ID |
| `industryLevel2Id` | String | ❌ | 二级行业 ID |

```bash
ggs-crm crm-add -t "your_token" --sales-id xxx --org-id xxx \
  -d '{"companyNameEn":"ABC Ltd.","country":"VN","email":"abc@abc.com","phone":"+84 912345678"}'
```

**返回：**
```json
{"success": true, "tool": "crm_customer_add_tool", "data": {"success": true, "errorMsg": null, "errorCode": null}}
```

---

## Enrichment → companyData 写回映射

本节定义 leads-finder 补全产出字段到 `crm-refine` / `crm-add` 的 `companyData` 字段的映射关系。

### 映射表

| 补全产出字段 | companyData 字段 | 必填性 | 转换规则 |
|------------|-----------------|-------|---------|
| company_name_en | `companyNameEn` | ✅ 必填 | 直接映射。如只有本地语言名且无英文名 → **阻断写回** |
| country | `country` | ✅ 必填 | 2 位国家码，直接映射 |
| email | `email` | ✅ 必填 | 直接映射 |
| phone | `phone` | ✅ 必填 | 直接映射，须为国际格式（+84 / +82 / +39 等） |
| tax_id / register_number | `registerNumber` | 条件必填 | VN/IN/KR 必填，其他国家选填。具体见 country 文件 |
| website | `website` | 选填 | 直接映射 |
| province（自然语言） | `province` | 选填 | **不能直接写入**，必须先调 `crm-address --country {country}` 转为编码 |
| city（自然语言） | `city` | 选填 | **不能直接写入**，必须先调 `crm-address` 转为编码 |
| address | `address` | 选填 | 直接映射（详细地址原文） |
| industry（行业 ID） | `industryId` | 选填 | 已在 Phase 7 LLM 推断时映射为 ID |
| industry_sub（二级行业 ID） | `industryLevel2Id` | 选填 | 仅在 ID 已明确时映射 |
| globalId | `globalId` | pickup 必填 | 仅 `crm-refine` 时需要，来自 dedup 返回 |

### pickup（crm-pickup → crm-refine）vs add（crm-add）分流

- **crm-pickup → crm-refine**：dedup 结果为 EXIST 且在公海，有可确认的 `globalId`。先 pickup 捡入，再 refine 补全。
- **crm-add**：dedup 结果为 NEW，无 `globalId`，直接新增。

### 不进入 write-back 的字段

以下信号可用于查询或排序，但 `crm-refine` / `crm-add` 无对应写回字段：

- 标签（tag）、活跃度（activity signals）、平台评分（score）、所有者（ownerId）、跟进记录

---

## 9. google-search（Google 搜索）

| 参数 | 类型 | 必填 | 说明 |
|:---|:---|:---:|:---|
| `--token, -t` | String | ✅ | CRM 认证 Token |
| `--keywords, -k` | String | ✅ | 搜索关键词，多个逗号分隔 |
| `--country, -c` | String | ❌ | 国家代码（默认 CN） |

```bash
ggs-crm google-search -t "your_token" -k "Vietnam furniture factory" -c vn
```

---

## 10. google-map（Google 地图搜索）

通过 Google 地图搜索企业位置信息。

### 参数说明

| 参数 | 类型 | 必填 | 默认值 | 说明 |
|:---|:---|:---:|:---|:---|
| `--token, -t` | String | ✅ | - | CRM 认证 Token |
| `--address, -a` | String | ✅* | - | 搜索地址关键词，与 `--latitude/--longitude` 二选一必填 |
| `--state` | String | ❌ | - | 省/州 |
| `--city` | String | ❌ | - | 城市 |
| `--latitude` | Float | ✅* | - | 纬度，与 `--address` 二选一必填，需配合 `--longitude` 使用 |
| `--longitude` | Float | ✅* | - | 经度，与 `--address` 二选一必填，需配合 `--latitude` 使用 |
| `--zoom` | Integer | ❌ | 15 | 地图缩放级别 |
| `--radius` | Integer | ❌ | 1000 | 搜索半径（米） |
| `--company-type` | String | ❌ | - | 企业类型，如 `trading company`、`restaurant` |
| `--industry` | String | ❌ | - | 主营行业，如 `food and beverage` |
| `--country, -c` | String | ✅ | - | 国家代码，如 `VN`、`US`、`CN`、`HK` |

### 使用示例

**按地址搜索**:
```bash
ggs-crm google-map -t "your_token" -a "Ho Chi Minh City" --radius 2000 -c VN
```

**按经纬度搜索**:
```bash
ggs-crm google-map -t "your_token" --latitude 10.8230989 --longitude 106.6296638 --radius 1000 -c VN --company-type "trading company"
```

**按城市搜索**:
```bash
ggs-crm google-map -t "your_token" -a "Hanoi" --city "Hanoi" --company-type "restaurant" -c VN
```

### 返回结果

```json
{
  "success": true,
  "tool": "google_map_search_tool",
  "data": [
    {
      "name": "Alibaba Xixi Campus",
      "address": "No. 969, Wenyi West Road, Hangzhou",
      "phone": "+86 571 8502 2088",
      "website": "https://www.alibaba.com",
      "rating": 4.5,
      "reviewCount": 1200
    }
  ]
}
```

---

## 11. web-scrape（网页抓取）

| 参数 | 类型 | 必填 | 说明 |
|:---|:---|:---:|:---|
| `--token, -t` | String | ✅ | CRM 认证 Token |
| `--url, -u` | String | ❌* | 单个 URL |
| `--urls` | String | ❌* | 多个 URL，逗号分隔 |
| `--content-type` | String | ❌ | `text`（默认）或 `html` |

`--url` 和 `--urls` 二选一。

---

## 12. industry-mapping（行业映射查询）

查看行业 Mapping 完整数据（**本地数据，无需 Token**）。输出全部行业分类及对应 ID，供 AI 模型根据上下文推断行业 ID。

```bash
ggs-crm industry-mapping 
```

**无需参数。** 返回所有一级/二级/三级行业的 ID 与名称映射表。

---

## 13. crm-industry-traffic（行业流量数据查询）

| 参数 | 类型 | 必填 | 说明 |
|:---|:---|:---:|:---|
| `-t, --token` | String | ✅ | CRM 认证 Token |
| `-i, --industry-id` | String | ✅ | 一级行业 ID，如 `1` |
| `--industry-lv2-id` | String | ✅ | 二级行业 ID，如 `222` |
| `-c, --country` | String | ✅ | 国家代码，如 `VN`、`CN` |
| `--industry-lv3-id` | String | ❌ | 三级行业 ID（可选） |

```bash
ggs-crm crm-industry-traffic -t "your_token" -i 1 --industry-lv2-id 222 -c VN
ggs-crm crm-industry-traffic -t "your_token" -i 1 --industry-lv2-id 222 -c VN --industry-lv3-id 333
```

---

## 14. crm-industry-buyer-country（行业买家国数据查询）

| 参数 | 类型 | 必填 | 说明 |
|:---|:---|:---:|:---|
| `-t, --token` | String | ✅ | CRM 认证 Token |
| `-i, --industry-id` | String | ✅ | 一级行业 ID，如 `1` |
| `--industry-lv2-id` | String | ✅ | 二级行业 ID，如 `222` |
| `-c, --country` | String | ✅ | 国家代码，如 `VN`、`CN` |
| `--industry-lv3-id` | String | ❌ | 三级行业 ID（可选） |

```bash
ggs-crm crm-industry-buyer-country -t "your_token" -i 1 --industry-lv2-id 222 -c VN
```

---

## 15. crm-industry-product（行业品数据查询）

| 参数 | 类型 | 必填 | 说明 |
|:---|:---|:---:|:---|
| `-t, --token` | String | ✅ | CRM 认证 Token |
| `-i, --industry-id` | String | ✅ | 一级行业 ID，如 `1` |
| `--industry-lv2-id` | String | ✅ | 二级行业 ID，如 `222` |
| `-c, --country` | String | ✅ | 国家代码，如 `VN`、`CN` |
| `--industry-lv3-id` | String | ❌ | 三级行业 ID（可选） |

```bash
ggs-crm crm-industry-product -t "your_token" -i 1 --industry-lv2-id 222 -c VN
```

---

## 16. crm-industry-benchmark（行业标杆数据查询）

| 参数 | 类型 | 必填 | 说明 |
|:---|:---|:---:|:---|
| `-t, --token` | String | ✅ | CRM 认证 Token |
| `-i, --industry-id` | String | ✅ | 一级行业 ID，如 `1` |
| `--industry-lv2-id` | String | ✅ | 二级行业 ID，如 `222` |
| `-c, --country` | String | ✅ | 国家代码，如 `VN`、`CN` |
| `--industry-lv3-id` | String | ❌ | 三级行业 ID（可选） |

```bash
ggs-crm crm-industry-benchmark -t "your_token" -i 1 --industry-lv2-id 222 -c VN
```

---

## 17. email-send（发送客户邮件）

| 参数 | 类型 | 必填 | 说明 |
|:---|:---|:---:|:---|
| `--token, -t` | String | ✅ | CRM 认证 Token |
| `--to-address` | String | ✅ | 收件人邮箱 |
| `--template` | String | ✅ | 邮件模板标识 |
| `--global-id, -g` | String | ✅ | 客户全局 ID（globalId） |
| `--from-address` | String | ❌ | 发件人地址 |
| `--cc-address` | String | ❌ | 抄送人地址 |
| `--reply-to` | String | ❌ | 回复邮箱地址 |
| `--variables, -v` | String | ❌ | 模板替换变量 JSON 字符串 |
| `--variables-file` | String | ❌ | 模板替换变量 JSON 文件路径 |

```bash
ggs-crm email-send -t "your_token" \
  --to-address "customer@example.com" \
  --template WELCOME_TEMPLATE \
  -g "1921590382" \
  -v '{"customerName": "John"}'
```

---

## 通用说明

### 输出格式

所有工具统一 JSON：
```json
{"success": true, "tool": "工具名称", "data": "具体数据", "error": null}
```

### 超时

- Google 搜索 / Google 地图 / 网页抓取：60 秒
- 其他工具：30 秒

