# Global CRM 查询 Schema

> **⚠️ 适用范围：** 本文件是 **Global CRM family**（非 HK/TW）的查询侧单一信源。
> - Phase 1 意图理解：理解用户表达、推断适用字段
> - Phase 5 内部查询：字段映射、排序、放宽
> - HKTW CRM 有不同字段定义，见 `hktw-field-schema.md`

**使用说明：** 不要硬编码关键词匹配。使用"典型用户表达"作为语义引导来推断适用字段。用户输入通常不够精确——依赖语义理解，而非字符串匹配。

**值类型：**
- `enum_fixed` — 固定枚举，直接使用值
- `enum_from_api` — 查询时从 API 获取枚举；调用指定接口获取列表后再基于用户指令进行映射
- `user_data_from_api` — 从 API 获取用户特定数据；调用指定接口获取用户自己的数据后再映射
- `user_input` — 从用户指令中提取

---

## 一、Pool 归一化

流程层的 pool 标签与 `crm-search --pool` 合法值不同，执行前必须转换：

| 流程层 pool | `crm-search --pool` | 说明 |
|------------|---------------------|------|
| `private` | `private` | 直接映射 |
| `public-only` | `public` | 不得传 `public-only` |
| `public+external` | `public`（仅内部查询段） | 外部走 Phase 6 |
| CRM record inspection | `all` | 可能在公海或私海 |

**禁止** 使用 `OFFICIAL`、`public-only` 等非法值。

---

## 二、查询字段定义

以下是 `crm-search -c` 允许使用的查询字段。**禁止使用本节未列出的字段名，禁止使用 CRM 返回字段名（如 `companyName`、`salesDegree`）作为查询字段。**

### 客户属性

#### 一级行业
- **查询 key：** `category_id`
- **Intent Struct 来源：** `industry_hint`
- **含义：** 线索所属的行业类别
- **典型用户表达：** beauty, apparel, electronics, "做 X 的公司", "X 行业", "X 类目"
- **值类型：** `enum_from_api` — 调用 `ggs-crm industry-mapping` 获取行业 ID 列表
- **转换规则：** 自然语言 → 行业 ID（语义匹配）
- **多选：** 是

#### 二级行业
- **查询 key：** `sub_category_id`
- **Intent Struct 来源：** `industry_hint`（二级）
- **含义：** 线索所属的二级行业分类
- **值类型：** `enum_from_api` — 同一级行业接口
- **转换规则：** 仅在二级行业 ID 已明确时使用，**不自造**
- **多选：** 是

#### 国家
- **查询 key：** `country`
- **Intent Struct 来源：** `country`
- **含义：** 线索所在国家
- **转换规则：** 2 位国家码，直接映射
- **多选：** 否

#### 地区
- **查询 key：** `province` / `city`
- **Intent Struct 来源：** `location_city`
- **含义：** 线索所在的省份/城市
- **典型用户表达：** Ho Chi Minh City, Hanoi, "X 城市的客户", "X 地区"
- **值类型：** `enum_from_api` — 调用 `ggs-crm crm-address -t {token} --country {country}` 获取编码列表
- **转换规则：** **必须先通过 `crm-address` 转为编码**，不能传自然语言文本
- **多选：** 是

#### 地址
- **查询 key：** `address`
- **Intent Struct 来源：** address 文本
- **含义：** 线索详细地址，分词检索
- **值类型：** `user_input`
- **多选：** 否

#### 电商业务
- **查询 key：** `is_ecommerce`
- **含义：** 线索是否有电商业务
- **典型用户表达：** 电商客户、有电商平台、"有电商业务"
- **值类型：** `enum_fixed`
- **取值范围：** true / false
- **多选：** 否

#### 出口业务
- **查询 key：** `is_exporter`
- **含义：** 线索是否从事出口贸易
- **典型用户表达：** 出口商、"做出口业务"、"跨境卖家"
- **值类型：** `enum_fixed`
- **取值范围：** true / false
- **多选：** 否

#### 有效电话号码
- **查询 key：** `all_phone_valid_status_list`
- **含义：** 线索有格式正确的电话号码或能打通的电话号码
- **典型用户表达：** 有电话的,能打通电话的
- **值类型：** `enum_fixed`
- **取值范围：** valid / VALID_CONFIRMED
- **业务规则：** valid:格式正确的电话号码，VALID_CONFIRMED:打通的电话号码
- **多选：** 否

#### 有效手机号码
- **查询 key：** `all_mobile_valid_status_list`
- **含义：** 线索有格式正确的手机号码或能打通的手机号码
- **典型用户表达：** 有手机的,能打通手机的
- **值类型：** `enum_fixed`
- **取值范围：** valid / VALID_CONFIRMED
- **业务规则：** valid:格式正确的号码，VALID_CONFIRMED:打通的号码
- **多选：** 否

### 意向与质量

> **关系说明：** 线索等级（Leads Level）和意向等级（Intent Level）是两个独立维度，共同反映线索质量。
> - 线索等级：平台系统基于数据推算的成交可能性，入库时即有值
> - 意向等级：销售跟进后人工打标的购买意向，需要有跟进记录才有值
>
> 用户表达"高意向"、"优质线索"等时，**同时触发两个字段，OR 逻辑**——满足其中一个即可。

#### 线索等级
- **查询 key：** `customer_level`
- **Intent Struct 来源：** `quality_hint`
- **含义：** 平台计算的分数，反映线索的转化可能性。分数越高 = 转化潜力越好。
- **典型用户表达：** "高质量的"、"优质leads"、"成交可能性高的"、"level 4的"
- **值类型：** `enum_fixed`
- **取值范围：** `"4"` / `"3"` / `"2"` / `"1"`（**字符串类型**）
- **业务规则：** 4 最高，1 最低。"高质量"请求使用 4 or 3
- **多选：** 是

#### 意向等级
- **查询 key：** `sales_degree`
- **含义：** 销售跟进后分配的意向评级——反映销售代表评估的购买意愿
- **典型用户表达：** 高意向、强意向、优质线索、"有购买兴趣"、"A级客户"、"B及以上"
- **值类型：** `enum_fixed`
- **取值范围与映射：**
  - A+ → `AA`、A → `AB`、A- → `A`
  - B+ → `BB`、B → `BA`、B- → `B`
  - C+ → `CC`、C → `C`
  - `CLSD`、`D`、`NIP`
- **业务规则：** B+ 及以上 = 高意向
- **多选：** 是

#### 线索阶段
- **查询 key：** `sop_status`
- **含义：** 线索在销售漏斗中的当前阶段
- **典型用户表达：** 新线索、"已发送方案"、"谈判中"、"已付款"、"服务中"
- **值类型：** `enum_fixed`
- **取值范围：** NEW / QUALIFICATION / NEEDS_ANALYSIS / PROPOSAL / AGREE_OFFER / PAYMENT / BV / FUTURE_OPPS / LOSE_REASON / IN_SERVICE
- **多选：** 单选

#### 标签
- **查询 key：** `customerdistinctprototag1`
- **Intent Struct 来源：** tag 引用
- **含义：** 销售代表添加的自定义标签
- **典型用户表达：** "标记为 X"、"标注为 X"
- **值类型：** `user_data_from_api` — 调用 `ggs-crm crm-tag -t {token} --sales-id {id} --org-id {id}` 获取标签列表后映射
- **转换规则：** 先通过 `crm-tag` 获取 tagId
- **多选：** 单选

### 活动行为

#### 活动
- **查询 key：** `leads_origins`
- **Intent Struct 来源：** `activity_hint`
- **含义：** 线索在平台上是否有任何记录活动——反映参与度
- **典型用户表达：** "有活动"、"活跃线索"、"有互动"、"有询盘"、"有登录"
- **值类型：** `enum_fixed`
- **取值范围（第一级，OR 逻辑）：**
  - `inbound 场景`：客户主动进线询问，查询入参 `"81199,81001,81002,81003,81004"` 的 IN 查询
  - `my_alibaba 场景`：My Alibaba 平台活动，查询入参 `"81199,81001,81002,81003,81004"` 的 IN 查询
  - `seller_central 场景`：Seller Central 活动，查询入参 `"81006,81007,81013,81099,81098,83011,81089,82002,82003,82004,82005"` 的 IN 查询
  - `AI外呼有高意愿`：查询入参 `"88098"` 的 IN 查询
- **多选：** 是；"有活动" = 全选（OR 逻辑）；指定渠道则只选该渠道

### 时间

#### 会员注册时间
- **查询 key：** `member_create_time`
- **含义：** 线索注册为会员的时间——反映"新鲜度"
- **典型用户表达：** "新注册的"、"最近注册的"、"今年的新用户"
- **值类型：** `user_input`
- **取值范围：** 10 位时间戳，查询条件 GE / LE

#### 公海进池时间
- **查询 key：** `distribute_time`（配合 `owner_1` EQ `public`）
- **Intent Struct 来源：** `time_hint`（放出来/进池/分发）
- **含义：** 线索最近一次被释放到公海的时间
- **典型用户表达：** "最近放出来的"、"刚进池的"、"新分配的"
- **值类型：** `user_input`
- **取值范围：** 10 位时间戳，查询条件 GE / LE

#### 最后激活时间
- **查询 key：** `latest_leads_modified`
- **Intent Struct 来源：** `time_hint`（激活）
- **含义：** 线索最近一次被激活的时间
- **典型用户表达：** "最近激活的"、"近期有leads的"
- **值类型：** `user_input`
- **取值范围：** 10 位时间戳，查询条件 GE / LE


#### 最后跟进时间
- **查询 key：** `ggs_last_visit_time`
- **Intent Struct 来源：** `time_hint`（跟进）
- **含义：** 线索最近一次被跟进的时间
- **典型用户表达：** "最近跟进的"、"近期联系的"、"X 天内跟进的"
- **值类型：** `user_input`
- **取值范围：** 10 位时间戳，查询条件 GE / LE


### 精确查找字段

#### 公司名称
- **查询 key：** `company_name`
- **Intent Struct 来源：** `company_name_hint`
- **转换规则：** 分词检索，直接映射

#### 邮箱
- **查询 key：** `email`
- **Intent Struct 来源：** `email_hint`
- **转换规则：** 精确查询

#### Member ID
- **查询 key：** `member_id`
- **转换规则：** 仅用户明确提供时使用

---

## 三、预调用（按需缓存）

以下工具在查询前按需调用，结果在会话中缓存复用：

| 工具 | 命令 | 触发条件 |
|------|------|---------|
| 地址映射 | `ggs-crm crm-address --country {country}` | location 相关字段非空 |
| 标签映射 | `ggs-crm crm-tag --sales-id {id} --org-id {id}` | 涉及 tag/group |
| 行业映射 | `ggs-crm industry-mapping` | 涉及行业筛选 |

---

## 四、time_hint 推断规则

当用户提及时间但未明确说是哪个时间字段时，按以下规则推断：

| 优先级 | 条件 | 映射查询 key |
|-----|------|-------------|
| 1   | 明确说"激活时间" | `latest_leads_modified` |
| 1   | 明确说"跟进时间" | `ggs_last_visit_time` |
| 2   | 明确说"放出来/进池/分发" | `distribute_time` |
| 3   | pool=private，未明确说 | `latest_leads_modified` |
| 24  | pool=public/public+external，未明确说 | `distribute_time` |

---

## 五、查询条件结构

`crm-search -c` 接收 JSON 条件组数组。具体参数格式见 `crm-api-reference.md`。

**约束：**
- `key` 必须来自本文件第二节的查询 key
- 所有值均为字符串（数字也加引号）
- 时间范围字段（`distribute_time`、`latest_leads_modified`）仅支持 `GE` `LE` `GT` `LT`，值为单个时间戳字符串
- 时间范围查询用两条条件组合（如 `GT` + `LT`），**禁止使用 `BETWEEN`**
- 多等级筛选需用 OR 条件组，不伪造数组值

---

## 六、排序映射

| Intent 信号 | `--sort` 参数 |
|------------|--------------|
| 按意向/按质量/高意向优先 | `sign_probability:desc` |
| 最近激活/最近跟进 | `latest_leads_modified:desc` |
| 最近放出来/最新分配 | `distribute_time:desc` |
| 最新创建 | `gmt_create:desc` |
| 无明确排序 + public | `sign_probability:desc` |
| 无明确排序 + private | `latest_leads_modified:desc` |


---

## 七、无结果放宽优先级

按以下顺序逐步放宽，每次放宽后重新查询，找到结果即停止并告知用户放宽了哪个条件：

1. 联系方式有效性 → 降级为"有值"，或移除条件
2. 意向等级 → 逐步放宽（如 A+ → A+/A → B 及以上 → 全部）
3. 活动行为 → 移除条件
4. 时间范围 → 扩大窗口（7 天 → 30 天 → 90 天）
5. 地区 → 扩大到附近城市或省级
6. 行业 → 最后手段；通常是用户的核心意图
