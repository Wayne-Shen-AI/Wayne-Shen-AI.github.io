# HKTW CRM 查询 Schema

> **⚠️ 适用范围：** 本文件是 **HKTW CRM family**（香港、台湾）的查询侧单一信源。
> - Phase 1 意图理解：理解用户表达、推断适用字段
> - Phase 5 内部查询：字段映射、排序、放宽
> - Global CRM 有不同字段定义，见 `global-field-schema.md`
>
> **⚠️ 路由方式：** HKTW CRM 搜索链路中**没有国家码（country）字段用于路由**。搜索范围由 `--org-id`（组织 ID）和 `--sales-id`（销售 ID）自动限定，无需在 `-c` 查询条件中传 `country` 字段。这与 Global CRM（通过 `country` 字段路由）不同。

**使用说明：** 不要硬编码关键词匹配。使用"典型用户表达"作为语义引导来推断适用字段。用户输入通常不够精确——依赖语义理解，而非字符串匹配。

**值类型：**
- `enum_fixed` — 固定枚举，直接使用值
- `enum_from_api` — 查询时从 API 获取枚举；调用指定接口获取列表后再基于用户指令进行映射
- `user_data_from_api` — 从 API 获取用户特定数据；调用指定接口获取用户自己的数据后再映射
- `user_input` — 从用户指令中提取

---

## 一、Pool 归一化

| 流程层 pool | `crm-search --pool` | 说明 |
|------------|---------------------|------|
| `private` | `private` | 直接映射 |
| `public-only` | `public` | 不得传 `public-only` |
| `public+external` | `public`（仅内部查询段） | 外部走 Phase 6 |
| CRM record inspection | `all` | 可能在公海或私海 |

**禁止** 使用 `OFFICIAL`、`public-only` 等非法值。

**⚠️ HKTW 公海搜索约束：** HKTW CRM 没有 `country` 字段做范围限定（与 Global CRM 不同）。搜索范围完全由 `--org-id` + `--sales-id` 限定。为确保公海查询结果准确，需注意：
- `--pool public` 仅查公海客户，`--pool private` 仅查本销售私海客户
- 若 `--pool public` 返回结果中混入了私海或非本销售客户，应检查 `--org-id` 和 `--sales-id` 是否正确（必须来自 Phase 3 的 `crm-roles` 返回值）
- **对比 Global CRM**：Global 通过 `--pool public` + `-c country=XX` 双重限定；HKTW 通过 `--pool public` + `--org-id/--sales-id` 双重限定，效果等价

---

## 二、查询字段定义

### 精确查找字段

#### 公司名称
- **查询 key：** `company_name_gb`
- **Intent Struct 来源：** `company_name_hint`
- **转换规则：** 分词检索，直接查询即可,但需要简体中文

#### 邮箱
- **查询 key：** `email`
- **Intent Struct 来源：** `email_hint`
- **转换规则：** 精确查询

#### Member ID
- **查询 key：** `member_id`
- **转换规则：** 仅用户明确提供时使用


### 筛选类字段

#### 合作状态
- **查询 key：** `contract_status`
- **含义：** 客户的合作阶段状态
- **典型用户表达：** "已合作的"、"还没签约的"、"潜在客户"
- **值类型：** `enum_fixed`
- **取值范围：**

| 枚举值 | 含义 |
| :--- | :--- |
| `25` | 断约1年内 |
| `20` | 断约超1年 |
| `15` | 合同作废 |
| `10` | 未签约 |

#### 兴趣指数
- **查询 key：** `willing_level`
- **Intent Struct 来源：** `interest_level`
- **含义：** 客户对平台的意向强度
- **典型用户表达：** "高意向的"、"主动联系过的"、"没兴趣的"、"互动过的"
- **值类型：** `enum_fixed`
- **取值范围与映射：**

| 枚举值 | 含义 | 映射 |
| :--- | :--- | :--- |
| `3` | 高兴趣（主动） | 高意向/积极 |
| `2` | 中兴趣（互动） | 有互动/参与过 |
| `1` | 低兴趣（认知） | 知道但没行动 |
| `0` | 无兴趣（无感） | 无反馈/冷 |

### 时间类字段

#### 创建时间
- **查询 key：** `gmt_create`
- **含义：** 线索创建的时间
- **典型用户表达：** "新创建的"、"最近录入的"、"X 日期后创建的"
- **值类型：** `user_input`
- **取值范围：** 10 位时间戳，查询条件 GE / LE

#### 拜访时间
- **查询 key：** `last_visit_time`
- **含义：** 最近一次拜访该线索的时间
- **典型用户表达：** "最近拜访过的"、"X 天内跟进的"
- **值类型：** `user_input`
- **取值范围：** 10 位时间戳，查询条件 GE / LE

#### 开放时间
- **查询 key：** `distribute_date`
- **含义：** 线索被开放到公海的时间
- **典型用户表达：** "最近开放的"、"刚放出来的"
- **值类型：** `user_input`
- **取值范围：** 10 位时间戳，查询条件 GE / LE

#### 到公海时间
- **查询 key：** `open_time`
- **含义：** 线索进入公海的时间
- **典型用户表达：** "最近进池的"、"新到公海的"
- **值类型：** `user_input`
- **取值范围：** 10 位时间戳，查询条件 GE / LE

### 标签类字段

#### 标签取值方式说明
- **固定标签**（常用筛选、基本信息、电商外贸、客户行为、企业实力、金品诚企）：值类型为 `enum_fixed`，枚举值见下方各表。
- **动态标签**（大区专享、个人标签）：值类型为 `enum_from_api`，必须调用 `crm-tag` 获取当前可用的 tagId 列表。

#### 常用筛选
- **值类型：** `enum_fixed`（基础字段的预设组合）

| 标签值 | 含义 | 搜索条件 |
| :--- | :--- | :--- |
| 1日内有leads | 最近 1 天内有新 leads 进入 | `g06_last_leads_time` GE 昨天当前时间的时间戳 |
| 7日内有leads | 最近 7 天内有新 leads 进入 | `g06_last_leads_time` GE 上周当前时间的时间戳 |
| 2日内强开 | 最近 2 天内被强制开放的线索 | `target_open_time` GT 0 AND `target_open_time` LT 3 |
| 一周内开放 | 最近 7 天内开放的线索 | `target_open_time` GT 0 AND `target_open_time` LT 8 |
| 线下展会 | 参加过线下展会的线索 | `distinctprototag` EQ 190088 |
| 蓝海行业定招 | 蓝海行业招商定向线索 | `distinctprototag` EQ 518484 |
| 行业RTS招商 | 行业 RTS 招商标记的线索 | `distinctprototag` EQ 218883 |
| CC外呼意愿 | 被 CC 外呼且有意愿的线索 | `g06_last_leads_origin` EQ 60001 AND `g06_last_leads_time` GT 120天前时间戳 |
| 小满高潜 | 小满高潜客户 | `distinctprototag` EQ 616081 |

#### 基本信息

| 标签值 | 含义 | 搜索条件 |
| :--- | :--- | :--- |
| 新注册企业 | 近期新注册的企业 | `distinctprototag` EQ 536367 |

#### 电商外贸

| 标签值 | 含义 | 搜索条件 |
| :--- | :--- | :--- |
| 电商企业 | 本身有电商业务的企业 | `distinctprototag` EQ 533136 |
| 天淘商家 | 天猫或淘宝平台的商家 | `distinctprototag` EQ 533395 |
| AE 商家 | AliExpress 平台的商家 | `distinctprototag` EQ 533240 |
| 1688商家 | 1688 平台的商家 | `distinctprototag` EQ 633981 OR `distinctprototag` EQ 633842 |
| 外贸企业 | 有外贸业务的企业 | `distinctprototag` EQ 533414 |
| 活跃外贸企业 | 外贸活跃度高的企业 | `g06_last_leads_origin` IN [30012, 30014, 30016] |
| 外贸招聘 | 当前有外贸相关岗位招聘的企业 | `distinctprototag` EQ 181540 |
| 竞对卖家 | 竞争对手平台上的卖家 | `distinctprototag` IN [209247, 209127, 190084, 190086] |
| 钉钉外贸企业 | 使用钉钉且有外贸业务的企业 | `distinctprototag` EQ 196193 |

#### 客户行为

| 标签值 | 含义 | 搜索条件 |
| :--- | :--- | :--- |
| CC外呼意愿 | CC 外呼后表达有意愿 | `g06_last_leads_origin` EQ 60001 AND `g06_last_leads_time` GT 120天前时间戳 |
| 举个栗子 | 举个栗子活动参与者 | `g06_last_leads_origin` EQ 110 AND `g06_last_leads_time` GT 180天前时间戳 |
| 电话咨询 | 曾进行电话咨询 | `g06_last_leads_origin` EQ 6 AND `g06_last_leads_time` GT 180天前时间戳 |
| 官网入驻意愿 | 在官网上表达过入驻意愿 | `g06_last_leads_origin` IN [73,72,71,74,57,51,75,52,22201,58,26001,76021] AND `g06_last_leads_time` GT 180天前时间戳 |
| 官网互动行为 | 在官网有过互动行为 | `g06_last_leads_origin` IN [76012,67,66,56,62,76011,61,76022,8300201,75108,75107,76021,69] AND `g06_last_leads_time` GT 180天前时间戳 |
| 国际站意愿 | 对国际站表达过意愿 | `g06_last_leads_origin` IN [501,85101,502,203,505,10055,10550,11006,17002,20017,20018,504,11049,11051,30000,30001,80019] AND `g06_last_leads_time` GT 180天前时间戳 |
| 国际站行为 | 在国际站有过行为动作 | `g06_last_leads_origin` IN [50,100,506,511,512,513,514,515,516,517,518,519,520,521,522,524,21,22,11012,16000,16001,16002,16003,16527,11008,85102,85103,85104,85105,85106] AND `g06_last_leads_time` GT 180天前时间戳 |
| 报名活动 | 报名过相关活动 | `g06_last_leads_origin` IN [80028,80029,80031,80032] AND `g06_last_leads_time` GT 180天前时间戳 |
| 社媒入驻意愿 | 在社交媒体上表达过入驻意愿 | `g06_last_leads_origin` IN [81005,20010,87032,87031,81004,87041,20006,20033,20003,80009,20004,87033,87011,87021,81002,20007,81003,20005,20002,20001] AND `g06_last_leads_time` GT 180天前时间戳 |
| 投放潜客 | 通过投放渠道来的潜在客户 | `g06_last_leads_origin` IN [66667,83007,85005,83006,4702,85004,83009,83002,85013,83000,83005,83017,85011,85007,85003,83015,83013,82006,83004,83001,83003,83010,83008,20000,85008,66666,83014,85012,80019,66668,47,4701,85006,85009,85010,82004,85001,85002,85014,85015,40] AND `g06_last_leads_time` GT 180天前时间戳 |
| 公海激活 | 在公海中有激活行为 | `g06_last_leads_origin` IN [20025,20035,507,525,64,20021] AND `g06_last_leads_time` GT 180天前时间戳 |
| 外部合作意愿 | 表达过外部合作意愿 | `g06_last_leads_origin` IN [82014,82009,82050,82013,82012,82001,82002,82026,82008,82015,82029,82005,82016,82011,82007,20019] AND `g06_last_leads_time` GT 180天前时间戳 |
| 参加活动 | 参加过相关活动 | `distinctprototag` EQ 564593 |
| 行业营销意愿 | 有行业营销相关意愿 | `distinctprototag` EQ 565282 |

#### 企业实力

| 标签值 | 含义 | 搜索条件 |
| :--- | :--- | :--- |
| 线下展会 | 参加过线下展会 | `distinctprototag` EQ 190088 |
| 蓝海行业定招 | 蓝海行业招商定向 | `distinctprototag` EQ 518484 |
| 行业RTS招商 | 行业 RTS 专项招商 | `distinctprototag` EQ 218883 |

#### 金品诚企

| 标签值 | 含义 | 搜索条件 |
| :--- | :--- | :--- |
| 行业领袖潜客 | 有潜力成为行业领袖认证的客户 | `distinctprototag` EQ 603281 |
| 实力星选（2星） | 已达到 2 星实力星选认证 | `distinctprototag` EQ 213560 |
| 品质优商（3星） | 已达到 3 星品质优商认证 | `distinctprototag` EQ 213561 |
| 金品续签 | 金品诚企续签客户 | `distinctprototag` EQ 214027 |

#### 大区专享 & 个人标签
- **值类型：** `enum_from_api`
- **动作：** 必须调用 `crm-tag` 获取当前标签列表及 tagId。

---

## 三、预调用（按需缓存）

| 工具 | 命令 | 触发条件 |
|------|------|----------|
| 地址映射 | `ggs-crm crm-address --country {TW/HK}` | location 相关字段非空 |
| 标签映射 | `ggs-crm crm-tag --sales-id {id} --org-id {id}` | 涉及大区专享 / 个人标签 |
| 行业映射 | `ggs-crm industry-mapping` | 涉及行业筛选 |

---

## 四、time_hint 推断规则

| 优先级 | 条件 | 映射查询 key |
|-------|------|-------------|
| 1 | 明确说"拜访/跟进时间" | `last_visit_time` |
| 1 | 明确说"开放/放出来" | `distribute_date` |
| 1 | 明确说"进池/到公海" | `open_time` |
| 2 | pool=private，未明确说 | `last_visit_time` |
| 2 | pool=public，未明确说 | `distribute_date`|

---

## 五、查询条件结构

`crm-search -c` 接收 JSON 条件组数组。具体参数格式见 `crm-api-reference.md`。

**约束：**
- `key` 必须来自本文件第二节的查询 key
- 所有值均为字符串（数字也加引号）
- 时间范围字段（`gmt_create`、`last_visit_time`、`distribute_date`、`open_time`）仅支持 `GE` `LE` `GT` `LT`，值为单个时间戳字符串
- 时间范围查询用两条条件组合（如 `GT` + `LT`），**禁止使用 `BETWEEN`**
- 多等级筛选需用 OR 条件组，不伪造数组值

---

## 六、排序映射

| Intent 信号 | `--sort` 参数 |
|------------|--------------|
| 按意向/按质量/高意向优先 | `model_rank_score:desc` |
| 最近拜访/最近跟进 | `last_visit_time:desc` |
| 最近开放/最近放出来 | `open_time:desc` |
| 最新创建 | `gmt_create:desc` |
| 无明确排序 + public | `model_rank_score:desc` |
| 无明确排序 + private | `last_visit_time:desc` |


---

## 七、无结果放宽优先级

按以下顺序逐步放宽，每次放宽后重新查询，找到结果即停止并告知用户：

1. 标签筛选 → 逐步移除非核心标签（如海整售卖状态、金品诚企）
2. 兴趣指数 → 逐步放宽（如 主动 → 主动+互动 → 全部）
3. 时间范围 → 扩大窗口（如 7天 → 30天 → 90天）
4. 地区 → 扩大到附近县市或全区域
5. 行业 → 最后手段；通常是用户的核心意图

---
