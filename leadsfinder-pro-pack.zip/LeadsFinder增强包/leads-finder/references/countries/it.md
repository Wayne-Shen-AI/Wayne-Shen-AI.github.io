# Italy (IT) - 国家策略文件

本文件是意大利（IT）地区的专属执行知识库。当 Phase 2 路由结果为 `country=IT` 时加载本文件。

---

## Part 1: 数据源与搜索策略

意大利企业数据补全高度依赖官方或半官方商业目录平台。Exa Search（`accio-mcp-cli call web_search_exa`）优先用于发现高端制造与利基市场（Niche）工厂。

### 1.1 采集数据源意图映射

| 用户意图 | 主数据源 | 采集方式 | Fallback |
|---------|---------|---------|----------|
| 泛搜工厂 | Exa Search | `accio-mcp-cli call web_search_exa --query '"{industry}" fabbrica produzione italia' --num_results 15` | Google 搜索 |
| 出口商 | Exa Search | `accio-mcp-cli call web_search_exa --query '"{industry}" esportatore produttore italia' --num_results 15` | — |
| 竞品发现 | Exa Similar | `accio-mcp-cli call find_similar_pages_exa --url "{参照公司官网}" --num_results 10` | — |
| 营收/员工查询 | Report Aziende | reportaziende.it/cerca，输入 11 码 VAT | — |
| 企业工商验证 | 官网 Footer | 寻找 "P.IVA" 或 "Partita Iva" | Google 搜索 "{company} partita iva" |

### 1.2 关键词本地化规则

**强制使用意大利语。**

| 英文 | 意大利语 |
|------|---------|
| factory / manufacturer | fabbrica / produttore |
| exporter | esportatore |
| furniture | mobili / arredamento |
| company | azienda |
| revenue | fatturato |
| employees | dipendenti |

---

## Part 2: 字段补全指引

### 去重主键优先级

`VAT Number (P.IVA)` > `website（域名）` > `company_name + city`

### P0 级别字段（核心）

#### 1. VAT Number (P.IVA / Partita IVA) 【去重主键 + 核心阻断点】

- **定义：** 意大利增值税号，11 位数字。
- **补全指引：** 官网 Footer 或 Privacy Policy，寻找 "P.IVA" 或 "Partita Iva"。
- **格式清洗：** 去掉 "IT" 前缀，仅保留 11 位数字。
- **阻断规则：** **找不到 VAT Number → 严禁继续查找营收等信息，直接跳过。**

#### 2. Revenues (Fatturato) & Employees (Dipendenti)

- **补全指引：** 访问 `reportaziende.it`，使用 VAT 搜索。
- 获取 "Fatturato"（营收）和 "Numero dipendenti"（员工数）。
- **前提：** 必须已获得 VAT Number。

#### 3. 联络人 / 电话 / Email / 网站

- 邮箱和电话优先从官网 Contact 页面获取。
- 电话格式：+39 开头。

#### AI Summary

- 若无额外信息，填 `N/A`。

---

## Part 3: 去重与校验规则

### 3.1 去重主键字段

| 优先级 | 字段 | 说明 |
|-------|------|------|
| 1 | VAT (P.IVA) | 11 位数字，去掉 IT 前缀 |
| 2 | website（域名） | .it 域名常见 |
| 3 | company_name + city | — |

### 3.2 联系方式校验

| 项目 | 规则 |
|------|------|
| 电话格式 | +39 开头 |
| 主要 IM 渠道 | WhatsApp > LinkedIn |

### 3.3 crm-dedup 字段选择

```json
{
  "uid": "序号",
  "companyName": "英文名或意语名",
  "country": "IT",
  "email": "联系邮箱",
  "registerNumber": "P.IVA（如已获取）"
}
```

---

## Part 4: 输出格式

### 4.1 用户输出表格

| Company Name | Domain | VAT (P.IVA) | Revenues | Employees | Industry | First Name | Last Name | Email | Phone | CRM Detail | AI Summary |
|--------------|--------|-------------|----------|-----------|----------|------------|-----------|-------|-------|------------|------------|
| AMP Spa | amp.it | 12345678901 | € 1.5M | 15 | Furniture | Mario | Rossi | info@amp.it | +39 02 1234 | [详情](https://crm.alibaba-inc.com/crmagent/romeo/public-sea/customer-detail.html?globalId=xxx) | N/A |

### 4.2 输出要求

1. 缺失字段填 `N/A`。
2. 附 Result Summary + Data Provenance Table。
3. **CRM Detail 列**：仅 CRM 内已有客户（`globalId` 非空）展示详情页链接（`detailUrl`），外部新发现的线索填 `N/A`。链接使用 Markdown 格式 `[详情](url)` 展示。

### 4.3 CRM 写回：意大利专属规则

完整的 write-back mapping 表见 `crm-api-reference.md`「Enrichment → companyData 写回映射」。以下为意大利的国家级 override：

| 规则 | 说明 |
|------|------|
| `registerNumber` **选填** | 意大利的 VAT 不是 CRM 写回的条件必填，但强烈建议提供 |
| VAT 格式 | 写回前确保已去掉 "IT" 前缀，保留 11 位数字 |
| `province` / `city` 需转码 | 调 `crm-address --country IT` 获取编码 |
