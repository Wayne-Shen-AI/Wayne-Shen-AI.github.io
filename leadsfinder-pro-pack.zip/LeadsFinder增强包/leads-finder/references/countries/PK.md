# Pakistan (PK) - 国家策略文件

本文件是巴基斯坦（PK）地区的专属执行知识库。当 Phase 2 路由结果为 `country=PK` 时加载本文件。
后续的外部发现（Phase 6）、补全验证（Phase 7）、判重（Phase 8）、写回（Phase 11）必须遵循本文件的规则。

---

## Part 1: 数据源与搜索策略

巴基斯坦企业（特别是 Sialkot 产业集群）高度依赖 Facebook（Group 和 Page）进行 B2B 营销，同时其商会（Chamber of Commerce）数据非常权威。

### 1.1 采集数据源意图映射

| 用户意图 | 主数据源 | 采集方式 | Fallback |
|---------|---------|---------|----------|
| Sialkot 制造商 | Facebook Groups | 搜索 "Sialkot Export", "Manufacturers Sialkot" | SCCI (scci.com.pk) |
| 出口商/Exporter | LinkedIn / ImportYeti | 搜索 "Pakistan {keyword} exporters" | Panjiva / TradeMap |
| 联系方式补全 | Facebook Page / WhatsApp | 从 FB About 或帖子提取 | 官网 / contact 页面 |
| 工商验证 | SCCI / NTN Verification | 搜索公司名 + SCCI | FBR (fbr.gov.pk) |
| 行业协会 | PRGMEA / PGMEA / SIMAP | 协会官网会员名单 | — |

### 1.2 关键词本地化规则

巴基斯坦外贸通用语言为**英语**，搜索时无需强制翻译为乌尔都语，但可结合行业热词：

| 英文 | 行业/属性 |
|------|--------|
| manufacturer / factory | 制造/工厂 |
| sports goods / activewear | 体育用品/运动服 (Sialkot 核心) |
| surgical instruments | 手术器械 (Sialkot 核心) |
| leather products | 皮革制品 |
| Himalayan salt | 喜马拉雅盐 (Karachi/Khewra 核心) |
| rice / textile | 大米/纺织 |

---

## Part 2: 字段补全指引

### 去重主键优先级

`NTN (National Tax Number)` > `website` > `company_name_en`

### P0 级别字段（核心）

#### 1. Phone / WhatsApp
- **定义：** 巴基斯坦企业最核心的联络方式。
- **格式：** `+92` 开头。巴基斯坦手机通常为 10 位（去掉首位 0 后为 3xx-xxxxxxx）。
- **优先级：** WhatsApp 状态（在 FB 帖子中经常出现） > 官网 > 黄页。

#### 2. Social Media (Facebook)
- **重要性：** 极高。巴基斯坦许多 B2B 工厂甚至没有官网，但一定有活跃的 Facebook Page。
- **输出：** 必须包含完整的 Facebook Page URL。

---

## Part 3: CRM 写回规则 (Neo 专属逻辑)

### 3.1 组织路由 (Org Routing) - 关键

**强制规则：** 巴基斯坦 (PK) 线索写回时，必须使用 **Alibaba Pakistan** 组织权限。

- **Org ID:** `110313935` (Alibaba Pakistan)
- **Sales ID:** `zy01976568` (Neo)

### 3.2 判重与地址

- **判重字段：** `companyName` + `country: "PK"`。
- **地址编码：** 写回前必须调用 `crm-address --country PK` 获取省/市编码。
  - **Sialkot:** Province `916000050000000000`, City `916000050172000000`
  - **Karachi:** Province `916000080000000000`, City `916000080188000000`

---

## Part 4: 输出格式

使用标准 B2B 线索表，重点突出 WhatsApp 和 Facebook 链接。
缺失字段填 `N/A`。
数据来源必须包含 Facebook 帖子或 Page 证据。
