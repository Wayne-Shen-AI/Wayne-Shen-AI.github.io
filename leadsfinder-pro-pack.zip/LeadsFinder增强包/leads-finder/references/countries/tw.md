# Taiwan (TW) - 国家策略文件

本文件是台湾（TW）地区的专属执行知识库。当 Phase 2 路由结果为 `country=TW` 时加载本文件。

**CRM 注意：** TW 属于 HKTW CRM family。CRM 内部查询/判重/写回均可用。

---

## Part 1: 数据源与搜索策略

台湾地区的数据源分为政府公示系统、竞对平台、行业协会和展会四大类。

### 1.1 采集数据源意图映射

| 用户意图 | 主数据源 | 采集方式 | Fallback |
|---------|---------|---------|----------|
| 泛搜工厂 | Exa Search | `accio-mcp-cli call web_search_exa --query '"{industry}" 台灣 製造商' --num_results 15` | Google 搜索 |
| 出口商 | Exa Search | `accio-mcp-cli call web_search_exa --query '"{industry}" 台灣 出口商 推薦' --num_results 15` | — |
| 竞品发现 | Exa Similar | `accio-mcp-cli call find_similar_pages_exa --url "{参照公司官網}" --num_results 10` | — |
| 精准校验 | FindBiz | findbiz.nat.gov.tw 输入统编 | — |
| 出口级距查询 | 贸易署 | fbfh.trade.gov.tw 输入统编 | — |
| 联系方式/员工数 | 104/1111 人力银行 | `web_search` + `web_fetch` | LinkedIn |

### 1.2 关键词本地化规则

**强制使用繁体中文。**

| 英文 | 繁体中文 |
|------|---------|
| manufacturer | 製造商 |
| factory | 工廠 |
| exporter | 出口商 |
| electronics | 電子零組件 |
| textiles | 紡織 |
| trading company | 貿易商 |

### 1.3 核心政府数据源（必查）

| 数据源 | URL | 用途 |
|--------|-----|------|
| 台灣商業登記網站 (FindBiz) | findbiz.nat.gov.tw | 企業名單、統編、負責人、資本額、地址、在營狀態 |
| 貿易署出進口廠商資料 | fbfh.trade.gov.tw | 年出口實績級距（需先有統編） |

---

## Part 2: 字段补全指引

### 去重主键优先级

`統一編號` > `website（域名）` > `公司全名（繁中）`

### P0 级别字段（核心）

#### 1. 公司全名（繁中）

- **定义：** 包含完整法律後綴（如「股份有限公司」「有限公司」）的繁體中文名稱。
- **补全指引：** 從官網 Footer 或 FindBiz 獲取。

#### 2. 統一編號 【去重主键】

- **定义：** 台灣企業唯一身份證，固定 8 位數字。
- **补全指引：** 來源：FindBiz（findbiz.nat.gov.tw）。
- **阻斷規則：** 若找不到統編，後續出口級距無法查詢，**應停止該筆資料開發**。

#### 3. 負責人姓名

- **补全指引：** FindBiz 系統獲取。

#### 4. 產業

- **补全指引：** FindBiz 或 104/1111 人力銀行。

#### 5. 電話/手機

- **格式要求：** `886+區號+號碼`（如 `886+2+87972088`）。

#### 6. Email

- **补全指引：** 優先 LinkedIn、官網 Contact 頁面。

#### 7. 地址

- **补全指引：** FindBiz 獲取。

#### 8. 員工人數

- **补全指引：** 104/1111 人力銀行。必須提供具體數字（如「85人」），嚴禁模糊範圍。

#### 9. 資本額

- **补全指引：** FindBiz。統一以 TWD 為單位（如「5,000,000 TWD」）。

#### 10. 出口級距

- **定义：** 決定該客戶是否為優質對標對象的關鍵指標。
- **补全指引：** 貿易署（fbfh.trade.gov.tw），需先有統編。
- **级距标准：** A級（1000萬USD+）、B級（500萬-1000萬USD）、C級（500萬USD以下）。

#### 11. 社媒資訊

- **格式要求：** 必須是完整 URL（如 `https://www.facebook.com/company`），禁止只寫「FB」或「LinkedIn」。

#### 12. 網站

- **格式要求：** 移除 `https://`，保留主域名。

#### AI Summary

- 若無額外信息，填 `N/A`。

---

## Part 3: 去重与校验规则

### 3.1 去重主键字段

| 优先级 | 字段 | 说明 |
|-------|------|------|
| 1 | 統一編號 | 8 位數字 |
| 2 | website（域名） | 去除協議頭後比較 |
| 3 | 公司全名（繁中）+ 縣市 | — |

### 3.2 联系方式校验

| 项目 | 规则 |
|------|------|
| 電話格式 | 886+區號+號碼 |
| 主要 IM 渠道 | LINE > Facebook Messenger |

### 3.3 crm-dedup 字段选择

```json
{
  "uid": "序号",
  "companyName": "公司英文名或繁中名",
  "country": "TW",
  "email": "联系邮箱",
  "registerNumber": "統一編號（如已获取）"
}
```

---

## Part 4: 输出格式

### 4.1 用户输出表格

| 公司全名 | 統一編號 | 負責人 | 產業 | 電話/手機 | Email | 地址 | 員工人數 | 資本額 | 出口級距 | 社媒資訊 | 網站 | CRM 詳情 |
|----------|----------|--------|------|-----------|-------|------|----------|--------|----------|----------|------|----------|
| 台達電子工業股份有限公司 | 11089653 | 海英俊 | 電子零組件 | 886+2+87972088 | info@deltaww.com | 台北市內湖區瑞光路186號 | 80,000+ | 25.9B TWD | A級 | https://linkedin.com/company/delta-electronics | deltaww.com | [詳情](https://crm.alibaba-inc.com/crmagent/romeo/public-sea/customer-detail.html?globalId=xxx) |

### 4.2 CSV 列定义

```
index, source, company_name_en, company_name_local, country, province, city, address,
industry, industryId, tax_id, phone, email, website,
key_person_family_name, key_person_given_name,
globalId, pool, orgId, ownerId, detailUrl,
confidence, aiSummary, aiMatcher, qualityTags, dataSources, commandResult
```

### 4.3 输出要求

1. `統一編號` 保持 8 位數字格式顯示。
2. 缺失字段填 `N/A`。
3. 附 Result Summary + Data Provenance Table。
4. Phone 必須為 `886+區號+號碼` 格式。
5. 統編阻斷：如果某條線索沒有統一編號且沒有官網，置信度標記為 `low`。
6. **CRM 詳情列**：僅 CRM 內已有客戶（`globalId` 非空）展示詳情頁連結（`detailUrl`），外部新發現的線索填 `N/A`。連結使用 Markdown 格式 `[詳情](url)` 展示。

### 4.4 CRM 写回：台湾专属规则

完整的 write-back mapping 表见 `crm-api-reference.md`「Enrichment → companyData 写回映射」。以下为台湾的国家级 override：

| 规则 | 说明 |
|------|------|
| `registerNumber` **必填** | 台湾线索写回时統一編號为必填。没有 → 阻断写回。写回时保持 8 位数字 |
| `province` / `city` 需转码 | 不能直接写入"台北市"，必须先调 `crm-address --country TW` 获取编码 |
| `companyNameEn` 必填 | 如只有繁中名且无英文名 → 阻断写回 |
| `phone` 格式 | 必须为 886+区号+号码 格式，写回前校验 |
