# Default / Global - 国家策略文件（Fallback）

本文件是通用 Fallback 知识库。当用户意图中的国家未匹配到专属配置文件（如 VN、IT、TW、KR、ES 等）时，加载本文件。

---

## Part 1: 数据源与搜索策略

对于没有特定本地工商库的国家，依赖跨国界的通用数据平台。

### 1.1 采集数据源意图映射

| 用户意图 | 主数据源 | 采集方式 | Fallback |
|---------|---------|---------|----------|
| 泛搜工厂 | Exa Search | `accio-mcp-cli call web_search_exa --query '"{local_industry} {local_factory} in {country}"' --num_results 15` | `google-search` |
| 出口商 | Exa Search | `accio-mcp-cli call web_search_exa --query '"top {country} {industry} exporters and manufacturers"' --num_results 15` | ImportYeti |
| 竞品发现 | Exa Similar | `accio-mcp-cli call find_similar_pages_exa --url "{参照公司官网}" --num_results 10` | — |
| 某地区工厂 | Google Maps | `google-map --city "{city}" -c {country} --company-type "{industry}"` | Google 搜索 |
| 联系方式补全 | 官网 Contact 页面 | `web-scrape` 或 `web_fetch` | Google 搜索 |
| 通用搜索 | `web_search` / `google-search` | 英文 + 本地语言并发 | — |

### 1.2 关键词本地化规则

**强制执行：** 在发起任何搜索前，必须将行业关键词和"工厂"、"制造"、"出口"翻译为目标国家的官方语言。生成 1 组英文关键词 + 1 组本地语言关键词并发搜索。

---

## Part 2: 字段补全指引

### 去重主键优先级

`website（域名）` > `company_name + country`

### 必须补全的字段

#### 1. Company Name 【去重主键辅助】

- **补全指引：** 优先从官网或 LinkedIn 公司主页提取官方名称。

#### 2. Website 【去重主键】

- **补全指引：** 移除 `www.` 和协议头。严禁使用 B2B 平台商铺链接代替官网。

#### 3. Contact Email & Phone

- **补全指引：** 访问官网 Contact 页面。电话必须包含国际区号。

#### 4. Is Exporter

- **判断依据：** 检查官网文本是否包含 FOB、CIF、MOQ、Export、Global Shipping 等外贸术语。

#### 5. Industry

- **补全指引：** 从官网产品页或搜索结果推断。映射到 CRM 行业 ID（见 `global-field-schema.md`）。

#### AI Summary

- 若无额外信息，填 `N/A`。

---

## Part 3: 去重与校验规则

### 3.1 去重主键字段

| 优先级 | 字段 | 说明 |
|-------|------|------|
| 1 | website（域名） | 通用最可靠标识 |
| 2 | company_name + country | 名称 + 国家组合 |

### 3.2 联系方式校验

| 项目 | 规则 |
|------|------|
| 电话格式 | 必须包含国际区号（如 +1、+49、+66 等） |
| 主要 IM 渠道 | 因国家而异，无默认偏好 |

### 3.3 crm-dedup 字段选择

```json
{
  "uid": "序号",
  "companyName": "公司英文名",
  "country": "国家代码",
  "email": "联系邮箱"
}
```

注意：通用 fallback 下大多数国家 `registerNumber` 不是必填，如有则提供。

---

## Part 4: 输出格式

### 4.1 用户输出表格

| Company Name | Website | Phone | Email | Industry | Is Exporter | Confidence | CRM Detail | AI Summary |
|--------------|---------|-------|-------|----------|-------------|------------|------------|------------|
| Example Corp | example.com | +1 234 567 8900 | info@example.com | Manufacturing | Yes | High | [详情](https://crm.alibaba-inc.com/crmagent/romeo/public-sea/customer-detail.html?globalId=xxx) | N/A |

### 4.2 输出要求

1. 缺失字段填 `N/A`。
2. 附 Result Summary + Data Provenance Table。
3. **CRM Detail 列**：仅 CRM 内已有客户（`globalId` 非空）展示详情页链接（`detailUrl`），外部新发现的线索填 `N/A`。链接使用 Markdown 格式 `[详情](url)` 展示。

### 4.3 CRM 写回：通用规则

完整的 write-back mapping 表见 `crm-api-reference.md`「Enrichment → companyData 写回映射」。以下为通用 override：

| 规则 | 说明 |
|------|------|
| `registerNumber` **选填** | 通用 fallback 下不强制要求 |
| `province` / `city` 需转码 | 调 `crm-address --country {country}` 获取编码 |
| `companyNameEn` 必填 | 如无英文名 → 阻断写回 |
