# Spain (ES) - 国家策略文件

本文件是西班牙（ES）地区的专属执行知识库。当 Phase 2 路由结果为 `country=ES` 时加载本文件。

---

## Part 1: 数据源与搜索策略

西班牙企业数据补全采用分层执行策略。Exa Search（`accio-mcp-cli call web_search_exa`）优先用于发现出口型（Exportadores）工厂。

### 1.1 采集数据源意图映射

| 用户意图 | 主数据源 | 采集方式 | Fallback |
|---------|---------|---------|----------|
| 泛搜工厂 | Exa Search | `accio-mcp-cli call web_search_exa --query '"{industry}" fábrica fabricación españa' --num_results 15` | Google 搜索 |
| 出口商 | Exa Search | `accio-mcp-cli call web_search_exa --query '"{industry}" exportadores fabricantes españa' --num_results 15` | — |
| 竞品发现 | Exa Similar | `accio-mcp-cli call find_similar_pages_exa --url "{参照公司官网}" --num_results 10` | — |
| 营收/员工查询 | Iberinform | www.iberinform.es，输入 9 码 VAT/NIF | — |
| 企业工商验证 | 官网 Footer | 寻找 "NIF" 或 "IVA" | Google 搜索 "{company} NIF" |

### 1.2 关键词本地化规则

**强制使用西班牙语。**

| 英文 | 西班牙语 |
|------|---------|
| factory / manufacturer | fábrica / fabricante |
| exporter | exportador |
| furniture | muebles |
| company | empresa |
| revenue | facturación |
| employees | empleados |

---

## Part 2: 字段补全指引

### 去重主键优先级

`VAT Number (NIF)` > `website（域名）` > `company_name + city`

### P0 级别字段（核心）

#### 1. VAT Number (NIF/IVA) 【去重主键 + 核心阻断点】

- **定义：** 西班牙税号，9 位字符（1 位字母 + 7 位数字 + 1 位校验码）。
- **补全指引：** 官网 Footer 或 Privacy Policy，寻找 "NIF" 或 "IVA"。
- **格式清洗：** 去掉 "ES" 前缀，保留 9 位字符。
- **阻断规则：** **找不到 VAT Number → 严禁继续查找营收等信息，直接跳过。**

#### 2. Revenues (Facturación) & Employees (Empleados)

- **补全指引：** 访问 `www.iberinform.es`，使用 VAT 搜索。
- 获取 "Tramo de facturación"（营收区间）和 "Empleados"（员工数）。
- **前提：** 必须已获得 VAT Number。

#### 3. 联络人 / 电话 / Email / 网站

- 邮箱和电话优先从官网 Contact 页面获取。
- 电话格式：+34 开头。

#### AI Summary

- 若无额外信息，填 `N/A`。

---

## Part 3: 去重与校验规则

### 3.1 去重主键字段

| 优先级 | 字段 | 说明 |
|-------|------|------|
| 1 | VAT (NIF) | 9 位字符，去掉 ES 前缀 |
| 2 | website（域名） | .es 域名常见 |
| 3 | company_name + city | — |

### 3.2 联系方式校验

| 项目 | 规则 |
|------|------|
| 电话格式 | +34 开头 |
| 主要 IM 渠道 | WhatsApp > LinkedIn |

### 3.3 crm-dedup 字段选择

```json
{
  "uid": "序号",
  "companyName": "英文名或西语名",
  "country": "ES",
  "email": "联系邮箱",
  "registerNumber": "VAT/NIF（如已获取）"
}
```

---

## Part 4: 输出格式

### 4.1 用户输出表格

| Company Name | Domain | VAT (NIF) | Revenues | Employees | Industry | First Name | Last Name | Email | Phone | CRM Detail | AI Summary |
|--------------|--------|-----------|----------|-----------|----------|------------|-----------|-------|-------|------------|------------|
| Ejemplo S.L. | ejemplo.es | B12345678 | € 1M - 2M | 10 - 50 | Furniture | Juan | Pérez | info@ejemplo.es | +34 91 123 | [详情](https://crm.alibaba-inc.com/crmagent/romeo/public-sea/customer-detail.html?globalId=xxx) | N/A |

### 4.2 输出要求

1. 缺失字段填 `N/A`。
2. 附 Result Summary + Data Provenance Table。
3. **CRM Detail 列**：仅 CRM 内已有客户（`globalId` 非空）展示详情页链接（`detailUrl`），外部新发现的线索填 `N/A`。链接使用 Markdown 格式 `[详情](url)` 展示。

### 4.3 CRM 写回：西班牙专属规则

完整的 write-back mapping 表见 `crm-api-reference.md`「Enrichment → companyData 写回映射」。以下为西班牙的国家级 override：

| 规则 | 说明 |
|------|------|
| `registerNumber` **选填** | 西班牙的 VAT 不是 CRM 写回的条件必填，但强烈建议提供 |
| VAT 格式 | 写回前确保已去掉 "ES" 前缀，保留 9 位字符 |
| `province` / `city` 需转码 | 调 `crm-address --country ES` 获取编码 |
