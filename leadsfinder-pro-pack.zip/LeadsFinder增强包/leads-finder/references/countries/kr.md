# South Korea (KR) - 国家策略文件

本文件是韩国（KR）地区的专属执行知识库。当 Phase 2 路由结果为 `country=KR` 时加载本文件。

---

## Part 1: 数据源与搜索策略

韩国互联网生态高度封闭，Google 渗透率低于 NAVER。数据源分为搜索引擎、政府公示系统、企业信息平台、垂直品类平台、行业协会与地方政府、展会以及 B2B 竞对平台。

### 1.1 采集数据源意图映射

| 用户意图 | 主数据源 | 采集方式 | Fallback |
|---------|---------|---------|----------|
| 某地区工厂/企业 | NAVER / Google Maps | `google-map` 按城市搜索 | `accio-mcp-cli call web_search_exa --query "..." --num_results 15` |
| 出口商 | Exa Search / TradeKorea | `accio-mcp-cli call web_search_exa --query "{韩语行业} 수출업체" --num_results 15` + `web_fetch` 抓取 TradeKorea | EC21 / Global Sources 韩国板块 |
| 竞品发现 | Exa Similar | `accio-mcp-cli call find_similar_pages_exa --url "{参照公司官网}" --num_results 10` | Kompass Korea |
| 企业工商验证 | Bizno.net / Moneypin.biz | `web-scrape` 或 `web_fetch` 按公司名/VAT 搜索 | 官网 Footer / FTC |
| 联系方式补全 | Naver 本地 API / 企业官网 | Naver 本地 API 为电话主要来源；官网多页面爬取 | Bizno / Moneypin |
| 域名发现 | Naver 搜索 API | LLM 根据标题+摘要+公司名选择官网 | Naver 地图（约 3% 覆盖率） |
| 展会参展商 | KINTEX / COEX 官网 | `web_fetch` 抓取参展商列表 | — |

### 1.2 关键词本地化规则

**强制要求：** 搜索前必须将关键词翻译为韩语。

| 英文 | 韩语 |
|------|------|
| manufacturer | 제조업체 |
| factory | 공장 |
| exporter | 수출업체 |
| cosmetics | 화장품 |
| electronics | 전자제품 |
| textiles | 섬유 |
| trading company | 무역회사 |

### 1.3 核心数据源

| 数据源 | URL | 用途 |
|--------|-----|------|
| NAVER 搜索 API | developers.naver.com | 域名发现（每 key 每日 25,000 次调用） |
| Naver 本地 API | developers.naver.com | 电话号码、地区确认 |
| Naver 地图 | map.naver.com | 域名、电话（约 3% 覆盖率） |
| Bizno.net | bizno.net | VAT 号、代表人、行业分类 |
| Moneypin.biz | moneypin.biz | VAT 号、代表人、营收区间 |
| 韩国公平交易委员会 (FTC) | ftc.go.kr | 工商注册验证、通信销售业申报 |
| FactoryOn 工厂登记 | factoryon.go.kr | 工厂登记信息 |

> ⚠ **Bizno/Moneypin IP 封锁：** 频繁访问会被封 IP，需 IP 轮换服务（如 Scraper API）。

### 1.4 垂直品类网站

| 行业 | 网站 | URL |
|------|------|-----|
| 机械/工业 | Komachine | komachine.com/ko |
| 机械 | Daara | mc.daara.co.kr |
| 美妆/护肤 | StyleKorean | stylekorean.com |
| 美妆 | SelfCos | selfcos.com |
| 纺织/服装 | KTextile | ktextile.net |
| 化工 | ChemKnock | chemknock.co.kr |
| 农业/食品 | Tridge | tridge.com/ko |

### 1.5 协会与认证

| 机构 | URL | 领域 |
|------|-----|------|
| Hi Seoul 优秀企业 | hiseoul.sba.kr | 首尔综合 |
| 首尔贸易平台 | tradeon.sba.kr | 首尔出口 |
| 韩国食药处 | nedrug.mfds.go.kr | 医药/医疗器械 |
| 新能源联盟 | ref.or.kr | 新能源 |
| 素部装 | sobujang.net | 材料/零部件/设备 |

### 1.6 B2B 平台

| 平台 | URL | 说明 |
|------|-----|------|
| TradeKorea | tradekorea.com | 韩国贸易协会官方 B2B |
| EC21 | ec21.com | 韩国 B2B |
| Kompass Korea | kr.kompass.com | 全球企业目录韩国站 |
| TradeWheel | tradewheel.com/suppliers/south-korea/ | 韩国供应商 |

---

## Part 2: 字段补全指引

### 去重主键优先级

`사업자등록번호（Business Registration No.）` > `website（域名）` > `회사명（公司韩文名）+ 地区`

### P0 级别字段（核心 / 阻断字段）

#### 1. 회사명 (Company Name) 【起始字段】

- **定义：** 企业韩文法定名称及英文名称。在平台爬取阶段采集，是后续所有补全的起点。
- **补全指引：** 优先从 FTC 登记信息或官网 Footer 提取。需包含 "(주)"（株式会社）等法律后缀。
- **匹配规则：**
  - 允许法律后缀差异：주식회사 / (주) / Co.,Ltd / Inc. 等
  - 允许标点差异：空格、句号(.)、连字符(-)
  - 例：`한국무역 주식회사` ↔ `한국무역(주)`
- **标准化：** 搜索前移除 주식회사、유한회사、(주)、(유) 等后缀。
- **阻断规则：** 若差异无法用上述规则解释 → 停止，不继续执行。
- **已知挑战：**
  - 大量公司同名 → 需使用地址辅助匹配
  - 品牌名 ≠ 法人实体名 → 品牌搜索可能无法匹配工商记录

#### 2. 사업자등록번호 (Business Registration No.) 【去重主键】

- **定义：** 韩国商业登记号，固定 10 位数字，格式 `XXX-XX-XXXXX`。
- **补全指引（按优先级）：**
  1. 官网页脚 — 关键词：사업자등록번호、사업자번호、Business Registration No.
  2. Bizno.net / Moneypin.biz — 按公司名搜索
  3. LLM 解析页脚非结构化文本（补充正则遗漏）
- **标准化：** 格式 `XXX-XX-XXXXX`（10 位数字，含连字符）。注意页脚边缘情况：ㅡ 代替 -、混合特殊字符、数字间有空格。
- **阻断规则：** 若无法确认 VAT 号 → 停止，不继续执行。
- ⚠ 纯 AI 采集准确率 < 30%，**必须**通过 Bizno/Moneypin 验证。
- ⚠ Bizno/Moneypin 频繁访问会封 IP → 需 IP 轮换。

#### 3. 회사 홈페이지 (Website)

- **定义：** 公司独立域名。韩国企业常用 `.co.kr` 或 `.kr`。
- **补全指引（按优先级）：**
  1. 平台爬取阶段已采集（约 10%，因平台而异）
  2. Naver 地图注册信息（约 3%）
  3. Naver 搜索 API — LLM 根据标题 + 摘要 + 公司名选择官网
  4. Bizno.net / Moneypin.biz
- **标准化：** 仅保留域名，去掉 `www.` / `http(s)://`。排除电商及招聘平台 URL：Coupang、Gmarket、Saramin、Jobkorea 等。严禁使用 B2B 平台商铺链接代替官网。
- ⚠ 约 70% 的韩国企业没有官网 — 找不到则留空。

### P1 级别字段（重要联系字段）

#### 4. 연락처 이메일 (Contact Email)

- **补全指引（按优先级）：**
  1. 平台爬取阶段已采集
  2. 官网爬取 — 页脚、联系页(Contact)、客服页(고객센터)、关于我们(About Us)、隐私政策页面
  3. Naver 地图爬取
  4. Bizno / Moneypin 邮箱字段
- **标准化：** 排除无效域名：CS 中心、no-reply、noreply、webmaster。
- ⚠ 退信率约 10%。批量发送到 Naver/Gmail 域名有被标记为垃圾邮件的风险。
- ⚠ 邮箱可能属于已离职员工。
- ⚠ 很多邮箱以图片或 JS 渲染 — 目前不支持提取（可通过 @sparticuz/chromium 解决）。
- 找不到则留空。

#### 5. 전화번호 (Phone Number)

- **补全指引（按优先级）：**
  1. 平台爬取阶段已采集（展会参展商列表）
  2. **Naver 本地 API — 大部分电话号码的主要来源**
  3. 官网页脚 — 关键词：전화、TEL、연락처
  4. Bizno / Moneypin 电话字段
- **标准化：**
  - 010 号码（个人手机）→ 排除在公司电话之外，单独分类
  - 采集时保留本地格式：区号-号码（如 `02-XXXX-XXXX` / `031-XXX-XXXX`）
  - CRM 写回时转为国际格式：首尔 `02-1234-5678` → `+82 2 1234 5678`；手机 `010-1234-5678` → `+82 10 1234 5678`
- ⚠ 官网解析经常返回无效数据（号码缺失或嵌入图片中）。
- ⚠ 总机号码接通转化率低 — 优先获取个人直线。
- 找不到则留空。

#### 6. 대표자명 (CEO / Representative Name)

- **补全指引（按优先级）：**
  1. Bizno.net 代表人字段 — 通过 VAT 号查询
  2. Moneypin.biz 代表人字段
  3. 官网 关于/公司介绍 页面，寻找"대표자"或"CEO"
- **姓名拆分规则：**
  - 第一个字 → 姓（Family Name）
  - 其余 → 名（Given Name）
  - 例：홍길동 → 姓：홍 / 名：길동
- ⚠ Bizno/Moneypin 的 IP 封锁问题同样适用。
- ⚠ 共同代表人或家族传承企业的信息可能已过时。
- ⚠ 多位代表人同名时存在歧义。

#### 7. 지역 (Region)

- **补全指引（按优先级）：**
  1. 平台爬取 / Bizno / Moneypin 采集公司名时附带的地址
  2. Naver 本地 API — 公司名 + 地址匹配确认地区
  3. 官网页脚地址
- **标准化：** 提取 시/도 + 시/군/구 级别。例：경기도 시흥시 / 서울 강남구。
- ⚠ 注册地址可能与实际经营地不同。
- ⚠ 同地区同名企业 → 存在错误匹配风险。

#### 8. 산업 (Industry)

- **补全指引（按优先级）：**
  1. 官网产品/服务分类及关键词分析
  2. Bizno / Moneypin 行业分类字段
  3. Naver 地图行业类别
  4. LLM 基于官网内容的分类映射
- **行业 ID 映射：** 将自然语言描述映射到 CRM 行业 ID（见 `global-field-schema.md` 一级行业枚举）。
- **分类标准：** KSIC（韩国标准产业分类，统计厅）+ NTS 事业分类码（国税厅）。KSIC 不可用时使用平台自有分类。
- ⚠ 韩国企业注册时倾向登记最多行业码 → 注册行业 ≠ 实际经营。
- ⚠ 多品类公司难以映射到单一类目。

#### AI Summary

- 承载用户意图中要求但不在预定义字段内的额外信息，以及采集中发现的高价值补充信息。
- 若无额外信息，填 `N/A`。

---

## Part 3: 去重与校验规则

### 3.1 去重主键字段

| 优先级 | 字段 | 说明 |
|-------|------|------|
| 1 | 사업자등록번호 | 10 位数字，格式 XXX-XX-XXXXX |
| 2 | website（域名） | .co.kr / .kr 域名 |
| 3 | 회사명 + 지역 | 韩文全称 + 地区 |

### 3.2 联系方式校验

| 项目 | 规则 |
|------|------|
| 手机号格式 | +82 开头，010 去掉首位 0 → +82 10 |
| 固话格式 | +82 + 区号（去 0）+ 号码 |
| 010 处理 | 个人手机号排除在公司电话之外，单独分类 |
| 主要 IM 渠道 | KakaoTalk > LinkedIn |
| 邮箱校验 | 排除 no-reply/noreply/webmaster；退信率约 10% |

### 3.3 工商验证

| 字段 | 本地名称 | 格式 | 说明 |
|------|---------|------|------|
| 事业者登录番号 | 사업자등록번호 | XXX-XX-XXXXX（10 位数字） | 韩国企业唯一标识，CRM 写回时去掉连字符 |

### 3.4 crm-dedup 字段选择

```json
{
  "uid": "序号",
  "companyName": "英文名或韩文名",
  "country": "KR",
  "email": "联系邮箱",
  "registerNumber": "사업자등록번호（如已获取）"
}
```

---

## Part 4: 输出格式

### 4.1 用户输出表格

| Company Name (Korean) | Company Name (Eng) | Business Reg No. | CEO Name | Phone | Email | Website | Region | Industry/Products | CRM Detail | AI Summary |
|-----------------------|--------------------|------------------|----------|-------|-------|---------|--------|-------------------|------------|------------|
| (주)아모레퍼시픽 | Amorepacific | 100-81-00000 | 서경배 | +82 2 1234 5678 | info@amore.co.kr | amorepacific.com | 서울 용산구 | Cosmetics | [详情](https://crm.alibaba-inc.com/crmagent/romeo/public-sea/customer-detail.html?globalId=xxx) | N/A |

### 4.2 CSV 列定义

```
index, source, company_name_en, company_name_local, country, province, city, address,
industry, industryId, tax_id, phone, email, website,
key_person_family_name, key_person_given_name,
globalId, pool, orgId, ownerId, detailUrl,
confidence, aiSummary, aiMatcher, qualityTags, dataSources, commandResult
```

### 4.3 输出要求

1. `Business Reg No.` 保持 `XXX-XX-XXXXX` 格式显示。
2. 缺失字段填 `N/A`。
3. 附 Result Summary + Data Provenance Table。
4. Phone 必须为 `+82` 国际格式。
5. VAT 阻断：如果某条线索没有 VAT 号且没有官网，置信度标记为 `low`。
6. **CRM Detail 列**：仅 CRM 内已有客户（`globalId` 非空）展示详情页链接（`detailUrl`），外部新发现的线索填 `N/A`。链接使用 Markdown 格式 `[详情](url)` 展示。

### 4.4 CRM 写回：韩国专属规则

完整的 write-back mapping 表见 `crm-api-reference.md`「Enrichment → companyData 写回映射」。以下为韩国的国家级 override：

| 规则 | 说明 |
|------|------|
| `registerNumber` **必填** | 韩国线索写回时사업자등록번호为必填。没有 → 阻断写回。写回时去掉连字符，仅保留 10 位数字 |
| `province` / `city` 需转码 | 不能直接写入"경기도"，必须先调 `crm-address --country KR` 获取编码 |
| `companyNameEn` 必填 | 如只有韩文名且无英文名 → 阻断写回 |
| `phone` 格式 | 必须为 +82 国际格式，写回前校验 |
