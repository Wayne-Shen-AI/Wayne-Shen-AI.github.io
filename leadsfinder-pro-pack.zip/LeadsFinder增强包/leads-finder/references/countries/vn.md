# Vietnam (VN) - 国家策略文件

本文件是越南（VN）地区的专属执行知识库。当 Phase 2 路由结果为 `country=VN` 时加载本文件。
后续的外部发现（Phase 6）、补全验证（Phase 7）、判重（Phase 8）、用户输出（Phase 10）必须遵循本文件的规则。

---

## Part 1: 数据源与搜索策略

越南企业的数据补全高度依赖社交媒体（尤其是 Facebook 和 Zalo）以及专门的工商验证网站。

### 1.1 采集数据源意图映射

根据用户意图选择对应数据源。优先使用 Accio 原生工具（`web_search` / `web_fetch`），ggs-crm CLI 工具（`google-search` / `google-map` / `web-scrape`）作为补充/兜底。

| 用户意图 | 主数据源 | 采集方式 | Fallback |
|---------|---------|---------|----------|
| 某地区工厂/企业 | Exa Search / Google Maps | `accio-mcp-cli call web_search_exa --query "..." --num_results 15` 或 `google-map` 按城市搜索 | Facebook 搜索 `"{keyword}" "{city}"` |
| 出口商/Exporter | Exa Search / ImportYeti | `accio-mcp-cli call web_search_exa --query "top Vietnamese {keyword} exporters" --num_results 15` + `web_fetch` 抓取 | GlobalSources 越南板块 |
| 竞品发现 | Exa Similar | `accio-mcp-cli call find_similar_pages_exa --url "{参照公司官网}" --num_results 10` | — |
| 企业工商验证 | masothue.com | `web-scrape` 或 `web_fetch` 抓取 | `web_search "{company_name} mã số thuế"` |
| 联系方式补全 | Facebook Page → About | `web-scrape` 或 `web_fetch` 抓取 | 官网 /contact 页面 |
| 展会参展商 | 展会官网 | `web_search` + `web_fetch` 抓取参展商列表 | — |
| 行业协会会员 | 协会官网 | `web_search` + `web_fetch` | — |
| 新注册外贸公司 | masothue.com / dangkykinhdoanh.gov.vn | `web-scrape` 批量抓取 | doanhnghiepmoi.vn |
| 工业园区企业 | VSIP / Amata 官网 | `web_search` + `web_fetch` | vieclambinhduong.vn |
| 招聘信息/规模估计 | vietnamworks.com / topcv.vn | `web_search` 搜索 | careerbuilder.vn / jobsgo.vn |

### 1.2 关键词本地化规则

**强制要求：** 搜索前必须将关键词翻译为越南语，生成 1 组英文 + 1 组越南语并发搜索。

常用翻译参考：

| 英文 | 越南语 |
|------|--------|
| factory / manufacturer | nhà máy / nhà sản xuất |
| exporter | nhà xuất khẩu |
| furniture | nội thất / đồ gỗ |
| textiles / garment | dệt may |
| seafood | thủy sản |
| trading company | công ty thương mại |
| industrial zone | khu công nghiệp (KCN) |

### 1.3 重点行业协会

| 协会 | 领域 | 官网 | 会员名录路径 |
|------|------|------|------------|
| VASEP | 水产品出口 | vasep.com.vn | /doanh-nghiep/danh-sach-hoi-vien |
| BIFA | 平阳省木制家具 | bifa.vn | /thanh-vien |
| HAWA | 胡志明市家具手工艺品 | hawa.com.vn | /member |
| VITAS | 纺织服装 | vietnamtextile.org.vn | /hoi-vien |
| LEFASO | 皮革鞋业 | lefaso.org.vn | /member |
| VPA | 塑料 | vpas.vn | /hoi-vien |
| VICOFA | 咖啡可可 | vicofa.vn | /member |
| VEIA | 电子 | veia.org.vn | 需 JS 渲染 |

### 1.4 重点展会

| 展会 | 领域 | 官网 | 参展商页面 |
|------|------|------|----------|
| VIFA Fair | 家具 | vfrexpo.com | /exhibitors |
| VIETFISH | 水产 | hcmcfoodex.com | /exhibitors |
| VTG | 纺织服装 | vtgexpo.com | /exhibitor-list |
| ILDEX | 畜牧 | ildex-vietnam.com | /exhibitors |
| ProPak Vietnam | 食品包装 | propakvietnam.com | /exhibitors |

### 1.5 重点工业园区 (KCN)

| 园区 | 城市/省 | 主要行业 |
|------|--------|---------|
| KCN Sóng Thần 1/2/3 | Bình Dương | 家具、机械 |
| KCN Tân Bình | HCM | 食品、塑料 |
| KCN Biên Hòa 1/2 | Đồng Nai | 电子、纺织 |
| KCN Mỹ Phước 1/2/3 | Bình Dương | 综合制造 |
| KCN Nhơn Trạch | Đồng Nai | 化工、机械 |
| KCN Long Hậu | Long An | 食品、物流 |
| KCN VSIP | Bình Dương / Bắc Ninh | 电子、精密制造 |

### 1.6 企业目录（通用补充）

| 网站 | 获取方式 | 说明 |
|------|---------|------|
| fact-link.com.vn | crawler | 制造业目录，4500+ 家 |
| ecvn.com | crawler | B2B 供应商 |
| yellowpages.vn | crawler | 越南语黄页 |
| yellowpages.com.vn | crawler | 英文黄页 |
| trangvangvietnam.com | crawler | 黄页 |
| infocom.vn | crawler | 企业目录 |
| doanhnghiep.biz | crawler | 企业目录 |
| tratencongty.com | crawler | 企业目录 |
| congtyviet.org | crawler | 企业目录 |

---

## Part 2: 字段补全指引

> **联系方式类字段的通用优先级：** Phone / Zalo / Email 等联系方式字段，优先从 Facebook（Page 和行业群组）提取，其次从官网，最后从其他平台补充。工商类字段（MST / Address / Industry）仍按各自权威来源优先。

### 去重主键优先级

`MST（Mã số thuế）` > `website（域名）` > `company_name_local（越南语全称）`

### P0 级别字段（核心）

#### 1. Business Registration No. (MST / Mã số thuế) 【去重主键】

- **定义：** 越南企业税号，10 位或 13 位数字。
- **补全指引：**
  - 来源 1：`masothue.com` — 搜索公司名，抓取详情页
    ```bash
    python3 -m ggs_crm_cli web-scrape -u "https://masothue.com/Search/?q={company_name}" -t text
    ```
  - 来源 2：公司官网 Footer，寻找 "Mã số thuế" 或 "MST"
- **阻断规则：** 如果找不到 MST，无法验证企业合法性，应标记风险或放弃后续依赖 MST 的查询（如工商详情）。

#### 2. Company Name Local (Tên công ty)

- **定义：** 越南语全称，通常包含 "Công ty TNHH"（有限公司）或 "Công ty Cổ phần"（股份公司）。
- **补全指引：** 从 masothue.com 或官网提取。

#### 3. Phone (Điện thoại)

- **定义：** 联系电话。**手机号为 primary**，固话降级为 secondary。
- **补全指引（按优先级）：**
  1. Facebook Page / 行业群组的 About 页面
  2. 官网 Contact 页面
  3. masothue.com 或其他企业目录
- **手机 vs 固话分流：**
  - **手机号（primary）：** 越南手机号以 03/05/07/08/09 开头，10 位。如有多个手机号，**全部填入 phone 字段**（逗号分隔），CRM 写回时取第一个。
  - **固话（secondary）：** 以 02 开头（如 028 胡志明、024 河内、0274 平阳）。**不填入 phone 主字段**，记入 AI Summary 备注。
- **格式清洗：** 去掉首位 0，加 `+84`。例：`0912345678` → `+84 912345678`。
- ⚠ 如果只找到固话没有手机号，固话作为唯一联系方式仍记入 phone 字段，但标注 `(landline)`。

#### 4. Social Media (Zalo / Facebook)

- **定义：** 越南最核心的通讯与社媒渠道。
- **补全指引：**
  - **Zalo（最重要）：** 通常绑定在手机号上。如果在官网或 FB 看到手机号旁有 Zalo 图标，记录该号码。
  - **Facebook：** 搜索公司名找到官方 Page 或所在的行业群组(Group)。输出**完整 URL**（如 `https://www.facebook.com/abccompany`），方便用户直接访问。
  - **LinkedIn：** 优先级低于前两者，仅作为补充。

#### 5. Website

- **定义：** 官方独立域名。严禁使用 B2B 平台商铺链接代替官网。
- **补全指引：** 从官网、Google 搜索或 Facebook Page 中的链接提取。
- **输出格式：** 用户输出表保留**完整 URL**（如 `https://abc.com.vn`），方便直接访问。CRM 写回时 strip 为纯域名（`abc.com.vn`）。

### P1 级别字段（重要补充）

#### 6. Email

- **补全指引：** 从 Facebook Page 的 About 页面或官网 Footer 提取。

#### 7. Address (Địa chỉ)

- **补全指引：** 从 masothue.com 提取官方注册地址。注意识别是否位于重点工业园区（KCN）内。

#### 8. Industry & Products (Ngành nghề)

- **补全指引：** 通过官网产品页或所在的行业协会/展会类别判断。
- **行业 ID 映射：** 将自然语言描述映射到 CRM 行业 ID（见 `global-field-schema.md` 一级行业枚举）。

#### 9. Company Size / Employees

- **补全指引：** 通过 vietnamworks.com 或 careerbuilder.vn 的招聘信息估计员工数量。

#### 10. Is Exporter (是否出口商)

- **判断依据：**
  - `confirmed`：明确提到海外客户、出口业务、FOB/CIF 等贸易术语
  - `inferred`：官网有英文版、参加国际展会、产品含国际认证
  - `unknown`：信息不足

#### 11. Is B2B

- **判断依据：**
  - `Yes`：描述中提到批发、供应商、B2B、wholesale；有企业客户案例
  - `No`：明确只面向个人消费者
  - `Unknown`：信息不足

#### AI Summary（兜底摘要）

- **定义：** 承载用户意图中要求但不在预定义字段内的额外信息（如主要客户、成立年份），以及采集中发现的高价值补充信息。
- **补全指引：** 若无额外信息，填 `N/A`。

---

## Part 3: 去重与校验规则

### 3.1 去重主键字段

按优先级顺序尝试匹配：

| 优先级 | 字段 | 说明 |
|-------|------|------|
| 1 | MST（Mã số thuế） | 10 位或 13 位数字，越南唯一企业标识 |
| 2 | website（域名） | 去除协议头和 www 后比较 |
| 3 | company_name_local + province | 越南语全称 + 省份组合 |

### 3.2 联系方式校验

| 项目 | 规则 |
|------|------|
| 手机号识别 | 以 `03/05/07/08/09` 开头的 10 位号码 → 手机号（primary phone） |
| 固话识别 | 以 `02` 开头 → 省份固话（如 028 胡志明、024 河内、0274 平阳）→ secondary，不填主字段 |
| 手机号格式 | +84 开头，去掉首位 0，9 位本地号 |
| 多号处理 | 多个手机号逗号分隔填入，第一个为 primary（CRM 写回用） |
| 主要 IM 渠道 | **Zalo**（权重等同手机号）> Facebook Messenger > LinkedIn |
| Email 校验 | 基本格式校验，去重时作为辅助匹配键 |

### 3.3 工商验证

| 字段 | 本地名称 | 格式 | 说明 |
|------|---------|------|------|
| 税号/营业执照号 | Mã số thuế (MST) | 10 位或 13 位数字 | 越南的营业执照号 = 税号，同一编号 |

### 3.4 crm-dedup 字段选择

在调用 `crm-dedup` 时，越南线索优先提供以下字段：

```json
{
  "uid": "序号",
  "companyName": "公司英文名或越南语名",
  "country": "VN",
  "email": "联系邮箱",
  "registerNumber": "MST（如已获取）"
}
```

---

## Part 4: 输出格式

### 4.1 用户输出表格

在向用户交付越南线索时，使用以下列定义：

| Company Name (Local) | MST (Tax ID) | Phone | Zalo / FB | Email | Website | Address / KCN | Industry / Products | CRM Detail | AI Summary |
|----------------------|--------------|-------|-----------|-------|---------|---------------|---------------------|------------|------------|
| Công ty TNHH ABC | 0312345678 | +84 912345678, +84 987654321 | [Zalo: +84 912345678] / https://facebook.com/abcvn | info@abc.vn | https://abc.com.vn | KCN Sóng Thần 1, Bình Dương | Furniture | [详情](https://crm.alibaba-inc.com/crmagent/romeo/public-sea/customer-detail.html?globalId=xxx) | 固话: +84 274 1234567 |

### 4.2 CSV 列定义

CSV 输出使用以下列顺序：

```
index, source, company_name_en, company_name_local, country, province, city, address,
industry, industryId, tax_id, phone, email, website, zalo, facebook_url,
key_person_name, globalId, pool, orgId, ownerId, detailUrl,
confidence, aiSummary, aiMatcher, qualityTags, dataSources, commandResult
```

### 4.3 输出要求

1. 缺失字段一律填 `N/A`。
2. Markdown 预览表使用 4.1 的列定义（越南专属）。
3. 表格下方附 `Result Summary`（50 字），说明数据来源和质量情况。
4. 必须附 Data Provenance Table（见 SKILL.md Phase 10）。采集中使用的黄页(trangvangvietnam.com)等数据源链接在此表中体现。
5. Phone 必须为 `+84` 国际格式。Phone 列填手机号（primary），固话记入 AI Summary。多个手机号逗号分隔。
6. Facebook / Website 列填写完整可点击 URL。
7. MST 阻断：如果某条线索既没有 MST 也没有官网，置信度标记为 `low`。
8. **CRM Detail 列**：仅 CRM 内已有客户（`globalId` 非空）展示详情页链接（`detailUrl`），外部新发现的线索填 `N/A`。链接使用 Markdown 格式 `[详情](url)` 展示。

### 4.4 CRM 写回：越南专属规则

完整的 write-back mapping 表见 `crm-api-reference.md`「Enrichment → companyData 写回映射」。以下为越南的国家级 override：

| 规则 | 说明 |
|------|------|
| `registerNumber` **必填** | 越南线索写回时 MST 为必填。没有 MST → 阻断写回 |
| `province` / `city` 需转码 | 不能直接写入 "Bình Dương"，必须先调 `crm-address --country VN` 获取编码 |
| `companyNameEn` 必填 | 如果只有越南语名称（Công ty TNHH...）且无法确认英文名 → 阻断写回 |
| `phone` 格式 | 必须为 +84 国际格式。多号时取第一个（primary）写入。仅写入手机号，固话不写回 |
| `website` 格式 | 写回时 strip 为纯域名（移除 `www.` 和 `http(s)://`），用户输出表保留完整 URL |
