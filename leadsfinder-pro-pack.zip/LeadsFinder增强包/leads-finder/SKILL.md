---
name: leads-finder
description: >
  【触发条件】：只要用户意图涉及"搜寻/查找/推荐/调研 公司/工厂/供应商/出口商/线索/客户/leads"就触发。
  包括模糊表达："帮我找几个"、"有什么推荐"、"高意向的有哪些"、"找胡志明市的客户"、
  "最近放出来的公海"、"找和@xxx类似的"、"我最近跟进的进展怎样"、
  "看下这个网站xx最新注册的公司"、"给我找附近10公里的工厂"、
  "最近inbound的"、"与我刚签单的类似的"、"帮我调研xx公司"、"帮我查xx公司的跟进记录"。
  有疑问时优先触发，不要等用户说得更明确。
  【硬性约束】：
    1. 你的 FIRST ACTION 必须是 Read 本 SKILL.md 全文（激活校验逻辑），禁止先执行搜索。
    2. 必须先完成意图理解，以自然语言向用户确认搜索条件后再执行。
    3. 严禁仅使用通用 web_search 裸跑，必须执行国家级"发现 → 验证 → 审计"链。
  【交付红线】：
    - 必须严格遵循 references/countries/{country_code}.md 规定的字段与输出格式。
      > ⚠️ 路径基准：`skills/leads-finder/references/countries/`（搜索策略），勿与 `skills/ggs-sales-email/countries/`（邮件模板）混淆。
    - 必须包含"事实审计表 (Data Provenance Table)"。
    - 否则视为任务失败。
---

# Leads Finder 工作流

本 Skill 整合 CRM 内部查询与外部 Web 发现两条链路，为销售提供统一的线索搜索能力。

---

## 核心工作准则 (Golden Rules)

1. **本地化优先**：执行搜索前，必须先将关键词翻译为目标国家的官方语言。
2. **三位一体验证**：每条外部线索必须经过 [第三方平台发现] → [官网/社媒提取] → [官方工商数据校验] 的交叉验证。
3. **拒绝编造**：缺失字段必须标注 N/A，严禁基于常识猜测联系方式或注册号。
4. **语言镜像**：所有面向用户的输出必须使用**用户输入的语言**作答。搜索关键词可使用目标国语言，但呈现给用户的内容语言须与输入一致。
5. **Tool Contract 为准**：工具的可执行行为以实际 CLI 参数为准，不得凭流程文档假设不存在的能力。

---

## 文件引用与加载时机

| 文件 | 加载时机       | 用途 |
|------|------------|------|
| references/countries/{country_code}.md | Phase 2 国家路由后 | 该国专属数据源、补全指引、去重规则、输出格式 |
| references/hktw-field-schema.md | Phase 1 意图理解、Phase 5 内部查询（港台） | 港台查询侧单一信源：字段语义、白名单、映射规则、排序、放宽 |
| references/global-field-schema.md | Phase 1 意图理解、Phase 5 内部查询（Global） | Global 查询侧单一信源：字段语义、白名单、映射规则、排序、放宽 |
| references/scoring.md | Phase 10 打分时 | 打分与排序规则 |
| references/platform-sop.md | Phase 6-7 执行跨国平台抓取时 | Google Maps、LinkedIn、Facebook 等通用平台 SOP |
| references/auth-guidance.md | Phase 6 执行前（涉及需登录平台时） | 平台授权与登录引导 |
| references/crm-api-reference.md | 调用CRM工具时 | 工具参数 + 写回映射的单一信源 |

---

## 环境准备

### 工具版本校验与安装

本 Skill 使用 ggs-crm-cli 工具。每次执行前按以下顺序校验并安装：

**Step 1：查询远端最新版本**
```bash
pip3 index versions ggs-crm-cli -i http://yum.tbsite.net/aliyun-pypi/simple --trusted-host yum.tbsite.net
```

- 查询成功 → 获取最新版本号，进入 Step 2
- 查询失败（网络不通）→ 跳过，使用本地兜底版本（见 `references/crm-tools` 目录）

**Step 2：校验当前已安装版本**
```bash
ggs-crm --version
```

- 未安装 → 执行安装
- 已安装且版本 < 远端最新版本 → 执行升级安装
- 已安装且版本 ≥ 远端最新版本 → 跳过

```bash
# 优先：从远端 PyPI 安装最新版本
pip3 install ggs-crm-cli -i http://yum.tbsite.net/aliyun-pypi/simple --trusted-host yum.tbsite.net
```

> 若远端安装失败，回退到本地 whl 文件安装：
> `pip3 install app/skills/leads-finder/references/crm-tools/ggs_crm_cli-0.0.27-py3-none-any.whl`

### Token 认证流程

本 Skill 使用 **ggs-sales-auth-provider** 进行统一认证。所有 CRM 工具接口调用前必须先验证 Token 有效性。

**认证流程请参照 [ggs-sales-auth-provider SKILL.md](../ggs-sales-auth-provider/SKILL.md)**

### 调用方式

优先使用 CLI 命令方式：`ggs-crm <command> [options]`

若 CLI 命令不可用，回退到 Python 模块方式：`python3 -m ggs_crm_cli <command> [options]`

---

## 主流程概览

```
Phase 0  触发与入口约束
Phase 1  意图理解与结构化
Phase 2  国家识别与 CRM family 路由
Phase 3  CRM 上下文准备
Phase 4  执行路径判定（internal / external / hybrid）
Phase 5  内部查询
Phase 6  外部发现
Phase 7  补全与验证
Phase 8  判重与合并
Phase 9  写回准备
Phase 10 排序与用户输出
Phase 11 可选 CRM 写回
```

不是所有请求都走完整链路。路径由 Phase 4 决定，详见各 Phase 说明。

---

## Phase 0：触发与入口约束

读完本 SKILL.md 后立即进入意图理解。禁止先执行搜索。

---

## Phase 1：意图理解与结构化

### 1.1 查询类型前置判断

语义判断，非关键词匹配。先判断查询类型，再确定搜索路径。

#### direct-lookup（直接查找）

用户提供了可直接定位记录的具体标识符。需进一步分为两个子类型：

**A. company research（公司调研）**
- 典型表达："帮我调研 XX 公司信息"、"帮我查一下 XX 公司"、"XX 公司什么情况"
- 默认处理：external-first，不按批量 lead sourcing 处理

**B. CRM record inspection（CRM 记录查看）**
- 典型表达："帮我看下 XX 公司的跟进记录"、"帮我查 CRM 里这个公司"
- 默认处理：internal-first
- 当前无真实 follow-up history retrieval contract，仅支持 CRM 记录定位与基础信息查看

#### standard-search（常规搜索）

非 direct-lookup 时，判断搜索路径：
- url-extract：用户提供了列表页 URL
- reference-based：用户提到参照对象
- standard-search：其他所有情况（默认）

### 1.2 池子判断（Pool）

语义判断，四档互斥：

| Pool | 触发信号 | 典型表达 |
|------|---------|---------|
| private | 归属词 | "我的客户"、"分给我的"、"我在跟进的" |
| public-only | 内部专属概念 | "最近放出来的"、"公海里的"、"最近inbound的" |
| external-only | 用户直接提供 URL | "看下这个网站 xxx.vn" |
| public+external | 其他所有情况（默认） | "找越南家具厂"、"展会leads"、"附近工厂" |

**public-only 判断依据——用户表达的概念在外部数据源中根本不存在：**

| 信号类型 | 具体表达 | 原因 |
|---------|---------|------|
| 内部系统操作词 | "放出来"、"分配"、"进池" | distribute_time 是内部 CRM 概念 |
| 平台专属行为字段 | "inbound"、"my_alibaba 上有活动" | 平台内买家行为，外部无法采集 |
| 用户自定义数据 | "我的 tag X"、"group Y 里的" | 内部系统标签，外部不存在 |

### 1.3 澄清与 ICP 引导

**何时澄清：** 除非同时满足以下条件，否则走一次 ICP 引导：
- 有效过滤条件 >= 3 个
- 且覆盖行业 + 地区 + 至少一个质量/联系方式维度

**例外：** pool 为 external-only（用户直接给 URL）时不触发澄清。

**澄清方式：** 直接向用户展示已提取的信息并请求确认或补充。

**多客户选择：** 当用户意图针对单个客户但查询返回多条匹配时，展示列表让用户选择。

### 1.4 Intent Struct 构造

从用户输入提取原始意图。原则：只提取用户明确表达的内容，不猜测补充。

```json
{
  "raw_query": "原始用户输入",
  "query_type": "standard-search | direct-lookup.company-research | direct-lookup.crm-inspection | url-extract | reference-based",
  "pool": "private | public-only | external-only | public+external",
  "country": "VN",
  "industry_hint": "家具",
  "location_hint": "胡志明市",
  "location_city": null,
  "location_lat": null,
  "location_lng": null,
  "radius_km": null,
  "quality_hint": null,
  "time_hint": null,
  "contact_hint": null,
  "activity_hint": null,
  "exporter_hint": null,
  "b2b_hint": null,
  "reference_hint": null,
  "reference_resolved_industry": null,
  "reference_resolved_city": null,
  "direct_url": null,
  "company_name_hint": null,
  "email_hint": null,
  "limit": 10
}
```

**内部使用：** Intent Struct 是流程内部的语义容器，供后续 Phase 消费，不需要向用户展示原始 JSON。澄清时以自然语言向用户确认搜索条件即可。

### 1.5 信息增强（按需工具调用）

| 情况 | 工具               | 目的                                      | Fallback |
|------|------------------|-----------------------------------------|---------|
| 提到公司名/线索引用 | CRM 搜索   | 获取行业、地区、address                         | 无 address → Google Places 取坐标 |
| 用户输入精确地址文本 | 模型自行推断    | 使用`ggs-crm google-map`搜索时,可文字地址转坐标做精确搜索 | 无法解析 → 降级到城市级 |
| 国别推断兜底 | crm-roles 返回的账号上下文 | 取账号默认负责市场                               | — |
| 用户给 URL | 直接标记 direct_url  | —                                       | — |

**国别推断优先级：** 地区提及 > 输入语言 > 账号默认市场

---

## Phase 2：国家识别与 CRM Family 路由

1. 从 Intent Struct 识别 country
2. 若用户输入中**有明确国家信息**：
   - 根据 country 确定 crm_family：HK / TW → HKTW，其他 → Global
3. 若用户输入中**无国家信息**（如"帮我查公海客户"）：
   - **先执行 Phase 3**（获取 crm-roles），根据角色的组织信息判断 CRM Family
   - 若角色属于 HKTW 组织 → crm_family = HKTW，country 根据组织推断为 TW 或 HK
   - 若角色属于 Global 组织 → crm_family = Global，country 从账号默认市场推断
   - 若仍无法确定 → 向用户澄清
4. 加载对应文件：
   - country strategy：references/countries/{country_code}.md（无则 default.md）
   - field schema：references/global-field-schema.md（Global）或 references/hktw-field-schema.md（HKTW）

**⚠️ HKTW 路由差异：** HKTW CRM 搜索链路中**没有国家码（country）字段用于路由**。HKTW CRM 通过 `--org-id`（组织 ID）和 `--sales-id`（销售 ID）确定搜索范围，`crm-search` 查询条件中**不需要传 country 字段**。因此当用户未提及国家时，必须先通过 crm-roles 获取角色信息来判断 CRM Family。

---

## Phase 3：CRM 上下文准备

**执行条件：** 流程涉及 CRM 查询、判重或写回时。**当 Phase 2 无法从用户输入识别国家时，Phase 3 需提前执行以辅助路由。**

1. 验证 token（fast_auth）
2. 调用 crm-roles 获取当前角色（参数详见 `references/crm-api-reference.md`）
   - 单角色 → 直接使用
   - 多角色 → 展示列表让用户选择
   - 空/失败 → 提示检查 token，中断流程
3. 缓存 sales-id 和 org-id 供后续使用
4. **CRM Family 反推（当 Phase 2 未确定 country 时）：** 根据角色的组织名称/路径判断是否属于 HKTW 组织，若是则设定 crm_family = HKTW 并回填 country，然后回到 Phase 2 第 4 步加载对应文件

> 角色信息在会话中缓存一次。用户明确要求切换角色时重新调用。

---

## Phase 4：执行路径判定

根据 Phase 1 的 pool 和 query_type，决定后续走哪些 Phase：

| 情况 | 执行路径 | Phase 5 | Phase 6 | Phase 7 | Phase 8 |
|------|---------|---------|---------|---------|---------|
| private | internal only | 执行 | 跳过 | 跳过 | 跳过 |
| public-only | internal only | 执行 | 跳过 | 跳过 | 跳过 |
| external-only | external only | 跳过 | 执行 | 执行 | 执行 |
| public+external | hybrid | 执行 | 执行 | 执行 | 执行 |
| company research | external-first | 跳过 | 执行 | 执行 | 按需 |
| CRM record inspection | internal-first | 执行 | 跳过 | 跳过 | 跳过 |

**关键约束：**
- private / public-only 不默认触发 external enrichment
- CRM record inspection 不默认进入外部发现/补全/判重/写回

**请求数量（hybrid 模式）：**
- 内部：limit * 2（成本低，多拉作为去重损耗 buffer）
- 外部：limit * 1（成本高，严格控制）

---

## Phase 5：内部查询

**执行条件：** pool 为 private / public-only / public+external，或 query_type 为 CRM record inspection。

### 5.1 查询准备

按对应 `field-schema.md` 执行（**HKTW 用 `references/hktw-field-schema.md`，Global 用 `references/global-field-schema.md`**）：
1. **Pool 归一化**：将流程层 pool 转为 `crm-search --pool` 合法值（见对应 field-schema 第一节）
2. **预调用**：按需缓存 crm-address / crm-tag / industry-mapping（见对应 field-schema 第三节，工具参数详见 `references/crm-api-reference.md`）
3. **Query-time Mapping**：将 Intent Struct 映射为 crm-search 查询条件（见对应 field-schema 第二、四、五节）
4. **排序**：确定 `--sort` 参数（见对应 field-schema 第六节）

### 5.2 执行查询（工具参数详见 `references/crm-api-reference.md`）

#### ▌Global CRM（非 HK/TW）

```bash
ggs-crm crm-search \
  -t {token} \
  --pool {normalized_pool} \
  --sales-id {sales_id} \
  --org-id {org_id} \
  -c '{conditions_json}' \
  --sort {sort_field} \
  --start 0 \
  --count {limit_x_2}
```

Global CRM 的 `conditions_json` 中**必须包含 `country` 字段**用于路由（如 `"key":"country","operation":"EQ","value":"VN"`）。

#### ▌HKTW CRM（香港、台湾）

```bash
ggs-crm crm-search \
  -t {token} \
  --pool {normalized_pool} \
  --sales-id {sales_id} \
  --org-id {org_id} \
  -c '{conditions_json}' \
  --sort {sort_field} \
  --start 0 \
  --count {limit_x_2}
```

**⚠️ HKTW 路由差异：** HKTW CRM 搜索链路中**没有国家码路由**，搜索范围由 `--org-id` 和 `--sales-id` 自动限定。`conditions_json` 中**不需要传 `country` 字段**，直接传业务筛选条件即可（如 `contract_status`、`willing_level`、标签等）。

**严格约束：**
1. --pool 只能是 private / public / all
2. -c 的 key 必须来自对应 field-schema.md 查询字段白名单（**HKTW 用 `references/hktw-field-schema.md`，Global 用 `references/global-field-schema.md`**），禁止使用 CRM 返回字段名
3. 所有值均为字符串类型
4. **HKTW 的 -c 条件中禁止传 country 字段**，Global 的 -c 条件中 country 为必传

**产出：** internal search results

### 5.3 无结果放宽

按对应 `field-schema.md` 第七节的放宽优先级逐步放宽（**HKTW 用 `references/hktw-field-schema.md`，Global 用 `references/global-field-schema.md`**），找到结果即停止，并告知用户放宽了哪个条件。

---

## Phase 6：外部发现

**执行条件：** pool 为 external-only / public+external，或 query_type 为 company research。

### 6.1 工具分层

| 优先级 | 工具 | 用途 |
|--------|------|------|
| 首选 | web_search / web_fetch（Accio 原生） | 通用网页搜索和内容抓取 |
| 首选 | Exa Search（如可用） | 语义化发现、相似公司 |
| 补充 | google-map | 地理位置搜索 |
| 补充 | google-search + web-scrape | CRM 工具链搜索+抓取 |

### 6.2 执行逻辑

**A. direct_url 场景：** 跳过数据源匹配，直接 web-scrape 或 web_fetch。

**B. 地图类场景（有经纬度，工具参数详见 `references/crm-api-reference.md`）：**
```bash
ggs-crm google-map \
  --latitude {lat} --longitude {lng} --radius {radius_m} \
  -c {country} --company-type "{industry_hint}"
```

**C. 标准外部搜索：**
1. 读当前 countries/{country_code}.md Part 1 数据源策略
2. 按用户意图匹配数据源类型（工厂/出口商/展会/协会/工业园区等）
3. 执行本地化关键词翻译（目标国语言 + 英语并发）
4. 并发 2-3 条不同搜索取结果并集去重

**D. reference-based 场景：** 先解析参照对象，再用 Exa find_similar_pages 或行业+地区关键词搜索。

**E. 需登录平台时：** 读 references/auth-guidance.md。遇到 CAPTCHA/登录墙 → 立即停止该平台，告知用户，降级到替代数据源。

**产出：** external discovery results

**无结果处理：** 直接展示空状态，不放宽条件。

---

## Phase 7：补全与验证

**执行条件：** Phase 6 产出了 external discovery results。

**核心原则：** 补全 = 发现 + 验证 + 保留证据，不是填满空字段。

### 7.1 流程骨架

对每条外部记录按以下顺序执行，已有字段跳过：

```
① 工商库查询 → ② 社媒查询 → ③ 官网爬取 → ④ Web Search 兜底 → ⑤ LLM 推断
```

### 7.2 具体规则由 Country 文件控制

每一步"去哪个网站、用什么关键词、怎么验证、何时阻断"全部由当前 countries/{country_code}.md 控制。

例如：
- 越南：masothue.com 查 MST → Facebook Page → 官网 → google-search → is_exporter 推断
- 意大利：官网 Footer 找 P.IVA → reportaziende.it 查营收 → P.IVA 找不到则阻断营收查询
- 韩国：官网 Footer 找 사업자등록번호 → FTC 验证 → NAVER 补充

### 7.3 通用操作 SOP

跨国平台操作步骤见 references/platform-sop.md。

### 7.4 LLM 推断

基于前序步骤采集内容做推断：

**行业映射：** 自然语言 → 行业 ID（枚举见对应 field-schema.md，**HKTW 用 `references/hktw-field-schema.md`，Global 用 `references/global-field-schema.md`**）

**是否出口（is_exporter）：**
- confirmed：明确提到海外客户、出口业务、FOB/CIF 等
- inferred：官网有英文版、参加国际展会、产品含国际认证
- unknown：信息不足

**是否 B2B（is_b2b）：** Yes / No / Unknown

> 中间字段（industry_raw / activity_signals / export_signals）不对外输出。

**产出：** enriched results

---

## Phase 8：判重与合并

**执行条件：** 存在 external 结果需要与 CRM 判重。

### 8.1 去重主键

读当前 countries/{country_code}.md Part 3 的去重主键优先级。

### 8.2 CRM 判重

对外部数据调用 crm-dedup。`check_params` 可用字段见 `crm-api-reference.md` §5，各国去重主键优先级见 country 文件 Part 3。

构造 `check_params` 时：`companyName` + `country` 必填；`registerNumber` 优先填入（如 country 文件要求且已获取）；`email` 有则填入。

```bash
ggs-crm crm-dedup \
  -t {token} --sales-id {sales_id} --org-id {org_id} \
  -p '[{"uid":"1","companyName":"ABC Corp","country":"VN","email":"test@abc.com"}]'
```

### 8.3 判重结果处理

`crm-dedup` 返回的 `deduplicationStatus` 与 `pool` 字段共同决定处理方式（返回字段详见 `references/crm-api-reference.md` §5）：

| `deduplicationStatus` | 返回 `pool` | 含义 | 处理 | 后续动作 |
|----------------------|------------|------|------|---------|
| `not_repeat` | — | CRM 中不存在 | ✅ 保留 | 可 crm-add 新增 |
| `public_repeat` | `public` | 公海重复 | ✅ 保留 | 可 crm-pickup 捡入 |
| `channel_repeat` | `public` | 渠道公海重复 | ✅ 保留 | 可 crm-pickup 捡入 |
| `depot_repeat` | `private` | 私海重复（已有归属销售） | ❌ 移除 | — |
| `manager_repeat` | — | 经理库重复 | ✅ 保留 | 标记来源，提示用户需联系经理 |

**关键映射说明：**
- `not_repeat` = 全新线索，走 Phase 9 的 crm-add 路径
- `public_repeat` / `channel_repeat` = 公海可捡入，走 Phase 9 的 crm-pickup → crm-refine 路径
- `depot_repeat` = 已在他人私海，直接移除不展示
- `manager_repeat` = 经理库中的客户，保留展示但提示用户需通过经理操作

### 8.4 结果合并

- 外部在公海有对应记录 → 以公海记录为主体，用 enriched 字段补充 null
- 外部多源返回同一公司 → 合并为一条，字段取并集
- 内部组内重复 → 去重保留一条

**产出：** merged/deduped results

---

## Phase 9：写回准备

**执行条件：** 存在需写回的结果。

### 9.1 pickup（crm-pickup → crm-refine）vs add（crm-add）分流

- **crm-pickup → crm-refine**：dedup 结果为 EXIST 且在公海，有可确认的 `globalId`。先 pickup 捡入，再 refine 补全。（工具参数详见 `references/crm-api-reference.md`）
- **crm-add**：dedup 结果为 NEW，无 `globalId`，直接新增。（工具参数详见 `references/crm-api-reference.md`）

### 9.2 写回映射与校验

按 `references/crm-api-reference.md`「Enrichment → companyData 写回映射」章节执行字段映射和必填性校验。写回前须满足所有必填字段，否则阻断并告知用户缺失原因。

**产出：** CRM payload candidates 或明确 blocked reason

---

## Phase 10：排序与用户输出

### 10.1 打分与排序

读 references/scoring.md 执行。

- 外部数据：意图匹配分 * 0.6 + 数据质量分 * 0.4 = 综合分
- 内部数据：保持 API 返回顺序，leads_level 换算为分值用于混合排序
- 混合排序：综合分降序；同分时内部优先；再同分按置信度降序

截取前 limit 条。

### 10.2 输出格式

最终产出：CSV 文件 + Markdown 预览 + Data Provenance Table

**CSV：**
- UTF-8 with BOM
- 列定义由当前 countries/{country_code}.md Part 4 控制
- 上传：调用 storage 工具写入 OSS

**Markdown 预览：** 前 3-5 条 + CSV 下载链接。

**Data Provenance Table（强制）：**

| 事实点 | 声明内容 | 验证来源 | 验证状态 |
|:---|:---|:---|:---|
| 企业在营状态 | [结果] | [URL/Tool] | Verified / Not Found |
| 税号/注册号 | [结果] | [官方系统] | Verified / Not Found |
| 核心联系方式 | [结果] | [来源路径] | Verified / Not Found |

**快速操作建议：**
- pool=null → 建议导入 CRM
- pool=public → 可直接跟进或捡入
- pool=otherPublic → 可尝试联系

### 10.3 单公司调研输出

company research 不输出列表，输出单条深度报告 + 完整 Data Provenance Table + AI Summary。

### 10.4 CRM 记录查看输出

CRM record inspection 直接展示 CRM 记录字段，不附 Data Provenance Table。不展示跟进历史（无真实 contract）。

---

## Phase 11：可选 CRM 写回

**执行条件：** 用户明确要求导入/补全/捡入，且 Phase 9 已准备好 payload。

### 11.1 写回执行

| 动作 | 工具 | 前提 |
|------|------|------|
| 捡入公海客户 | crm-pickup | 有 globalId + pool=public |
| 补全已有客户 | crm-refine | 捡入成功后，有 globalId + 必填字段齐全 |
| 新增客户 | crm-add | 判重 NEW + 必填字段齐全 |

写回前须确认：payload 符合 `references/crm-api-reference.md` 工具 contract、分流已明确、必填字段齐全（含 country 文件的条件必填）、地址字段已转码。任一条件不满足 → 停止，告知用户原因。

---

## 异常处理

| 异常场景 | 处理方式 |
|---------|---------|
| Token 验证失败 | 引导用户 BUC 登录，等待确认后 get_token |
| crm-roles 返回空 | 提示检查 token，中断流程 |
| Browser Relay 未连接 | 降级为 web_search + web_fetch + CLI 工具 |
| CAPTCHA / 强制登录墙 | 立即停止该平台，告知用户并附截图，降级或跳过 |
| 主数据源访问失败 | 按 country 文件 Fallback 策略处理 |
| storage 上传失败 | 如实告知用户 |
| crm-pickup/add 失败 | 展示错误信息，不重试，等用户指示 |
