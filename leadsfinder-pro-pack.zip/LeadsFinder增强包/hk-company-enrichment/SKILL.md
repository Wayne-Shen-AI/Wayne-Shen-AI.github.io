---
name: hk-company-enrichment
description: >
  香港 (HK) 公司线索补全专用 skill —— 针对香港市场独有的
  Companies Registry (ICRIS) / Business Registration (BR) / Yellow Pages HK 等
  数据源与地址/电话/中文双名格式量身定制。是通用 websearch-enrichment
  skill 的香港特化版本 (HK-optimized fork)，已经在 1327 家 HK 企业上验证。
  【触发条件】：用户提到 "香港客户/HK leads/给HK公司补字段/BR号/公司注册号/
  yp.com.hk/openrice/HK公司注册处/HK Companies Registry/ICRIS/双名/繁体名"
  或明确指定 country=HK/香港/Hong Kong 时触发。
  【与其它 skill 的关系】：
  - 通用国别补全 → websearch-enrichment (跨国通用)
  - 官网优先补全 → website-enrichment (先抓官网)
  - 越南补全   → masothue/hsctvn 走 leads-finder + websearch-enrichment
  - HK 补全   → 本 skill (专用, 更高质量)
---

# HK Company Enrichment (香港公司线索补全)

## 🎯 定位
香港市场 SME/贸易商/工厂 leads 字段补全。跟越南 masothue 对等，HK 有自己的
一手工商库 (`cr.gov.hk` ICRIS) 和成熟的目录站 (`yp.com.hk`)，且 HK 企业
普遍有 **英文名 + 繁体中文名** 双名、**8 位 BR 号**、**港式楼层地址** (`N/F, Room, Flat`)
等独有特征，需要专门处理。

---

## 📚 数据源分层 (Layer 1-5, 从权威到兜底)

### Layer 1: HK Companies Registry (cr.gov.hk) — 唯一官方工商库
- **入口**: https://www.icris.cr.gov.hk/csci/
- **能拿到**: `CR No.` (Certificate of Incorporation 8 位)、`company_name_en`、`company_name_zh` (繁体)、`status` (Live/Dissolved/Struck Off/Deregistered)、`date_of_incorporation`、`company_type` (Private/Public/NP Limited)
- **搜索方式**: web_search 命中通常出现在 `cr.gov.hk` 或 `webb-site.com` (Webb-site 是 HK 上市/知名公司免费镜像)
- **⚠️ 限制**: ICRIS 网页本身有 captcha，无法直接抓取；必须靠搜索引擎索引到的镜像。若想批量精确抓 → 走 Webb-site (`webb-site.com/dbpub/`) 更稳。

### Layer 2: yp.com.hk (香港黃頁 Yellow Pages HK)
- **能拿到**: `phone`、`address`、`business_type` (行业标签)、部分 `email`
- **URL 模式**: `https://www.yp.com.hk/Category/{L1}/{L2}/{leaf}/pN/en` (英文站)、`/tc` (繁体)
- **⚠️ 抓取要求**: 有 TLS 指纹反爬，普通 `requests` 会 403 → **必须** 使用 `curl_cffi` + `impersonate="chrome120"`，见 `resources/yp_hk_scraper.py`
- **结构陷阱**: 每个 L1 分类页展示的是**全站所有** leaves (不是该 L1 独有)，采集时需按 leaf URL 去重

### Layer 3: 官网 contact/about 页
- **常见 TLD**: `.com.hk` `.hk` `.com` `.com.cn`（HK 公司常用）
- **常见路径**: `/contact-us` `/contact` `/about-us` `/about`
- 抓取时用 `curl_cffi` 或 `web_fetch`，遇 Cloudflare 用 `Scrapling-Skill`

### Layer 4: 其它权威目录 (次优)
- **`openrice.com`** / `openrice.com.hk` — 餐饮类
- **`hktdc.com`** — HK 贸发局企业录 (官方但简略)
- **`webb-site.com`** — HK 上市公司 + 大企业档案 (免费质量高)
- **`data.gov.hk`** — HK 政府开放数据集

### Layer 5: web_search 通用兜底
- 关键词模板见 §3

---

## 📋 HK 独有字段清单 (11+ 字段)

| 字段 | 说明 | 来源优先级 |
|------|------|------------|
| `company_name_en` | 英文法定名 | ICRIS > 官网 > YP > 搜索 |
| `company_name_zh` | 繁体中文法定名 (**保留繁体，不 T2S**) | ICRIS > 官网 > YP |
| `br_no` | Business Registration 号 (8 位数字)，或含 3 位分支 `12345678-001` | 官网 footer > ICRIS |
| `cr_no` | Certificate of Incorporation 8 位 (跟 BR 不同) | ICRIS 一手 |
| `status` | `active` / `closed` / `unknown` | ICRIS / webb-site |
| `status_raw` | ICRIS 原文 (`Live` / `Dissolved` / `Struck Off` / `Deregistered`) | ICRIS |
| `reg_date` | 成立日期 YYYY-MM-DD | ICRIS |
| `company_type` | `Private company limited by shares` / `Public` / `Non-profit` | ICRIS |
| `directors` | 董事姓名 (可多个 `;` 分隔) | ICRIS / 官网 |
| `secretary` | 公司秘书 | ICRIS |
| `address` | 完整港式地址 (见地址规则) | ICRIS / YP / 官网 |
| `district` | 香港/九龙/新界 + 区 (18 区之一) | 地址派生 |
| `phone` | 电话 (强制 8 位 + 852 区号) | YP / 官网 |
| `email` | 邮箱 (合法性) | 官网 / 搜索 |
| `website` | 官网 URL | 官网 / 搜索 |
| `business_type` | 主营/行业 (英文短语) | YP / 官网 |
| `industry_zh` | 中文行业分类 | YP 繁体页 |
| `crm_industry` / `crm_code` | GGS CRM 44 行业映射 | 通过 industry-mapping skill |

---

## 🔍 搜索模板 (每家最多 4 次 web_search + 2 次 web_fetch)

### 搜索 A: 拿 BR / ICRIS
```
web_search("{company_name} Hong Kong BR")
web_search("{company_name} 香港 公司注册")
web_search("{company_name} site:webb-site.com")
web_search("{company_name} site:cr.gov.hk")
```

### 搜索 B: 拿地址 + 电话
```
web_search("{company_name} Hong Kong contact")
web_search("{company_name} address Hong Kong")
web_search("{company_name} site:yp.com.hk")
```

### 搜索 C: 拿官网 + 邮箱
```
web_search("{company_name} Hong Kong website")
web_search("{company_name} email Hong Kong contact")
```

### 抓取: web_fetch 优先顺序
```
web_fetch(["{official_website}/contact-us"])
web_fetch(["{official_website}/about-us"])
web_fetch(["https://www.webb-site.com/dbpub/orgdata.asp?p={BR}"])  # 若已知 BR
```

---

## 🏠 地址规则 (HK 独有)

### 港式地址关键词 (地址提取正则必须容纳)
```
Room, Rm, Flat, Suite, Unit
G/F, LG/F, UG/F, M/F, R/F, 1/F ... 99/F, Basement, Ground Floor
Podium, Court, Mansion, Plaza, Arcade, Tower, House, Terrace, Centre, Center
Building, Estate, Industrial Building, Commercial Building, IB, Comm Bldg
Street, Rd, Road, Avenue, Ave, Lane, Path, Wan (灣), Kok (角), Wai (圍)
Hong Kong, HK, Kowloon, KLN, N.T., New Territories, HKSAR
```

### 香港 18 区映射 (district 字段)
```
Hong Kong Island:  中西區/Central & Western, 灣仔/Wan Chai, 東區/Eastern, 南區/Southern
Kowloon:          油尖旺/Yau Tsim Mong, 深水埗/Sham Shui Po, 九龍城/Kowloon City,
                  黃大仙/Wong Tai Sin, 觀塘/Kwun Tong
New Territories:   荃灣/Tsuen Wan, 屯門/Tuen Mun, 元朗/Yuen Long, 北區/North,
                  大埔/Tai Po, 沙田/Sha Tin, 西貢/Sai Kung, 葵青/Kwai Tsing,
                  離島/Islands
```

### 地址规范化
- 去掉重复 `Hong Kong` / `HK` / `Kowloon` 尾巴
- `N/F` 保留原样（这是港式 N 楼，不要展开）
- `Room 123, 4/F` 保留（Room + Floor 组合）
- 大厦名保留原大小写，不要 title-case

---

## 📞 电话规则 (HK 独有)

- **HK 电话固定 8 位**（不含区号）
- **区号 +852 或 852**
- **首位数字判类型**:
  - `2xxx xxxx` → 固话 (香港)
  - `3xxx xxxx` → 固话 (含 IP 电话)
  - `5xxx / 6xxx / 9xxx` → 手机
  - `7xxx` → 传呼 (罕见)
  - `8xxx` → 收费电话
- **规范化目标**: `+852 2xxx xxxx` (加空格分组，去括号)
- **正则**: `(?:(?:\+?852)[\s\-]?)?[2356789]\d{3}[\s\-]?\d{4}\b`
- **⚠️ 拒识**: 只有 4-6 位的号码不要认，可能是分机

---

## 🆔 BR 号 / CR 号 校验

- **BR** (Business Registration): 8 位数字 (可带 3 位分支)
  - 正则: `^\d{8}(-\d{3})?$`
  - 示例: `12345678` 或 `12345678-001`
- **CR** (Certificate of Incorporation): 也是 8 位数字，但**跟 BR 不同**！
  - 一家公司同时有 BR 号 (税务用) 和 CR 号 (注册用)，通常两者不同
  - 若从 ICRIS 搜到的是 CR，从 IRD 搜到的是 BR
- **格式不对 → 留空**，绝不猜

---

## 📛 双名处理 (英文 + 繁体)

- HK 公司**几乎 100% 有繁体中文名**（法定要求）
- **保留繁体**，不做 T2S 转换（跟越南场景相反，繁体是港人身份认同）
- 中文名常见结尾: `有限公司` / `控股有限公司` / `國際有限公司`
- 英文名对应: `Limited` / `Holdings Limited` / `International Limited`
- 抓取时**分开存**: `company_name_en` + `company_name_zh`，不要合并

---

## 🚫 域名黑白名单

### ✅ 白名单 (权威一手)
```
cr.gov.hk           # 公司注册处
ird.gov.hk          # 税务局
data.gov.hk         # 政府开放数据
webb-site.com       # 免费上市公司/大企业档案
hktdc.com           # HK 贸发局 (官方，简略)
```

### ⚠️ 目录站 (可作补充，仅取 phone/address 等，不当权威源)
```
yp.com.hk           # 黃頁
openrice.com(.hk)   # 食肆
```

### ❌ 黑名单 (不要取，纯是营销站/AI 生成/信息聚合)
```
hktdc.com/mkt/      # 营销页
tradeeasy.hk
todaytex.com
mingluji.com        # 内容农场
mycom.com.hk        # 广告目录
```

---

## 🕷 yp.com.hk 爬虫 (已趟坑经验)

### 抓取要点 (见 resources/yp_hk_scraper.py)
1. **必须** `curl_cffi` + `impersonate="chrome120"` (普通 requests/urllib 403)
2. **必须** 加 `Sec-Ch-Ua` / `Sec-Fetch-*` 完整 headers
3. **结构陷阱**: 首页 18 个 L1 分类，但**每个 L1 详情页展示的是全站所有 leaves**（不是该 L1 独占）
   - 解决: 用 `all_leaves` dict 全站去重，key = leaf URL
4. **URL 模式**: `/Category/{L1}/{L2}/{leaf}/p{N}/en`
5. **每 leaf 分页**: `p1, p2, ..., pN`；碰到"下一页 = 首页"停
6. **反爬节奏**: 每次请求间隔 1-3 秒随机 + 3 次重试 (5s/15s/40s backoff)
7. **crash-safe**: 每 leaf 结果单独 `jsonl` 存盘 + `_done_leaves.txt` resume
8. **测试模式**: `MAX_L1 / MAX_LEAVES_PER_L1 / MAX_PAGES_PER_LEAF` 上限 (设 0 表示不限)

### YP 每公司拿到的字段
- 公司名（英文 + 繁体）
- 电话（有时多个）
- 地址
- 行业标签 (英文 + 繁体)
- 部分邮箱 / 官网 (需要点进详情页)

---

## 🏭 HK 中文行业 → GGS CRM 映射
- 参考 `resources/hk_industry_map.json` (待建/后续沉淀)
- 常见: `貿易` `進出口` → Trading; `餐飲` → Food Service; `電子` → Electronics;
  `製衣` `紡織` → Apparel; `印刷` → Printing; `物流` `貨運` → Logistics
- 兜底调用 `industry-mapping` skill 的 `map_by_text()`

---

## 🔴 铁律 (与 websearch-enrichment 同源，HK 场景加强)

1. **空值铁律**: 找不到留 `""`，严禁 `N/A` / `Not Found` / `null` / `****` / `无`
2. **status 规范**:
   - `Live` / `Active` → **active**
   - `Dissolved` / `Struck Off` / `Deregistered` / `Ceased` → **closed**
   - 未搜到 → **unknown**
3. **status_raw** 保留 ICRIS 原文
4. **BR / CR 号** 格式不符（不是 8 位数字或 8+3 分支）→ 留空
5. **中文名** 保留繁体，禁 T2S
6. **电话** 强制 8 位 + 852 前缀，不含区号 8 位以外的数字留空
7. **地址** 保留港式楼层写法 (`Room 123, 4/F, ...`)，不要展开
8. **每家最多 4 次 web_search + 2 次 web_fetch**，超时就跳
9. **严禁编造**: `example.com.hk`、`contact@abc.com.hk`、`+852 xxxx xxxx` 一律禁止
10. **同名冲突**: HK 常有多家近同名公司 (例如 `Wing Fat Trading Ltd` 有 5 家)，靠 **BR 号** + **成立日期** 选最匹配的一家；无法确定就留 `remark: 同名多个,选X`

---

## ⚠️ 限流应对
- web_search 返回 `<!DOCTYPE` → 等 15 秒重试，最多 3 次仍失败则跳过该家继续
- 单 shard 时间预算 5-7 分钟；超时就停搜写盘

---

## 📥 标准输入契约
输入 JSON 数组，每条:
```json
{
  "row": <int>,
  "company_name": "<英文名或双名, 原始>",
  "hint_addr": "<可选, 已有的地址片段>",
  "hint_phone": "<可选, 已有的电话>",
  "hint_website": "<可选, 已有的 URL>"
}
```

## 📤 标准输出契约
```json
{
  "row": <int>,                             // 与输入一致
  "company_name_en": "英文法定名",
  "company_name_zh": "繁体中文名",
  "br_no": "8 位数字",
  "cr_no": "8 位数字",
  "status": "active | closed | unknown",
  "status_raw": "Live / Dissolved / ...",
  "reg_date": "YYYY-MM-DD",
  "company_type": "Private company limited by shares / ...",
  "directors": "张三; 李四",
  "secretary": "王秘书",
  "address": "港式完整地址",
  "district": "18 区之一",
  "phone": "+852 2xxx xxxx",
  "email": "邮箱",
  "website": "https://...",
  "business_type": "英文行业短语",
  "industry_zh": "中文行业分类",
  "crm_industry": "GGS 行业名",
  "crm_code": "GGS 行业 code",
  "source_url": "主数据来源 URL",
  "remark": "备注"
}
```

---

## 📊 已验证记录 (baseline)
- **HK 1327 家批量补全** (2026-06-30 前)
  - phone 覆盖: 70-90%
  - BR 号: 67%
  - 中文名: 92%
  - 完整 11 字段填充率: 80%+
- **HK 598 家详细产品名录** (2026-06-30)
- **yp.com.hk 爬虫** (2026-07-01 完稿, curl_cffi + chrome120 + 结构去重)

---

## 🎬 使用流程速查

```
1. 拿到 HK 公司列表 → 分片 6-8 家/shard (11 字段密集)
2. 并发 3 sub-agent (skill 甜区)
3. 每家:
   a) web_search 找 CR/BR (webb-site 或 cr.gov.hk)
   b) web_search 找 yp.com.hk 页面拿 phone + address
   c) 找到官网 → web_fetch contact/about
   d) 都缺则 web_search 兜底
4. 输出 22 字段 JSON, 严格铁律
5. 主流程合并 → 应用 industry-mapping 补 crm_industry/code
6. 输出 xlsx + csv
```

---

## 🚨 常见坑
1. **繁体被误 T2S** → 不要用其它 skill 的 T2S map，HK 场景必须保留繁体
2. **BR 号跟 CR 号混淆** → 用户报的 8 位号可能是任意一种，两者都存
3. **同名公司** → 例如 5 家 `Wing Fat Trading Ltd`，靠 BR + 成立日期区分
4. **yp.com.hk L1 页结构** → 全站 leaves 混在每个 L1 页 (采集时去重)
5. **`.com.hk` 域名不一定是 HK 公司** → 要跟 BR 或地址交叉验证
6. **香港政府中文用繁体不用简体** → 中文搜索用繁体关键词命中率高
