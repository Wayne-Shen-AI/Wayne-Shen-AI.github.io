# -*- coding: utf-8 -*-
"""
yp.com.hk (Yellow Pages Hong Kong) 爬虫 — 稳定版
================================================
经过 2026-07-01 实战调试的最终版本。核心解决的坑:

1. **TLS 指纹反爬**: 普通 requests / urllib3 → 403;
   必须用 `curl_cffi.requests` + `impersonate="chrome120"`。
2. **完整 Chrome 头**: `Sec-Ch-Ua*` / `Sec-Fetch-*` 必须都齐,否则风控更严格。
3. **结构陷阱 (重要)**: 首页 18 个 L1 分类,但**每个 L1 详情页展示的是全站所有 leaves**
   (并非该 L1 独占)。所以采集时必须**用 leaf URL 做全站去重** (all_leaves dict),
   不能按 "L1 → 遍历 L1 内 leaves" 的思路,会漏或重复。
4. **分页停止条件**: 当 "下一页" 的第一条记录 = "上一页" 的第一条记录时,说明已到底。
5. **反爬节奏**: 每次请求间隔 1-3 秒随机 + 3 次重试 (5s/15s/40s backoff)。
6. **Crash-safe**: 每 leaf 结果单独存 `_data/{leaf_slug}.jsonl` + `_done_leaves.txt` resume。

使用:
    # 安装依赖 (若还没装):
    #   pip install curl_cffi beautifulsoup4 lxml
    #
    # 运行:
    #   python yp_hk_scraper.py            # 全量抓
    #   python yp_hk_scraper.py --test     # 测试模式,只抓少量

限速: 默认每请求 1-3s 随机 + 每 leaf 完成后 sleep(2-4s)。全量约 8-12 小时。

依赖: curl_cffi >= 0.6, beautifulsoup4, lxml
"""
from __future__ import annotations
import argparse
import json
import os
import random
import re
import sys
import time
from pathlib import Path
from typing import Iterable, List, Optional
from urllib.parse import urljoin, urlparse

try:
    from curl_cffi import requests as curl_requests
except ImportError:
    print("ERROR: 请先安装 curl_cffi:  pip install curl_cffi", file=sys.stderr)
    sys.exit(1)

try:
    from bs4 import BeautifulSoup
except ImportError:
    print("ERROR: 请先安装 beautifulsoup4:  pip install beautifulsoup4 lxml", file=sys.stderr)
    sys.exit(1)


# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------
BASE = "https://www.yp.com.hk"
HOME = f"{BASE}/en"
OUT_DIR = Path("_yp_hk_data")
DONE_FILE = Path("_yp_hk_done_leaves.txt")

# Test-mode limits (0 = unlimited)
MAX_L1: int = 0
MAX_LEAVES_PER_L1: int = 0
MAX_PAGES_PER_LEAF: int = 0

MIN_SLEEP = 1.0
MAX_SLEEP = 3.0
LEAF_INTERVAL_MIN = 2.0
LEAF_INTERVAL_MAX = 4.0
RETRY_BACKOFF = (5, 15, 40)  # seconds

# Rotating User-Agent (all Chrome-family; matches impersonate)
UA_LIST = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
]


def build_headers(referer: str = HOME) -> dict:
    return {
        "User-Agent": random.choice(UA_LIST),
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.9,zh-HK;q=0.8,zh;q=0.7",
        "Accept-Encoding": "gzip, deflate, br",
        "Cache-Control": "no-cache",
        "Pragma": "no-cache",
        "Referer": referer,
        "Sec-Ch-Ua": '"Chromium";v="120", "Not=A?Brand";v="8", "Google Chrome";v="120"',
        "Sec-Ch-Ua-Mobile": "?0",
        "Sec-Ch-Ua-Platform": '"Windows"',
        "Sec-Fetch-Dest": "document",
        "Sec-Fetch-Mode": "navigate",
        "Sec-Fetch-Site": "same-origin",
        "Sec-Fetch-User": "?1",
        "Upgrade-Insecure-Requests": "1",
    }


def sleep_between():
    time.sleep(random.uniform(MIN_SLEEP, MAX_SLEEP))


def sleep_between_leaves():
    time.sleep(random.uniform(LEAF_INTERVAL_MIN, LEAF_INTERVAL_MAX))


# ---------------------------------------------------------------------------
# HTTP layer (curl_cffi + retry + backoff)
# ---------------------------------------------------------------------------
def http_get(url: str, referer: str = HOME) -> Optional[str]:
    for attempt, wait in enumerate((0,) + RETRY_BACKOFF):
        if wait:
            print(f"    [retry {attempt} after {wait}s] {url}", flush=True)
            time.sleep(wait)
        try:
            r = curl_requests.get(
                url,
                headers=build_headers(referer),
                impersonate="chrome120",
                timeout=30,
            )
            if r.status_code == 200 and r.text:
                return r.text
            print(f"    status {r.status_code}, len={len(r.text or '')}", flush=True)
        except Exception as e:
            print(f"    EXC {type(e).__name__}: {e}", flush=True)
    return None


# ---------------------------------------------------------------------------
# Leaf discovery: parse ALL leaf URLs from any L1 page.
# Leaf URL pattern: /Category/{L1}/{L2}/{leaf}/p{N}/en
# We match the p1 form directly.
# ---------------------------------------------------------------------------
_LEAF_URL_RE = re.compile(
    r"/Category/([^/]+)/([^/]+)/([^/]+)/p1/en\b"
)

def parse_leaf_links(html: str) -> List[dict]:
    """Return list of {url, l1, l2, leaf} for all leaf links found on the page.
    Because every L1 page shows all leaves site-wide, one call is enough."""
    out = []
    seen = set()
    for m in _LEAF_URL_RE.finditer(html):
        l1, l2, leaf = m.group(1), m.group(2), m.group(3)
        # URL rebuilt with p1
        rel = f"/Category/{l1}/{l2}/{leaf}/p1/en"
        if rel in seen:
            continue
        seen.add(rel)
        out.append({
            "url": urljoin(BASE, rel),
            "l1": l1,
            "l2": l2,
            "leaf": leaf,
        })
    return out


# ---------------------------------------------------------------------------
# Company row parsing (per leaf page)
# ---------------------------------------------------------------------------
def parse_companies_on_page(html: str) -> List[dict]:
    """Extract company rows from a leaf listing page.
    Fields: name_en, name_zh, phone, address, categories, detail_url."""
    soup = BeautifulSoup(html, "lxml")
    out = []
    # yp.com.hk uses .listing-item or article-based cards; be lenient
    cards = soup.select("article, div.listing-item, li.company, div.company-card")
    if not cards:
        # fallback: any element with class containing 'company' and a heading
        cards = [el for el in soup.find_all(True) if "company" in " ".join(el.get("class") or []).lower()]
    for c in cards:
        name_el = c.select_one("h2, h3, .name, .company-name, a[href*='/Company/']")
        if not name_el:
            continue
        name = name_el.get_text(strip=True)
        if not name:
            continue
        # detail URL
        detail_a = c.select_one("a[href*='/Company/']")
        detail = urljoin(BASE, detail_a["href"]) if detail_a and detail_a.get("href") else ""
        # phone
        phone_el = c.find(string=re.compile(r"\+?852\s*[2-9]\d{3}|[2-9]\d{3}[\s\-]?\d{4}"))
        phone = phone_el.strip() if phone_el else ""
        # address (heuristic)
        addr_el = c.select_one(".address, .addr, .location")
        addr = addr_el.get_text(strip=True) if addr_el else ""
        # categories/tags
        tags = [t.get_text(strip=True) for t in c.select(".tag, .category, .biz-type")]
        out.append({
            "name": name,
            "detail_url": detail,
            "phone": phone,
            "address": addr,
            "categories": tags,
        })
    return out


def next_page_url(current_url: str, current_page: int) -> str:
    return re.sub(r"/p\d+/en", f"/p{current_page+1}/en", current_url)


# ---------------------------------------------------------------------------
# State (done leaves resume)
# ---------------------------------------------------------------------------
def load_done() -> set:
    if not DONE_FILE.exists():
        return set()
    return set(DONE_FILE.read_text(encoding="utf-8").splitlines())


def mark_done(leaf_slug: str):
    with DONE_FILE.open("a", encoding="utf-8") as f:
        f.write(leaf_slug + "\n")


def leaf_slug(leaf: dict) -> str:
    return f"{leaf['l1']}__{leaf['l2']}__{leaf['leaf']}"


# ---------------------------------------------------------------------------
# Per-leaf loop
# ---------------------------------------------------------------------------
def scrape_leaf(leaf: dict) -> int:
    slug = leaf_slug(leaf)
    out_file = OUT_DIR / f"{slug}.jsonl"
    out_file.parent.mkdir(parents=True, exist_ok=True)
    n_written = 0
    prev_first_name = ""
    page = 1
    url = leaf["url"]
    while True:
        if MAX_PAGES_PER_LEAF and page > MAX_PAGES_PER_LEAF:
            print(f"  [max-pages] stop at page {page}", flush=True)
            break
        print(f"  page {page}: {url}", flush=True)
        html = http_get(url, referer=HOME)
        if not html:
            print(f"  [no-html] give up leaf", flush=True)
            break
        companies = parse_companies_on_page(html)
        if not companies:
            print(f"  [no-companies] stop", flush=True)
            break
        # Detect looping: same first-company name across pages → end reached
        first = companies[0]["name"]
        if page > 1 and first == prev_first_name:
            print(f"  [same-first-as-prev] end", flush=True)
            break
        prev_first_name = first
        with out_file.open("a", encoding="utf-8") as fp:
            for c in companies:
                c["_leaf"] = slug
                fp.write(json.dumps(c, ensure_ascii=False) + "\n")
                n_written += 1
        sleep_between()
        page += 1
        url = next_page_url(leaf["url"], page - 1)
    print(f"  → wrote {n_written} companies", flush=True)
    return n_written


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
def main():
    global MAX_L1, MAX_LEAVES_PER_L1, MAX_PAGES_PER_LEAF
    ap = argparse.ArgumentParser()
    ap.add_argument("--test", action="store_true", help="test mode: only 1 L1, 2 leaves, 2 pages")
    ap.add_argument("--max-l1", type=int, default=0)
    ap.add_argument("--max-leaves-per-l1", type=int, default=0)
    ap.add_argument("--max-pages-per-leaf", type=int, default=0)
    args = ap.parse_args()
    if args.test:
        MAX_L1, MAX_LEAVES_PER_L1, MAX_PAGES_PER_LEAF = 1, 2, 2
    else:
        MAX_L1 = args.max_l1
        MAX_LEAVES_PER_L1 = args.max_leaves_per_l1
        MAX_PAGES_PER_LEAF = args.max_pages_per_leaf

    OUT_DIR.mkdir(parents=True, exist_ok=True)
    done = load_done()
    print(f"[start] existing done leaves: {len(done)}", flush=True)

    # Home page → find L1 category URLs
    print("[home] fetching home page...", flush=True)
    home_html = http_get(HOME)
    if not home_html:
        print("[FATAL] cannot fetch home page. Check network / TLS.", file=sys.stderr)
        sys.exit(2)

    # discover ALL leaves site-wide from just one L1 page (structure fix)
    # first find any L1 category URL from the home page
    l1_urls = re.findall(r'href="(/Category/[^/]+/en)"', home_html)
    l1_urls = list(dict.fromkeys(l1_urls))  # dedupe preserving order
    print(f"[home] found {len(l1_urls)} L1 categories", flush=True)
    if not l1_urls:
        print("[FATAL] no L1 URLs on home page", file=sys.stderr)
        sys.exit(3)

    # Use just the FIRST L1 page to enumerate all leaves site-wide
    first_l1_url = urljoin(BASE, l1_urls[0])
    print(f"[first-l1] enumerating all leaves via: {first_l1_url}", flush=True)
    l1_html = http_get(first_l1_url, referer=HOME)
    if not l1_html:
        print("[FATAL] cannot fetch first L1 page", file=sys.stderr)
        sys.exit(4)
    all_leaves = parse_leaf_links(l1_html)
    print(f"[leaves] found {len(all_leaves)} unique leaves site-wide", flush=True)

    if MAX_LEAVES_PER_L1:
        # in test mode, cap leaves
        all_leaves = all_leaves[:MAX_LEAVES_PER_L1]
        print(f"[test] capped to {len(all_leaves)} leaves", flush=True)

    total_companies = 0
    for i, leaf in enumerate(all_leaves, 1):
        slug = leaf_slug(leaf)
        if slug in done:
            print(f"[{i}/{len(all_leaves)}] SKIP (done) {slug}", flush=True)
            continue
        print(f"[{i}/{len(all_leaves)}] {slug}", flush=True)
        n = scrape_leaf(leaf)
        total_companies += n
        mark_done(slug)
        sleep_between_leaves()

    print(f"\n[done] total companies written: {total_companies}", flush=True)


if __name__ == "__main__":
    main()
