# -*- coding: utf-8 -*-
"""
hk-company-enrichment 专用提取器
================================
在通用 websearch-enrichment/resources/extractors.py 基础上,针对 HK 独有:
- 电话 (强制 8 位 + 852)
- BR/CR 号 (8 位数字, 可带 -3 位分支)
- 港式楼层地址 (Room / Flat / N/F / G/F / LG/F / Podium ...)
- 香港 18 区映射
- 中英双名 (保留繁体, 不 T2S)
- ICRIS status (Live/Dissolved/Struck Off) 归一

提取器是纯函数,不发起网络请求,只从传入的文本 (web_search title+snippet
或 web_fetch 页面纯文本) 里正则/关键字提取。

Usage:
    from hk_extractors import (
        extract_hk_phones, extract_br_no, extract_cr_no,
        extract_hk_address, extract_hk_district,
        normalize_hk_status, split_zh_en_names,
    )

    text = title + "\n" + snippet
    br_no    = extract_br_no(text)
    phones   = extract_hk_phones(text)         # -> list of "+852 xxxx xxxx"
    address  = extract_hk_address(text)
    district = extract_hk_district(address)
    status   = normalize_hk_status("Live")     # -> "active"
    en, zh   = split_zh_en_names("ABC Ltd 甲乙丙有限公司")
"""
from __future__ import annotations
import re
from typing import List, Optional, Tuple

# ---------------------------------------------------------------------------
# 1) HK phone (8 digits + 852)
# ---------------------------------------------------------------------------

# HK phone types by leading digit:
#   2xxx → landline
#   3xxx → IP landline / VoIP
#   5xxx / 6xxx / 9xxx → mobile
#   7xxx → pager (rare)
#   8xxx → premium (rare)
# Region code +852 or 852 (optional)
_HK_PHONE_RE = re.compile(
    r"(?:\+?852[\s\-\.]?)?"        # optional country code
    r"([2356789]\d{3})"            # first 4 digits
    r"[\s\-\.]?"                   # optional separator
    r"(\d{4})"                     # last 4 digits
    r"(?!\d)"                      # not followed by more digits (avoid partial match)
)

def extract_hk_phones(text: str) -> List[str]:
    """Return normalized HK phones like '+852 2xxx xxxx' (deduped, order preserved)."""
    if not text:
        return []
    out, seen = [], set()
    for m in _HK_PHONE_RE.finditer(text):
        p = f"+852 {m.group(1)} {m.group(2)}"
        if p not in seen:
            out.append(p)
            seen.add(p)
    return out


def normalize_hk_phone(raw: str) -> str:
    """Return the first valid HK phone in normalized form, or ''."""
    p = extract_hk_phones(raw)
    return p[0] if p else ""


# ---------------------------------------------------------------------------
# 2) BR / CR number
# ---------------------------------------------------------------------------

# BR (Business Registration) 8 digits, optional 3-digit branch suffix
_BR_RE = re.compile(
    r"(?<![\d\w])"               # left boundary
    r"(?:BR\s*(?:No\.?|Number)?[:\s\.]*)?"  # optional "BR No.:" prefix
    r"(\d{8})"                    # 8 digits
    r"(?:[\-\s](\d{3}))?"        # optional branch
    r"(?![\d\w])"                # right boundary
)

_CR_RE = re.compile(
    r"(?<![\d\w])"
    r"(?:C(?:\.|R\.?)|Certificate\s*of\s*Incorporation)[\s\.]*(?:No\.?|Number)?[:\s\.]*"
    r"(\d{8})"
    r"(?![\d\w])"
)

def extract_br_no(text: str) -> str:
    """Return BR no (with branch if present), else ''."""
    if not text:
        return ""
    m = _BR_RE.search(text)
    if not m:
        return ""
    base = m.group(1)
    branch = m.group(2)
    return f"{base}-{branch}" if branch else base


def extract_cr_no(text: str) -> str:
    """Return CR no (Cert of Incorporation), else ''.  Requires explicit CR prefix.
    (Bare 8-digit without prefix should NOT be classified as CR — call extract_br_no
    instead when unsure.)"""
    if not text:
        return ""
    m = _CR_RE.search(text)
    return m.group(1) if m else ""


def is_valid_br_or_cr(s: str) -> bool:
    """Check whether a string is a valid BR/CR format."""
    return bool(re.fullmatch(r"\d{8}(-\d{3})?", s or ""))


# ---------------------------------------------------------------------------
# 3) HK-style address
# ---------------------------------------------------------------------------

# HK 楼层前缀
_FLOOR_RE = re.compile(
    r"\b("
    r"G/F|LG/F|UG/F|M/F|R/F|Basement|Ground\s+Floor|"
    r"(?:\d{1,2})/F|"                      # 1/F ... 99/F
    r"Room\s*\d+|Rm\s*\d+|Flat\s*[\dA-Z]+|Suite\s*\d+|Unit\s*[\dA-Z]+"
    r")\b",
    re.IGNORECASE,
)

_HK_ADDR_KEYWORDS = re.compile(
    r"\b("
    r"Building|Bldg|Tower|Court|Mansion|Plaza|Arcade|House|Terrace|Centre|Center|"
    r"Estate|Industrial\s+Building|IB|Commercial\s+Building|Comm\s+Bldg|"
    r"Podium|Wan|Kok|Wai|"
    r"Street|Rd|Road|Ave|Avenue|Lane|Path|Circuit"
    r")\b",
    re.IGNORECASE,
)

_HK_TAIL_RE = re.compile(
    r"\b(Hong Kong|HK|HKSAR|Kowloon|KLN|New Territories|N\.\s?T\.)\b",
    re.IGNORECASE,
)

def extract_hk_address(text: str) -> str:
    """Best-effort address extractor: pull the sentence around HK/Kowloon tail."""
    if not text:
        return ""
    # Try to find a chunk ending with 'Hong Kong'/'Kowloon'/'N.T.'
    m = re.search(
        r"([^.\n\r]{15,200}?\b(?:Hong Kong|HK|HKSAR|Kowloon|KLN|New Territories|N\.T\.)\b)",
        text,
        re.IGNORECASE,
    )
    if m:
        return m.group(1).strip(" ,;:\t")
    # fallback: look for a chunk with Floor/Building/Street signals
    m = re.search(
        r"((?:Room|Flat|Suite|Unit|G/F|\d{1,2}/F|LG/F|M/F|R/F)[^.\n\r]{5,180})",
        text,
        re.IGNORECASE,
    )
    if m:
        return m.group(1).strip(" ,;:\t")
    return ""


# ---------------------------------------------------------------------------
# 4) 18-district mapping
# ---------------------------------------------------------------------------

_DISTRICT_MAP = {
    # Hong Kong Island
    "central":       "Central & Western",
    "sheung wan":    "Central & Western",
    "sai wan":       "Central & Western",
    "kennedy town":  "Central & Western",
    "mid-levels":    "Central & Western",
    "中西":          "Central & Western",

    "wan chai":      "Wan Chai",
    "causeway bay":  "Wan Chai",
    "happy valley":  "Wan Chai",
    "灣仔":          "Wan Chai",
    "湾仔":          "Wan Chai",
    "銅鑼灣":        "Wan Chai",
    "铜锣湾":        "Wan Chai",

    "north point":   "Eastern",
    "quarry bay":    "Eastern",
    "chai wan":      "Eastern",
    "shau kei wan":  "Eastern",
    "sai wan ho":    "Eastern",
    "東區":          "Eastern",
    "东区":          "Eastern",
    "北角":          "Eastern",
    "柴灣":          "Eastern",

    "aberdeen":      "Southern",
    "ap lei chau":   "Southern",
    "wong chuk hang":"Southern",
    "南區":          "Southern",
    "南区":          "Southern",

    # Kowloon
    "tsim sha tsui": "Yau Tsim Mong",
    "mong kok":      "Yau Tsim Mong",
    "yau ma tei":    "Yau Tsim Mong",
    "jordan":        "Yau Tsim Mong",
    "旺角":          "Yau Tsim Mong",
    "尖沙咀":        "Yau Tsim Mong",
    "油尖旺":        "Yau Tsim Mong",

    "sham shui po":  "Sham Shui Po",
    "cheung sha wan":"Sham Shui Po",
    "lai chi kok":   "Sham Shui Po",
    "深水埗":        "Sham Shui Po",

    "kowloon city":  "Kowloon City",
    "hung hom":      "Kowloon City",
    "to kwa wan":    "Kowloon City",
    "kowloon tong":  "Kowloon City",
    "九龍城":        "Kowloon City",
    "红磡":          "Kowloon City",

    "wong tai sin":  "Wong Tai Sin",
    "diamond hill":  "Wong Tai Sin",
    "san po kong":   "Wong Tai Sin",
    "黃大仙":        "Wong Tai Sin",
    "黄大仙":        "Wong Tai Sin",

    "kwun tong":     "Kwun Tong",
    "ngau tau kok":  "Kwun Tong",
    "kowloon bay":   "Kwun Tong",
    "lam tin":       "Kwun Tong",
    "yau tong":      "Kwun Tong",
    "觀塘":          "Kwun Tong",
    "观塘":          "Kwun Tong",

    # New Territories
    "tsuen wan":     "Tsuen Wan",
    "kwai chung":    "Kwai Tsing",
    "tsing yi":      "Kwai Tsing",
    "荃灣":          "Tsuen Wan",
    "葵青":          "Kwai Tsing",

    "tuen mun":      "Tuen Mun",
    "屯門":          "Tuen Mun",
    "屯门":          "Tuen Mun",

    "yuen long":     "Yuen Long",
    "tin shui wai":  "Yuen Long",
    "tuen mun road": "Yuen Long",
    "元朗":          "Yuen Long",

    "sheung shui":   "North",
    "fanling":       "North",
    "北區":          "North",
    "北区":          "North",

    "tai po":        "Tai Po",
    "大埔":          "Tai Po",

    "sha tin":       "Sha Tin",
    "ma on shan":    "Sha Tin",
    "沙田":          "Sha Tin",
    "馬鞍山":        "Sha Tin",

    "sai kung":      "Sai Kung",
    "tseung kwan o": "Sai Kung",
    "西貢":          "Sai Kung",
    "西贡":          "Sai Kung",
    "将军澳":        "Sai Kung",

    "lantau":        "Islands",
    "tung chung":    "Islands",
    "cheung chau":   "Islands",
    "peng chau":     "Islands",
    "離島":          "Islands",
    "离岛":          "Islands",
    "大嶼山":        "Islands",
}

def extract_hk_district(address_or_text: str) -> str:
    """Return one of HK 18 districts (English) from address/text, else ''."""
    if not address_or_text:
        return ""
    low = address_or_text.lower()
    # try longer keys first
    for key in sorted(_DISTRICT_MAP.keys(), key=len, reverse=True):
        if key in low or key in address_or_text:
            return _DISTRICT_MAP[key]
    return ""


# ---------------------------------------------------------------------------
# 5) ICRIS status normalization
# ---------------------------------------------------------------------------

def normalize_hk_status(raw: str) -> str:
    """Map ICRIS raw status → active|closed|unknown."""
    if not raw:
        return "unknown"
    r = str(raw).lower().strip()
    if any(k in r for k in ("live", "active", "normal", "continuing", "在營", "在营", "正常")):
        return "active"
    if any(k in r for k in (
        "dissolved", "struck off", "deregistered", "wound up", "winding up",
        "ceased", "closed", "terminated", "cancelled", "已解散", "已註銷", "已注销",
        "已撤銷", "已撤销", "已結業", "已结业",
    )):
        return "closed"
    return "unknown"


# ---------------------------------------------------------------------------
# 6) Split CJK + Latin names
# ---------------------------------------------------------------------------

_CJK_RE = re.compile(r"[\u3400-\u9fff]+(?:[（）\s]*[\u3400-\u9fff]+)*")
_ASCII_NAME_RE = re.compile(r"[A-Za-z0-9&'.,\-\s]+")

def split_zh_en_names(name: str) -> Tuple[str, str]:
    """Given a mixed string like 'ABC Trading Ltd 甲乙丙貿易有限公司',
    return (en_name, zh_name). Either may be ''."""
    if not name:
        return "", ""
    s = name.strip()
    # extract all CJK segments
    zh_parts = _CJK_RE.findall(s)
    zh = " ".join(p.strip() for p in zh_parts).strip()
    # remove CJK from string to get EN part
    en = _CJK_RE.sub(" ", s)
    en = re.sub(r"\s+", " ", en).strip(" ,;:\t")
    return en, zh


def is_traditional_chinese(s: str) -> bool:
    """Heuristic: contains typical traditional-only characters."""
    if not s:
        return False
    # A very small sample of traditional-only chars often seen in HK names
    trad_chars = "有限國際貿易國電機東實業運輸倉儲貨運餐廳點心飲食製衣紡織"
    return any(c in s for c in trad_chars)


# ---------------------------------------------------------------------------
# 7) Website / email helpers (HK-tuned)
# ---------------------------------------------------------------------------

_HK_WEBSITE_TLDS = (".com.hk", ".hk", ".com.cn")

_WEBSITE_BLACKLIST_SUBSTR = (
    "facebook.com", "linkedin.com", "instagram.com", "twitter.com", "x.com",
    "wikipedia.org", "wikidata.org",
    "hktdc.com/mkt/", "tradeeasy.hk", "todaytex.com", "mingluji.com",
    "mycom.com.hk",
    "yp.com.hk",           # keep as directory-only, do NOT treat as official website
    "openrice.com",
    "webb-site.com",       # authoritative CR/BR source, but not a company website
    "sentry.io", "wix.com", "godaddy.com",
    "example.com",
)

def is_valid_hk_website(url: str) -> bool:
    if not url:
        return False
    low = url.lower()
    if any(bad in low for bad in _WEBSITE_BLACKLIST_SUBSTR):
        return False
    return low.startswith(("http://", "https://"))


_EMAIL_RE = re.compile(r"\b[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}\b")

_EMAIL_BLACKLIST = (
    "example.com", "noreply@", "no-reply@", "sentry.", "wix.com",
    "godaddy.com", "test@test", "abc@abc",
)

def extract_emails(text: str) -> List[str]:
    if not text:
        return []
    out, seen = [], set()
    for m in _EMAIL_RE.finditer(text):
        e = m.group(0).lower()
        if e in seen:
            continue
        if any(bad in e for bad in _EMAIL_BLACKLIST):
            continue
        seen.add(e)
        out.append(e)
    return out


# ---------------------------------------------------------------------------
# 8) tiny smoke test
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    sample = """
    ABC Global Trading Limited 環球貿易有限公司
    BR No.: 12345678-001
    Certificate of Incorporation No: 87654321
    Room 1203, 12/F, Kowloon Bay Industrial Centre,
    15 Wang Hoi Road, Kowloon Bay, Kowloon, Hong Kong
    Tel: (852) 2345 6789 / +852 9876 5432
    Status: Live
    Email: sales@abc-global.com.hk
    Website: https://www.abc-global.com.hk
    """
    print("phones :", extract_hk_phones(sample))
    print("br     :", extract_br_no(sample))
    print("cr     :", extract_cr_no(sample))
    print("addr   :", extract_hk_address(sample))
    print("district:", extract_hk_district(sample))
    print("status :", normalize_hk_status("Live"))
    print("names  :", split_zh_en_names("ABC Global Trading Limited 環球貿易有限公司"))
    print("emails :", extract_emails(sample))
