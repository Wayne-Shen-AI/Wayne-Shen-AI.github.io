# -*- coding: utf-8 -*-
"""
CRM 行业映射 —— 固定 Tool 入口 (多国通用)
==========================================
统一函数: 把"行业文本"或"国家行业code"映射到 GGS CRM 44个标准行业。
被 website-enrichment / websearch-enrichment 在需要补"行业"字段时调用。

两种输入:
  1) map_by_code(code, country="VN")  —— 国家行业code(目前支持越南VSIC)
  2) map_by_text(text)                —— 任意英文/中文行业描述 → 关键词模糊匹配CRM

返回统一三元组: (crm_industry:str, crm_code:int|None, confidence:"HIGH"|"MEDIUM"|"LOW")

CLI:
  python map_industry.py --text "frozen seafood importer"
  python map_industry.py --code 4632 --country VN
"""
import json, re, argparse
from pathlib import Path

RES = Path(__file__).parent / "resources"
GGS = json.load(open(RES / "ggs_crm_industries.json", encoding="utf-8"))["mapping"]

# 关键词 -> CRM行业名 (模糊匹配桶, 多国通用; 可持续扩充)
KEYWORD_BUCKETS = {
    "Food & Beverage": ["food", "beverage", "drink", "seafood", "frozen", "snack",
                        "rice", "nuts", "wine", "dairy", "meat", "fish", "grocery",
                        "edible", "catering", "confection", "tea", "coffee"],
    "Agriculture": ["agriculture", "farm", "crop", "grain", "livestock", "fertiliz"],
    "Apparel & Fashion Accessories": ["apparel", "garment", "clothing", "fashion", "wear", "denim"],
    "Fabric & Textile Raw Material": ["textile", "fabric", "yarn", "silk", "cotton", "knit"],
    "Shoes & Accessories": ["shoe", "footwear", "sneaker"],
    "Luggage, Bags & Cases": ["bag", "luggage", "case", "handbag", "leather goods"],
    "Beauty": ["beauty", "cosmetic", "makeup", "skincare"],
    "Personal Care & Household Cleaning": ["personal care", "cleaning", "detergent", "hygiene"],
    "Chemicals": ["chemical", "polymer", "resin", "coating", "adhesive"],
    "Rubber & Plastics": ["rubber", "plastic", "pvc", "silicone"],
    "Metals & Alloys": ["metal", "steel", "alloy", "iron", "aluminium", "aluminum", "copper"],
    "Tools & Hardware": ["tool", "hardware", "fastener", "screw", "welding"],
    "Industrial Machinery": ["machinery", "machine", "industrial equip", "automation"],
    "Construction & Building Machinery": ["construction machine", "building machine", "excavat"],
    "Construction & Real Estate": ["construction", "real estate", "property", "building material"],
    "Electrical Equipment & Supplies": ["electrical", "switchgear", "transformer", "cable"],
    "Electronic Components, Electronic Accessories & Telecommunications":
        ["electronic component", "semiconductor", "pcb", "telecom", "connector"],
    "Consumer Electronics": ["consumer electronic", "gadget", "smartphone", "audio"],
    "Home Appliances": ["appliance", "refrigerator", "washing machine"],
    "Lights & Lighting": ["light", "lighting", "led", "lamp"],
    "Furniture": ["furniture", "sofa", "chair", "table"],
    "Home & Garden": ["home", "garden", "household", "kitchenware"],
    "Gifts & Crafts": ["gift", "craft", "handicraft", "souvenir"],
    "Mother, Kids & Toys": ["toy", "kids", "baby", "infant", "maternity"],
    "Sports & Entertainment": ["sport", "fitness", "entertainment", "outdoor"],
    "Packaging & Printing": ["packaging", "printing", "label", "carton", "box"],
    "Medical devices & Medical Supplies": ["medical device", "medical supply", "surgical"],
    "Health Care": ["health care", "healthcare", "pharma", "medicine", "supplement"],
    "Vehicle Parts & Accessories": ["auto part", "vehicle part", "car accessor", "spare part"],
    "Vehicles & Transportation": ["vehicle", "transport", "logistic", "automobile"],
    "Business Services": ["service", "trading", "import", "export", "consult", "agency", "sourcing"],
    "School & Office Supplies": ["office", "stationery", "school supply"],
    "Security": ["security", "surveillance", "cctv", "alarm"],
    "Lights & Lighting": ["lighting"],
    "Pet Supplies": ["pet", "animal feed"],
}


def map_by_text(text):
    """行业文本 → CRM (关键词模糊匹配)。命中专属桶=MEDIUM,落到Trading/Service=LOW。"""
    if not text:
        return (None, None, "LOW")
    t = text.lower()

    def hit(kw):
        # 短词(<=6)用词边界,避免 fabric 命中 fabrication; 长词/含空格直接子串
        if " " in kw or len(kw) > 6:
            return kw in t
        return re.search(r"\b" + re.escape(kw) + r"\w*", t) is not None and \
               not (kw == "fabric" and "fabrication" in t)

    # 优先匹配具体行业(非泛Business Services)
    for ind, kws in KEYWORD_BUCKETS.items():
        if ind == "Business Services":
            continue
        if any(hit(k) for k in kws):
            return (ind, GGS.get(ind), "MEDIUM")
    # 兜底: 贸易/服务类
    if any(k in t for k in KEYWORD_BUCKETS["Business Services"]):
        return ("Business Services", GGS.get("Business Services"), "LOW")
    return (None, None, "LOW")


def map_by_code(code, country="VN"):
    """国家行业code → CRM。目前支持越南 VSIC。"""
    country = country.upper()
    if country == "VN":
        vsic = json.load(open(RES / "vsic_to_ggs.json", encoding="utf-8"))
        m4 = {k: v for k, v in vsic["vsic_4digit"].items() if not k.startswith("_")}
        m2 = {k: v for k, v in vsic["vsic_2digit_fallback"].items() if not k.startswith("_")}
        try:
            s = str(int(float(code))).zfill(4)
        except Exception:
            return (None, None, "LOW")
        if s in m4:
            v = m4[s]; return (v["ggs_industry"], v["ggs_code"], v["confidence"])
        if s[:2] in m2:
            v = m2[s[:2]]; return (v["ggs_industry"], v["ggs_code"], "LOW")
        return (None, None, "LOW")
    # 其他国家暂无 code 字典, 提示走文本映射
    return (None, None, "LOW")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--text"); ap.add_argument("--code"); ap.add_argument("--country", default="VN")
    a = ap.parse_args()
    if a.code:
        print(map_by_code(a.code, a.country))
    elif a.text:
        print(map_by_text(a.text))
    else:
        # demo
        for t in ["frozen seafood importer", "steel & metal fabrication",
                  "ladies handbag manufacturer", "general trading company"]:
            print(f"{t!r:45} -> {map_by_text(t)}")
