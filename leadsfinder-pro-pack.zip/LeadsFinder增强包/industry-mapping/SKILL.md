# industry-mapping

把任意外部行业体系（LinkedIn industry / 越南 VSIC 2007 / 中文/英文自由文本 / 印度 NIC ...）
统一映射到 **GGS CRM 44 个行业 code**，并输出标准三列：

```
crm_industry   (str)   GGS CRM 行业名 (英文)
crm_code       (int)   GGS CRM 行业 code (1 ~ 202014504)
map_confidence (enum)  HIGH | MEDIUM | LOW
```

---

## When to use

用户给一个 Excel/CSV，含 "industry / 行业 / sector / business_code / nganh_nghe" 字段，
要把它**入库 GGS CRM** 或**导入 ODPS 表**，触发本 skill。

典型自然语言触发：
- "把这批 leads 的行业映射成 GGS code"
- "看下 xxx.xlsx 的 industry 列，处理成 CRM 行业"
- "这个 main_business_code 是越南 VSIC，转成我们行业体系"
- "印度 NIC code 跟 GGS 行业对一下"

---

## Decision tree (先判断源字段类型)

```
源字段是什么?
├─ 英文 industry 文本 (LinkedIn / Crunchbase / 自填)
│    → 走 linkedin_to_ggs.json (107+ 已沉淀)
│    → 缺失关键词时 fuzzy match
│
├─ 国家行业 code (数字 4-5 位)
│    ├─ 越南 VSIC 2007    → vsic_to_ggs.json    (83 个 4 位 code + 41 个 2 位 fallback)
│    ├─ 印度 NIC 2008     → 暂未沉淀, 按需扩展
│    └─ 中国 GB/T 4754    → 暂未沉淀, 按需扩展
│
└─ 中文/越南语/自由文本描述
     → fuzzy_keyword_matcher (按关键词桶匹配)
     → 置信度普遍 MEDIUM/LOW, 输出后让用户复核 mapping_report.csv
```

---

## 固定 Tool 入口 (推荐, 给其他 skill 调用)

`map_industry.py` —— 统一映射函数, 被 website-enrichment / websearch-enrichment 调用:
```python
from map_industry import map_by_text, map_by_code
map_by_text("frozen seafood importer")   # -> ('Food & Beverage', 2, 'MEDIUM')  任意国家行业文本
map_by_code(4632, country="VN")          # -> ('Food & Beverage', 2, 'HIGH')    国家行业code
# 返回统一三元组: (crm_industry, crm_code, confidence)
```
CLI: `python map_industry.py --text "..."` 或 `--code 4632 --country VN`
多国: VN 有 VSIC code 走 map_by_code(最准); 其他国家只有行业文本走 map_by_text(关键词模糊)。

## Resources (本 skill 内置)

| 文件 | 用途 |
|------|------|
| `map_industry.py`                    | **固定Tool入口**: map_by_text / map_by_code, 多国统一映射函数 |
| `resources/ggs_crm_industries.json` | **唯一权威**: GGS CRM 44 个行业 → code (其他映射都靠这个反查) |
| `resources/vsic_to_ggs.json`         | 越南 VSIC 2007 → GGS (2 层 fallback: 4 位精确 + 2 位大类兜底) |
| `resources/linkedin_to_ggs.json`     | (Faire4 项目沉淀, 待迁移) LinkedIn industry 文本 → GGS |

加载方式：

```python
import json
from pathlib import Path

SKILL = Path(__file__).parent / "resources"   # 或硬编码 skill 绝对路径
GGS = json.load(open(SKILL / "ggs_crm_industries.json", encoding="utf-8"))["mapping"]
VSIC = json.load(open(SKILL / "vsic_to_ggs.json",        encoding="utf-8"))
```

---

## Workflow (跑一次完整映射)

### 1) Discover
```python
df = pd.read_excel(src)
print(df.columns.tolist())
print(df["industry_field"].value_counts(dropna=False).head(20))
print(f"unique 值: {df['industry_field'].nunique()}")
```
**目的**: 看 unique 值数量决定映射策略
- < 200 个 → 硬编码字典即可
- 200~2000 个 → 字典 + fuzzy fallback
- > 2000 个 → 先聚类清洗

### 2) Select mapping table
对照 Decision tree 找/创建对应 `resources/xxx_to_ggs.json`。

**新建一份映射表时的最低要求** (1 小时人工可完成):
- 列 unique 值排序 → 覆盖 top 80% 频次的就够
- 每条至少打 `confidence` (HIGH=语义精确 / MEDIUM=合理但不唯一 / LOW=兜底)
- 加 `_comment` 分段方便后续维护

### 3) 写映射函数 (3 层 fallback)
```python
def map_one(value):
    # Layer 1: 精确命中
    if v := MAIN.get(value):
        return (v["ggs_industry"], v["ggs_code"], v["confidence"])
    # Layer 2: fallback (大类 / fuzzy)
    if v := FALLBACK_RULE(value):
        return (v["ggs_industry"], v["ggs_code"], "LOW")
    # Layer 3: miss
    return (None, None, "LOW")
```

### 4) 应用到 DataFrame + 输出 3 文件
```python
mapped = df["src_col"].apply(map_one)
df["crm_industry"]   = mapped.apply(lambda x: x[0])
df["crm_code"]       = mapped.apply(lambda x: x[1])
df["map_confidence"] = mapped.apply(lambda x: x[2])

df.to_excel(out_xlsx, index=False)                                        # 用户复核
df.to_csv(out_csv, index=False, encoding="utf-8-sig")                     # ODPS 上传
# crm_code / 源 code 都要 Int64 否则 CSV 里出现 28.0
```
**别忘了第 3 个文件 — 映射报告 (mapping_report.csv)**:
```python
df.groupby("src_col", dropna=False).agg(
    count=("src_col", "size"),
    crm_industry=("crm_industry", "first"),
    crm_code=("crm_code", "first"),
    confidence=("map_confidence", "first"),
).sort_values("count", ascending=False).to_csv(report, encoding="utf-8-sig")
```

### 5) 汇报覆盖率给用户
必须报这 4 个数:
- 总行数
- 含源 code 的行数
- 映射成功行数 (含 HIGH/MEDIUM/LOW)
- HIGH/MEDIUM/LOW 比例

---

## 已验证案例

| 数据集 | 源字段 | 映射表 | 覆盖率 | 备注 |
|--------|--------|--------|--------|------|
| Faire4.xlsx (9356 行) | LinkedIn industry 文本 (107 unique) | hardcoded 字典 | 99.5% (HIGH 66.6% + MEDIUM 32.9% + LOW 0.5%) | 未映射 39 行属机构类 (nonprofit/government) |
| masothue_with_phone20260525.xlsx (1255 行) | main_business_code (VSIC, 83 unique) | vsic_to_ggs.json (4位 + 2位) | 含 code 的 866 行 100% (HIGH 69.1% + MEDIUM 30.9%) | 389 行源数据无 code, 非映射问题 |
| masothue_20260618.xlsx (1481 行) | main_business_code (VSIC, 208 unique) | vsic_to_ggs.json 大扩充 (4位 111→253, 2位 40→71) | 含 code 的 1355 行 100% (HIGH 61.9% + MEDIUM 37.9% + LOW 0.1%) | 126 行无 code; 本次新沉淀服务业大类: 餐饮56/软件IT62/房地产68/教育85/医疗86/汽修95/美容96/体育93/住宿55/旅游79/安保80/运输49,50,53/环保38,39/电力35/维修33/采矿08/农林牧渔01,02,03 |

---

## Anti-pattern (踩过的坑)

1. **不要基于越南语字符串映射** — 同一 VSIC code 在 masothue 有 N 种写法 (有 "Chi tiết:..." 尾巴),
   字符串去重失败。**永远基于 code (数字标准) 映射**。
2. **不要写死成 .py 字典** — 资源跟脚本耦合，无法被其他 skill 共享。
   **统一放 `resources/*.json`**, 脚本 load JSON 用。
3. **CSV 里 code 列不要漏 cast Int64** — pandas 默认浮点会出现 `28.0`，DataWorks 入 BIGINT 列报错。
4. **确认置信度可让用户决策** — HIGH 自动入库, MEDIUM 抽样复核, LOW 人工兜底。
   不要把 LOW 当 HIGH 上报「100% 成功」。

---

## Extending (新增国家/体系)

1. 用户给一份 N 行的源数据
2. `value_counts(dropna=False).head(N)` 看 top 频次
3. 在 `resources/` 下新建 `{source}_to_ggs.json` (照抄 vsic_to_ggs.json 结构)
4. 跑一次脚本生成 mapping_report.csv → 用户复核 → 迭代字典
5. 更新本 SKILL.md 的 "已验证案例" 表
