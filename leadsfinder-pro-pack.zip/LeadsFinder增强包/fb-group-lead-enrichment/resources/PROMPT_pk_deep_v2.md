# PROMPT: PK FB v2 深度补全 sub-agent 契约 (4 字段版)

**触发**: 只对 v1 交付后 `is_business=yes` 但零联系方式的子集使用。跟 PROMPT_pk_direct.md (v1 24 字段) 互补, 不重复。

**输入 shard**: `_fb_pk_v2/in_XXX.json` (8 家/片), 每条含 v1 已知信息:
```json
{
  "row": <int>,
  "fb_name": "", "fb_url": "", "fb_category": "", "fb_loc_hint": "",
  "company_name": "",   // v1 已确认
  "city": "", "province": "",
  "product": "", "sitc_text": "",
  "urdu_name": "",
  "address": "",        // v1 已有
  "status": ""
}
```

## 🎯 只补 4 个字段

| 字段 | 来源优先级 | 说明 |
|---|---|---|
| `website_v2` | 1. **PSGMEA/SIALKOT.CC 商会目录** > 2. Alibaba/IndiaMART/ExportersIndia > 3. **官网直接域名猜测** (`<slug>.com.pk` / `<slug>.pk`) > 4. **FB Page About Section 里的官网链接** | 官网根域, 排除 fb/linkedin/insta/psgmea/alibaba/indiamart 目录站 |
| `email_v2` | 1. 官网 /contact > 2. **FB Page About** > 3. PSGMEA/SCCI 目录 > 4. LinkedIn About | `info@` / `sales@` / `export@` / `contact@`; 严禁 `.in`/`.cn` 域, 严禁编造 |
| `mobile_no_v2` | 1. **FB Page bio** > 2. **Instagram bio** > 3. LinkedIn > 4. 官网/商会 | `+92 3xx xxxxxxx` (PK 手机 3 开头); Sialkot 座机是 `+92-52-xxxxxxx` |
| `founder_owner_v2` | 1. **LinkedIn Company Page** ("Founded by" / "CEO") > 2. **FB Page About** > 3. About Us 页 > 4. 商会目录 | CEO/Founder/MD/Owner 姓名, 姓名 tokens ≥ 2 才算有效 |

## 🔎 检索路径 (每家 4-6 次工具调用为限)

**推荐顺序 (v2 独有优先级)**:

1. **web_fetch `<fb_url>`** (**新路径, 高命中**)
   - 直接抓 FB Page 主页, About Section 里常含 official website / email / phone / founder
   - 覆盖率约 30-40%, 一次就能拿到 2-3 个字段
   - 若返回 empty/404, note=`fb_not_found` 跳过

2. **web_search `"<company_name>" sialkot OR pakistan site:psgmea.org.pk OR site:sialkot.cc`**
   - Sialkot 体育/手术器械专用商会目录
   - 命中直接能拿 phone/email/官网

3. **web_search `"<company_name>" pakistan linkedin`** 或 `linkedin.com/company/<slug>`
   - LinkedIn 是 founder_owner 主要来源

4. **web_search `"<company_name>" pakistan contact email`**
   - 常规 web_search 兜底

5. **web_fetch <官网>** — 拿到官网后抓 /contact 或 /about-us

6. **备用**: `site:instagram.com <company_name> pakistan`
   - Instagram bio 里的 `+92` 手机

## 🔴 硬规则

- **禁止编造**: 找不到留 ""; 明显海外域 (`.in` / `.cn` / `-india` / `-china` / `-korea`) 一律拒收 → 标 `enrich_note_v2=email_offshore_reject`, 字段空
- **同名歧义**: Sialkot 撞名严重, 命中的必须能证明:
  - (a) 域名 `.com.pk` / `.pk` 或
  - (b) FB Page 显示 Sialkot 地址 或
  - (c) LinkedIn About 明确 Pakistan
  - 否则 `enrich_note_v2=ambiguous`, 4 字段空
- **email 去噪**: 过滤 `example.com` / `sentry` / `wixpress` / `noreply@` / `.png` / `.jpg`; 保留 `@gmail.com` (PK SME 惯用)
- **mobile 规范化**:
  - `03xxxxxxxxx` (11 位) → `+92 3xx xxxxxxx`
  - `0092xxx` → `+92xxx`
  - `92xxx` → `+92xxx`
  - 明显海外号 (印度 +91 / 中国 +86 / 美国 +1) 拒收
- **website 排除**: fb.com/linkedin.com/instagram.com/pinterest.com/psgmea.org.pk/sialkot.cc/alibaba.com/indiamart.com/exportersIndia/tradesparq (这些是目录站, 不是官网)
- **每家最多 6 次工具调用**, 超支就跳 (`enrich_note_v2=timeout`)

## 📤 输出

写到 `_fb_pk_v2_out/out_XXX.json` (与输入 shard 同名), 格式:

```json
[
  {
    "row": <int, 与输入一致>,
    "company_name": "<透传 v1 值>",
    "website_v2": "",
    "email_v2": "",
    "mobile_no_v2": "",
    "founder_owner_v2": "",
    "source_url_v2": "",
    "enrich_note_v2": ""
  }
]
```

**`enrich_note_v2` 可选值** (帮 audit 用):
- `fb_page_hit` — 从 FB Page About 拿到 (推荐 note 类型)
- `psgmea_hit` / `scci_hit` — 商会目录命中
- `linkedin_hit` — LinkedIn 命中
- `official_hit` — 抓到官网
- `no_online_presence` — 完全无线索 (稀有)
- `ambiguous` — 同名撞车字段空
- `email_offshore_reject` — 命中海外域拒收
- `fb_not_found` — fb_url 无效
- `backend_error` — YOU.COM 后端连败 3 次
- `timeout` — 单家超预算

## ⚙️ 分片 / 并发参数

| 参数 | 值 | 依据 |
|---|---|---|
| 每片家数 | **8** | 单 sub-agent 4-6 min 内可完成 write |
| 每 sub-agent 处理 | **2 片 (16 家)** | 超过 3 片会超时 |
| 并发 sub-agent | **3** | 稳定甜蜜点 |
| 每家 tool 预算 | **4-6** (search + fetch 合计) | 找不到就跳 |
| 单 shard 时间 | **6-10 min** | 卡时限就 write |

## 🎬 完成信号

**每片处理完立即 write** (别攒), 完成后回复:
`DONE v2 XXX-YYY, N filled (email:X web:Y mobile:Z kp:W)`

## 📊 实战 baseline (2026-07-09, PK 450 家里的 112 家)

- 命中率: **75/112 = 67%**
- mobile_no +60 (54% of 112)
- email +48 (43%)
- website +37 (33%)
- founder_owner +28 (25%)
- **合并 v1 后: yes+contact 270 → 340 家 (+70 家 +26%)**
