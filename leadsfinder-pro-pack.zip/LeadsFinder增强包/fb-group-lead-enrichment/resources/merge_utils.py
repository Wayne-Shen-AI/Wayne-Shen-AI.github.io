# -*- coding: utf-8 -*-
"""
fb-group-lead-enrichment / Stage 4 merge utilities
==================================================
Given a set of `out_*.json` files from sub-agents + a `target.pkl` (Stage 1
output DataFrame), produce the final xlsx/csv with:
  - scrubbed placeholders
  - normalized status (active/closed/unknown)
  - normalized tax_code (10-digit or 10-3 branch)
  - VSIC → GGS CRM industry mapping (via industry-mapping skill)
  - normalized state (HK 18 districts / VN provinces)

Also has:
  - `union_batches()` to combine v2/v3/v4/v5 outputs into a master xlsx
  - state normalization for VN

Usage:
    from merge_utils import (
        scrub, norm_status_vn, norm_tax, do_industry_map,
        normalize_vn_state, union_batches, build_final_row,
    )
"""
from __future__ import annotations
import re
import sys
from typing import Tuple

# ---------------------------------------------------------------------------
# 1) Placeholder scrubber
# ---------------------------------------------------------------------------
_BAD_TOKENS = {
    "n/a", "n.a", "na", "not found", "notfound", "none", "nil", "null",
    "无", "未找到", "-", "--", "unknown", "unavailable",
}
def scrub(v) -> str:
    if v is None:
        return ""
    s = str(v).strip()
    if not s:
        return ""
    if s.lower() in _BAD_TOKENS:
        return ""
    if re.fullmatch(r"\*+", s):
        return ""
    return s


# ---------------------------------------------------------------------------
# 2) Status normalization (VN language + English)
# ---------------------------------------------------------------------------
def norm_status_vn(status: str, raw: str = "") -> str:
    """Map VN status text to active/closed/unknown. Checks BOTH status + raw."""
    s = (status or "").lower().strip()
    if s in ("active", "closed", "unknown"):
        return s
    # combined check: status + raw
    combined = (s + " " + (raw or "").lower()).strip()
    if any(k in combined for k in (
        "ngừng", "không hoạt động", "hết hiệu lực", "tạm ngừng",
        "closed", "chấm dứt",
    )):
        return "closed"
    if any(k in combined for k in ("đang hoạt động", "hoạt động", "active")):
        return "active"
    return "unknown"


# ---------------------------------------------------------------------------
# 3) Tax code normalization (VN: 10 digits, optional 3-digit branch)
# ---------------------------------------------------------------------------
def norm_tax(v) -> str:
    v = scrub(v)
    if not v:
        return ""
    if re.fullmatch(r"(\d{10})(-\d{3})?", v):
        return v
    digits = re.sub(r"\D", "", v)
    if len(digits) >= 10:
        return digits[:10]
    return ""


# ---------------------------------------------------------------------------
# 4) VSIC → GGS CRM industry mapping
# ---------------------------------------------------------------------------
# Delayed import to keep this module importable without industry-mapping skill.
_INDUSTRY_MAPPING_PATH_CANDIDATES = [
    r"C:\Users\zhangyu\.accio\accounts\1660079974\agents\MID-78079974U1776135-18EA3F-2181-A25DCF\agent-core\skills\industry-mapping",
]

def _load_industry_mapping():
    for p in _INDUSTRY_MAPPING_PATH_CANDIDATES:
        try:
            if p not in sys.path:
                sys.path.insert(0, p)
            from map_industry import map_by_code, map_by_text
            return map_by_code, map_by_text
        except Exception:
            continue
    return None, None

def do_industry_map(vsic_code: str, vsic_text: str = "",
                    product: str = "", country: str = "VN") -> Tuple[str, str, str]:
    """Return (industry_name, crm_code, confidence). Empty tuple on failure."""
    map_by_code, map_by_text = _load_industry_mapping()
    if map_by_code is None:
        return ("", "", "")
    if vsic_code:
        try:
            c = int(re.sub(r"\D", "", str(vsic_code))[:4])
            if c:
                r = map_by_code(c, country=country)
                if r and r[0]:
                    return r
        except Exception:
            pass
    for text in (vsic_text, product):
        if text and map_by_text:
            r = map_by_text(text)
            if r and r[0]:
                return r
    return ("", "", "")


# ---------------------------------------------------------------------------
# 5) VN state / province normalization
# ---------------------------------------------------------------------------
_VN_STATE_MAP = {
    # HCM variations → Ho Chi Minh City
    r"^(tp\.?\s*)?hồ\s*chí\s*minh$":    "Ho Chi Minh City",
    r"^(tp\.?\s*)?ho\s*chi\s*minh$":    "Ho Chi Minh City",
    r"^hcmc?$":                          "Ho Chi Minh City",
    r"^ho\s*chi\s*minh\s*city$":         "Ho Chi Minh City",
    r"^sài\s*gòn$":                      "Ho Chi Minh City",
    r"^saigon$":                          "Ho Chi Minh City",
    # Hanoi
    r"^hà\s*nội$": "Hanoi",
    r"^ha\s*noi$": "Hanoi",
    r"^hanoi$":    "Hanoi",
    # Provinces
    r"^bình\s*dương$": "Binh Duong", r"^binh\s*duong$": "Binh Duong",
    r"^bà\s*rịa\s*-?\s*vũng\s*tàu$": "Ba Ria - Vung Tau",
    r"^ba\s*ria\s*-?\s*vung\s*tau$": "Ba Ria - Vung Tau",
    r"^vũng\s*tàu$":   "Ba Ria - Vung Tau",
    r"^long\s*an$":    "Long An",
    r"^an\s*giang$":   "An Giang",
    r"^cần\s*thơ$":    "Can Tho", r"^can\s*tho$":  "Can Tho",
    r"^cà\s*mau$":     "Ca Mau",  r"^ca\s*mau$":   "Ca Mau",
    r"^hưng\s*yên$":   "Hung Yen", r"^hung\s*yen$": "Hung Yen",
    r"^đồng\s*nai$":   "Dong Nai", r"^dong\s*nai$": "Dong Nai",
    r"^đồng\s*tháp$":  "Dong Thap", r"^dong\s*thap$": "Dong Thap",
    r"^bình\s*thuận$": "Binh Thuan", r"^binh\s*thuan$": "Binh Thuan",
    r"^hải\s*phòng$":  "Hai Phong", r"^hai\s*phong$": "Hai Phong",
    r"^đà\s*nẵng$":    "Da Nang",   r"^da\s*nang$":   "Da Nang",
    r"^nha\s*trang$":  "Khanh Hoa",
    r"^khánh\s*hòa$":  "Khanh Hoa", r"^khanh\s*hoa$": "Khanh Hoa",
    r"^bến\s*tre$":    "Ben Tre",   r"^ben\s*tre$":  "Ben Tre",
    r"^tiền\s*giang$": "Tien Giang", r"^tien\s*giang$": "Tien Giang",
    r"^lâm\s*đồng$":   "Lam Dong",  r"^lam\s*dong$": "Lam Dong",
    r"^tây\s*ninh$":   "Tay Ninh",  r"^tay\s*ninh$": "Tay Ninh",
    r"^bình\s*phước$": "Binh Phuoc", r"^binh\s*phuoc$": "Binh Phuoc",
    r"^quảng\s*ninh$": "Quang Ninh", r"^quang\s*ninh$": "Quang Ninh",
    r"^kiên\s*giang$": "Kien Giang", r"^kien\s*giang$": "Kien Giang",
    r"^bắc\s*ninh$":   "Bac Ninh",  r"^bac\s*ninh$":  "Bac Ninh",
    r"^bắc\s*giang$":  "Bac Giang", r"^bac\s*giang$": "Bac Giang",
    r"^vĩnh\s*long$":  "Vinh Long", r"^vinh\s*long$": "Vinh Long",
    r"^ninh\s*bình$":  "Ninh Binh", r"^ninh\s*binh$": "Ninh Binh",
    r"^phú\s*thọ$":    "Phu Tho",   r"^phu\s*tho$":   "Phu Tho",
}

def normalize_vn_state(s: str) -> str:
    if not s:
        return ""
    s = str(s).strip()
    if not s:
        return ""
    low = s.lower()
    for pat, canon in _VN_STATE_MAP.items():
        if re.match(pat, low):
            return canon
    # Strip ", Vietnam" tail and retry
    cleaned = re.sub(r",?\s*vietnam$", "", low, flags=re.IGNORECASE).strip()
    if cleaned != low:
        for pat, canon in _VN_STATE_MAP.items():
            if re.match(pat, cleaned):
                return canon
    return s


# ---------------------------------------------------------------------------
# 6) Final row builder (canonical schema)
# ---------------------------------------------------------------------------
FB_COLS = ["fb_name", "fb_url", "fb_category", "fb_followers", "fb_loc_hint"]
PROBE_COLS = ["country_probe", "country_reason", "country_detail"]
ENR_COLS = [
    "is_business", "company_name", "local_company_name", "tax_code",
    "established", "status", "status_raw", "link_man", "address",
    "state", "phone_number", "mobile_no", "email", "website",
    "product", "vsic_code", "vsic_text", "is_exporter",
    "source_url", "remark",
]
CRM_COLS = ["crm_industry", "crm_code", "map_confidence"]
FINAL_COLS_VN = FB_COLS + ["category"] + ENR_COLS + CRM_COLS
FINAL_COLS_FULL = FB_COLS + ["category"] + PROBE_COLS + ENR_COLS + CRM_COLS

def build_final_row(target_row, enr: dict, with_probe: bool = False) -> dict:
    """Assemble one final row.
    target_row: pandas Series (from target.pkl) with keys name/fb_url/loc_or_cat/...
    enr: dict from out_XX.json for this row's `row` index. May be empty.
    """
    row = {}
    row["fb_name"]      = scrub(target_row.get("name", ""))
    row["fb_url"]       = scrub(target_row.get("fb_url", ""))
    row["fb_category"]  = scrub(target_row.get("fb_category", ""))
    row["fb_followers"] = scrub(target_row.get("fb_followers", ""))
    row["fb_loc_hint"]  = scrub(target_row.get("loc_or_cat", ""))
    row["category"]     = scrub(target_row.get("category", ""))
    if with_probe:
        row["country_probe"]  = scrub(enr.get("country_probe", ""))
        row["country_reason"] = scrub(enr.get("country_reason", ""))
        row["country_detail"] = scrub(enr.get("country_detail", ""))
    for c in ENR_COLS:
        row[c] = scrub(enr.get(c, ""))
    row["tax_code"] = norm_tax(row["tax_code"])
    row["status"]   = norm_status_vn(row["status"], row["status_raw"])
    row["state"]    = normalize_vn_state(row["state"])
    ci, cc, cf = do_industry_map(row["vsic_code"], row["vsic_text"], row["product"])
    row["crm_industry"]    = ci or ""
    row["crm_code"]        = cc or ""
    row["map_confidence"]  = cf or ""
    return row


# ---------------------------------------------------------------------------
# 7) Union of multiple batches (cross-batch dedup)
# ---------------------------------------------------------------------------
def union_batches(batch_xlsx_paths: list, output_xlsx: str,
                  key_cols: list = None) -> "pandas.DataFrame":
    """Concat multiple batch xlsx, dedup on fb_url (fallback fb_name), write output.

    Adds a `batch` column at position 0 (based on file basename)."""
    import pandas as pd
    import os
    key_cols = key_cols or ["fb_url", "fb_name"]
    frames = []
    for p in batch_xlsx_paths:
        df = pd.read_excel(p, dtype=str).fillna("")
        tag = os.path.basename(p).split(".")[0]
        # Extract short tag like 'v2' from 'fb_vn_enriched_v2'
        m = re.search(r"(v\d+)", tag)
        if m:
            tag = m.group(1)
        df.insert(0, "batch", tag)
        frames.append(df)
    union = pd.concat(frames, ignore_index=True)
    before = len(union)
    # dedup on fb_url first, fallback fb_name
    union["_k"] = union["fb_url"].where(
        union["fb_url"].astype(str).str.strip() != "",
        union["fb_name"],
    ).astype(str).str.strip().str.lower()
    union = union.drop_duplicates(subset="_k", keep="first").drop(columns=["_k"]).reset_index(drop=True)
    union.to_excel(output_xlsx, index=False)
    union.to_csv(output_xlsx.replace(".xlsx", ".csv"), index=False,
                 encoding="utf-8-sig", lineterminator="\n")
    print(f"union: {before} → {len(union)} rows (deduped), wrote {output_xlsx}")
    return union


# ---------------------------------------------------------------------------
# Smoke test
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    print("scrub:")
    for v in ["hello", "n/a", "NOT FOUND", "**", " ", None, "0301427028"]:
        print(f"  {v!r:20s} → {scrub(v)!r}")

    print("\nnorm_status_vn:")
    for a, b in [("Đang hoạt động", ""), ("Ngừng hoạt động", ""),
                 ("active", ""), ("random", "Hoạt động"), ("", "closed")]:
        print(f"  ({a!r:20s}, {b!r:20s}) → {norm_status_vn(a, b)}")

    print("\nnorm_tax:")
    for v in ["0301427028", "0301427028-001", "N/A", "12345", "1234567890 (some suffix)"]:
        print(f"  {v!r:35s} → {norm_tax(v)!r}")

    print("\nnormalize_vn_state:")
    for s in ["TP Hồ Chí Minh", "Hà Nội", "HCMC", "Bình Dương", "Vũng Tàu", "Random Place"]:
        print(f"  {s!r:20s} → {normalize_vn_state(s)!r}")

    print("\ndo_industry_map:")
    for vsic in ["4632", "1071", "9999"]:
        print(f"  VSIC {vsic:6s} → {do_industry_map(vsic)}")
