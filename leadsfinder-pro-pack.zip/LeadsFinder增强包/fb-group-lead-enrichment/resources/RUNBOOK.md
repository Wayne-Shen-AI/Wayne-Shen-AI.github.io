# RUNBOOK: FB Group Lead Enrichment 快速操作手册

未来会话按这个流程执行, 6 步跑完全流程 (含多国路由决策)。

---

## Step -1: 决定 target_country (必做!)

**在开始任何流程前, 必须先确定 target_country**:

| 用户说 | target_country | 处理 |
|---|---|---|
| "越南 / VN / Vietnam FB 名单" | `VN` | 本 skill 主流程 |
| "巴基斯坦 / PK / Pakistan / Sialkot / Karachi FB 名单" | `PK` | 本 skill 主流程 |
| "香港 / HK / Hong Kong FB 名单" | `HK` | **委托** `hk-company-enrichment` skill (退出本流程) |
| "印度 / IN / India" | `IN` | pack 未建, 提示用户 (可用 template.md 帮扩) |
| **模糊或没提国家** | ? | **必须 `ask_user`** 确认 target_country, 不猜 |

代码里传参: `detect_country(name, loc, target_country="PK")` + `cat_and_reason(country, name, target_country="PK")`

---

## Step 0: 收集输入

用户丢来 `facebook (N).xlsx` 或多份。用 `glob` 找出所有:

```python
import glob
files = sorted(glob.glob(r"C:\Users\zhangyu\Downloads\facebook*.xlsx"))
```

**排除**:
- 广告文件 (29 列版, 结构不同): 检测列数或列名
- 已经跑过的 (与 `Agent_output/fb_vn_enriched_all.xlsx` 交叉去重)

---

## Step 1: 分类 (`_classify.py`, 支持多国)

```python
import pandas as pd, os
from resources.classify import detect_country, cat_and_reason, parse_followers, parse_fb_category

TARGET_COUNTRY = "PK"  # ← 从 Step -1 决定, VN/PK/其它

rows = []
for f in files:
    df = pd.read_excel(f, dtype=str).fillna("")
    for _, r in df.iterrows():
        rows.append({
            "src_file": os.path.basename(f),
            "fb_url":   r.get("x1i10hfl href", ""),
            "name":     r.get("x1i10hfl", ""),
            "joined":   r.get("x193iq5w", ""),
            "loc_or_cat": r.get("x193iq5w 2", ""),
        })
df = pd.DataFrame(rows)

# 批内 dedup
df["_key"] = df["name"].str.strip() + "||" + df["fb_url"].str.strip()
df = df.drop_duplicates(subset="_key").drop(columns=["_key"]).reset_index(drop=True)

# 跨批 dedup vs prev 总账 (按国家分开)
prev_file = f"Agent_output/fb_{TARGET_COUNTRY.lower()}_enriched_all.xlsx"
try:
    prev = pd.read_excel(prev_file, dtype=str).fillna("")
    prev_url  = set(prev["fb_url"].str.strip().str.lower())
    prev_name = set(prev["fb_name"].str.strip().str.lower())
    df = df[~df.apply(lambda r: (r["fb_url"].lower() in prev_url) or (r["name"].lower() in prev_name), axis=1)].reset_index(drop=True)
except: pass

# 分类 (带 target_country!)
df["country"], df["country_reason"] = zip(*df.apply(
    lambda r: detect_country(r["name"], r["loc_or_cat"], r["joined"], target_country=TARGET_COUNTRY), axis=1))
df["category"], df["cat_reason"] = zip(*df.apply(
    lambda r: cat_and_reason(r["country"], r["name"], target_country=TARGET_COUNTRY), axis=1))
df["fb_followers"] = df["loc_or_cat"].map(parse_followers)
df["fb_category"]  = df["loc_or_cat"].map(parse_fb_category)

# 拆两个待处理子集 (country 值动态取 TARGET_COUNTRY)
direct_target = df[(df["country"]==TARGET_COUNTRY) & df["category"].isin(["CO_STRICT","BIZ_LOOSE","AMBIGUOUS"])].reset_index(drop=True)
unk_probe     = df[(df["country"]=="UNKNOWN")      & df["category"].isin(["CO_STRICT","BIZ_LOOSE","AMBIGUOUS"])].reset_index(drop=True)

print(f"{TARGET_COUNTRY} direct: {len(direct_target)} | UNK probe: {len(unk_probe)}")
```

---

## Step 2: 拆 shard + 保存

```python
import json, shutil
def make_shards(target_df, folder, size=10):
    if os.path.exists(folder): shutil.rmtree(folder)
    os.makedirs(folder, exist_ok=True)
    target_df.to_pickle(f"{folder}/target.pkl")
    recs = [{
        "row": i,
        "fb_name":  r["name"],
        "category": r["category"],
        "fb_url":   r["fb_url"],
        "fb_category":  r.get("fb_category",""),
        "fb_followers": r.get("fb_followers",""),
        "fb_loc_hint":  r.get("loc_or_cat",""),
    } for i, r in target_df.iterrows()]
    n = 0
    for s in range(0, len(recs), size):
        n += 1
        json.dump(recs[s:s+size], open(f"{folder}/in_{n:02d}.json","w",encoding="utf-8"), ensure_ascii=False, indent=1)
    return n

tag = TARGET_COUNTRY.lower()
n_direct = make_shards(direct_target, f"_fb_enrich_{tag}_direct", size=8)
n_unk    = make_shards(unk_probe,     f"_fb_enrich_{tag}_unk",    size=15)
print(f"{TARGET_COUNTRY} direct shards: {n_direct} | UNK probe shards: {n_unk}")

# 复制对应国家的 PROMPT
skill_dir = r"C:\Users\zhangyu\.accio\accounts\1660079974\agents\MID-78079974U1776135-18EA3F-2181-A25DCF\agent-core\skills\fb-group-lead-enrichment\resources"
prompt_direct_map = {
    "VN": "PROMPT_vn_direct.md",
    "PK": "PROMPT_pk_direct.md",
    # 未来加新国家: "IN": "PROMPT_in_direct.md",
}
shutil.copy(f"{skill_dir}/{prompt_direct_map[TARGET_COUNTRY]}", f"_fb_enrich_{tag}_direct/PROMPT.md")
shutil.copy(f"{skill_dir}/PROMPT_probe_country.md",              f"_fb_enrich_{tag}_unk/PROMPT.md")
# 也复制 country pack 供 sub-agent 参考
shutil.copy(f"{skill_dir}/countries/{tag}.md",                    f"_fb_enrich_{tag}_direct/COUNTRY_PACK.md")
```

---

## Step 3: 并发 sub-agent 跑背调

**并发 3, 波次调度**。每波下发 3 个 `sessions_spawn`, 等全部完成再下下一波。

模板任务描述:
```
Kompass VN Batch X - shard NNNN (or 类似)
工作目录: C:\Users\zhangyu\PycharmProjects\pythonProject
输入: _fb_enrich_vX_vn/in_NN.json (N 条)
输出: _fb_enrich_vX_vn/out_NN.json
规范必读: _fb_enrich_vX_vn/PROMPT.md

⚠️ 极限约束: 总时长 ≤5-7 分钟, 每家 ≤3-4 次 search + 2 次 fetch, 找不到立即跳!
5 层数据源: masothue → hsctvn → 官网 → search. 25 字段 JSON, 找不到留空.
tax_code 严格, status 规范, 声调保留. 严禁编造. 遇 <!DOCTYPE 15s 重试 3 次.
完成返回: "shard NN done, N records, tax_code=A/N, ..."
```

**波次策略**:
- Wave 1: 并发 3 (VN s01, VN s02, UNK s01)
- Wave 2-N: 交替下发 VN/UNK, 保持 3 并发
- 单 shard 超时/失败 → 用 `sessions_send` 让它保存已有并退, 或加严约束重跑

---

## Step 4: 合并 (`_merge.py`)

```python
import json, glob, os
import pandas as pd
from resources.merge_utils import build_final_row, FINAL_COLS_VN, FINAL_COLS_FULL

def merge_shards(folder, output_xlsx, with_probe=False):
    target = pd.read_pickle(f"{folder}/target.pkl")
    enr = {}
    for f in sorted(glob.glob(f"{folder}/out_*.json")):
        for r in json.load(open(f, encoding="utf-8")):
            row_idx = r.get("row")
            if isinstance(row_idx, int): enr[row_idx] = r
    print(f"loaded {len(enr)}/{len(target)}")
    rows = [build_final_row(target.iloc[i], enr.get(i, {}), with_probe=with_probe)
            for i in range(len(target))]
    cols = FINAL_COLS_FULL if with_probe else FINAL_COLS_VN
    df = pd.DataFrame(rows, columns=cols)
    os.makedirs("Agent_output", exist_ok=True)
    df.to_excel(output_xlsx, index=False)
    df.to_csv(output_xlsx.replace(".xlsx",".csv"), index=False,
              encoding="utf-8-sig", lineterminator="\n")
    print(f"wrote {output_xlsx} ({len(df)} rows)")
    return df

# VN 直背结果
vn_df   = merge_shards("_fb_enrich_vX_vn",  "Agent_output/fb_vn_enriched_vX_direct.xlsx", with_probe=False)
# UNK 探测结果 (含 NON_VN 全量)
full_df = merge_shards("_fb_enrich_vX_unk", "Agent_output/fb_vn_probe_vX_full.xlsx",     with_probe=True)
# 只挑出 VN 的
vn_probed = full_df[full_df["country_probe"].str.upper()=="VN"][FINAL_COLS_VN].reset_index(drop=True)

# 本批 VN 全量 = 直背 + 探测VN
this_batch = pd.concat([vn_df, vn_probed], ignore_index=True)
this_batch.to_excel(f"Agent_output/fb_vn_enriched_vX.xlsx", index=False)
```

---

## Step 5: Union 到总账

```python
from resources.merge_utils import union_batches

union = union_batches([
    "Agent_output/fb_vn_enriched_v2.xlsx",
    "Agent_output/fb_vn_enriched_v3.xlsx",
    "Agent_output/fb_vn_enriched_v4.xlsx",
    "Agent_output/fb_vn_enriched_v5.xlsx",
    "Agent_output/fb_vn_enriched_vX.xlsx",  # 本次新增
], "Agent_output/fb_vn_enriched_all.xlsx")

# 派生 2 个子集
yes = union[union["is_business"].str.lower()=="yes"]
yes.to_excel("Agent_output/fb_vn_enriched_yes_only.xlsx", index=False)

ctc = yes[(yes["phone_number"]!="") | (yes["mobile_no"]!="") | (yes["email"]!="")]
ctc.to_excel("Agent_output/fb_vn_enriched_yes_with_contact.xlsx", index=False)

print(f"total: {len(union)} | yes: {len(yes)} | yes+contact: {len(ctc)}")
```

---

## 🎯 完成信号 (给用户)

汇报以下 5 个数字:
1. 输入原始 X 行 → 去重后 Y 行 → **抓到 VN Z 家**
2. tax_code / email / phone / website 命中率
3. 主要 CRM 行业 TOP5
4. 主要越南省份 TOP5
5. `fb_vn_enriched_yes_with_contact.xlsx` 家数 (可直接运营)

## 🚨 常见坑排查

参考 `SKILL.md § 常见坑` 章节。三大点:
1. PowerShell mojibake → `$env:PYTHONIOENCODING="utf-8"` + Out-File
2. 单 shard 超时 → 加严 `≤2 次 search + 找不到就跳` 约束
3. 后端限流 (`<!DOCTYPE`) → 等 90-180 秒再重试
