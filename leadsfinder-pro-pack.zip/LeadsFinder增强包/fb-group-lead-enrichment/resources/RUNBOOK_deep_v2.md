# RUNBOOK: v2 深度补 SOP

> v1 交付后, 若 `is_business=yes` 中零联系方式的占比 ≥ 25%, 走本 SOP 二次挖。
> 只补 4 字段: `website / email / mobile_no / founder_owner`
> 复用主 skill 5 阶段流水线里的 Stage 2/3/4, 不新起流程。

---

## 🎯 决策矩阵: v1 交付后是否走 v2?

**触发指标**: `yes_no_contact_ratio` = `(is_business=yes 且 email/website/phone/mobile 全空的家数) / (is_business=yes 总家数)`

| 指标 | 建议 |
|---|---|
| **< 15%** | 不做 v2, v1 已达可用天花板 |
| **15-25%** | 可选, 用户决定 |
| **25-40%** | **强烈建议 v2** (PK 案例: 29%, 命中率 67%) |
| **> 40%** | v1 数据源没铺开, 先反思 v1 契约再谈 v2 |

---

## 📋 5 步 SOP

### Step 1: 挑目标子集

```python
# _fb_pk_v2_pick.py 模板
import pandas as pd, json, os

V1 = "Agent_output/fb_pk_enriched_450_FINAL.xlsx"
OUT_DIR = "_fb_pk_v2"; os.makedirs(OUT_DIR, exist_ok=True); os.makedirs("_fb_pk_v2_out", exist_ok=True)

df = pd.read_excel(V1, sheet_name="全量450家", keep_default_na=False)
df["is_business"] = df["is_business"].astype(str).str.lower()
def is_blank(v): return str(v).strip() == "" or str(v).lower() in ("nan","none","null")

yes = df[df["is_business"] == "yes"].copy()
no_contact = yes[
    yes["email"].map(is_blank) & yes["website"].map(is_blank) &
    yes["mobile_no"].map(is_blank) & yes["phone_number"].map(is_blank)
].copy()
print(f"yes 总: {len(yes)}, 零联系方式: {len(no_contact)}, ratio: {len(no_contact)/len(yes)*100:.1f}%")
```

**产出**: `_fb_pk_v2/in_001.json` .. `in_NNN.json` (每 8 家一片)

### Step 2: 复制 PROMPT

```powershell
cp <skill_dir>/resources/PROMPT_pk_deep_v2.md _fb_pk_v2/PROMPT.md
```

### Step 3: 并发派单 (稳定甜区参数)

- **每 sub-agent 2 片 (16 家)**, 并发 **3**
- 每家 4-6 次 web_search + web_fetch
- 每片处理完立即 write

**首轮试点 3 sub-agent × 2 片 = 48 家**, 通过 `_fb_pk_v2_pilot_check.py` 校验命中率, 满足预期 (至少一字段命中率 ≥ 50%) 再批量派剩余。

**遇后端 `<!DOCTYPE`**: 等 30-90s 重试, 3 连败该家 `enrich_note_v2=backend_error` 空字段继续。整批崩溃时降到并发 1, 等 3-4 分钟恢复。

### Step 4: 合并回主表

```python
# _fb_pk_v2_merge.py 模板 (核心逻辑)
v1 = pd.read_excel("Agent_output/fb_pk_enriched_450_FINAL.xlsx", sheet_name="全量450家").fillna("")
v2 = pd.DataFrame([json.load(open(f, encoding="utf-8")) for f in glob.glob("_fb_pk_v2_out/out_*.json")])
# ... flatten v2 ...

merged = v1.merge(v2[["row","website_v2","email_v2","mobile_no_v2","founder_owner_v2","source_url_v2","enrich_note_v2"]],
                    on="row", how="left")

# v1 优先, v2 补空
def fill_from_v2(v1_val, v2_val):
    if scrub(v1_val): return scrub(v1_val)
    return scrub(v2_val)

merged["website"] = merged.apply(lambda r: fill_from_v2(r["website"], r.get("website_v2","")), axis=1)
merged["email"] = merged.apply(lambda r: fill_from_v2(r["email"], r.get("email_v2","")), axis=1)
merged["mobile_no"] = merged.apply(lambda r: fill_from_v2(r["mobile_no"], r.get("mobile_no_v2","")), axis=1)
merged["founder_owner"] = merged.apply(lambda r: fill_from_v2(r["founder_owner"], r.get("founder_owner_v2","")), axis=1)

# 命中标记
def hit_flag(r):
    hits = []
    for k, tag in [("website_v2","web"),("email_v2","email"),("mobile_no_v2","mobile"),("founder_owner_v2","kp")]:
        if scrub(r.get(k,"")): hits.append(tag)
    return "+".join(hits) if hits else ""
merged["v2_hit"] = merged.apply(hit_flag, axis=1)
```

### Step 5: 交付 (5 sheet 结构)

```
Agent_output/fb_pk_enriched_XXX_FINAL_v2.xlsx
├── 全量XXX家_v2                (含 v2_hit 标记列)
├── is_business=yes             (yes 全量)
├── yes+至少一联系方式_v2        ★ 重点交付 (可直接推 sales-email)
├── 覆盖率审计_v2                (对比 v1 增量)
└── v2补丁命中统计               (v2_hit 类型分布)

+ _yes_with_contact_v2.csv      (sales 直接用)
```

---

## 🎯 命中率预期 (baseline)

| 场景 | 至少 1 字段命中 | mobile 命中 | email 命中 | website 命中 | kp 命中 |
|---|---|---|---|---|---|
| **PK Sialkot 体育** (2026-07-09, 112 家) | **67%** | 54% | 43% | 33% | 25% |
| VN 类似场景 (未做过) | 预期 55-65% | — | — | — | — |
| HK 类似场景 | 建议委托 hk-company-enrichment | — | — | — | — |

---

## 🔴 什么时候 v2 不值得跑?

- **v1 已经 yes+contact ≥ 85%**: 剩余的多半是真的没线索
- **产品线是特种 B2B** (如冷门化学试剂): 官网都很少, v2 命中会显著低
- **完全无 fb_url** (输入 FB xlsx 缺 `x1i10hfl href`): v2 少了关键新路径, 命中率会掉一半
- **用户明确说 "接受空联系方式"**: 直接 v1 交付

---

## 📊 采样命中日志 (对话中给用户展示用)

```
[1] Candela Sports (v1 空)
  email     = excellentproduct786@gmail.com    ← FB Page About
  mobile    = +92 322 7440504                   ← FB Page bio
  founder   = Hassan                            ← FB Page About

[12] Stellix Hosiery & Sportswear (v1 空)
  email     = aasourcingltd@gmail.com          ← LinkedIn
  mobile    = +92 300 7154714                  ← LinkedIn
  founder   = Kashif Ali                        ← LinkedIn

[26] Holiway Sport (v1 空)
  mobile    = +92 332 5287794                  ← Instagram bio
  founder   = Usman Haider                      ← Instagram bio
```

---

## 🔗 与其它 sub-workflow 的关系

- **v1 (PROMPT_pk_direct.md)**: 首次背调, 24 字段全量
- **v2 (本 SOP)**: 只对 v1 空的补 4 字段
- **v3 (未来可能)**: 若还需第三轮, 只补 KP LinkedIn Profile / 决策人邮箱 (专门开发信用)
