# Country Pack: HK (Hong Kong)

⚠️ **本 pack 不在 fb-group-lead-enrichment 里执行,直接委托 `hk-company-enrichment` skill**。

原因:
1. HK 有独立的深度 skill (`hk-company-enrichment`) 已经封装了 ICRIS/BR/双名/yp.com.hk 全套逻辑
2. HK 场景独有的 22 字段 (BR + CR + 双名) 跟 fb-group 通用架构差异大
3. `yp.com.hk` 爬虫 (curl_cffi + chrome120 TLS 指纹) 已在 hk skill 里 hard-code

## 委托流程

当用户指定 target_country="HK" 时:
1. 本 skill 主流程停在 Stage 1 (完成分类)
2. 告知用户:
   > "HK 场景请改用 `hk-company-enrichment` skill, 它有 22 字段深度支持
   >  (BR/CR 号 / 双名繁体 / 港式楼层地址 / 18 区映射 / yp.com.hk 爬虫)。
   >  请调用 `skill({action:'read', skill_id:'hk-company-enrichment'})`。"
3. 若用户仍坚持要在 fb skill 里做, 只输出通用 15 字段 (无 BR/CR/双名):
   `name / fb_url / phone / email / website / address / district / product / status / source_url / remark ...`

## HK 场景的硬规则国家判定 (若需在 Stage 1 用)

### HK_HARD (任一命中即 HK)

```regex
# 语言/地区
hong\s*kong / \bhk\b / hkg / hksar
香港 / 港

# 香港城市/区
kowloon / \bkln\b / new\s*territories / \bn\.t\b
central / wan\s*chai / mong\s*kok / tsim\s*sha\s*tsui
tsuen\s*wan / sha\s*tin / tuen\s*mun / yuen\s*long
kwun\s*tong / sham\s*shui\s*po / kwai\s*chung

# 港式楼层
\bg/f\b / \blg/f\b / \d+/f\b / room\s+\d+ / flat\s+[a-z\d]+

# 域名
\.com\.hk\b / \.hk\b

# BR / CR
\bbr\s*no\.?\b / \bcr\s*no\.?\b / business\s*registration
```

---

## 详见 hk-company-enrichment

- **主 skill**: `~/.accio/.../skills/hk-company-enrichment/SKILL.md`
- **资源**: `hk_extractors.py` (BR/CR/港式楼层/18 区) + `hk_industry_map.json` (100+ 繁简中文→GGS) + `yp_hk_scraper.py` (curl_cffi 稳定版)
- **CRM Org**: `303525004` (跟 VN 一样)
