# Country Pack Template (COPY THIS TO CREATE NEW COUNTRY)

复制这个文件为 `{code}.md` (小写 2 字母代码,如 in.md / cn.md / tr.md),
然后填充 5 个 section 即可扩展新国家 pack。

## 快速填充清单 (5 minutes to build a new country pack)

**必填 5 项**:
1. **Layer 1-4 数据源**: 目标国的官方工商库/商会目录/兜底源
2. **{CODE}_HARD 硬规则**: 语言/城市/证件/域名 强信号 regex 列表
3. **字段清单**: 该国独特字段 (如 IN 加 CIN+GST, CN 加 USCC)
4. **CRM 行业映射来源**: 该国行业码 (SITC/SIC/HS/USCC 等) → GGS CRM
5. **CRM Org 路由**: 该国线索归到哪个 CRM Org ID

**选填 2 项**:
6. 电话/地址规范化规则 (国家码/省份)
7. 该国独有的坑 (印度 vs 巴基斯坦 Pvt Ltd 混淆等)

---

## 模板

# Country Pack: XX (Country Name)

**已验证**: [规模, 字段命中率, 项目来源]

## 📚 Layer 1-4 数据源
```
Layer 1: [官方工商库 URL]         ← 一手
Layer 2: [商会/行业协会目录]     ← 补充
Layer 3: [官网 contact/about]    ← 邮箱电话
Layer 4: web_search 兜底         ← "{name} {Country}"
```

## 🔍 硬规则国家判定
### {CODE}_HARD (任一命中即 {CODE})
```regex
# 语言
[本地语言关键词]
# 城市
[N 大城市 regex]
# 域名
\.{cctld}\b
# 证件
[N-位数字税号/公司注册号 regex]
```

## 📋 输出字段 (X 字段)
```json
{
  "row": <int>,
  "fb_*": "5 个 FB 原始字段",
  "is_business": "yes|no|uncertain",
  "company_name": "英文正式名",
  "[本国 tax_code 字段名]": "国税/工商号",
  "status": "active|closed|unknown",
  "status_raw": "原文",
  "link_man": "法人/负责人",
  "address": "完整地址",
  "state": "省/州",
  "phone_number": "固话",
  "mobile_no": "手机",
  "email": "邮箱",
  "website": "官网",
  "product": "产品",
  "[本国 industry_code 字段]": "本国行业码",
  "crm_industry": "GGS 行业名",
  "crm_code": "GGS 行业 code",
  "source_url": "来源",
  "remark": "备注"
}
```

## 🏭 行业映射
- 通过 `industry-mapping` skill 的 `map_by_code(code, country="XX")`
- 若 industry-mapping 无 XX 支持, 补 mapping 表或 fallback `map_by_text(product)`

## 🔴 铁律
- status 规范
- tax_code 格式校验
- 语言保留规则 (如繁体保留/声调保留)
- 邮箱黑名单

## 📞 电话规范
- 国家码 (+XX)
- 固话/手机区分方式

## 🎯 CRM 入库 org
- Org: `XXXXXXXXX` (对应 CRM 分区)

## ⚙️ 并发/时间参数
- shard 大小 / 并发 / 时间预算

## 🚨 独有坑
- 跟哪个国家容易混淆
- 独有陷阱
