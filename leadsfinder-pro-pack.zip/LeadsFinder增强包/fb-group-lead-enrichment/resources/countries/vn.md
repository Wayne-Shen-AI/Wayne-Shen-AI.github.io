# Country Pack: VN (Vietnam)

**已验证**: 218 家 (v2 102 + v3 18 + v4 21 + v5 77), tax_code 78-88%, 越南语名 91%.

---

## 📚 Layer 1-4 数据源

```
Layer 1: masothue.com     ← 越南官方工商库 (一手, 榨干 tax_code/越南语名/成立日期/status/法人/VSIC/地址)
Layer 2: hsctvn.com       ← masothue 找不到时补充
Layer 3: 官网 contact/about ← 补 email/phone/product
Layer 4: web_search 通用兜底 ← "{name} Vietnam" 搜索
```

---

## 🔍 硬规则国家判定

### VN_HARD (任一命中即 VN)

```regex
# 越南语关键词
việt\s*nam / vietnam\b
công\s*ty / cty\b / \btnhh\b
xuất\s*khẩu / nhập\s*khẩu / xuất\s*nhập\s*khẩu
sản\s*xuất / nông\s*sản / trái\s*cây

# 越南城市/省份
hà\s*nội / hanoi\b
ho\s*chi\s*minh / sài\s*gòn / saigon\b / tp\.?\s*hcm\b
bình\s*dương / biên\s*hòa / đồng\s*nai / hải\s*phòng
đà\s*nẵng / cần\s*thơ / nha\s*trang / vũng\s*tàu
long\s*an / tiền\s*giang / cà\s*mau / hưng\s*yên
quảng\s*ninh / lâm\s*đồng / tây\s*ninh / an\s*giang
bình\s*phước / bến\s*tre

# 声调字符
[àáảãạăằắ...đ]  (VN diacritics)

# Viet 前缀
\bviet\w*  (Viet Delta / Vietforce ...)  且非 vietnam 全词
```

### NON_VN 硬拒 (在 classify.py 的 NON_VN 列表, 见通用清单)

---

## 📋 输出字段 (25 字段 VN 特化)

```json
{
  "row": <int>,
  "fb_name": "", "fb_url": "", "fb_category": "", "fb_followers": "", "fb_loc_hint": "",
  "is_business": "yes|no|uncertain",
  "company_name": "英文/正式名",
  "local_company_name": "越南语全称 (保留声调, 禁 T2S)",
  "tax_code": "10位数字 MST (masothue)",
  "established": "YYYY-MM-DD",
  "status": "active|closed|unknown",
  "status_raw": "Đang hoạt động / Ngừng hoạt động / ...",
  "link_man": "法人代表",
  "address": "完整越南地址 (保留声调)",
  "state": "省份/城市 (归一化: Ho Chi Minh City / Hanoi / Binh Duong ...)",
  "phone_number": "固定电话 (+84 或 0 开头)",
  "mobile_no": "手机号",
  "email": "邮箱",
  "website": "官网 URL",
  "product": "主营/产品短语 (英文)",
  "vsic_code": "越南 VSIC 4位行业 code",
  "vsic_text": "VSIC 行业文本",
  "is_exporter": "yes|no|unknown",
  "source_url": "主数据来源 URL",
  "remark": "备注"
}
```

---

## 🏭 行业映射: VSIC → GGS CRM

- 通过 `industry-mapping` skill 的 `map_by_code(vsic_int, country="VN")`
- 兜底 `map_by_text(product)` 或 `map_by_text(vsic_text)`

---

## 🔴 铁律 (VN 特化)

- **status 规范**:
  - `Đang hoạt động` / `Hoạt động` → **active**
  - `Ngừng hoạt động` / `Không hoạt động` / `Hết hiệu lực` / `Tạm ngừng` / `Chấm dứt` → **closed**
- **tax_code**: 严格 10 位数字 或 `10位-3位` 分支 (如 `0301427028-001`)
- **越南语名/地址**: **保留声调, 禁 T2S** (跟 HK 场景相反)
- **邮箱清洗**: `example.com` / `noreply@` / `sentry` / `wix.com` / `kompass.com` 黑名单

---

## 📞 电话规范

- 前缀 `+84` 或 `0`
- 固话 8-10 位 (含区号), 手机 9 位 (`0xxxxxxxxx` / `+84xxxxxxxxx`)
- 存两列: `phone_number` (固话) 和 `mobile_no` (手机)

---

## 🗺 State 归一化

CRM 标准英文 (`normalize_vn_state()` 已实现):
- HCM 5 变体 → `Ho Chi Minh City`
- Hanoi 3 变体 → `Hanoi`
- 30+ 省份英化 (Bình Dương → Binh Duong, Đồng Nai → Dong Nai ...)

---

## 🎯 CRM 入库 org

- **Org**: `303525004` (HK-test team, VN 也走这里)
- **CLI**: `ggs-crm-cli` (先 crm-dedup → 按 pool 分流 → crm-add / crm-pickup)

---

## ⚙️ 并发/时间参数

- 每 shard: **8-10 家** (25 字段密集)
- 并发: **3** sub-agent (skill 甜区)
- 单 shard 时间: **5-7 分钟**
- 每家 search: **≤3-4 次** (VN 直背), **≤2 次** (UNKNOWN 探测)
- 每家 fetch: **≤2 次**

---

## 📥 使用: PROMPT
- VN 直背: `resources/PROMPT_vn_direct.md`
- UNKNOWN 探国家: `resources/PROMPT_probe_country.md`
