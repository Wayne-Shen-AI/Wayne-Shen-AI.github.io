# Country Pack: PK (Pakistan)

**已验证**: 8735 家 SMEDA 全量补全 (2026-06-22 至 2026-06-23), 24 字段, 关键字段命中率 70-94%.
基于 `PKsmeda.xlsx` + `SITC→CRM 27 类映射表` 沉淀。

---

## 📚 Layer 1-5 数据源

```
Layer 1: SECP.gov.pk               ← 巴基斯坦联邦证券交易委员会 (公司注册总库, 类似越南 masothue)
Layer 2: SMEDA.org.pk              ← 中小企业局 (轻工/纺织/皮革出口商详情, 8735 家已验证)
Layer 3: FBR.gov.pk (NTN Verify)   ← 联邦税务局, 查 NTN + STRN 号
Layer 4: 城市商会目录              ← Sialkot / Karachi / Lahore / Faisalabad 商会
                                     - Sialkot Chamber (SCCI): scci.com.pk (体育用品/手术器械)
                                     - Karachi Chamber (KCCI): kcci.com.pk (纺织/皮革/水产)
                                     - Lahore Chamber (LCCI): lcci.com.pk (化工/机械)
                                     - Faisalabad Chamber (FCCI): fcci.com.pk (纺织专业城)
Layer 5: 官网 contact/about + web_search 兜底
                                     "{name} Pakistan / Sialkot / Karachi"
```

**特别提示**:
- 巴基斯坦企业**高度地理集群化**, 抓地址时优先判 4 大城市 (Sialkot 体育/手术器械, Faisalabad 纺织, Karachi 综合港口, Lahore 化工机械)
- **TradePak** / **Yellow Pages PK** (yellowpages.com.pk) 是不错的补充
- 印巴关系, 印度出口商可能混入 (`Pvt Ltd` 是印度信号但巴基斯坦也用 `Pvt Ltd`!) → 靠**城市名** + **.pk 域名** + **NTN** 交叉判定

---

## 🔍 硬规则国家判定

### PK_HARD (任一命中即 PK)

```regex
# 国家关键词
pakistan / pakistani

# 4 大城市 (强信号)
karachi / lahore / sialkot / faisalabad
gujranwala / gujrat / islamabad / rawalpindi / peshawar / multan
sukkur / hyderabad\s+pakistan  (注意跟印度 Hyderabad 区分, 加国家词)
quetta / bahawalpur

# 域名/证件
\.pk\b / \.com\.pk\b
\bntn\b / national\s+tax\s+number
\bstrn\b / sales\s+tax\s+registration

# 特色行业词 (Sialkot/Faisalabad 专业)
surgical\s+instruments / martial\s+arts / boxing\s+gloves
football / sialkot\s+sports
denim / textile\s+mills / hosiery
```

### NON_PK 硬拒信号 (在 classify.py 的 NON_VN → 需要改成 NON_TARGET 通用列表; PK 场景加下面)

```regex
# India (混淆最多, 因都用 Pvt Ltd, 但印度城市不同)
\bindia\b / \bindian\b
mumbai / delhi / bangalore / chennai / kolkata / hyderabad\s+india
gujarat\s+india / kerala / pune / jaipur / ahmedabad
\.co\.in\b / \.in\b

# 中国
shanghai / guangzhou / shenzhen / beijing / \.cn\b / \bchina\b

# Bangladesh (跟巴基斯坦地理相邻, 需明确区分)
bangladesh / dhaka / chittagong / \.bd\b

# 其它 (跟 VN pack 同 NON_TARGET 列表)
turkey / thailand / malaysia / indonesia / vietnam ...
```

---

## 📋 输出字段 (24 字段 PK 特化)

```json
{
  "row": <int>,
  "fb_name": "", "fb_url": "", "fb_category": "", "fb_followers": "", "fb_loc_hint": "",

  "is_business": "yes|no|uncertain",
  "company_name": "英文/正式名 (罗马字母)",
  "urdu_name": "乌尔都语名 (可选, 大部分公司只用英文商号)",
  "ntn": "National Tax Number (7位数字, FBR)",
  "strn": "Sales Tax Registration Number (13位, FBR)",
  "cuin": "Company Unique Identification No. (SECP, 7位)",
  "status": "active|closed|unknown",
  "status_raw": "SECP 原文 (Active / Dormant / Struck Off / Liquidated)",
  "founder_owner": "创始人/所有人 (SMEDA/SECP)",
  "address": "完整巴基斯坦地址",
  "city": "4 大 + 常见城市 (Karachi / Lahore / Sialkot / Faisalabad / Gujranwala / Gujrat / Islamabad / Rawalpindi ...)",
  "province": "Sindh / Punjab / KPK / Balochistan / Islamabad Capital Territory / AJK / GB",
  "phone_number": "固定电话 (+92-XX-XXXXXXX)",
  "mobile_no": "手机号 (+92-3XX-XXXXXXX)",
  "email": "邮箱",
  "website": "官网 URL (常见 .com.pk / .pk / .com)",
  "product": "主营/产品短语 (英文)",
  "sitc_code": "SITC 4位行业代码 (巴基斯坦标准分类, 类似 VN VSIC)",
  "sitc_text": "SITC 行业描述文本",
  "is_exporter": "yes|no|unknown",
  "export_markets": "主要出口市场 (US / EU / UAE / KSA / ...)",
  "source_url": "主数据来源 URL",
  "remark": "备注"
}
```

---

## 🏭 行业映射: SITC → GGS CRM (27 类, 已 100% 覆盖)

已建立 SMEDA sector → GGS CRM 27 类完整映射 (见 diary/2026-06-22.md):
- 纺织/成衣类 → **Apparel (3)** / **Textiles (42)**
- Sialkot 手术器械 → **Health Care (20)**
- Sialkot 体育用品 → **Sports & Entertainment (41)**
- 皮革/手袋 → **Luggage (24)** / **Leather (42)**
- 稻米/农产品 → **Agriculture (2)** / **Food (18)**
- 化工/塑料 → **Chemicals (10)** / **Rubber & Plastics (38)**
- 食品/糖 → **Food & Beverage (18)**
- 五金/机械 → **Hardware (20)** / **Industrial Machinery (22)**
- 建材/水泥 → **Construction & Real Estate (13)** / **Minerals & Metallurgy (26)**

### ⚠️ 实证教训 (2026-07-09): 严禁直调 `map_by_code(sitc_int, country="PK")`

**问题**: 该分支返回混乱的 GBT4754 中国国标 code (`201943703` / `1420` / `502` 这种超长值), 87% 场景不可用。

**替代方案**: 用关键词兜底表 (下方), FB PK 450 家实战覆盖率 87% 有效映射 (非 Others)。

### 🔑 关键词兜底 CRM 映射表 (2026-07-09 实证)

按 `product / sitc_text / fb_name / fb_category` 拼接文本, 按优先顺序匹配 (先命中先赢):

| # | 关键词模式 (regex, case-insensitive) | crm_industry | crm_code |
|---|---|---|---:|
| 1 | `sportswear \| sports?\s+goods? \| jersey \| kit \| track\s*suit \| goalkeeper` | Sports & Entertainment | **18** |
| 2 | `football \| soccer \| cricket \| basketball \| volleyball \| rugby \| hockey \| tennis \| badminton \| golf` | Sports & Entertainment | 18 |
| 3 | `boxing \| mma \| martial\s+arts \| karate \| taekwondo \| judo \| jiu\s*jitsu \| fitness \| gym` | Sports & Entertainment | 18 |
| 4 | `surgical \| dental \| medical.*instruments` | Health & Medical | 26 |
| 5 | `pharma \| healthcare` | Health & Medical | 26 |
| 6 | `leather\s+goods? \| leather\s+jacket \| leather\s+bag \| leather\s+wallet` | Bags & Cases | 5 |
| 7 | `handbag \| luggage \| backpack \| wallet \| \bbag\b` | Bags & Cases | 5 |
| 8 | `leather` (兜底, 前面未命中) | Bags & Cases | 5 |
| 9 | `shoes? \| footwear \| sandals? \| sneakers? \| boots?` | Shoes & Accessories | 15 |
| 10 | `apparel \| clothing \| garment \| hosiery \| denim \| jeans? \| shirt \| t.?shirt \| dress \| fashion \| uniform` | Apparel | 4 |
| 11 | `textile \| fabric \| yarn \| cotton \| weav(ing\|ers?) \| mills?` | Textile & Leather Products | 19 |
| 12 | `food \| beverage \| drink \| snack \| bakery \| dairy \| meat \| fish \| seafood \| rice \| wheat \| flour \| sugar \| salt \| spice \| tea \| coffee \| honey` | Food & Beverage | 12 |
| 13 | `agri \| agro \| fruit \| vegetable \| nuts? \| grain` | Agriculture | 1 |
| 14 | `cutlery \| knives? \| scissors \| tableware \| kitchen(ware)? \| hardware \| tools \| fasteners?` | Hardware | 44 |
| 15 | `chemical \| polymer \| plastic \| rubber \| paint \| coating \| resin \| adhesive` | Chemicals | 2 |
| 16 | `machinery \| machine \| equipment \| pump \| valve \| bearing \| generator \| motor \| compressor \| industrial` | Machinery | 28 |
| 17 | `steel \| iron \| aluminum \| aluminium \| copper \| brass \| metal \| alloy \| foundry \| casting` | Metals & Alloys | 34 |
| 18 | `cement \| brick \| tile \| marble \| granite \| construction \| building \| contractor` | Construction & Real Estate | 13 |
| 19 | `cosmetics? \| beauty \| skincare \| hair\s+care \| makeup \| perfume \| salon` | Beauty & Personal Care | 15 |
| 20 | `furniture \| wooden\s+furniture \| home\s+decor` | Furniture | 22 |
| 21 | `trad(ing\|ers?) \| import \| export \| distribut \| whole\s*sale \| retail \| supplier` (兜底: 贸易类) | Business Services | 66 |
| 22 | `logistic \| freight \| cargo \| shipping \| forwarder \| warehouse \| courier` | Logistics | 80 |
| 23 | `auto \| automobile \| car \| vehicle \| motorcycle \| tire \| tyre \| battery` | Vehicles & Transportation | 34 |
| 24 | `electronic \| electric \| led \| lighting \| lamp \| solar` | Consumer Electronics | 1 |
| **兜底** | 无一命中 | Others | 30 |

**实证效果 (PK 450 家)**:
- Sports & Entertainment (18): 157 (35%)
- Apparel (4): 59 (13%)
- Business Services / Trading (66): 55 (12%)
- Others (30): 57 (13%)
- Food (12): 39 (8.7%)
- 其他共 83 家 (18%)

代码见 `_fb_pk_fix_crm.py` (KW_MAP list of tuples).

---

## 🔍 v2 深度补新路径 (2026-07-09 新增)

**用途**: v1 交付后, `is_business=yes` 但零联系方式的家继续挖 (只补 4 字段: `website / email / mobile_no / founder_owner`).

详见 `resources/RUNBOOK_deep_v2.md` + `resources/PROMPT_pk_deep_v2.md`.

### v2 路径优先级 (与 v1 不同, v1 用过的常空)

| 优先级 | 路径 | 主要拿到什么 | 命中率 (估) |
|---:|---|---|---:|
| **1** | **web_fetch `<fb_url>`** — FB Page About Section | 官网 / email / mobile / founder | 30-40% (**新路径**) |
| 2 | PSGMEA / SIALKOT.CC / SCCI 商会目录 | website + phone | 20% (PK Sialkot 集群) |
| 3 | LinkedIn Company Page | founder_owner + website | 25% |
| 4 | Instagram bio | mobile_no (`+92 3xx`) | 15% |
| 5 | Alibaba / IndiaMART 目录页 | 部分 email/website | 10% |
| 6 | web_search 兜底 | 兜底 | 30% |

### v2 严禁编造的额外规则

- Sialkot 撞名严重 (`Sports Industries`, `International Sportswear`), 命中官网必须 `.pk` / `.com.pk` 或 About 页面明确 Sialkot 地址, 否则 `enrich_note_v2=ambiguous`, 字段空
- FB Page About 拿到的 email 常是 `@gmail.com` (PK SME 惯用), **不算海外域拒收**
- Instagram bio 常见 `+92 3XX XXX XXXX` 空格格式, 规范化为 `+92 3xx xxxxxxx`

---

## 🔴 铁律 (PK 特化)

- **status 规范**:
  - `Active` / `Registered` → **active**
  - `Dormant` / `Struck Off` / `Liquidated` / `Cancelled` / `Suspended` → **closed**
- **NTN 格式**: 7 位纯数字, 严格校验; 格式不符留空
- **STRN 格式**: 13 位数字 (可含 `-`)
- **电话**: 必须 `+92` 开头; `+92-3XX` 是手机, `+92-2X` (Karachi) / `+92-42` (Lahore) / `+92-52` (Sialkot) 是固话
- **地址**: 保留 `Plot / House / Street / Sector / Phase / Block` 等本地格式
- **英文商号**: 巴基斯坦公司普遍用英文, 少量含乌尔都语 (اردو) 可选择性抓
- **邮箱**: 常见 `@companyname.com.pk` 或 `@gmail.com` (SME 惯用 gmail)
- **严禁编造**: 找不到就留空

---

## 📞 电话规范

- 国家码 `+92`
- 手机: `+92-3XX-XXXXXXX` (11 位)
- 固话: `+92-21-XXXXXXXX` (Karachi 21) / `+92-42-XXXXXXX` (Lahore 42) / `+92-52-XXXXXXX` (Sialkot 52) / `+92-41-XXXXXXX` (Faisalabad 41)

---

## 🗺 4 省 + Islamabad Capital Territory

- **Sindh**: Karachi (港口/纺织/皮革) / Hyderabad / Sukkur
- **Punjab**: Lahore (省会/化工) / Faisalabad (纺织) / Sialkot (体育/手术器械/皮革) / Gujranwala (五金/餐具) / Multan (棉/水果) / Rawalpindi
- **KPK (Khyber Pakhtunkhwa)**: Peshawar (皮革/大理石)
- **Balochistan**: Quetta (矿产)
- **Islamabad Capital Territory**: Islamabad (首都政府/服务业)
- **AJK (Azad Jammu & Kashmir)** / **GB (Gilgit-Baltistan)**: 边远, leads 少

---

## 🎯 CRM 入库 org (关键区别!)

- **Org**: `110313935` (Alibaba Pakistan, **不是** `303525004`!)
- **CLI**: `ggs-crm-cli` 同 VN, 但入库时 `--org 110313935`

---

## ⚙️ 并发/时间参数 (跟 VN 相同)

- 每 shard: **8-12 家** (24 字段稍宽松)
- 并发: **3-4** sub-agent
- 单 shard 时间: **5-7 分钟**
- 每家 search: **≤3-4 次**
- 每家 fetch: **≤2 次**

---

## 📥 使用: PROMPT
- PK 直背: `resources/PROMPT_pk_direct.md`
- UNKNOWN 探国家 (target=PK): `resources/PROMPT_probe_country.md` (加参数)

---

## 🚨 巴基斯坦独有的坑

1. **Pvt Ltd 不专属印度** — 巴基斯坦也用, 别在 NON_TARGET 硬拒里把它列成印度信号 (要跟城市名交叉验证)
2. **Hyderabad 两地都有** — 巴基斯坦 Sindh 省有 Hyderabad, 印度 Telangana 省也有 Hyderabad, 必须看国家/邻近城市
3. **Sialkot ≈ 全球体育用品制造中心** — 若地址 Sialkot 且行业含 sports/football/boxing/martial → 大概率是 PK 出口商
4. **Faisalabad ≈ 全球第 3 大纺织城** — 若 Faisalabad + textile/denim → 大概率 PK
5. **手术器械是 Sialkot 王牌** — surgical instruments = Sialkot 概率 90%+
6. **英文名可能跟印度撞车** — `Ali Trading Corp` 印巴都有, 靠城市/网站/NTN 判定
7. **domain .pk 是硬信号** — `.com.pk` / `.pk` 域名基本 100% 是 PK 企业
8. **WhatsApp 是主流联系方式** — 大量 SME 邮箱不常用, 但 WhatsApp 号 = 手机号
