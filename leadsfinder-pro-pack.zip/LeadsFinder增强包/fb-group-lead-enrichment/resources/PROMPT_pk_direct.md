# Sub-agent PROMPT: PK 直接背调 (Stage 2 for Pakistan)

你会拿到一份 JSON 输入 (~8-12 家巴基斯坦企业/商家/工厂), 每条含
`row / fb_name / category / fb_url / fb_category / fb_followers / fb_loc_hint`。

## 📚 数据源优先级 (成本从低到高)

```
Layer 1: SECP.gov.pk               ← 联邦证券交易委员会 (公司注册, CUIN)
Layer 2: SMEDA.org.pk              ← 中小企业局 (制造业/出口商, 8735 家已验证)
Layer 3: FBR.gov.pk (NTN Verify)   ← 联邦税务局 (NTN 7位/STRN 13位)
Layer 4: 城市商会目录              ← Sialkot SCCI / Karachi KCCI / Lahore LCCI / Faisalabad FCCI
Layer 5: 官网 + web_search 兜底    ← "{name} Pakistan / Sialkot" 或 "{name} .com.pk"
```

## 🔍 搜索模板 (每家 3-4 次 web_search + 1-2 次 web_fetch)

1. `web_search("{fb_name} Pakistan site:secp.gov.pk")` → 拿 CUIN + status
2. `web_search("{fb_name} Pakistan NTN")` → 拿 NTN
3. `web_search("{fb_name} Pakistan contact")` → 找官网/邮箱/电话
4. (可选) `web_fetch(["{官网}/contact", "{官网}/about"])` → 官网 contact 页

## 🏙 巴基斯坦地理集群 (帮助定位)

若在搜索结果里看到:
- **Sialkot** → 大概率 sports goods / surgical instruments / boxing gloves / leather
- **Karachi** → 综合港口 / 纺织 / 皮革 / 水产 / 化工
- **Lahore** → 化工 / 机械 / 皮革 / 服装
- **Faisalabad** → 纺织王国 / 全球第 3 大纺织城 / denim / hosiery
- **Gujranwala** → 五金 / 餐具 / 电风扇
- **Gujrat** (跟印度 Gujarat 不同!) → 陶瓷 / 家具
- **Islamabad** → 首都 / 服务业 / IT
- **Peshawar** → 皮革 / 大理石

## 📋 输出字段 (24 字段, 所有 key 必须出现, 找不到用空字符串 `""`)

```json
{
  "row": <int, 与输入一致>,
  "fb_name": "<输入原样>",
  "fb_url": "<输入原样>",
  "fb_category": "<输入原样>",
  "fb_followers": "<输入原样>",
  "fb_loc_hint": "<输入原样>",

  "is_business": "yes | no | uncertain",
  "company_name": "英文正式名 (罗马字母)",
  "urdu_name": "乌尔都语名 (اردو, 可选, 大部分公司只用英文)",
  "ntn": "National Tax Number (7位数字, FBR)",
  "strn": "Sales Tax Registration Number (13位数字, 可含 -)",
  "cuin": "Company Unique Identification No. (SECP, 7位)",
  "status": "active | closed | unknown",
  "status_raw": "SECP 原文 (Active / Dormant / Struck Off / Liquidated / Suspended)",
  "founder_owner": "创始人/所有人 (SMEDA/SECP)",
  "address": "完整巴基斯坦地址 (含 Plot/House/Street/Sector/Phase/Block)",
  "city": "Karachi / Lahore / Sialkot / Faisalabad / Gujranwala / Gujrat / Islamabad / Rawalpindi / Multan / Peshawar / ...",
  "province": "Sindh | Punjab | KPK | Balochistan | Islamabad Capital Territory | AJK | GB",
  "phone_number": "固定电话 (+92-XX-XXXXXXX)",
  "mobile_no": "手机号 (+92-3XX-XXXXXXX, 11位)",
  "email": "邮箱 (合法性: 含@, 常见 @companyname.com.pk 或 @gmail.com)",
  "website": "官网 URL (常见 .com.pk / .pk / .com)",
  "product": "主营/产品短语 (英文, 6-15字)",
  "sitc_code": "SITC 4位行业代码 (如 8422 手术器械, 6541 纺织服装, 0421 大米)",
  "sitc_text": "SITC 行业文本",
  "is_exporter": "yes | no | unknown (名称/product 含 export/pakistan exports/international 或 SMEDA 收录)",
  "export_markets": "主要出口市场 (US / EU / UAE / KSA / UK / Africa / ...)",
  "source_url": "主数据来源 URL",
  "remark": "备注 (如 'Sialkot chamber verified' / 'SECP not found, from SMEDA')"
}
```

## 🔴 铁律

1. **空值铁律**: 找不到留 `""`, 严禁 `N/A` / `not found` / `null` / `-` / `无` / `****`
2. **status 规范**:
   - `Active` / `Registered` → **active**
   - `Dormant` / `Struck Off` / `Liquidated` / `Cancelled` / `Suspended` → **closed**
   - 未搜到 → **unknown**
3. **status_raw** 保留 SECP 原文
4. **NTN 格式**: 严格 7 位数字, 不符留空
5. **STRN 格式**: 13 位数字 (可含 `-` 分隔)
6. **CUIN 格式**: 7 位数字 (SECP 独有)
7. **电话前缀 +92** 必备:
   - 手机 `+92-3XX-XXXXXXX`
   - 固话 `+92-21-XXXXXXXX` (Karachi) / `+92-42-XXXXXXX` (Lahore) / `+92-52-XXXXXXX` (Sialkot) / `+92-41-XXXXXXX` (Faisalabad)
8. **邮箱清洗**: `example.com` / `noreply@` / `sentry` / `wix.com` / `not found` 黑名单
9. **严禁编造**: `contact@example.com.pk` / `+92 xxx xxx` / `Plot X, Karachi` 一律禁止
10. **一家最多 3-4 次 web_search + 2 次 web_fetch**, 超时就跳
11. **省份归一**: `Sindh` / `Punjab` / `KPK (Khyber Pakhtunkhwa)` / `Balochistan` / `Islamabad Capital Territory` / `AJK` / `GB`

## ⚠️ 巴基斯坦独有的坑 (务必注意)

1. **Pvt Ltd 不专属印度** — 巴基斯坦也用 `Pvt Ltd`, 必须靠**城市名 / 域名 .pk / NTN** 交叉验证才能判 PK
2. **Hyderabad 两地都有** — 巴基斯坦 Sindh 省 vs 印度 Telangana 省, 必须看**邻近城市**或**国家词**
3. **Sialkot ≈ 全球体育用品制造中心** — 若地址 Sialkot 且产品含 sports/football/boxing/martial arts → **确认是 PK**
4. **手术器械 = Sialkot 90%+ 是 PK** — surgical instruments 是 Sialkot 王牌
5. **Faisalabad 纺织城** — 若 Faisalabad + textile/denim/hosiery → PK
6. **英文名可能撞车** — `Ali Trading Corp` 印巴都有, 靠**城市 + 网站 + NTN** 判定
7. **WhatsApp 号 = 手机号** — SME 邮箱不常用, 但 WhatsApp 号可作为 mobile_no

## ⚠️ 限流应对

- web_search 返回 `<!DOCTYPE` (HTML 错误页) → 等 15 秒重试, 最多 3 次仍失败则跳过继续

## ⏱ 时间预算

- 单 shard 总时长 ≤ 5-7 分钟
- 找不到的家不要磕, 立即写盘继续

## 📥 输入
读取 `<批次文件夹>/in_XX.json`

## 📤 输出
写入 `<批次文件夹>/out_XX.json` (JSON 数组, 每家一条, 顺序与 row 一致)

## ✅ 完成信号
返回一句: `shard XX done, N records, ntn=A/N, phone=B/N, city=C/N`
