# -*- coding: utf-8 -*-
"""
fb-group-lead-enrichment / Stage 1 classifier (multi-country router)
====================================================================
Pure-rule classification of Facebook Group leads:
  - country: {TARGET_COUNTRY} | NON_TARGET | UNKNOWN
  - category: CO_STRICT | BIZ_LOOSE | AMBIGUOUS | PERSON | SKIP_JUNK | EMPTY | NON_TARGET_SKIP

Supported target_country:
  - "VN" (Vietnam)   ← default, 218 家验证
  - "PK" (Pakistan)  ← 8735 家 SMEDA 验证
  - "HK" (Hong Kong) ← 委托 hk-company-enrichment skill

Usage:
    from classify import detect_country, classify_name, cat_and_reason
    country, reason = detect_country(name, loc, joined, target_country="VN")
    cat, cat_reason = classify_name(name, target_country="VN")

For new countries, add:
  1. A {CODE}_HARD list of regex patterns for strong signals
  2. A {CODE}_CITIES list (for name/loc cross-check)
  3. Optional {CODE}_STRONG_INDUSTRY_KW (Sialkot=sports, Faisalabad=textile...)
  4. Update _COUNTRY_HARD_MAP and _COUNTRY_KEY_MAP at the bottom
"""
from __future__ import annotations
import re
import unicodedata
from typing import Tuple

# ---------------------------------------------------------------------------
# 1) Country detection (rule-based, no network)
# ---------------------------------------------------------------------------

VN_HARD = [
    # Vietnamese-language keywords
    r"việt\s*nam", r"vietnam\b",
    r"công\s*ty", r"cty\b", r"\btnhh\b",
    r"xuất\s*khẩu", r"nhập\s*khẩu", r"xuất\s*nhập\s*khẩu",
    r"sản\s*xuất", r"nông\s*sản", r"trái\s*cây",
    # Cities/provinces
    r"hà\s*nội", r"\bhanoi\b",
    r"ho\s*chi\s*minh", r"sài\s*gòn", r"\bsaigon\b", r"tp\.?\s*hcm\b",
    r"bình\s*dương", r"biên\s*hòa", r"đồng\s*nai", r"hải\s*phòng",
    r"đà\s*nẵng", r"cần\s*thơ", r"nha\s*trang", r"vũng\s*tàu",
    r"long\s*an", r"tiền\s*giang", r"cà\s*mau", r"hưng\s*yên",
    r"quảng\s*ninh", r"lâm\s*đồng", r"tây\s*ninh", r"an\s*giang",
    r"bình\s*phước", r"bến\s*tre",
]

# ---------------------------------------------------------------------------
# 1.1) Pakistan (PK) — new country pack, 2026-07
# ---------------------------------------------------------------------------

PK_HARD = [
    # Country
    r"pakistan", r"pakistani",
    # 4 major cities (strong signal)
    r"karachi", r"lahore", r"sialkot", r"faisalabad",
    r"gujranwala", r"gujrat\b(?!\s*india)",  # Gujrat PK, not Gujarat IN
    r"islamabad", r"rawalpindi", r"peshawar", r"multan",
    r"sukkur", r"quetta", r"bahawalpur",
    # Domain / tax ID
    r"\.pk\b", r"\.com\.pk\b",
    r"\bntn\b", r"national\s+tax\s+number",
    r"\bstrn\b", r"sales\s+tax\s+registration",
    # Signature Pakistan industries (Sialkot=sports/surgical, Faisalabad=textile)
    r"surgical\s+instruments", r"martial\s+arts", r"boxing\s+gloves",
    r"sialkot\s+sports",
    r"denim", r"textile\s+mills",
]

# For PK, common NON_PK signals (harder because Pvt Ltd is shared with India)
NON_PK = [
    # India — MUST identify by city, not just "Pvt Ltd" (both use it)
    r"\bindia\b", r"\bindian\b",
    r"\bmumbai\b", r"\bdelhi\b", r"\bbangalore\b", r"\bchennai\b", r"\bkolkata\b",
    r"hyderabad,?\s*india", r"gujarat,?\s*india", r"kerala", r"\bpune\b", r"jaipur",
    r"ahmedabad", r"noida", r"gurgaon", r"gurugram",
    r"\.co\.in\b", r"\.in\b(?!\.)",
    # China
    r"shanghai", r"guangzhou", r"shenzhen", r"beijing", r"tianjin",
    r"wuhan", r"chongqing", r"xiamen", r"hangzhou", r"yiwu",
    r"dongguan", r"foshan", r"ningbo", r"qingdao",
    r"\bchina\b(?!town)", r"\.cn\b", r"\.com\.cn\b",
    # Bangladesh (bordering, easy to confuse)
    r"bangladesh", r"dhaka", r"chittagong", r"\.bd\b",
    # Others
    r"vietnam", r"việt\s*nam", r"turkey", r"türkiye", r"thailand", r"malaysia",
    r"indonesia", r"philippines", r"korea", r"japan",
    r"russia", r"cambodia", r"myanmar",
    # Latin America / Africa / Europe (same as VN)
    r"méxico", r"mexico", r"argentina", r"colombia", r"peru", r"chile", r"brasil",
    r"españa", r"\bspain\b", r"sa\s+de\s+cv",
    r"algeria", r"morocco", r"nigeria", r"kenya", r"egypt", r"south\s*africa",
]

# ---------------------------------------------------------------------------
# 1.2) Vietnam (VN) - unchanged from v1
# ---------------------------------------------------------------------------

NON_VN = [
    # India
    r"\bpvt\s*\.?\s*ltd\b", r"\bpvt\.?\s*limited\b", r"private\s*limited",
    r"\bindia\b", r"\bindian\b",
    r"chennai", r"mumbai", r"delhi", r"bangalore", r"kolkata",
    r"hyderabad", r"gujarat", r"kerala", r"pune", r"jaipur",
    # China
    r"shanghai", r"guangzhou", r"shenzhen", r"beijing", r"tianjin",
    r"wuhan", r"chongqing", r"xiamen", r"hangzhou", r"yiwu",
    r"hebei", r"shandong", r"zhejiang", r"jiangsu", r"anhui",
    r"henan", r"hubei", r"hunan", r"guangdong", r"sichuan",
    r"dongguan", r"foshan", r"ningbo", r"qingdao",
    r"\bchina\b(?!town)", r"\bchinese\b", r"\bpr\s*china\b",
    r"广州", r"上海", r"深圳", r"北京",
    # Pakistan
    r"pakistan", r"karachi", r"lahore", r"sialkot", r"faisalabad",
    r"gujranwala", r"islamabad",
    # Bangladesh / Sri Lanka
    r"bangladesh", r"dhaka", r"sri\s*lanka", r"colombo", r"ceylon",
    # Turkey
    r"türkiye", r"turkey", r"istanbul", r"ankara",
    # East / SE Asia
    r"korea", r"korean", r"seoul",
    r"japan", r"tokyo",
    r"thailand", r"thai\b", r"bangkok",
    r"malaysia", r"kuala\s*lumpur",
    r"indonesia", r"jakarta",
    r"philippines", r"manila",
    r"russia", r"moscow",
    r"cambodia", r"phnom\s*penh",
    r"myanmar", r"yangon",
    # LatAm
    r"méxico", r"mexico", r"guadalajara", r"monterrey",
    r"argentina", r"buenos\s*aires",
    r"colombia", r"bogotá", r"bogota",
    r"peru\b", r"lima\b", r"perú",
    r"chile", r"santiago",
    r"brasil", r"brazil", r"são\s*paulo", r"sao\s*paulo",
    r"españa", r"\bspain\b", r"madrid", r"barcelona",
    r"\bsa\s*de\s*cv\b", r"\bs\.a\.\s*de\s*c\.v\b",
    r"exportacion\s+de", r"exportador\s+de",
    # Africa
    r"algerie", r"algeria", r"morocco", r"marruecos",
    r"nigeria", r"lagos", r"kenya", r"nairobi",
    r"egypt", r"cairo", r"south\s*africa",
    # Europe/CIS
    r"rusagro", r"\brussian\b",
    r"greek\b", r"greece", r"athens",
    r"ukraine", r"belarus",
]

_VN_DIACRITIC_RE = re.compile(
    r"[àáảãạăằắẳẵặâầấẩẫậèéẻẽẹêềếểễệìíỉĩịòóỏõọôồốổỗộơờớởỡợùúủũụưừứửữựỳýỷỹỵđ]"
)

def strip_accent(s: str) -> str:
    return "".join(c for c in unicodedata.normalize("NFD", s or "")
                   if unicodedata.category(c) != "Mn")

# ---------------------------------------------------------------------------
# 1.3) Country routing map
# ---------------------------------------------------------------------------

# For each target_country: (POSITIVE_HARD_PATTERNS, NEGATIVE_NON_TARGET_PATTERNS)
_COUNTRY_HARD_MAP = {
    "VN": (VN_HARD, NON_VN),
    "PK": (PK_HARD, NON_PK),
    # "HK": (HK_HARD, NON_HK),   ← 委托 hk-company-enrichment, 不在本 skill
}

def detect_country(name: str, loc: str = "", joined: str = "",
                   target_country: str = "VN") -> Tuple[str, str]:
    """
    Return (country, reason).
    country in {TARGET_COUNTRY, NON_TARGET, UNKNOWN} where TARGET_COUNTRY = target_country arg.

    For VN, also uses diacritic + 'viet' prefix heuristics.
    """
    target_country = (target_country or "VN").upper()
    if target_country not in _COUNTRY_HARD_MAP:
        raise ValueError(f"Unsupported target_country {target_country!r}. "
                         f"Supported: {list(_COUNTRY_HARD_MAP.keys())}. "
                         f"For HK, use hk-company-enrichment skill.")
    positive_patterns, negative_patterns = _COUNTRY_HARD_MAP[target_country]

    text_full = f"{name} | {loc} | {joined}"
    low = text_full.lower()

    # 1) hard NON_TARGET (other countries) first — reject
    for pat in negative_patterns:
        m = re.search(pat, low)
        if m:
            return "NON_TARGET", f"non_{target_country.lower()}:{m.group(0)[:20]}"

    # 2) hard target-country accept
    for pat in positive_patterns:
        m = re.search(pat, low)
        if m:
            return target_country, f"{target_country.lower()}:{m.group(0)[:20]}"

    # 3) VN-specific extras: diacritic + 'viet' prefix
    if target_country == "VN":
        if _VN_DIACRITIC_RE.search((name or "").lower()):
            return "VN", "vn_diacritic"
        if re.search(r"\bviet\w*", low) and not re.search(r"vietnam\b|việt\s*nam", low):
            return "VN", "viet_prefix"

    # 4) PK-specific extras: WhatsApp-like +92 phone in loc_hint
    if target_country == "PK":
        if re.search(r"\+?92[-\s]?\d", low):
            return "PK", "pk_+92_phone"

    return "UNKNOWN", "no_signal"


# ---------------------------------------------------------------------------
# 2) Name classification (rule-based)
# ---------------------------------------------------------------------------

VN_SURNAMES_NORM = {
    "nguyễn", "nguyen", "trần", "tran", "lê", "le", "phạm", "pham",
    "hoàng", "hoang", "huỳnh", "huynh", "phan", "vũ", "vu", "võ", "vo",
    "đặng", "dang", "bùi", "bui", "đỗ", "do", "hồ", "ho", "ngô", "ngo",
    "dương", "duong", "lý", "ly", "đào", "dao", "đinh", "dinh",
    "trịnh", "trinh", "mai", "châu", "chau", "cao", "tăng", "tang",
    "lương", "luong", "tống", "tong", "trương", "truong", "lưu", "luu",
    "hà", "ha", "tô", "to", "lư", "lu", "thái", "thai",
}

# Pakistani common given / surnames (Muslim + Punjabi + Sindhi + Balochi + Pashto)
# Used to detect "PERSON" in PK context (2-4 tokens starting with these = likely person, not company)
PK_NAME_TOKENS = {
    # Muslim first / surnames
    "muhammad", "mohammad", "mohd", "muhamad", "mohamad", "md",
    "ahmed", "ahmad", "ali", "hussain", "hussein", "hasan", "hassan",
    "syed", "sayed", "shah", "malik", "khan", "chaudhry", "chaudhary",
    "sheikh", "shaikh", "sh", "mir", "mirza", "abbas", "raza",
    "abdullah", "abdul", "abdur", "abdel",
    "umar", "omar", "usman", "osman", "uthman", "uthman",
    "bilal", "hamza", "yousuf", "yusuf", "yaqub", "yaqoob", "ibrahim",
    "ismail", "ismael", "khalid", "khaleed", "waseem", "waqar",
    "asif", "arif", "aamir", "amir", "aslam", "akbar", "akram",
    "javed", "javid", "junaid", "jamil", "jameel",
    "kashif", "kamran", "kamal", "khurshid",
    "nadeem", "naveed", "nasir", "naeem", "nazir", "nauman",
    "rashid", "rasheed", "rehan", "rizwan",
    "salim", "saleem", "sohail", "shahzad", "shahid", "shakir", "shafiq",
    "tariq", "tahir", "taimur", "tanveer",
    "waheed", "wasim", "wajid", "wali",
    "zafar", "zaheer", "zahid", "zain", "zubair",
    # Punjabi/Sindhi/Balochi/Pashto surnames
    "gill", "sandhu", "sidhu", "randhawa", "arain", "butt", "bhatti",
    "cheema", "chatha", "ghous", "gujjar", "jat", "kakar", "kayani",
    "lodhi", "mughal", "mansha", "naqvi", "niazi", "pathan", "qureshi",
    "qazi", "raja", "rana", "rathore", "sherazi", "siddiqui", "swati",
    "tarar", "wattoo", "yousafzai", "zafar", "zahid",
    # Common salutation/honorific
    "haji", "hafiz", "mian", "mr", "mrs", "ms",
    # (English 'khan' overlaps but PERSON test also checks token count + no biz kw)
}

JUNK_KW = [
    r"khoá\s*học", r"khóa\s*học", r"đào\s*tạo", r"nghiệp\s*vụ",
    r"triển\s*lãm", r"cộng\s*đồng", r"trung\s*tâm",
    r"tra\s*cứu", r"dữ\s*liệu",
    r"cùng\s*alibaba", r"alibaba\s*việt", r"alibaba\.com",
    r"học\s*viện", r"đại\s*học", r"trường\s*học",
    r"phiên\s*dịch\s*viên", r"seo\s*website",
    r"^dịch[-\s]*vụ\b", r"khai\s*hải\s*quan",
]

CO_STRICT_KW = [
    r"\bco\.?,?\s*ltd\.?", r"\bco\.,?ltd\b", r"\bcompany\b", r"\blimited\b",
    r"\s+co\.?\s*$", r"\s+co\s+ltd\b",  # trailing " Co" / " Co Ltd"
    r"\bcorp(?:oration)?\b", r"\binc\b", r"\bltd\.?\b", r"\bjsc\b",
    r"\bjoint stock\b", r"\btnhh\b", r"\bcông\s*ty\b", r"\bcty\b",
    r"\bxưởng\b", r"\bnhà\s*máy\b", r"\bfactory\b", r"\bmanufactur",
    r"\bgroup\b", r"\benterprises?\b", r"\bcooperative\b", r"\bhợp tác xã\b",
    r"\bplant\b", r"\bmill\b", r"\bworkshop\b",
    # PK common company suffixes
    r"\bindustries?\b", r"\bexports?\s+co\b", r"\bimpex\b",
    r"\bsons\b", r"\bbrothers\b", r"&\s*sons?\b", r"&\s*co\.?", r"&\s*bros?\.?",
    r"\bassociates\b", r"\bconcerns?\b",
    # Pakistan / India specific
    r"\bpvt\.?\s*\(?ltd\)?\b", r"\bpvt\.?\s*limited\b", r"private\s*limited",
]

# Base biz keywords (extend per FB Group theme).
BIZ_LOOSE_KW_BASE = [
    r"sản\s*xuất", r"xuất\s*khẩu", r"nhập\s*khẩu", r"xuất\s*nhập\s*khẩu",
    r"gia\s*công", r"bao\s*bì", r"logistic", r"forwarding",
    r"wood", r"furniture", r"pallet", r"plastic", r"nhựa",
    r"food", r"foods", r"agri", r"agriculture", r"nông\s*sản",
    r"trading", r"export", r"import", r"hub", r"vina", r"vietnam",
    r"decor", r"fashion", r"industry", r"industrial", r"tech",
    r"engineering", r"service", r"solutions?", r"eco",
    r"cargo", r"freight", r"transport", r"forklift", r"machinery",
    r"chemical", r"steel", r"mesh", r"metal", r"paper", r"printing",
    r"in\s+ấn", r"digital", r"seo", r"marketing", r"consulting",
    r"consultant", r"seller", r"shop", r"store", r"mart", r"center",
    r"agency", r"studio", r"lab",
    # Theme extensions (add more as needed)
    r"shoe", r"footwear", r"giày", r"giay", r"da\b",
    r"trái\s*cây", r"fruit", r"vegetable", r"banana",
    r"spice", r"garlic", r"pepper", r"cashew",
    r"coffee", r"tea", r"rice", r"seafood", r"fish", r"aqua",
    r"crab", r"crawfish", r"prawn", r"shrimp", r"squid", r"tuna", r"pearl",
    r"tropical", r"organic", r"fresh", r"raw", r"material",
    # more theme extensions
    r"agro", r"vegetable", r"fruit", r"grain", r"herb",
]

def _person_check_vn(tokens: list, low: str, biz_hit: bool) -> Tuple[str, str] | None:
    """VN-specific person detection: VN surname prefix, 2-4 tokens, no biz kw."""
    if not tokens:
        return None
    first_low = tokens[0].lower()
    first_lowa = strip_accent(first_low)
    ntok = len(tokens)
    if 2 <= ntok <= 4 and (first_low in VN_SURNAMES_NORM or first_lowa in VN_SURNAMES_NORM) and not biz_hit:
        return "PERSON", f"vn_surname:{tokens[0]}"
    if ntok == 2 and not biz_hit and all(re.match(r"^[A-Za-zÀ-ỹ][A-Za-zÀ-ỹ']+$", t) for t in tokens):
        last_lowa = strip_accent(tokens[-1].lower())
        if last_lowa in VN_SURNAMES_NORM or first_lowa in VN_SURNAMES_NORM:
            return "PERSON", f"en_person:{tokens[-1]}"
        if all(len(t) <= 10 for t in tokens):
            return "PERSON", "en_short_person"
    return None


def _person_check_pk(tokens: list, low: str, biz_hit: bool) -> Tuple[str, str] | None:
    """PK-specific person detection: Muslim/Punjabi name tokens, 2-5 tokens, no biz kw.
    Different from VN because PK names often have Muhammad/Ali/Khan as first token
    with 3-4 tokens total (Muhammad Ali Khan / Syed Muhammad Bilal ...)."""
    if not tokens:
        return None
    ntok = len(tokens)
    if not (2 <= ntok <= 5):
        return None
    if biz_hit:
        return None
    # If ≥2 tokens are in PK_NAME_TOKENS → likely a person name
    matching = sum(1 for t in tokens if t.lower() in PK_NAME_TOKENS)
    if matching >= 2:
        return "PERSON", f"pk_multi_names:{matching}/{ntok}"
    # OR first + last both in PK names
    if tokens[0].lower() in PK_NAME_TOKENS and tokens[-1].lower() in PK_NAME_TOKENS:
        return "PERSON", f"pk_name_bookend"
    # OR just Khan/Ali/Ahmed as last token + reasonable first name
    if ntok == 2 and tokens[-1].lower() in {"khan", "ali", "ahmed", "ahmad", "hussain", "shah", "malik", "syed", "chaudhry"}:
        if all(len(t) <= 12 for t in tokens):
            return "PERSON", f"pk_short_person:{tokens[-1]}"
    return None


_PERSON_CHECKERS = {
    "VN": _person_check_vn,
    "PK": _person_check_pk,
}


def classify_name(name: str, extra_biz_kw: list | None = None,
                  target_country: str = "VN") -> Tuple[str, str]:
    """Return (category, reason). Category in
    {EMPTY, SKIP_JUNK, CO_STRICT, PERSON, BIZ_LOOSE, AMBIGUOUS}.

    Person detection is country-specific (PK uses Muslim/Punjabi names,
    VN uses 14 main surnames). JUNK / CO_STRICT / BIZ_LOOSE are shared."""
    target_country = (target_country or "VN").upper()
    n = (name or "").strip()
    if not n:
        return "EMPTY", "empty"
    low = n.lower()
    biz_kw = BIZ_LOOSE_KW_BASE + (extra_biz_kw or [])

    # Shared: JUNK
    for pat in JUNK_KW:
        if re.search(pat, low):
            return "SKIP_JUNK", f"junk:{pat}"

    # Shared: CO_STRICT
    for pat in CO_STRICT_KW:
        if re.search(pat, low):
            return "CO_STRICT", f"kw:{pat}"

    tokens = re.split(r"[\s,.\-–_/&+()\[\]]+", n)
    tokens = [t for t in tokens if t]

    # Shared: placeholder names
    if re.search(r"\bnguyen\s+van\s+a\b|\bvan\s+a\b", strip_accent(low)):
        return "AMBIGUOUS", "placeholder"

    biz_hit = any(re.search(pat, low) for pat in biz_kw)

    # Country-specific PERSON detection
    checker = _PERSON_CHECKERS.get(target_country)
    if checker:
        result = checker(tokens, low, biz_hit)
        if result:
            return result

    # BIZ_LOOSE (shared, biz kw hit)
    if biz_hit:
        return "BIZ_LOOSE", "biz_kw"

    # Single-token fallback
    if len(tokens) == 1:
        return "AMBIGUOUS", "single_token"
    return "AMBIGUOUS", "no_rule"


def cat_and_reason(country: str, name: str,
                   extra_biz_kw: list | None = None,
                   target_country: str = "VN") -> Tuple[str, str]:
    """Combined: NON_TARGET (previously NON_VN) → skip.
    TARGET/UNKNOWN → classify_name(target_country)."""
    if country == "NON_TARGET":
        return ("NON_TARGET_SKIP", f"non_{target_country.lower()}_hard_reject")
    return classify_name(name, extra_biz_kw, target_country)


# ---------------------------------------------------------------------------
# 3) Helper: parse FB xlsx metadata columns
# ---------------------------------------------------------------------------

def parse_followers(s: str) -> str:
    """Extract '2,345' from 'Furniture2,345 people follow this'."""
    m = re.search(r"([\d,]+)\s+people follow", s or "")
    return m.group(1).replace(",", "") if m else ""

def parse_fb_category(s: str) -> str:
    """Strip the '... N people follow this' suffix."""
    if not s:
        return ""
    m = re.match(r"^(.*?)(\d[\d,]*\s+people follow this)?$", s.strip())
    return m.group(1).strip() if m else s


# ---------------------------------------------------------------------------
# 4) Smoke test
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    # test cases: (name, loc, target_country, expected_country, expected_category)
    tests_vn = [
        ("Sgc Gold Furniture", "Hanoi, Vietnam", "VN", "VN", "BIZ_LOOSE"),
        ("Nguyễn Văn Nam",     "",              "VN", "VN", "PERSON"),
        ("Xuất Khẩu Cùng Alibaba Việt Nam", "", "VN", "VN", "SKIP_JUNK"),
        ("Duba Wood Factory - Sản Xuất Đồ Gỗ", "", "VN", "VN", "CO_STRICT"),
        ("Divine X Global Exports Pvt Ltd", "Chennai", "VN", "NON_TARGET", "NON_TARGET_SKIP"),
        ("Shanghai Chengyue Import & Export", "", "VN", "NON_TARGET", "NON_TARGET_SKIP"),
        ("Vietforce International Agro",   "",   "VN", "VN",     "BIZ_LOOSE"),
        ("Jd Prime Export",                "",   "VN", "UNKNOWN", "BIZ_LOOSE"),
    ]
    tests_pk = [
        # PK cases
        ("Sialkot Sports Industries",       "Sialkot",              "PK", "PK",         "CO_STRICT"),        # industries
        ("Muhammad Ali Trading",            "",                     "PK", "UNKNOWN",    "BIZ_LOOSE"),        # trading biz, no city → UNKNOWN, hit biz before person
        ("Muhammad Ali Khan",               "Karachi, Pakistan",    "PK", "PK",         "PERSON"),           # 3 PK name tokens, no biz
        ("Ali Textile Mills Ltd",           "Faisalabad",           "PK", "PK",         "CO_STRICT"),        # ltd → CO
        ("Kashan Denim Faisalabad",         "",                     "PK", "PK",         "BIZ_LOOSE"),        # denim + city
        ("Lahore Chemical Industries",      "",                     "PK", "PK",         "CO_STRICT"),        # industries (CO first, before chemical BIZ)
        ("Karachi Surgical Instruments Co", "",                     "PK", "PK",         "CO_STRICT"),        # 'co' hit but need word boundary; 'surgical' biz
        ("Kashmir Handicrafts (Pvt) Ltd",   "Mumbai, India",        "PK", "NON_TARGET", "NON_TARGET_SKIP"),  # Mumbai
        ("Guangzhou Trading Co Ltd",        "",                     "PK", "NON_TARGET", "NON_TARGET_SKIP"),  # Guangzhou
        ("Ahmed & Sons Enterprises",        "Sialkot, Pakistan",    "PK", "PK",         "CO_STRICT"),        # enterprises
        ("Bilal Ahmed",                     "",                     "PK", "UNKNOWN",    "PERSON"),           # 2 PK name tokens, no country signal
    ]

    print("=== VN target_country tests ===")
    for name, loc, tc, exp_c, exp_cat in tests_vn:
        c, cr = detect_country(name, loc, target_country=tc)
        cat, catr = cat_and_reason(c, name, target_country=tc)
        ok = "PASS" if (c == exp_c and cat == exp_cat) else "FAIL"
        print(f"  [{ok}] {name[:40]:40s} | country={c:12s} ({cr:20s}) | cat={cat:16s} ({catr})")

    print("\n=== PK target_country tests ===")
    for name, loc, tc, exp_c, exp_cat in tests_pk:
        c, cr = detect_country(name, loc, target_country=tc)
        cat, catr = cat_and_reason(c, name, target_country=tc)
        ok = "PASS" if (c == exp_c and cat == exp_cat) else "FAIL"
        print(f"  [{ok}] {name[:40]:40s} | country={c:12s} ({cr:20s}) | cat={cat:16s} ({catr})")
