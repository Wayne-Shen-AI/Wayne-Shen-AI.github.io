# Sub-agent PROMPT: VN 直接背调 (Stage 2)

你会拿到一份 JSON 输入 (~8-15 家越南企业/商家/机构), 每条含
`row / fb_name / category / fb_url / fb_category / fb_followers / fb_loc_hint`。

## 📚 数据源优先级 (成本从低到高)

```
Layer 1: masothue.com    ← 越南官方工商库 (一手, 榨干 tax_code/越南语名/成立日期/status/法人/VSIC/地址)
Layer 2: hsctvn.com      ← 补充工商信息
Layer 3: 官网 contact/about ← 补 email/phone/product
Layer 4: web_search 通用兜底 ← 上述都缺时 "{fb_name} Vietnam"
```

## 🔍 搜索模板 (每家 3-4 次 web_search + 1-2 次 web_fetch)

1. `web_search("{fb_name} masothue")` OR `web_search("{fb_name} mã số thuế")` → 拿工商号
2. `web_search("{fb_name} Vietnam contact")` → 找官网 / 邮箱 / 电话
3. (可选) `web_fetch(["{官网}/contact", "{官网}/lien-he"])` → 榨干官网

## 📋 输出字段 (25 字段, 所有 key 必须出现, 找不到用空字符串 `""`)

```json
{
  "row": <int, 与输入一致>,
  "fb_name": "<输入原样>",
  "fb_url": "<输入原样>",
  "fb_category": "<输入原样>",
  "fb_followers": "<输入原样>",
  "fb_loc_hint": "<输入原样>",

  "is_business": "yes | no | uncertain",
  "company_name": "英文/正式名 (优先 masothue/官网; 找不到回退 fb_name)",
  "local_company_name": "越南语全称 (masothue 一手)",
  "tax_code": "10位数字 MST (masothue)",
  "established": "YYYY-MM-DD (成立日期)",
  "status": "active | closed | unknown",
  "status_raw": "masothue 原文 (如 'Đang hoạt động' / 'Ngừng hoạt động')",
  "link_man": "法人代表姓名",
  "address": "完整越南地址",
  "state": "省份/城市 (Ho Chi Minh City / Hanoi / Binh Duong / Dong Nai 等)",
  "phone_number": "固定电话 (+84 或 0 开头)",
  "mobile_no": "手机号 (0/84 开头)",
  "email": "邮箱 (合法性: 含@, 域名合法)",
  "website": "官网 URL",
  "product": "主营/产品短语 (英文, 10-30字)",
  "vsic_code": "越南 VSIC 4位行业 code (masothue)",
  "vsic_text": "VSIC 行业中文/越南语文本",
  "is_exporter": "yes | no | unknown (依据名称/产品含 export/xuất khẩu)",
  "source_url": "主数据来源 URL (masothue页/官网首页)",
  "remark": "备注"
}
```

## 🔴 铁律

1. **空值铁律**: 找不到留 `""`, 严禁 `N/A` / `not found` / `null` / `-` / `无` / `****`
2. **status 规范**:
   - `Đang hoạt động` / `Hoạt động` → **active**
   - `Ngừng hoạt động` / `Không hoạt động` / `Hết hiệu lực` / `Tạm ngừng` → **closed**
   - 无法判定 → **unknown**
3. **status_raw** 保留 masothue 原文, 便于溯源
4. **tax_code**: 严格 10 位或 10-3 分支格式, 其它留空
5. **邮箱清洗**: `example.com` / `noreply@` / `sentry` / `wix.com` / `kompass.com` 黑名单一律留空
6. **一家最多 3-4 次 web_search + 2 次 web_fetch**, 超时就跳
7. **is_business=no** 场景: 判为个人 FB 账号 / 展会官方号 / 无实际商业实体 → 大部分字段留空
8. **重复名筛选**: masothue 搜出多家同名时, 优先选 fb_loc_hint 匹配的省份; 无法确定则留空 + remark 说明
9. **严禁编造**: 找不到就空, 不要写 `contact@example.com` / `+84 xxx xxx` / `84 Hai Ba Trung Hanoi`
10. **越南语名/地址保留声调** (禁 T2S 简化)

## ⚠️ 限流应对

- web_search 返回 `<!DOCTYPE` (HTML 错误页) → 等 15 秒重试, 最多 3 次仍失败则跳过该家继续下一家

## ⏱ 时间预算

- 单 shard 总时长 ≤ 5-7 分钟
- 找不到的家不要磕, 立即写盘继续

## 📥 输入
读取 `<批次文件夹>/in_XX.json`

## 📤 输出
写入 `<批次文件夹>/out_XX.json` (JSON 数组, 每家一条, 顺序与 row 一致)

## ✅ 完成信号
返回一句: `shard XX done, N records, tax_code=A/N, website=B/N, email=C/N`
