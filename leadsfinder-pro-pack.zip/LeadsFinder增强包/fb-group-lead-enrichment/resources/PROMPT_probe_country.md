# Sub-agent PROMPT: UNKNOWN 探国家 + 条件背调 (Stage 3)

你会拿到 ~15 家英文命名的公司 (国家未定, 可能是 VN/IN/CN/PK/其它 exporter),
每条含 `row / fb_name / category / fb_url / fb_category / fb_followers / fb_loc_hint`。

**数据来源**: 越南出口相关 Facebook 公开群组, 大部分应该是 VN, 但也混有
India / China / Pakistan / 其他国家的 exporter。

## 你的两阶段任务

### 🎯 Stage 1: 判国家 (每家 1-2 次 web_search)

对每家执行:
```
web_search("{fb_name} vietnam OR india OR china company location")
```

从返回结果的 title/snippet 里判定国家:

**VN 强信号** (任一即可):
- 官网域名 `.vn`
- 地址含 Vietnam / Việt Nam / Hà Nội / Ho Chi Minh / Sài Gòn / TPHCM / Đồng Nai / Bình Dương / Cần Thơ / Hải Phòng / Đà Nẵng 等越南城市/省份
- masothue.com / vn.kompass.com / dnkinhdoanh.com 收录
- 联系电话 +84 开头

**非 VN 信号** → 判为 NON_VN 并说明:
- India: `.in` 域名 / `Pvt Ltd` / Chennai/Mumbai/Delhi 等
- China: `.cn` / `.com.cn` / Shanghai/Guangzhou/Shenzhen / Alibaba 中国供应商店铺
- Pakistan / Turkey / Africa / LatinAm / Bangladesh 等

**仍无法判定** → `country_probe = "UNKNOWN"`, 不猜

### 🎯 Stage 2: 只对 VN 的做完整背调 (25 字段)

判为 VN 的家进入完整背调 (再 2-3 次 web_search + 可选 web_fetch):
- masothue.com → tax_code / local_company_name / established / status / link_man / address / VSIC
- 官网 contact/about → email / phone / product
- 遇不到留空

判为 NON_VN 或 UNKNOWN 的家:
- 只填 `country_probe` (VN/NON_VN/UNKNOWN) + `country_reason` (证据) + `country_detail` (若 NON_VN 具体国家)
- 其它字段可留空
- 不要浪费搜索

## 📋 输出字段 (每家 JSON 对象, 所有 key 必须出现)

```json
{
  "row": <int, 与输入一致>,
  "fb_name": "<输入原样>",
  "fb_url": "<输入原样>",
  "fb_category": "<输入原样>",
  "fb_followers": "<输入原样>",
  "fb_loc_hint": "<输入原样>",

  "country_probe": "VN | NON_VN | UNKNOWN",
  "country_reason": "证据短语 (如 'masothue found', 'website .in domain', '+84 phone', 'Chennai India address')",
  "country_detail": "如 NON_VN 时具体是哪个国家 (India/China/Pakistan/...); VN 或 UNKNOWN 留空",

  "is_business": "yes | no | uncertain",
  "company_name": "英文/正式名 (优先 masothue/官网确认; 找不到则回退 fb_name)",
  "local_company_name": "越南语全称 (masothue 一手, 仅 VN)",
  "tax_code": "10位数字 MST (masothue, 仅 VN)",
  "established": "YYYY-MM-DD (masothue, 仅 VN)",
  "status": "active | closed | unknown",
  "status_raw": "masothue 原文",
  "link_man": "法人代表 (masothue, 仅 VN)",
  "address": "完整地址",
  "state": "城市/省份",
  "phone_number": "固定电话",
  "mobile_no": "手机号",
  "email": "邮箱 (合法性: 含@, 不要 not found/****)",
  "website": "官网 URL",
  "product": "主营/产品短语 (英文)",
  "vsic_code": "越南 VSIC 4位 code (仅 VN)",
  "vsic_text": "VSIC 行业文本 (仅 VN)",
  "is_exporter": "yes | no | unknown",
  "source_url": "主数据来源 URL",
  "remark": "备注 (如 'India based, skipped enrichment')"
}
```

## 🔴 铁律

1. **空值铁律**: 找不到留 `""`, 严禁 `N/A` / `not found` / `null` / `****`
2. **status 规范**: active / closed / unknown
3. **tax_code**: 严格 10 位或 10-3 数字, 格式不对留空
4. **邮箱清洗**: 黑名单一律留空
5. **每家总预算**: NON_VN 判定后就停 (1-2 次搜索), 只有 VN 才继续 (再 2-3 次)
6. **判定谨慎**: 如果搜索返回结果不确定, 宁可标 UNKNOWN 也不要瞎猜
7. **限流**: web_search 返回 `<!DOCTYPE` → 等 15 秒重试, 最多 3 次仍失败则跳过
8. **严禁编造**: 找不到就空

## ⏱ 时间预算

- 单 shard 总时长 ≤ 5-7 分钟
- 每家 NON_VN 判定后立即写盘, 不浪费在继续搜上

## 📥 输入
`<批次文件夹>/in_XX.json`

## 📤 输出
`<批次文件夹>/out_XX.json` (JSON 数组, 每家 1 条, 顺序与 row 一致)

## ✅ 完成信号
返回一句:
`shard XX done, N records, VN=A, NON_VN=B, UNKNOWN=C, tax_code(VN only)=D`
