# SKILL.patch.md — 增量沉淀

> 本 patch 由 `fb-group-lead-enrichment` skill 使用后合并至 SKILL.md 主体。
> 每条 patch 独立追加, 记录日期 + 场景 + 教训, 不改主体只补新增。

---

## 📌 Patch 2026-07-09 · PK 6 文件 450 家实战 + v2 深度补 (+ 70 家联系方式)

### 场景

用户丢来 `facebook (25-30).xlsx` 6 个巴基斯坦 FB 群导出 (Sialkot 体育集群为主), 走 PK 直背 24 字段, 完成 450 家; 但发现 112 家 is_business=yes 却零联系方式, 追加 v2 深度补 (只补 4 字段: website/email/mobile_no/founder_owner)。

### 关键沉淀 (SKILL.md 未覆盖的新经验)

#### 1. **v2 深度补 sub-workflow (新增)**

**触发条件**: v1 交付后, `is_business=yes` 但 `email/website/phone/mobile 全空` 的比例 ≥ 25%

**决策矩阵**:
| yes_only 中零联系方式占比 | 建议 |
|---|---|
| < 15% | 不做 v2, 直接交付, 空联系方式的算成本 |
| **15-40%** | **强烈建议 v2**, 命中率约 60-70% |
| > 40% | 可能 v1 数据源没铺开, 先反思 v1 契约再谈 v2 |

**v2 4 字段契约** (只补这 4 个, 别贪): `website / email / mobile_no / founder_owner`

**v2 新路径** (v1 用过的路径大概率已空, 换路径):
1. **PSGMEA / SIALKOT.CC / SCCI 商会目录** (PK Sialkot 体育集群专用, v1 常漏)
2. **FB Page About Section** (直接 web_fetch 输入里的 fb_url, About 段常有 email/官网/电话)
3. **LinkedIn Company Page** (founder_owner 金矿, v1 只搜官网常错过)
4. **Instagram bio** (mobile_no 金矿, +92 手机常直接列出)
5. **Alibaba / IndiaMART / ExportersIndia 目录页**

**v2 合并规则** (v1 优先, v2 补空):
```python
def fill_from_v2(v1_val, v2_val):
    if scrub(v1_val): return scrub(v1_val)  # v1 有 → 保留
    return scrub(v2_val)                     # v1 空 → 用 v2
```

**PK 450 家 v2 实战**:
- 挑 112 家 (yes 且零联系方式)
- 14 分片 × 8 家, 并发 3, 每 sub-agent 2 片
- 命中率 **75/112 = 67%**
- yes+contact 从 **270 → 340 家 (+70 家 +26%)**
- 高产字段: **mobile_no +60** (60% 来自 FB Page bio + Instagram)

#### 2. **CRM 行业映射 — industry-mapping skill 对 PK SITC 不靠谱** ⚠️

**教训**: 直接调 `map_by_code(sitc_int, country="PK")` 会返回混乱的 GBT4754 中国国标 code (`201943703` 这种超长值), 不可用。

**必须用关键词兜底表**, 沉淀在 `resources/countries/pk.md#关键词兜底 CRM 映射表` (本次已补入)。

覆盖率对比:
- industry-mapping.map_by_code: 12% 有效 (88% 是错的长数字)
- 关键词兜底表: **87% 有效** (Sports+Apparel+Textile+Bags+Food 5 类占 85%+)

#### 3. **fb_url 直接 web_fetch 是关键新路径**

v1 的 PROMPT 只让 sub-agent 走 web_search, 但 **fb.com/xxx/about 这种 URL 直接 web_fetch 能拿到大量 email/官网/电话**, 甚至 founder。

**v2 PROMPT 强调**: 优先 `web_fetch <fb_url>` 拿 About Section, 命中率 30-40%.

#### 4. **PK 46-city cluster 补充**

pk.md 里 4 大城市已列, 但 v1 实战发现小城 Gujranwala/Gujrat/Wazirabad/Kamoke 也是 Sialkot 集群外围 (五金/餐具/皮革), 应加入 PK_HARD 强信号词。

#### 5. **同名歧义 — Sialkot 撞名严重**

`Sports Industries` / `International Sportswear` 这种通用名, 光靠名字无法定位:
- 硬规则: 命中的官网必须 `.pk` / `.com.pk`, 或 About 页面明确 Sialkot 地址, 否则 `enrich_note=ambiguous` 字段空
- v1 撞车率 ~8% (被正确标 ambiguous 空字段)

#### 6. **v2 sub-workflow 沉淀路径**

新增文件:
- `resources/PROMPT_pk_deep_v2.md` — v2 4 字段契约 (完整 sub-agent PROMPT)
- `resources/RUNBOOK_deep_v2.md` — v2 SOP 快查 (从 v1 交付到 v2 落地)

---

## 📌 Patch 2026-07-06 · fb-group-lead-enrichment skill 多国路由建立

### 场景

从 VN-only skill 升级到 VN/PK/HK/... 多国路由, target_country 决定 pack 选择。

### 已沉淀
见 SKILL.md 主体 "多国路由 (必读)" 段。

---

## 🎯 使用本 patch 的建议

- 每次跑 FB 补全, 先 read SKILL.md + SKILL.patch.md (skill 系统会自动合并)
- v1 交付后若 yes+零联系方式占比 ≥ 25%, 明确询问用户是否走 v2 深度补
- PK 场景严禁直接调 `map_by_code(sitc)`, 必须用 pk.md 里的关键词兜底表
