---
name: fb-group-lead-enrichment
description: >
  Facebook 公开群组导出员工列表 (xlsx: name + fb_url + fb_category + followers + loc_hint)
  → 5 阶段流水线, 多国路由 (VN / PK / HK / 可扩展) → 合并落地 xlsx + csv.
  架构: 主流程 5 阶段 (采集→分类→直背→探国家+条件背调→合并) 通用不变,
  各国差异 (数据源/字段/硬规则/行业映射) 沉淀在 resources/countries/{code}.md,
  运行时用户指定 target_country=VN|PK|HK|...  自动路由到对应 pack.
  已验证: 218 家 VN (v2-v5, tax_code 78-88%) + 8735 家 PK SMEDA 全量 (24 字段, 70-94%).
  【触发条件】: 用户提到 "FB group leads", "Facebook 客户", "背调这批 FB 名单",
  "把 FB 导出的 excel 补全字段", "越南/巴基斯坦/HK Facebook 客户",
  或提供 x1i10hfl 列的 xlsx 文件; 会先问用户 target_country 后走对应 pack.
  【与其它 skill 的关系】:
  - 通用国别补全 → websearch-enrichment (跨国通用)
  - 官网优先补全 → website-enrichment
  - HK 深度补全  → hk-company-enrichment (HK 独有 BR/ICRIS/双名, 本 skill 会自动委托)
  - Kompass 越南 → leads-finder + masothue (走 vn.kompass.com URL)
  - 本 skill    → FB Group 特化 (硬规则 + 探国家 + 目标国背调, VN/PK/HK 多国路由)
---

# FB Group Lead Enrichment (Facebook 公开群组线索背调流水线)

## 🌏 多国路由 (必读)

用户跑本 skill 时**必须先指定 target_country** (目标国代码), 由此决定:
- **Layer 1 一手工商源**   (每国不同: VN=masothue, PK=SMEDA/SECP, HK=ICRIS/webb-site)
- **硬规则国家判定**  (VN 强信号 = 越南语/HCM; PK 强信号 = Karachi/Sialkot/CNIC)
- **字段清单**       (VN=25 字段含 tax_code+VSIC; PK=24 字段含 NTN+SITC; HK=22 字段含 BR+CR)
- **CRM 行业映射来源** (VN VSIC→GGS, PK SITC→GGS, HK 中文行业→GGS)
- **CRM Org 路由**   (VN/HK/global=`303525004`, PK=`110313935`)

### 支持的国家 pack (查看 `resources/countries/{code}.md`)

| 国家 | code | 状态 | Layer 1 一手源 | 字段特色 | 已验证规模 |
|---|---|---|---|---|---|
| Vietnam | `VN` | ✅ 生产 | masothue.com (工商库) | tax_code / VSIC / 越南语双名 / 声调保留 | 218 家 (v2-v5) |
| Pakistan | `PK` | ✅ 生产 | SMEDA / SECP / Sialkot 商会目录 | NTN / STRN / SITC / Sialkot-Karachi-Lahore 集群 | 8735 家 SMEDA |
| Hong Kong | `HK` | ➡️ 委托 `hk-company-enrichment` | cr.gov.hk ICRIS / webb-site.com | BR / CR / 双名 / 港式楼层 | 1327 家 |
| India | `IN` | 🔜 待建 | MCA / IndiaMART / Zauba Corp | CIN / GSTN | — |
| China | `CN` | 🔜 待建 | 天眼查 / 企查查 / 阿里国际 | USCC / 法人证件 | — |
| Turkey | `TR` | 🔜 待建 | ticaretsicil.gov.tr | — | — |

### 未指定 country 时的默认路由

- 用户明确说 "越南 / VN"  → target_country="VN"
- 用户明确说 "巴基斯坦 / Pakistan / PK / Sialkot / Karachi" → target_country="PK"
- 用户明确说 "香港 / HK / 港" → **委托 hk-company-enrichment** (本 skill 结束)
- **未指定** → 一定要**先问用户 target_country**, 不要默认

### 运行时决策
```
Step 0 收到用户输入
  ↓
识别 target_country (从用户话里, 或 ask_user)
  ↓
IF target_country == "HK":
    → 建议用户改用 hk-company-enrichment skill (不在本 skill 处理)
ELSE:
    读取 resources/countries/{code}.md (若不存在提示用户 pack 未建)
    加载对应 硬规则 / 字段清单 / 数据源 / CRM 映射
    走 5 阶段流水线
```

---

## 🎯 定位

Facebook 公开群组 (贸易/出口/行业社区) 通常汇聚大量潜在 B2B 客户,但导出的
xlsx 只有 6 列 (`x1i10hfl href/x1i10hfl/x193iq5w/x193iq5w 2/x193iq5w 3/x1lliihq`)
其中真正有用的只有 3 个: `name / fb_url / loc_hint`。本 skill 把这类原始名单
按用户指定的 target_country 转成对应国 CRM 可入库的结构化数据 (VN 25 字段 /
PK 24 字段 / HK 22 字段等)。

**核心洞察**:
1. FB Group 是**跨国混合**的 (贸易群里有 India/China/VN/HK/Pakistan 等)
2. 名字里的**国家线索非常显性** (Pvt Ltd = India, .cn 域名 = China, Việt Nam = VN)
3. **人名 vs 公司名** 用规则可判 90%+ 准确率
4. **越南工商库 masothue.com 命中率 76-88%**, 是黄金一手源
5. 每家背调 3-4 次 web_search + 1-2 次 fetch 是甜区

**已验证水准** (218 家 VN):
- tax_code 78% | 越南语公司名 91% | 完整地址 91% | CRM 行业映射 94%
- 是 kompass 越南 batch 3-6 的同级质量

---

## 📚 五阶段流水线 (v2→v5 演进后的定型版本)

```
[Stage 0] 采集 → FB Group xlsx 输入
[Stage 1] 分类 → 硬规则国家判定 + 名字分类 (CO/BIZ/PERSON/JUNK/AMBIGUOUS)
[Stage 2] VN 直背 → CO/BIZ/AMBIGUOUS 且 country=VN 直接进背调
[Stage 3] UNKNOWN 探国家 → web_search 判国家, 只对目标国 (VN) 继续背调
[Stage 4] 合并落地 → union + 去重 + state 归一 + CRM 行业映射
```

---

## 📥 Stage 0: 输入契约

### FB xlsx 标准格式 (Facebook Group 导出)
| 列名 | 含义 | 用途 |
|------|------|------|
| `x1i10hfl href` | FB 用户主页 URL | fb_url |
| `x1i10hfl` | 名称 (公司名 or 人名) | ⭐核心信号 |
| `x193iq5w` | 加入时间 | 一般忽略 |
| `x193iq5w 2` | 地点/分类 + N people follow this | 派生 fb_category + fb_followers |
| `x193iq5w 3` | 补充信息 | 一般忽略 |
| `x1lliihq` | Follow / Add friend 按钮 | 一般忽略 |

**变体处理**:
- 某些 FB 群导出 4 列版本 (少了 `x193iq5w 3` + `x1lliihq`), 只要有 name+href 就行
- 广告帖子 xlsx (29 列, 完全不同结构) — **不属于本 skill 范围, 应剔除**

### 支持的输入模式
1. **单文件**: `facebook (5).xlsx`
2. **多文件**: `facebook (5..12).xlsx` 全部合并
3. **增量**: 之前跑过 v2/v3/v4, 新增 v5 只做增量 (跨批去重靠 fb_url + fb_name)

---

## 🔍 Stage 1: 分类 (Rule-based, 零 API 调用)

### 1.1 去重 (两级)
```python
# 批内去重: (name + fb_url) 双键
df["_key"] = df["name"].str.strip() + "||" + df["fb_url"].str.strip()
df = df.drop_duplicates(subset="_key", keep="first")

# 跨批去重: 与总账 fb_vn_enriched_all.xlsx 对照
prev_urls = set(prev["fb_url"].str.strip().str.lower())
prev_names = set(prev["fb_name"].str.strip().str.lower())
df = df[~df.apply(lambda r: (r["fb_url"].lower() in prev_urls) or (r["name"].lower() in prev_names), axis=1)]
```

### 1.2 硬规则国家判定 (无网络请求)

**VN 强信号** (任一命中即 VN):
- 越南语关键词: `việt nam` / `vietnam` / `công ty` / `cty` / `tnhh` / `xuất khẩu` / `nhập khẩu` / `sản xuất` / `nông sản` / `trái cây`
- 越南城市/省份: `hà nội` / `hanoi` / `ho chi minh` / `sài gòn` / `saigon` / `tphcm` / `bình dương` / `biên hòa` / `đồng nai` / `hải phòng` / `đà nẵng` / `cần thơ` / `nha trang` / `vũng tàu` / `long an` / `tiền giang` / `cà mau` / `hưng yên` / `quảng ninh` / `lâm đồng` / `tây ninh` / `an giang` / `bình phước` / `bến tre`
- 越南声调字符检测: 包含 `[àáảãạăằắ...đ]` 中任一 → 高概率 VN
- Viet 前缀 (不带 vietnam 全词): `Viet Delta / Vietforce` 等

**NON_VN 硬拒信号** (任一命中即拒):

| 国家 | 特征词 |
|---|---|
| India | `pvt ltd` / `private limited` / `india` / `chennai` / `mumbai` / `delhi` / `bangalore` / `kolkata` / `hyderabad` / `gujarat` / `kerala` / `pune` / `jaipur` |
| China | `shanghai` / `guangzhou` / `shenzhen` / `beijing` / `wuhan` / `chongqing` / `xiamen` / `hangzhou` / `yiwu` / `dongguan` / `foshan` / `ningbo` / `qingdao` / `china` / `chinese` / 广州/上海/深圳/北京 |
| Pakistan | `pakistan` / `karachi` / `lahore` / `sialkot` / `faisalabad` / `gujranwala` / `islamabad` |
| Bangladesh/Sri Lanka | `bangladesh` / `dhaka` / `sri lanka` / `colombo` / `ceylon` |
| Turkey | `türkiye` / `turkey` / `istanbul` / `ankara` |
| Korea/Japan/Thailand/... | `korea` / `japan` / `thailand` / `malaysia` / `indonesia` / `philippines` / `russia` / `cambodia` / `myanmar` |
| Latin America | `méxico` / `argentina` / `colombia` / `peru` / `chile` / `brasil` / `españa` / `sa de cv` / `exportacion de` |
| Africa | `algeria` / `morocco` / `nigeria` / `kenya` / `egypt` / `south africa` |

**否则 → UNKNOWN** (进入 Stage 3 用 web_search 探测)

### 1.3 名字分类

**JUNK** (无价值,跳过):
- `khóa học` / `đào tạo` / `nghiệp vụ` / `triển lãm` (培训/展会)
- `cộng đồng` / `trung tâm` / `học viện` / `đại học` (社区/学校)
- `tra cứu dữ liệu` / `cùng alibaba` / `alibaba việt` (工具/官方号)

**CO_STRICT** (明确公司实体):
- 含 `co.,ltd` / `company` / `limited` / `corp` / `inc` / `ltd` / `jsc` / `joint stock` / `tnhh` / `công ty` / `cty` / `xưởng` / `nhà máy` / `factory` / `manufactur` / `group` / `enterprise` / `cooperative` / `plant` / `mill` / `workshop`

**PERSON** (明确人名, 跳过):
- 首 token 是越南 14 大姓氏 (`nguyễn/trần/lê/phạm/hoàng/huỳnh/phan/vũ/võ/đặng/bùi/đỗ/hồ/ngô/dương/lý/đào`) 且 2-4 tokens 且无 biz 关键词
- 2-token 英文人名 (Firstname Lastname, 无 biz)
- 占位符名 (如 `Nguyen Van A`)

**BIZ_LOOSE** (业务描述型 SME, 有背调价值):
- 含产品/业务关键词: `sản xuất/xuất khẩu/nhập khẩu/logistic/wood/furniture/pallet/plastic/food/agri/nông sản/trading/export/import/hub/vina/vietnam/fashion/industry/tech/engineering/service/cargo/freight/transport/machinery/chemical/steel/metal/paper/printing/marketing/consulting/shop/store/agency/studio/lab`
- 品类扩展 (按 FB Group 主题动态加): `shoe/footwear/giày/trái cây/fruit/spice/cashew/coffee/rice/seafood/aqua/shrimp/tuna/tropical/organic/fresh/raw`

**AMBIGUOUS** (无法判定, 保险起见进背调):
- 单个 token 且非上述任一
- 无法命中任何规则

### 1.4 分类输出
- **VN + (CO_STRICT / BIZ_LOOSE / AMBIGUOUS)** → Stage 2 (直接背调)
- **UNKNOWN + (CO_STRICT / BIZ_LOOSE / AMBIGUOUS)** → Stage 3 (探国家 + 条件背调)
- **PERSON** → 跳过
- **JUNK** → 跳过
- **NON_VN** → 跳过 (硬拒, 有明确非目标国证据)

---

## 🔬 Stage 2: VN 直接背调 (25 字段)

### 4 层数据源 (越南)
```
Layer 1: masothue.com     ← 越南官方工商库 (一手, 榨干 tax_code/越南语名/成立日期/status/法人/VSIC/地址)
Layer 2: hsctvn.com       ← masothue 找不到时补充
Layer 3: 官网 contact/about ← 补 email/phone/product
Layer 4: web_search 兜底  ← 都缺时 "{name} Vietnam" 搜索
```

### 每家搜索预算
- **每家最多 3-4 次 web_search + 2 次 web_fetch**
- 超时或找不到就跳,别硬磕单一家
- 每 shard 严格 5-7 分钟时限

### 25 字段输出契约
```json
{
  "row": <int, 与输入一致>,
  "fb_name": "<原样>",
  "fb_url": "<原样>",
  "fb_category": "<原样>",
  "fb_followers": "<原样>",
  "fb_loc_hint": "<原样>",

  "is_business": "yes | no | uncertain",
  "company_name": "英文/正式名 (masothue/官网确认)",
  "local_company_name": "越南语全称 (masothue 一手, 保留声调)",
  "tax_code": "10位数字 MST (masothue), 或 10-3 分支格式",
  "established": "YYYY-MM-DD",
  "status": "active | closed | unknown",
  "status_raw": "masothue 原文 (Đang hoạt động / Ngừng hoạt động / ...)",
  "link_man": "法人代表",
  "address": "完整越南地址",
  "state": "省份/城市 (归一化英文)",
  "phone_number": "固话 (+84 或 0 开头)",
  "mobile_no": "手机号",
  "email": "邮箱 (合法性校验)",
  "website": "官网 URL",
  "product": "主营/产品短语 (英文)",
  "vsic_code": "越南 VSIC 4位 code",
  "vsic_text": "VSIC 行业文本",
  "is_exporter": "yes | no | unknown",
  "source_url": "主数据来源 URL",
  "remark": "备注"
}
```

---

## 🌍 Stage 3: UNKNOWN 探国家 + 条件背调 (v4/v5 独创)

对硬规则判 UNKNOWN 的家 (英文名 exporter 通常没有国家显性词),用 1-2 次
web_search 探测国家,**只有判定为目标国 (VN) 才进入完整背调**。

### 探测搜索模板
```
web_search("{name} vietnam OR india OR china company location")
```

从结果 title/snippet 判国家 (证据强度顺序):
1. **VN 强证据**: 官网 `.vn` 域名 / 地址含越南城市 / masothue.com 收录 / +84 电话
2. **NON_VN 证据**: 官网 `.in/.cn/.com.cn` / 印度 Pvt Ltd 后缀 / 中国城市地址 / 阿里巴巴中国供应商店铺
3. **UNKNOWN**: 都无 → 谨慎标 UNKNOWN, 不猜

### 输出加 3 字段
```json
{
  ...25 字段...,
  "country_probe": "VN | NON_VN | UNKNOWN",
  "country_reason": "证据短语 (如 'masothue found', '.in domain', '+84 phone', 'Chennai India')",
  "country_detail": "如 NON_VN 时具体是哪个国家; VN/UNKNOWN 留空"
}
```

### 探测预算
- 每家最多 2 次 web_search 判国家
- 判为 VN → 再花 2-3 次 web_search + 1-2 次 web_fetch 做完整背调
- 判为 NON_VN/UNKNOWN → 只填 country_probe 字段, 其它留空 (省预算)

---

## 🔴 铁律 (跨所有 Stage)

1. **空值铁律**: 找不到留 `""`, 严禁 `N/A` / `not found` / `null` / `****` / `无`
2. **status 规范** (VN):
   - `Đang hoạt động` / `Hoạt động` → **active**
   - `Ngừng hoạt động` / `Không hoạt động` / `Hết hiệu lực` / `Tạm ngừng` → **closed**
   - 未搜到 → **unknown**
3. **status_raw** 保留原文, 便于溯源
4. **tax_code**: 严格 10 位数字或 10-3 分支; 格式不符留空
5. **越南语名/地址**: 保留声调, 禁 T2S (跟 HK 场景相反)
6. **邮箱清洗**: 黑名单 `example.com` / `noreply@` / `sentry` / `wix.com` / `kompass.com` / `not found` → 留空
7. **严禁编造**: `contact@example.com` / `+84 xxx xxx` / `84 Hai Ba Trung Hanoi` 一律禁止
8. **同名冲突**: masothue 搜出多家同名时, 优先选 fb_loc_hint 匹配的省份; 无法确定则留空 + remark 说明
9. **每 shard 5-7 分钟时限**: 卡时间就写盘,别让一家拖垮整批
10. **限流应对**: web_search 返回 `<!DOCTYPE` (HTML 错误页) → 等 15 秒重试, 3 次仍失败则跳过

---

## ⚙️ 并发策略 (v2→v5 实战调参)

| 参数 | 值 | 依据 |
|---|---|---|
| 每 shard 大小 | **8-15 家** | 25 字段密集, 太多写盘容易超时 |
| 并发 sub-agent | **3** | skill 甜区, 8 会触发后端限流 |
| 单 shard 时间 | **5-7 分钟** | 太长会 timeout |
| 每家 search 上限 | **3-4 次** (VN 直背) / **2 次** (UNKNOWN 探测) | 精算过的甜区 |
| 每家 fetch 上限 | **2 次** | 抓官网 contact/about |

---

## 🔄 主流程合并 (Stage 4)

### 4.1 加载所有 out shard
```python
import json, glob, os
enr = {}
for f in sorted(glob.glob("_fb_enrich_vX/out_*.json")):
    for r in json.load(open(f, encoding="utf-8")):
        row = r.get("row")
        if isinstance(row, int):
            enr[row] = r
```

### 4.2 主流程逐行处理
- **scrub()**: 去掉 `n/a / not found / null / **** / -- / unknown / unavailable / 无 / 未找到`
- **norm_status()**: 双语规范到 active/closed/unknown
- **norm_tax()**: 提取纯 10 位数字
- **do_map()**: `vsic_code` → `map_by_code(country="VN")` → CRM industry name + code + confidence; 兜底 `map_by_text(product/vsic_text)`

### 4.3 落地
```
Agent_output/
├── fb_vn_enriched_v5.xlsx           ← 本次批次结果 (28 字段: fb 6 + category + 20 背调 + 3 CRM)
├── fb_vn_enriched_v5.csv
├── fb_vn_probe_v5_full.xlsx         ← v5 探测详情 (含 NON_VN 供审计)
├── fb_vn_classified.xlsx            ← 分类总账 (含 PERSON/JUNK)
└── fb_vn_enriched_all.xlsx          ← v2+v3+v4+v5 union 总账 (**最终交付**)
```

### 4.4 union 到总账
```python
union = pd.concat([v2, v3, v4_vn, v5_vn], ignore_index=True)
union["_k"] = union["fb_url"].where(union["fb_url"]!="", union["fb_name"]).str.strip().str.lower()
union = union.drop_duplicates(subset="_k", keep="first")
```

### 4.5 state 归一化 (归一到 CRM 标准英文)
- HCM 变体 (`TP Hồ Chí Minh` / `Hồ Chí Minh` / `Sài Gòn` / `HCMC`) → `Ho Chi Minh City`
- Hanoi 变体 (`Hà Nội` / `Ha Noi`) → `Hanoi`
- 其它 30+ 越南省份类似归一

### 4.6 三层交付
```
fb_vn_enriched_all.xlsx              (全量, 含 uncertain/no)
fb_vn_enriched_yes_only.xlsx         (is_business=yes 子集)
fb_vn_enriched_yes_with_contact.xlsx (yes + 至少一项联系方式, 可入 CRM)
```

---

## 📊 已验证记录 (baseline for future runs)

| 批次 | 输入原始 | 去重后 | VN 直背 | UNKNOWN 探测 | 抓到 VN | tax_code% | 说明 |
|---|---|---|---|---|---|---|---|
| v2 (10 fb 文件) | 331 | 154 | 102 | — | 102 | 78% | 家具/木材/包装/机械 |
| v3 (fb 1/2/3/13) | 471 | 455 | 18 | — | 18 | 88% | 农产品+鞋类 |
| v4 (v3 unknown 深挖) | — | 272 | — | 272 | 21 | 100% | 全字段满 |
| v5 (fb 14/15/16) | 333 | 298 | 16 | 245 | 77 | 85% | 海鲜/食品 |
| **累计** | **1135** | **1179** | **136** | **517** | **218** | **83%** | — |

---

## 🎬 使用流程速查 (给未来的 Claude 会话)

```
1. 用户丢来 facebook (N).xlsx 或多份 FB 文件
2. 读取 → 合并 → 批内去重 → 与总账去重
3. 硬规则国家判定 (NON_VN/VN/UNKNOWN)
4. 名字分类 (CO/BIZ/PERSON/JUNK/AMBIGUOUS)
5. VN + (CO/BIZ/AMBIGUOUS) 分片 8-15 家 → 并发 3 sub-agent → 直接背调 25 字段
6. UNKNOWN + (CO/BIZ/AMBIGUOUS) 分片 15 家 → 并发 3 sub-agent → 探国家 + 只对 VN 继续背调
7. 主流程合并 out shard → scrub/norm/map → xlsx + csv
8. Union 到总账 fb_vn_enriched_all.xlsx (去重靠 fb_url + fb_name)
9. state 归一化 → 三层交付 (all / yes_only / yes+contact)
```

---

## 🚨 常见坑

1. **PowerShell mojibake**: 输出 Excel/txt 用 UTF-8-sig, print 语句用 `$env:PYTHONIOENCODING="utf-8"`
2. **Windows 文件名不能含 `>` `→`**: 用 `_to_` 替代
3. **广告 FB 文件混入**: 29 列 vs 6 列 → 用列数或列名过滤剔除
4. **同名多家公司**: `Wing Fat Trading` 可能有 5 家, 靠 fb_loc_hint 省份 + BR/tax_code 交叉确认
5. **英文名 exporter 判国家**: 硬规则大概率 UNKNOWN, 必须走 Stage 3 探测, 否则漏掉大量 VN
6. **单 shard 超时**: agent 陷入单家反复搜索 → 强化 "每家 ≤2 次 search + 找不到就跳" 约束
7. **后端 web_search 挂**: YOU.COM API 波动时返回 `<!DOCTYPE` HTML → 等 15s 重试 3 次, 失败则本 shard 跳到下一家; **circuit breaker 触发时整批停 60-180 秒重试**
8. **kompass 越南场景不要用本 skill**: kompass 数据已有 vn.kompass.com URL, 走 masothue+URL 抓取, 用 leads-finder + websearch-enrichment 更快 (本 skill 是 FB 特化, 无 URL)

---

## 📁 参考代码 (v5 是最终版, 沉淀在 diary/2026-07-04.md)

- `_fb_v5_classify.py` (Stage 1)
- `_fb_v5_make_batches.py` (拆 shard)
- `_fb_enrich_v5_vn/PROMPT.md` (VN 直背 sub-agent 规范)
- `_fb_enrich_v5_unk/PROMPT.md` (UNKNOWN 探测 sub-agent 规范)
- `_fb_v5_merge.py` (Stage 4 合并)
- `_fb_all_finalize.py` (跨批 union + state 归一)

---

## 🌏 可扩展到其它目标国

本 skill 默认目标国是 VN, 但架构通用. 换目标国只需替换 3 处:

| 目标国 | Layer 1 一手源 | 命中率参考 | 硬规则 VN_HARD 换成 | 输出字段变化 |
|---|---|---|---|---|
| **HK** | cr.gov.hk (ICRIS) / webb-site.com | 未测 | HK 语言/城市/BR 号 | 走 `hk-company-enrichment` skill |
| **IN** | mca.gov.in / IndiaMART | 未测 | Pvt Ltd / .in / 印度城市 | 加 CIN / GST 字段 |
| **CN** | 天眼查 / 企查查 | 未测 | 中文城市 / .cn / USCC | 加 USCC / 法人证件字段 |
| **PK** | secp.gov.pk / SMEDA | 未测 | .pk / Pakistan / Karachi | 加 NTN / CNIC |
| **TR** | ticaretsicil.gov.tr | 未测 | .tr / Türkiye / İstanbul | — |

---

## 🔗 与其它 skill 的协作

- **industry-mapping**: 一定要用, VSIC→CRM 兜底 `map_by_text(product)`
- **websearch-enrichment**: 通用兜底, 若目标国无 Layer 1 一手源
- **website-enrichment**: 官网优先场景, 若数据里已有 website 列
- **leads-finder**: 从 CRM 或平台先找 leads 再补全 (本 skill 是 "已有名单" 场景, 补字段)
- **hk-company-enrichment**: 目标国 = HK 时直接切换过去, 本 skill 场景选 country="HK"

## ✅ 完成信号

用户看到:
1. `fb_XX_enriched_all.xlsx` (总账文件)
2. is_business=yes 子集数
3. tax_code / email / phone / website 命中率
4. 行业 TOP10 分布
5. 建议下一步 (`crm-add` 入库 or 分行业运营)
