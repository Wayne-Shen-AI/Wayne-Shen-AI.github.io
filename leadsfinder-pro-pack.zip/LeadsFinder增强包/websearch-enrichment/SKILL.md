---
name: websearch-enrichment
description: >
  通用「公司线索字段补全」skill —— 用 web search 给一批公司补全任意字段
  (email / website / phone / address / contact_person / industry / 等)。
  字段不固定：用户给什么列、要补什么字段，都按需补。
  每次搜索强制带【国家】(用户每次会告知,如 HK/VN/PK/IN)。
  本 skill 可被 website-enrichment 调用作兜底,也可【单独直接调用】。
  触发: "补全这批公司的邮箱/官网/电话"、"给leads补字段"、"websearch补全"、
  "查这些公司的联系方式"、"enrich这批线索"。
---

# websearch-enrichment

## 定位 (一句话)

**输入**: 一个公司名列表(可能还带已知字段) + 国家代码 + 要补的字段清单
**输出**: 每家公司补全后的记录(每个补全字段尽量带 source_url 来源)
**手段**: web_search（不打开官网，只读搜索结果标题+摘要）

> 这是「纯搜索」补全层。若要"优先抓官网、官网缺再搜"，用上层 `website-enrichment`，
> 它会在官网拿不到时回落到本 skill。

---

## When to use

- 用户给一批公司名,要补 email / 官网 / 电话 / 地址 / 联系人 / 行业等任意字段。
- 没有官网线索,或不要求进官网,只要快速搜索补全。
- 作为 `website-enrichment` 的兜底被调用。

---

## 核心约定 (硬性)

### 1) 字段宽泛 + 可扩展
默认可补字段(用户没指定时的全集):
```
email, website, phone, address, contact_person, industry_text
```
但**以用户本次指定的字段为准**。用户说"只补邮箱和官网"就只补这两个；
说"再加个传真 fax"就临时加。skill 不写死字段,按本次需求动态决定。

> ⚠️ **空值铁律 (必须遵守)**: 某字段没找到时, **一律留真正的空值 (空字符串)**,
> 绝不填 `N/A` / `N.A` / `not found` / `未找到` / `-` / `none` / `nil` / `无` 等占位符。
> 占位符会污染下游(CRM导入、去重、统计)。note 列可以写"未找到"说明,
> 但**字段值本身必须为空**。这同样适用于交付前的合并/清洗步骤。

### 2) 每次搜索必须带国家 (关键)
用户每次会告诉你国家(HK/VN/PK/IN/TR/KR...)。
**query 模板**: `{公司名} {国家英文名} {字段关键词}`
例:
- HK → `Kai Fat Food Co Ltd Hong Kong email`
- VN → `Cong ty ABC Vietnam email`
- PK → `ABC Industries Pakistan email contact`
国家影响: ① 提高搜索准确度 ② 排除同名外国公司 ③ 决定行业映射走哪国字典。

### 3) 一次搜索尽量榨干 (省开销)
**关键成本认知**: 贵的是"发起一次 web_search",不是"提取几个字段"。
所以一次搜索结果里, 把能提的字段(email/官网/电话/地址/行业描述)**一次全提**,
不要为每个字段单独搜一次。详见"成本模型"。

### 4) 来源可溯
每个补到的字段尽量记 `{field}_source_url`,方便用户复核。

---

## 成本模型 (为什么这样设计)

| 环节 | 成本 | 结论 |
|------|------|------|
| 发起 1 次 web_search | 💰💰💰 最贵(网络+限流风险) | 尽量少搜 |
| 从返回文本提 1 个字段 | ~0 | —— |
| 从同一返回文本提 5 个字段 | ~0 | **一次搜索全提** |
| 为某字段额外开页面/额外搜 | 成本翻倍 | 避免;行业精确映射放到事后离线做 |

→ **黄金法则**: 每家公司原则上只搜 1 次, 从这 1 次结果里提全部字段。

---

## Workflow

### Step 1: 确认输入
- 公司列表(从文件读或用户直接给)
- **国家**(用户本次告知,必须有)
- 要补的字段(用户指定,否则用默认全集)

### Step 2: 逐家搜索 + 多字段提取
对每家公司:
```
query = f"{company} {country_full} email contact"
results = web_search(query)
# 从所有结果的 title + snippet 文本里一次性提取:
email   = 正则 [A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}
website = 找官网域名(排除目录站 kompass/hktdc/facebook/linkedin)
phone   = 电话正则(带国家区号优先)
address = snippet 里的地址行
contact = "Contact Person: Mr X" / "联系人:" 模式
industry_text = snippet 里的业务描述短语
```

### Step 3: 清洗过滤 (通用,不针对单站)
邮箱黑名单: `example.com sentry wix dpo@kompass.com .png .jpg noreply@`
邮箱去 www 污染: `@www. -> @`
多个值用 `;` 连接。

### Step 4: (可选)行业映射
若要补的字段含 `industry`(标准CRM行业 code,非纯文本):
→ **不在搜索时做**,先把 industry_text(文本)抓下来,
→ 事后统一调用 `industry-mapping` skill 离线映射成 CRM code(见下)。

### Step 5: 并发 & 限流防护 (HK/TR/VN 多轮实测校准)
> ⚠️ **并发 3 是安全甜区**(经 HK 1327家 / TR 2000家 / VN 200家 验证)。
> 早期"必须串行"的结论已被推翻 —— 并发 3 稳定不限流;并发 ≥4-5 才会触发限流。

- **并发 = 3 个子代理**(sessions_spawn 一次开 3 个),这是吞吐与稳定的最佳平衡。
- **每批家数按字段数反比**:
  - 4 字段(phone/email/website/contact) → **每批 12 家**
  - 6+ 字段(加工商号/行业/地址等结构化) → **每批 10 家**(单家要读工商页,更慢)
  - 11+ 字段(HK 全字段) → **每批 6 家**
- **限流信号 = web_search 返回 `<!DOCTYPE`(HTML错误页而非JSON)**。子代理内遇到→等15秒重试,最多3次仍失败就跳过该公司继续(别让一家拖垮整批)。
- **整批熔断处理**: 若某批子代理整体失败(circuit breaker),说明平台级限流。**主流程等待 90-180 秒**让限流恢复,然后**降到并发 1 单跑该批**验证恢复,再恢复并发 3。
- **每 N 轮做一次中间存档**(合并已完成的 CSV 到 PROGRESS.csv),防长跑数据丢失。
- 每批写独立 CSV,最后合并去重(同公司保留字段最全的行,见 Step 7)。

### Step 6: 官方工商库优先 (结构化字段的金矿)
若目标国有**公开工商登记库**,优先搜它 —— **一页就能榨干大量结构化字段**,远比逐字段搜划算:
| 国家 | 工商库 | 一页可得字段 |
|------|--------|--------------|
| 越南 VN | `masothue.com` / `thuvienphapluat.vn` | 工商号(MST)、越南语全称、成立日期、在营状态、法人代表、英文名、注册地址、VSIC行业code |
| (其他国按需扩充) | | |

query 模板: `{公司名} {国家} {工商号关键词} masothue`(VN 用 `mã số thuế`)。
工商库**缺联系方式**(email/website 命中低) —— 若用户更看重邮箱,工商页拿完结构化字段后**再补一轮官网搜索**(成本翻倍,按需)。

### Step 7: 枚举字段规范化 (交付前清洗)
状态/类型类字段必须规范成**标准英文枚举**,不要留原始外语值:
- **越南 status**: `Đang hoạt động`→**active**; `Ngừng/Không hoạt động`/`Hết hiệu lực`/`Tạm ngừng`→**closed**; 空值或误抓(人名/日期)→**unknown**。
- 保留一列 `status_raw` 存原始值供溯源。
- closed 关键词要**先于** active 判断(避免"ngừng hoạt động"里的"hoạt động"误判为 active)。

### Step 8: 输出 + 落地铁律 (字段错位根治方案)

> 🔴 **最重要的教训 (字段错位 bug)**: **禁止让子代理手写 CSV 文本**。
> 子代理靠"数逗号"拼 CSV,遇空字段极易漏写/多写分隔符 → 整行字段错位
> (实测 VN 200家有 13+7 行错位: contact 为空时后续 tax_code/公司名整体前移一列,
>  或多写一列导致右移)。**叮嘱它小心也无法根治,这是手拼文本的固有缺陷。**

✅ **标准方案: 子代理输出 JSON,主流程按 key 落地 CSV**
1. 子代理用 `write` 写 **JSON 数组**,每公司一个对象,**所有字段 key 必须出现(空值用 `""`)**:
   ```json
   [{"company_name":"...","phone":"...","email":"","tax_code":"0301234567",...}]
   ```
   JSON 是显式 key-value 映射,空值就是 `"key":""`, **不存在"数逗号"问题,错位从根上消失**。
2. 主流程用 `json_to_csv.py` 按固定列顺序落地(`pandas.DataFrame(data)[COLS]`,缺失 key 自动补空)。
   - 转换器: `agent-core/skills/websearch-enrichment/resources/json_to_csv.py`(或项目内同名)
3. **落地后必校验对齐**: 关键字段(如越南 tax_code)必须符合格式正则,否则报错。

**为什么不是"子代理写CSV + pandas按字段名读"**: pandas 只能读它收到的列,源头错位它无法纠正。必须在源头用 JSON 杜绝。

**编码**: 最终 CSV 用 **`utf-8-sig`**(否则越南语/土耳其语乱码)。
**合并读取**: 若历史遗留手写 CSV,用 **Python `csv` 标准库逐行读**(比 `pandas.read_csv` 容错好,
实测 pandas 对字段内引号会误跳行,csv 库能正确读出;读后补齐/截断到固定列数)。
没找到的字段留空(`""`), note 列可写"未找到"说明,字段值本身必须空。

---

## 与 industry-mapping 的衔接

本 skill 只负责抓"行业文本"(如 "frozen seafood importer")。
要转成 GGS CRM 44 个标准行业 code 时,调用 `industry-mapping` skill:
- 它有 `resources/ggs_crm_industries.json` (44个CRM行业权威字典)
- 它有 `resources/vsic_to_ggs.json` (越南VSIC→CRM)
- 国际站多国: 不同国家用不同源字典。VN 有 VSIC code 直接用;
  其他国家若只有行业文本, 走 industry-mapping 的 fuzzy keyword 匹配。
路径: agent-core/skills/industry-mapping/

---

## Anti-pattern (踩过的坑)

1. **不要 ≥4 并发** — 并发 **3 是甜区**(已实测);≥4-5 才触发限流(返回 HTML)。早期"必须串行"结论已作废,串行太慢。
2. **不要每字段单独搜** — 一次搜索/一页榨干所有字段。有官方工商库的国家优先搜工商库。
3. **不要硬编码站点结构** — 用通用正则/规则,换公司同样能跑。
4. **不要忘国家** — query 不带国家会大量混入同名外国公司(实测B E International搜出酒店)。
5. **不要把 LOW 置信当确定** — 第三方目录来的邮箱标注来源,让用户用 source_url 复核。
6. **批次按字段数定大小** — 4字段12家/6+字段10家/11字段6家;一刀切 50 家会超时。
7. **不要留原始外语枚举值** — status 等枚举字段规范成 active/closed/unknown,另存 _raw 溯源。
8. **不要忽视 CSV 引号转义** — 含逗号字段不双引号包裹会让整批被解析跳过(VN w03 教训)。
9. **不要因单家失败拖垮整批** — 子代理内单家限流重试3次仍失败就跳过;整批熔断才走"等待→降并发1重试"。

---

## 已验证

| 数据集 | 国家 | 字段 | 命中率 | 并发/批 | 备注 |
|--------|------|------|--------|---------|------|
| 1205家香港食品/贸易公司 | HK | email+source_url | 71% | 串行/50 | 早期方案 |
| 1327家香港全字段 | HK | 11字段(phone/email/contact/地址/中文名/社媒/官网/BR号/成立/员工/行业) | phone等70-90%,BR号67% | 3/6 | 字段多批要小 |
| ~2067家土耳其机械 | TR | 4字段(phone/email/website/contact) | phone93%/email83%/website88% | 3/12 | 并发3稳定;曾遇平台限流等3分钟恢复 |
| 200家越南(kompass) | VN | 结构化13字段(工商号/越南语名/成立日期/状态/法人/英文名/地址/行业映射等) | 工商号95%/越南语名95%/地址94%/成立92%/状态96% | 3/10 | masothue一页榨干;status规范active/closed/unknown;VSIC→GGS行业映射52% |
