# -*- coding: utf-8 -*-
"""通用 JSON -> CSV 转换器 (杜绝字段错位的标准落地工具)。
子代理只输出 JSON 数组(每个公司一个对象,key=字段名),本脚本按固定列顺序
用 pandas 落地。空值字段在 JSON 里可缺省或为"",pandas 按 key 对齐,绝不错位。

用法:
  python json_to_csv.py <input.json> <output.csv>
JSON 格式:
  [{"company_name":"...","phone":"...","tax_code":"...", ...}, ...]
"""
import sys, io, json
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
import pandas as pd

# 越南补全标准列顺序(可按任务调整)
VN_COLS = ["company_name","phone","email","website","contact","tax_code","vn_company_name",
           "established","status","legal_rep","intl_name","address","vsic_text","source_url","note"]

def convert(inp, outp, cols=VN_COLS):
    with open(inp, encoding="utf-8") as f:
        data = json.load(f)
    if isinstance(data, dict):
        data = data.get("companies") or data.get("data") or [data]
    # 按 key 对齐: 缺失的字段自动补空,多余的 key 忽略
    df = pd.DataFrame(data)
    for c in cols:
        if c not in df.columns:
            df[c] = ""
    df = df[cols].fillna("")
    df.to_csv(outp, index=False, encoding="utf-8-sig")
    print(f"converted: {len(df)} rows -> {outp}")
    return df

if __name__ == "__main__":
    convert(sys.argv[1], sys.argv[2])
