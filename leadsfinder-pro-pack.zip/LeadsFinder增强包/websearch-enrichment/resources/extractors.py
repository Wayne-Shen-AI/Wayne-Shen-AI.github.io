# -*- coding: utf-8 -*-
"""
websearch-enrichment 通用字段提取器 (零硬编码,任意公司通用)
=========================================================
从一段文本(web_search 的 title+snippet 拼接, 或官网HTML)里提取多字段。
被 websearch-enrichment 和 website-enrichment 两个 skill 共用。

用法:
  from extractors import extract_all, COUNTRY_FULL
  fields = extract_all(text, want=["email","website","phone"], site_domain=None)
"""
import re

# 国家代码 -> 搜索用英文名 (国际站多国)
COUNTRY_FULL = {
    "HK": "Hong Kong", "VN": "Vietnam", "PK": "Pakistan", "IN": "India",
    "TR": "Turkey", "KR": "South Korea", "TW": "Taiwan", "ID": "Indonesia",
    "TH": "Thailand", "MY": "Malaysia", "SG": "Singapore", "PH": "Philippines",
    "BD": "Bangladesh", "AE": "United Arab Emirates", "SA": "Saudi Arabia",
}

EMAIL_RE = re.compile(r"[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}")
# 电话: 容忍 +区号 () - 空格
PHONE_RE = re.compile(r"(?:\+?\d{1,3}[\s\-]?)?(?:\(\d{1,4}\)[\s\-]?)?\d[\d\s\-]{5,12}\d")
URL_RE = re.compile(r"https?://[^\s\"'<>)]+", re.I)

EMAIL_BLACKLIST = ("example.com", "sentry", "wix", "dpo@kompass.com",
                   ".png", ".jpg", ".jpeg", ".gif", "noreply@", "no-reply@",
                   "domain.com", "email.com", "yourdomain", "@2x", "@3x")
# 不算"官网"的目录/社媒站
NON_OFFICIAL = ("kompass.", "hktdc.", "facebook.", "linkedin.", "instagram.",
                "scribd.", "panjiva.", "importyeti.", "zoominfo.", "rocketreach.",
                "dnb.com", "yelp.", "made-in-china.", "tradeeasy.", "alibaba.",
                "mingluji.", "todaytex.", "youtube.", "twitter.", "wikipedia.")


def clean_emails(text):
    out, seen = [], set()
    for e in EMAIL_RE.findall(text or ""):
        e = re.sub(r"@www\.", "@", e.strip().strip(".").lower())
        if any(b in e for b in EMAIL_BLACKLIST):
            continue
        if e not in seen:
            seen.add(e); out.append(e)
    return out


def find_website(text):
    """从文本里找最像官网的URL(排除目录/社媒)"""
    for u in URL_RE.findall(text or ""):
        low = u.lower()
        if not any(n in low for n in NON_OFFICIAL):
            # 去掉路径只留域名根
            m = re.match(r"(https?://[^/]+)", u)
            return m.group(1) if m else u
    return ""


def find_phones(text, max_n=2):
    cands = []
    for p in PHONE_RE.findall(text or ""):
        digits = re.sub(r"\D", "", p)
        if 7 <= len(digits) <= 15:  # 合理电话长度
            cands.append(p.strip())
    # 去重保序
    seen, out = set(), []
    for c in cands:
        if c not in seen:
            seen.add(c); out.append(c)
    return out[:max_n]


def find_contact(text):
    """Contact Person: Mr X / 联系人:X 模式 (遇到 Email/Tel 等关键词截断)"""
    m = re.search(r"(?:Contact Person|联系人|聯絡人)\s*[:：]?\s*"
                  r"((?:Mr|Ms|Mrs|Dr|Miss)?\.?\s*[A-Za-z\u4e00-\u9fff]+(?:\s[A-Za-z\u4e00-\u9fff]+){0,3})",
                  text or "")
    if not m:
        return ""
    name = m.group(1).strip()
    # 截断到 Email/Tel/Position 等噪声词之前
    name = re.split(r"\s*(?:Email|E-mail|Tel|Phone|Position|Fax|地址|电话)", name)[0].strip()
    return name


def find_address(text):
    """粗取含地址特征词的片段 (在 . ; 换行 处切，避免吞整段)"""
    for line in re.split(r"[\n。;]|(?<=[a-z])\.\s+(?=[A-Z])", text or ""):
        line = line.strip()
        if re.search(r"\b(Road|Street|Floor|Building|Centre|Center|Tower|Estate|\d+/F)\b", line, re.I):
            # 去掉前缀噪声(如 Address:)
            line = re.sub(r"^.*?(?:Address|地址)\s*[:：]\s*", "", line, flags=re.I)
            return line[:120]
    return ""


def extract_all(text, want=None, site_domain=None):
    """主入口: 按 want 字段列表提取。want=None 则提全集。"""
    want = want or ["email", "website", "phone", "address", "contact_person", "industry_text"]
    res = {}
    if "email" in want:
        res["email"] = ";".join(clean_emails(text))
    if "website" in want:
        res["website"] = find_website(text)
    if "phone" in want:
        res["phone"] = ";".join(find_phones(text))
    if "address" in want:
        res["address"] = find_address(text)
    if "contact_person" in want:
        res["contact_person"] = find_contact(text)
    if "industry_text" in want:
        # 行业纯文本: 留给上层抓 snippet 业务描述, 这里不强解析
        res["industry_text"] = ""
    return res


if __name__ == "__main__":
    demo = ("Kai Fat Food Co Ltd Hong Kong. Contact Person: Mr Wong. "
            "Email: info@kaifatfood.com.hk Tel: (852) 2877 7908 "
            "Address: Unit 1102, 11/F Easey Commercial Building, Wan Chai. "
            "Website https://www.kaifatfood.com.hk frozen seafood importer")
    print(extract_all(demo))
