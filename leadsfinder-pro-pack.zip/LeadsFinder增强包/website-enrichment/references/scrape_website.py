# -*- coding: utf-8 -*-
"""
website-enrichment 官网多字段抓取模板 (零硬编码,任意官网通用)
========================================================
对一批有官网的公司,抓首页+contact/about子页,通用提取多字段。
复用 websearch-enrichment/resources/extractors.py 的提取器。

配置区改: SRC(输入文件) / WEBSITE_COL(官网列) / COMPANY_COL / WANT(要抓的字段)
用法(Git Bash):
  export PYTHONIOENCODING=utf-8
  "C:/.../python.exe" -B scrape_website.py [--limit N]
输出: <SRC>_website_enriched.xlsx, 每字段带 _source_url。
"""
import os, sys, re, time, random, argparse, warnings
from pathlib import Path
from urllib.parse import urljoin, urlparse
import pandas as pd
import requests
from bs4 import BeautifulSoup

warnings.filterwarnings("ignore")

# --- 引入共用提取器 ---
EXTRACTOR_DIR = Path(
    r"C:\Users\zhangyu\.accio\accounts\1660079974\agents"
    r"\MID-78079974U1776135-18EA3F-2181-A25DCF\agent-core"
    r"\skills\websearch-enrichment\resources"
)
sys.path.insert(0, str(EXTRACTOR_DIR))
from extractors import extract_all, clean_emails  # noqa

# ============ 配置 ============
ROOT = Path(r"C:\Users\zhangyu\PycharmProjects\pythonProject")
SRC = ROOT / "leads.xlsx"          # ← 改成你的文件
COMPANY_COL = "company"
WEBSITE_COL = "website"            # ← 官网列名(没有则全走搜索兜底)
WANT = ["email", "phone", "address", "contact_person"]  # ← 本次要抓的字段
OUT = ROOT / (SRC.stem + "_website_enriched.xlsx")
# ==============================

HEADERS = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                         "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120 Safari/537.36",
           "Accept-Language": "en-US,en;q=0.9,zh-HK;q=0.8"}
CONTACT_HINTS = ("contact", "about", "reach", "enquir", "inquir",
                 "联系", "聯絡", "聯繫", "关于", "關於", "联络")
MAX_SUB = 4


def fetch(url, timeout=(6, 10)):
    for a in range(2):
        try:
            r = requests.get(url, headers=HEADERS, timeout=timeout, verify=False, allow_redirects=True)
            return r.text if (r.status_code == 200 and r.text) else None
        except Exception:
            if a < 1: time.sleep(1.0)
    return None


def find_contact_links(html, base):
    out = []
    try:
        soup = BeautifulSoup(html, "html.parser")
        for a in soup.find_all("a", href=True):
            href = a["href"].strip()
            if href.startswith("#") or href.lower().startswith("javascript"): continue
            low = (href + " " + (a.get_text() or "")).lower()
            full = urljoin(base, href)
            if urlparse(full).netloc != urlparse(base).netloc: continue
            if any(h in low for h in CONTACT_HINTS) and full not in out:
                out.append(full)
    except Exception:
        pass
    return out[:MAX_SUB]


def scrape_site(website):
    """抓一个官网首页+contact子页,返回 (fields_dict, source_url, status)"""
    url = website.strip()
    if not url.startswith("http"): url = "http://" + url
    p = urlparse(url); host = p.netloc
    host_www = host if host.startswith("www.") else "www." + host
    cands, seen = [], set()
    for sch in ("https", "http"):
        for h in (host_www, host):
            c = f"{sch}://{h}{p.path or ''}"
            if c not in seen: seen.add(c); cands.append(c)
    home, base = None, url
    for c in cands:
        home = fetch(c)
        if home: base = c; break
    if not home:
        return {}, "", "unreachable"
    # 首页+contact子页文本合并
    texts = [home]
    for link in find_contact_links(home, base):
        time.sleep(random.uniform(0.5, 1.2))
        sub = fetch(link)
        if sub: texts.append(sub)
    big = " ".join(texts)
    big = big.replace("&#64;", "@").replace("&#46;", ".")
    fields = extract_all(big, want=WANT, site_domain=urlparse(base).netloc)
    got = any(v for v in fields.values())
    return fields, base, ("ok" if got else "no_data")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--limit", type=int, default=0)
    args = ap.parse_args()
    df = pd.read_excel(SRC, dtype=str).fillna("")
    has_web = df[WEBSITE_COL].str.strip() != "" if WEBSITE_COL in df.columns else df.index < 0
    idxs = list(df[has_web].index)
    if args.limit: idxs = idxs[:args.limit]
    print(f"有官网行: {len(idxs)} | 抓字段: {WANT}")

    for c in WANT + [f"{w}_source_url" for w in WANT] + ["_web_status"]:
        if c not in df.columns: df[c] = ""

    for i, idx in enumerate(idxs, 1):
        web = str(df.at[idx, WEBSITE_COL]); comp = str(df.at[idx, COMPANY_COL])
        try:
            fields, src, st = scrape_site(web)
        except Exception as e:
            fields, src, st = {}, "", f"err:{type(e).__name__}"
        for w in WANT:
            v = fields.get(w, "")
            if v:
                df.at[idx, w] = v
                df.at[idx, f"{w}_source_url"] = src
        df.at[idx, "_web_status"] = st
        print(f"[{i}/{len(idxs)}] {comp[:32]:32} | {st} | {fields.get('email','')[:40]}", flush=True)
        if i % 50 == 0: df.to_excel(OUT, index=False); print(f"  ...saved {i}")
        time.sleep(random.uniform(0.8, 1.8))

    df.to_excel(OUT, index=False)
    print(f"\nOK -> {OUT.name}")


if __name__ == "__main__":
    main()
