# -*- coding: utf-8 -*-
"""
公司线索补全 —— LangGraph 状态机版
==================================
工程化编排「官网优先 → 无官网/缺字段走搜索 → 行业映射」完整流程。

状态机流程 (每家公司一次):
  check_website ─┬─ 有官网 → scrape_website ─┬─ 字段齐 → map_industry → done
                 │                          └─ 缺字段 ↘
                 └─ 无官网 ─────────────────────────→ websearch → map_industry → done

搜索节点两种模式 (二选一, 自动判断):
  A) SERPAPI_KEY 有值 → 直接调 SerpApi, 脚本全自动独立跑完
  B) 无 key → LangGraph interrupt() 暂停, 吐出待搜清单;
     由 AI(web_search) 搜完, 用 Command(resume=...) 喂回, 状态机从断点继续。

行业映射: import industry-mapping/map_industry.py (纯本地, 无依赖)。

依赖: pip install langgraph requests pandas beautifulsoup4
用法:
  export PYTHONIOENCODING=utf-8
  export SERPAPI_KEY=xxx   # 可选; 有则全自动, 无则走 interrupt
  python enrich_langgraph.py --src leads.xlsx --country HK --fields email,website,phone,industry
"""
from __future__ import annotations
import os, sys, re, time, json, argparse, warnings
from pathlib import Path
from typing import TypedDict, Optional
from urllib.parse import urljoin, urlparse

import pandas as pd
import requests
from bs4 import BeautifulSoup
from langgraph.graph import StateGraph, START, END

warnings.filterwarnings("ignore")

# ---- 复用已沉淀的 skill 资源 ----
SKILLS = Path(r"C:\Users\zhangyu\.accio\accounts\1660079974\agents"
              r"\MID-78079974U1776135-18EA3F-2181-A25DCF\agent-core\skills")
sys.path.insert(0, str(SKILLS / "websearch-enrichment" / "resources"))
sys.path.insert(0, str(SKILLS / "industry-mapping"))
from extractors import extract_all, COUNTRY_FULL          # noqa  通用字段提取
from map_industry import map_by_text, map_by_code          # noqa  CRM行业映射

HEADERS = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                         "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120 Safari/537.36"}
CONTACT_HINTS = ("contact", "about", "enquir", "inquir", "联系", "聯絡", "关于", "關於")


# ============================================================
# 1. 状态定义 (State) —— 在节点间流动的数据
# ============================================================
class LeadState(TypedDict):
    company: str
    country: str                 # 国家代码 HK/VN/PK...
    want_fields: list            # 本次要补的字段
    website: Optional[str]       # 已知官网(可空)
    fields: dict                 # 已补到的字段 {name: value}
    sources: dict                # 各字段来源 {name: url}
    status: str                  # 处理状态
    search_text: Optional[str]   # interrupt模式: AI回填的搜索结果文本


# ============================================================
# 2. 节点 (Nodes) —— 每个职责单一
# ============================================================
def node_check_website(state: LeadState) -> dict:
    """判断是否有官网, 决定后续走向"""
    w = (state.get("website") or "").strip()
    has = bool(w) and ("." in w)
    return {"status": "has_website" if has else "no_website"}


def _fetch(url, timeout=(6, 10)):
    for a in range(2):
        try:
            r = requests.get(url, headers=HEADERS, timeout=timeout, verify=False, allow_redirects=True)
            return r.text if (r.status_code == 200 and r.text) else None
        except Exception:
            if a < 1: time.sleep(1.0)
    return None


def node_scrape_website(state: LeadState) -> dict:
    """官网优先: 抓首页+contact子页, 通用提取字段"""
    url = state["website"].strip()
    if not url.startswith("http"): url = "http://" + url
    p = urlparse(url); host = p.netloc
    hw = host if host.startswith("www.") else "www." + host
    cands = [f"{s}://{h}{p.path or ''}" for s in ("https", "http") for h in (hw, host)]
    home, base = None, url
    for c in dict.fromkeys(cands):
        home = _fetch(c)
        if home: base = c; break
    if not home:
        return {"status": "website_failed"}   # 抓不到 → 后面回落搜索
    texts = [home]
    try:
        soup = BeautifulSoup(home, "html.parser")
        links = []
        for a in soup.find_all("a", href=True):
            low = (a["href"] + " " + (a.get_text() or "")).lower()
            full = urljoin(base, a["href"])
            if urlparse(full).netloc == urlparse(base).netloc and any(h in low for h in CONTACT_HINTS):
                if full not in links: links.append(full)
        for link in links[:3]:
            time.sleep(0.6)
            sub = _fetch(link)
            if sub: texts.append(sub)
    except Exception:
        pass
    big = " ".join(texts).replace("&#64;", "@").replace("&#46;", ".")
    got = extract_all(big, want=state["want_fields"], site_domain=urlparse(base).netloc)
    fields = dict(state["fields"]); sources = dict(state["sources"])
    for k, v in got.items():
        if v:
            fields[k] = v; sources[k] = base
    return {"fields": fields, "sources": sources, "status": "website_done"}


def _missing(state) -> list:
    """still-missing 字段 (排除industry_text, 它靠映射)"""
    return [f for f in state["want_fields"]
            if f not in ("industry", "industry_text")
            and not state["fields"].get(f)]


def node_websearch(state: LeadState) -> dict:
    """无官网 或 官网缺字段: 搜索补全。SerpApi优先, 否则interrupt让AI补。"""
    company = state["company"]
    country_full = COUNTRY_FULL.get(state["country"].upper(), state["country"])
    query = f"{company} {country_full} email contact"

    text = None
    key = os.environ.get("SERPAPI_KEY", "")
    if key:
        # --- 模式A: SerpApi ---
        try:
            import serpapi
            client = serpapi.Client(api_key=key)
            res = dict(client.search({"q": query, "gl": state["country"].lower(),
                                      "hl": "en", "google_domain": "google.com"}))
            chunks = []
            for r in res.get("organic_results", []) or []:
                chunks += [str(r.get("title", "")), str(r.get("snippet", ""))]
            ai = res.get("ai_overview")
            if ai: chunks.append(json.dumps(ai, ensure_ascii=False))
            text = " ".join(chunks)
        except Exception as e:
            text = None
    if text is None:
        # --- 模式B: interrupt 让 AI 用 web_search 补 ---
        if state.get("search_text"):
            text = state["search_text"]          # AI 已回填
        else:
            from langgraph.types import interrupt
            text = interrupt({"action": "web_search", "query": query,
                              "company": company, "country": state["country"]})

    fields = dict(state["fields"]); sources = dict(state["sources"])
    got = extract_all(text or "", want=state["want_fields"])
    for k, v in got.items():
        if v and not fields.get(k):
            fields[k] = v; sources[k] = "websearch"
    # 行业文本兜底: 取 snippet 一段做 industry_text
    if not fields.get("industry_text") and text:
        fields["industry_text"] = (text[:160]).strip()
    return {"fields": fields, "sources": sources, "status": "search_done"}


def node_map_industry(state: LeadState) -> dict:
    """行业映射: 文本/code → CRM 44行业。仅当要补industry时执行。"""
    if "industry" not in state["want_fields"]:
        return {"status": "done"}
    fields = dict(state["fields"])
    ind_text = fields.get("industry_text") or fields.get("industry") or state["company"]
    name, code, conf = map_by_text(ind_text)
    fields["crm_industry"] = name or ""
    fields["crm_code"] = code or ""
    fields["map_confidence"] = conf
    return {"fields": fields, "status": "done"}


# ============================================================
# 3. 条件边 (Conditional Edges) —— 状态机的分支逻辑
# ============================================================
def route_after_check(state: LeadState) -> str:
    return "scrape_website" if state["status"] == "has_website" else "websearch"


def route_after_scrape(state: LeadState) -> str:
    # 官网抓失败 或 还有缺字段 → 搜索兜底; 否则直接映射
    if state["status"] == "website_failed" or _missing(state):
        return "websearch"
    return "map_industry"


# ============================================================
# 4. 组装 Graph
# ============================================================
def build_graph():
    g = StateGraph(LeadState)
    g.add_node("check_website", node_check_website)
    g.add_node("scrape_website", node_scrape_website)
    g.add_node("websearch", node_websearch)
    g.add_node("map_industry", node_map_industry)

    g.add_edge(START, "check_website")
    g.add_conditional_edges("check_website", route_after_check,
                            {"scrape_website": "scrape_website", "websearch": "websearch"})
    g.add_conditional_edges("scrape_website", route_after_scrape,
                            {"websearch": "websearch", "map_industry": "map_industry"})
    g.add_edge("websearch", "map_industry")
    g.add_edge("map_industry", END)
    return g.compile()


# ============================================================
# 5. 批量驱动
# ============================================================
def run_batch(src, country, fields, website_col, company_col, limit):
    app = build_graph()
    df = pd.read_excel(src, dtype=str).fillna("")
    if limit: df = df.head(limit)
    out_rows = []
    for i, (_, row) in enumerate(df.iterrows(), 1):
        init: LeadState = {
            "company": str(row.get(company_col, "")).strip(),
            "country": country,
            "want_fields": fields,
            "website": str(row.get(website_col, "")).strip() if website_col in df.columns else "",
            "fields": {}, "sources": {}, "status": "", "search_text": None,
        }
        if not init["company"]:
            continue
        try:
            final = app.invoke(init)   # SerpApi模式下一次跑完; interrupt模式见下方说明
            rec = {"company": init["company"], **final["fields"]}
            for k, v in final["sources"].items():
                rec[f"{k}_source"] = v
            rec["status"] = final["status"]
        except Exception as e:
            rec = {"company": init["company"], "status": f"err:{type(e).__name__}:{e}"}
        out_rows.append(rec)
        print(f"[{i}/{len(df)}] {init['company'][:32]:32} | {rec.get('status','')}", flush=True)

    out = Path(src).with_name(Path(src).stem + "_enriched_lg.xlsx")
    pd.DataFrame(out_rows).to_excel(out, index=False)
    print(f"\nOK -> {out.name} | {len(out_rows)} 行")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--src", required=True)
    ap.add_argument("--country", required=True, help="HK/VN/PK/IN...")
    ap.add_argument("--fields", default="email,website,phone,address,industry")
    ap.add_argument("--website-col", default="website")
    ap.add_argument("--company-col", default="company")
    ap.add_argument("--limit", type=int, default=0)
    a = ap.parse_args()
    run_batch(a.src, a.country, [f.strip() for f in a.fields.split(",")],
              a.website_col, a.company_col, a.limit)
