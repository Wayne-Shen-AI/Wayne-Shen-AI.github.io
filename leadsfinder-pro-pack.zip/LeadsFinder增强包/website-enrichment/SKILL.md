---
name: website-enrichment
description: >
  「官网优先」的公司线索字段补全 skill。有官网就先抓官网(contact/about页)拿字段
  (email/phone/address/contact/industry等),官网拿不到或无官网的字段,
  自动回落到 websearch-enrichment skill 用搜索兜底。
  字段不固定,按用户本次需求补;每次带【国家】(用户告知)。
  触发: "有官网的优先抓官网补全"、"先去官网找邮箱,没有再搜"、
  "这批公司有网址,去官网补字段"、"官网+搜索兜底补全leads"。
---

# website-enrichment

## 定位 (一句话)

**输入**: 公司列表(部分/全部带官网) + 国家 + 要补字段
**策略**: 官网优先 → 官网缺的字段回落 websearch-enrichment
**输出**: 补全记录(每字段带 source_url:官网URL 或 搜索来源)

> 这是上层「官网优先」补全。纯搜索补全用底层 `websearch-enrichment`(可单独调)。
> 行业标准化映射用 `industry-mapping`(被本 skill 在需要行业 code 时调用)。

---

## When to use

- 公司列表里**有官网字段**(或能先搜到官网),希望优先从官网拿一手信息(更准)。
- 要补的字段官网通常有(email/phone/address/contact)。
- 与 websearch-enrichment 的区别:
  - website-enrichment = **先开官网**抓,缺了再搜 → 更准,稍慢
  - websearch-enrichment = **不开官网**只搜 → 更快,可能混入同名公司

---

## 三层补全策略 (核心)

```
对每家公司, 对每个要补的字段:
┌─ Layer 1: 有官网? → 抓官网首页 + contact/about 子页, 通用解析提字段
│            (脚本 fetch HTML;  JS渲染页抓不到 → 降级 Layer 2)
├─ Layer 2: 官网抓取失败/无官网 → browser 子代理真实渲染访问官网(可选,准但慢)
└─ Layer 3: 仍缺 → 回落 websearch-enrichment skill 用 web_search 兜底
            (query 带国家)
```

**降级兜底**是用户确认的方案: 默认脚本抓HTML(快),抓不到再 browser,再不行回落搜索。

---

## 关键约定 (与 websearch-enrichment 一致)

1. **字段宽泛可扩展**: 默认 email/website/phone/address/contact_person/industry_text,
   以用户本次指定为准。
2. **每次带国家**: 用户告知国家(HK/VN/PK/IN...);回落搜索时 query 必须带国家英文名。
3. **一次抓取榨干**: 打开一个官网页就把所有能提的字段一次提全(开销同补一个字段)。
4. **来源可溯**: 每字段记 source_url(官网URL 或 搜索来源)。
5. **通用解析,零硬编码**: 不针对单个官网写 HTML 结构,用通用规则(见下)。

---

## 通用官网解析 (零硬编码,任意站通用)

复用 websearch-enrichment 的 `resources/extractors.py`,加官网专属逻辑:

```python
# 1. 多变体尝试 host (实测: amoy.com 带不带www内容不同)
candidates = [https://www.X, https://X, http://www.X, http://X]
# 2. SSL 缺陷站用 verify=False (实测 BKMEA 证书有问题)
# 3. 找 contact/about 子页: 扫 <a>, 匹配 contact/about/聯絡/关于 (多语言)
# 4. 首页 + contact子页都抓并合并 (邮箱常在contact页, 首页反而没有)
# 5. 解混淆: info[at]xxx[dot]com / HTML实体 &#64; 
# 6. 邮箱去 @www. 污染
```

(以上逻辑已在 references/scrape_website.py 模板里实现,直接复用)

---

## Workflow

### Step 1: 输入
公司列表 + 国家 + 字段。标出哪些公司已有官网(website列)。

### Step 2: 有官网的 → 抓官网 (Layer 1)
跑 references/scrape_website.py:
- 对每个官网抓首页+contact子页, extract_all() 提全部要的字段
- 抓到的字段 source_url = 对应官网页URL

### Step 3: 官网失败的 → browser 兜底 (Layer 2, 可选)
status=unreachable 且用户要求高准确时,
spawn browser 子代理真实渲染访问官网读字段。
(成本高,默认跳过,除非用户要;一般直接走 Layer 3)

### Step 4: 仍缺字段的 → 回落搜索 (Layer 3)
对"无官网"或"官网没拿到某字段"的公司,
调用 websearch-enrichment skill (web_search,query带国家)补剩余字段。

### Step 5: 行业映射 (若要 industry code)
抓到行业文本后,调用 industry-mapping skill 转 CRM 标准 code。

### Step 6: 合并输出
官网结果 + 搜索兜底结果按公司合并,
每字段保留 source_url。输出 Excel/CSV (utf-8-sig)。

---

## 限流/超时防护 (实战教训, 同 websearch-enrichment)

- 官网抓取: 分离 connect/read 超时(6s/10s),卡死站最多拖16s放弃。
- 回落搜索: **串行**,单子代理批 ≤50 家,遇 HTML 错误等几秒重试。
- 增量保存: 每50家存 partial,中断不丢。

---

## 与其他 skill/资源 的关系

| 依赖 | 用途 |
|------|------|
| websearch-enrichment | Layer 3 搜索兜底(也提供共用的 extractors.py) |
| industry-mapping | 行业文本 → CRM 44行业 code |
| references/scrape_website.py | 本 skill 的官网抓取脚本模板 |

---

## Anti-pattern

1. **不要硬编码官网HTML结构** — 通用解析,换站能跑。
2. **首页抓不到就放弃是错的** — 邮箱常在 contact 子页,必须进子页。
3. **不要为单字段单独开页/单独搜** — 一次打开榨干所有字段。
4. **官网域名 ≠ .hk 才算本国** — 香港公司多用 .com;判本国邮箱看"域名是否=官网域名"。
5. **回落搜索别忘国家** — 否则混入同名外国公司。
6. **browser兜底别全量用** — 太慢;只对"必须高准确且官网JS渲染"的少量公司用。

---

## 已验证

| 数据集 | 国家 | 做法 | 命中率 |
|--------|------|------|--------|
| 3505家香港官网(kompass) | HK | 脚本抓官网contact页 | 抓到约50-65%(unreachable受网关影响) |
| amoy.com / classicfinefoods等 | HK | 多变体+contact子页+解混淆 | 准确提取,正确筛HK邮箱 |
